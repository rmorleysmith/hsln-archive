/-
HSLNHilbertPolya.lean — the honest Hilbert–Pólya wiring, AND the constructive converse.
=======================================================================================

`HSLNRH.HilbertPolya` quietly bundles RH *inside* its hypothesis, which is why
`HSLNRH.riemannHypothesis_of_HilbertPolya` is trivial. This file removes the cheat AND proves the
full equivalence: `HilbertPolyaOperator` is not merely sufficient for RH, it is **logically
equivalent** to it — with the operator explicitly CONSTRUCTED.

  • `symmetric_eigenvalue_real`                  — sorry-free (mathlib): self-adjoint ⇒ real spectrum.
  • `HilbertPolyaOperator`                       — the OPEN existence claim, no RH bundled in.
  • `riemannHypothesis_of_hilbertPolyaOperator`  — sorry-free: HP operator ⇒ RH (the easy half).
  • `Spec` + `exists_selfAdjoint_realising`      — the CONSTRUCTIVE ENGINE: an explicit self-adjoint
       operator realising ANY prescribed real spectrum, on the finite-support carrier `ι →₀ ℂ`
       — the only carrier where an UNBOUNDED diagonal is total (finite support dodges the
       convergence that defeats `ℓ²`). The inner product is built from scratch via
       `InnerProductSpace.ofCore` (mathlib has none for `ι →₀ ℂ`); `Tdiag_symm` is the
       infinite-dimensional avatar of `HSLNTraceFormula.diagReal_isHermitian`.
  • `hilbertPolyaOperator_of_riemannHypothesis`  — sorry-free: RH ⇒ HP operator (heights are real,
       the engine realises them).
  • `riemannHypothesis_iff_hilbertPolyaOperator` — the EQUIVALENCE. "Make this `def` a theorem" =
       "prove RH", exactly — and the operator is concrete the moment the heights are known real.

Sorry-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
-/
import Mathlib
open Module.End Complex
open scoped BigOperators ComplexConjugate

namespace HSLNHilbertPolya

/-- **Spectral reality** (sorry-free, mathlib). A self-adjoint operator's eigenvalues are real. -/
theorem symmetric_eigenvalue_real
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
    {T : E →ₗ[ℂ] E} (hT : T.IsSymmetric) {μ : ℂ} (hμ : HasEigenvalue T μ) :
    μ.im = 0 :=
  Complex.conj_eq_iff_im.mp (hT.conj_eigenvalue_eq_self hμ)

/-- **Honest Hilbert–Pólya** — the OPEN existence claim, with NO RH bundled inside. -/
def HilbertPolyaOperator : Prop :=
  ∃ (E : Type) (_ : NormedAddCommGroup E) (_ : InnerProductSpace ℂ E) (T : E →ₗ[ℂ] E),
    T.IsSymmetric ∧
    ∀ s : ℂ, riemannZeta s = 0 → (¬ ∃ n : ℕ, s = -2 * (n + 1)) → s ≠ 1 →
      ∃ μ : ℂ, HasEigenvalue T μ ∧ s = ((1 / 2 : ℝ) : ℂ) + μ * I

/-- **Hilbert–Pólya ⇒ RH** — sorry-free. Self-adjointness forces real eigenvalues, so
`s = ½ + μ·i` has real part exactly `½`. -/
theorem riemannHypothesis_of_hilbertPolyaOperator
    (h : HilbertPolyaOperator) : RiemannHypothesis := by
  obtain ⟨E, _, _, T, hT, hcorr⟩ := h
  intro s hz htriv hone
  obtain ⟨μ, hμ, hsμ⟩ := hcorr s hz htriv hone
  have him : μ.im = 0 := symmetric_eigenvalue_real hT hμ
  rw [hsμ, Complex.add_re, Complex.ofReal_re, Complex.mul_re, Complex.I_re, Complex.I_im, him]
  norm_num

/-! ### The constructive engine: an inner product space of finite support + a self-adjoint
diagonal operator realising ANY prescribed real spectrum. -/

abbrev Spec (ι : Type) : Type := ι →₀ ℂ

namespace Spec
variable {ι : Type}

/-- the pairing, as a plain function (no `Inner` instance yet) -/
noncomputable def ipair (f g : Spec ι) : ℂ := ∑ i ∈ f.support, conj (f i) * g i

theorem ipair_eq_sum (s : Finset ι) (f g : Spec ι) (hf : f.support ⊆ s) :
    ipair f g = ∑ i ∈ s, conj (f i) * g i := by
  classical
  apply Finset.sum_subset hf
  intro i _ hi
  rw [Finsupp.notMem_support_iff.mp hi, map_zero, zero_mul]

theorem ipair_self_ofReal (f : Spec ι) :
    ipair f f = ((∑ i ∈ f.support, Complex.normSq (f i) : ℝ) : ℂ) := by
  rw [ipair, Complex.ofReal_sum]
  exact Finset.sum_congr rfl (fun i _ => (Complex.normSq_eq_conj_mul_self).symm)

noncomputable instance core : InnerProductSpace.Core ℂ (Spec ι) where
  inner := ipair
  conj_inner_symm f g := by
    classical
    show conj (ipair g f) = ipair f g
    rw [ipair_eq_sum (f.support ∪ g.support) g f Finset.subset_union_right,
        ipair_eq_sum (f.support ∪ g.support) f g Finset.subset_union_left, map_sum]
    exact Finset.sum_congr rfl (fun i _ => by rw [map_mul, Complex.conj_conj, mul_comm])
  re_inner_nonneg f := by
    show 0 ≤ (ipair f f).re
    rw [ipair_self_ofReal, Complex.ofReal_re]
    exact Finset.sum_nonneg (fun i _ => Complex.normSq_nonneg _)
  definite f hf := by
    classical
    rw [ipair_self_ofReal, Complex.ofReal_eq_zero] at hf
    have hz : ∀ i ∈ f.support, Complex.normSq (f i) = 0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => Complex.normSq_nonneg _)).mp hf
    apply Finsupp.ext
    intro i
    simp only [Finsupp.coe_zero, Pi.zero_apply]
    by_cases hi : i ∈ f.support
    · exact Complex.normSq_eq_zero.mp (hz i hi)
    · exact Finsupp.notMem_support_iff.mp hi
  add_left f g h := by
    classical
    show ipair (f + g) h = ipair f h + ipair g h
    have hsf : f.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_left Finset.subset_union_left
    have hsg : g.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_right Finset.subset_union_left
    have hsfg : (f + g).support ⊆ f.support ∪ g.support ∪ h.support := by
      intro i hi
      have hne : (f + g) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.add_apply] at hne
      by_cases h1 : f i = 0
      · have h2 : g i ≠ 0 := fun h2 => hne (by rw [h1, h2, add_zero])
        exact Finset.mem_union_left _ (Finset.mem_union_right _ (Finsupp.mem_support_iff.mpr h2))
      · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr h1))
    rw [ipair_eq_sum (f.support ∪ g.support ∪ h.support) (f+g) h hsfg,
        ipair_eq_sum (f.support ∪ g.support ∪ h.support) f h hsf,
        ipair_eq_sum (f.support ∪ g.support ∪ h.support) g h hsg, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun i _ => by rw [Finsupp.add_apply, map_add, add_mul])
  smul_left f g r := by
    classical
    show ipair (r • f) g = conj r * ipair f g
    have hsrf : (r • f).support ⊆ f.support := by
      intro i hi
      have hne : (r • f) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.smul_apply, smul_eq_mul] at hne
      exact Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne)
    rw [ipair_eq_sum f.support (r • f) g hsrf, ipair, Finset.mul_sum]
    exact Finset.sum_congr rfl (fun i _ => by
      rw [Finsupp.smul_apply, smul_eq_mul, map_mul]; ring)

noncomputable instance instNACG : NormedAddCommGroup (Spec ι) :=
  InnerProductSpace.Core.toNormedAddCommGroup (𝕜 := ℂ) (cd := core)

noncomputable instance instIPS : InnerProductSpace ℂ (Spec ι) := InnerProductSpace.ofCore _

open scoped InnerProductSpace

theorem inner_eq_ipair (f g : Spec ι) : (inner ℂ f g) = ipair f g := rfl

/-- Diagonal multiplication by a real sequence `r` (the possibly-unbounded operator). -/
noncomputable def Tdiag (r : ι → ℝ) : (Spec ι) →ₗ[ℂ] (Spec ι) :=
  Finsupp.linearCombination ℂ (fun i => Finsupp.single i (r i : ℂ))

theorem Tdiag_single (r : ι → ℝ) (i : ι) :
    Tdiag r (Finsupp.single i 1) = (r i : ℂ) • Finsupp.single i 1 := by
  simp [Tdiag, Finsupp.linearCombination_single, Finsupp.smul_single]

theorem Tdiag_apply (r : ι → ℝ) (x : Spec ι) (j : ι) :
    (Tdiag r x) j = (r j : ℂ) * x j := by
  classical
  simp only [Tdiag, Finsupp.linearCombination_apply, Finsupp.sum_apply]
  rw [Finsupp.sum]
  simp only [Finsupp.smul_single, smul_eq_mul, Finsupp.single_apply]
  rw [Finset.sum_ite_eq']
  by_cases hj : j ∈ x.support
  · simp [hj, mul_comm]
  · simp only [hj, if_false]; rw [Finsupp.notMem_support_iff.mp hj]; ring

/-- **The diagonal operator is self-adjoint** — the unbounded-spectrum, infinite-dimensional
avatar of `HSLNTraceFormula.diagReal_isHermitian`. Sorry-free. -/
theorem Tdiag_symm (r : ι → ℝ) : (Tdiag r).IsSymmetric := by
  classical
  intro x y
  have hx : (Tdiag r x).support ⊆ x.support ∪ y.support := by
    intro i hi
    have hne : (Tdiag r x) i ≠ 0 := Finsupp.mem_support_iff.mp hi
    rw [Tdiag_apply] at hne
    exact Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne))
  rw [inner_eq_ipair, inner_eq_ipair,
      ipair_eq_sum (x.support ∪ y.support) _ _ hx,
      ipair_eq_sum (x.support ∪ y.support) _ _ Finset.subset_union_left]
  apply Finset.sum_congr rfl
  intro i _
  rw [Tdiag_apply r x i, Tdiag_apply r y i, map_mul, Complex.conj_ofReal]
  ring

end Spec

/-- **The engine.** ANY prescribed real spectrum `(r i)` is realised by a self-adjoint operator
on a genuine complex inner product space — sorry-free, for an arbitrary (possibly *unbounded*)
real sequence. The real-diagonal-is-Hermitian fact lifted to the infinite carrier the
Riemann-zero spectrum requires (finite support makes the unbounded diagonal total). -/
theorem exists_selfAdjoint_realising {ι : Type} (r : ι → ℝ) :
    ∃ (E : Type) (_ : NormedAddCommGroup E) (_ : InnerProductSpace ℂ E) (T : E →ₗ[ℂ] E),
      T.IsSymmetric ∧ ∀ i, HasEigenvalue T (r i : ℂ) := by
  refine ⟨Spec ι, inferInstance, inferInstance, Spec.Tdiag r, Spec.Tdiag_symm r, ?_⟩
  intro i
  exact hasEigenvalue_of_hasEigenvector
    ⟨mem_eigenspace_iff.mpr (Spec.Tdiag_single r i), Finsupp.single_ne_zero.mpr one_ne_zero⟩
/-! ### The reverse direction: RH constructs the operator -/

/-- **RH builds the Hilbert–Pólya operator** — sorry-free. Under RH every nontrivial zero is
`s = ½ + i·γ` with `γ = s.im` *real*, so the engine's diagonal operator with spectrum `{Im s}`
(`ι = ℂ`, `r = Complex.im`) realises every height as a genuine eigenvalue. The converse of
`riemannHypothesis_of_hilbertPolyaOperator`: the operator *exists exactly when* RH holds — here
explicitly built. -/
theorem hilbertPolyaOperator_of_riemannHypothesis (h : RiemannHypothesis) :
    HilbertPolyaOperator := by
  obtain ⟨E, i1, i2, T, hT, hr⟩ := exists_selfAdjoint_realising (ι := ℂ) Complex.im
  refine ⟨E, i1, i2, T, hT, ?_⟩
  intro s hz htriv hone
  refine ⟨(s.im : ℂ), hr s, ?_⟩
  have hre : s.re = 1 / 2 := h s hz htriv hone
  apply Complex.ext
  · rw [Complex.add_re, Complex.ofReal_re, Complex.mul_re, Complex.I_re, Complex.I_im,
      Complex.ofReal_re, Complex.ofReal_im, hre]; ring
  · rw [Complex.add_im, Complex.ofReal_im, Complex.mul_im, Complex.I_re, Complex.I_im,
      Complex.ofReal_re, Complex.ofReal_im]; ring

/-- **The Hilbert–Pólya operator exists IF AND ONLY IF RH holds** — sorry-free. The `def` is
*logically equivalent* to the Riemann Hypothesis, with the operator explicitly constructed in
the reverse direction. "Make this `def` a theorem" = "prove RH", no slack. -/
theorem riemannHypothesis_iff_hilbertPolyaOperator :
    RiemannHypothesis ↔ HilbertPolyaOperator :=
  ⟨hilbertPolyaOperator_of_riemannHypothesis, riemannHypothesis_of_hilbertPolyaOperator⟩

/-- The single honest gap, now seen as an equivalence. -/
theorem hilbertPolya_is_the_only_gap :
    HilbertPolyaOperator → RiemannHypothesis :=
  riemannHypothesis_of_hilbertPolyaOperator

end HSLNHilbertPolya
