/-
Heterotic Spiking Liquid Network (HSLN) — Lean 4 / mathlib formalisation
=======================================================================

A skeleton formalisation of the architecture described in `system-spec.md`.

Conventions
-----------
* `sorry` marks a statement that is *mathematically established in the
  literature* but is not (yet) wired into mathlib. Each `sorry` is annotated
  with a literature reference so the proof obligation is concrete.
* `[NEW]` marks definitions that this file introduces because mathlib does not
  yet have them. Genus-1 (`UpperHalfPlane`, `ModularForm Γ k`, `qExpansion`,
  `symplecticGroup`, `Matrix.PosDef`, …) is in mathlib; the Siegel
  generalisation `g ≥ 2` is not.
* I have kept the design "wrong-state-impossible-to-represent" where the type
  system allows: e.g. the Siegel half-space is a `Subtype`, not an arbitrary
  symmetric matrix.
-/

import Mathlib.Analysis.Complex.UpperHalfPlane.Basic
import Mathlib.Analysis.Complex.UpperHalfPlane.Manifold
import Mathlib.LinearAlgebra.SymplecticGroup
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Symmetric
import Mathlib.NumberTheory.ModularForms.Basic
import Mathlib.NumberTheory.ModularForms.CongruenceSubgroups
import Mathlib.NumberTheory.ModularForms.QExpansion
import Mathlib.NumberTheory.ModularForms.SlashInvariantForms
import Mathlib.Geometry.Manifold.MFDeriv.Basic
import Mathlib.Geometry.Manifold.IntegralCurve.Basic
import Mathlib.RingTheory.PowerSeries.Basic
import Mathlib.NumberTheory.Divisors

noncomputable section
open Matrix Complex Filter Topology
open scoped UpperHalfPlane MatrixGroups Real

namespace HSLN

/-! ## §1.1 The Siegel upper half-space `ℍ_g`

`ℍ_1` is `UpperHalfPlane` and is in mathlib. For `g ≥ 2` we define it here. -/

/-- `[NEW]` The Siegel upper half-space of degree `g`: complex symmetric `g × g`
matrices whose imaginary part is positive-definite. -/
structure SiegelHalfSpace (g : ℕ) where
  toMat : Matrix (Fin g) (Fin g) ℂ
  isSymm : toMat.IsSymm
  imPosDef : (toMat.map Complex.im).PosDef

namespace SiegelHalfSpace

variable {g : ℕ}

notation "ℍ_[" g "]" => SiegelHalfSpace g

instance : CoeFun (ℍ_[g]) (fun _ => Matrix (Fin g) (Fin g) ℂ) := ⟨toMat⟩

/-- Real part. -/
def re (Z : ℍ_[g]) : Matrix (Fin g) (Fin g) ℝ := Z.toMat.map Complex.re

/-- Imaginary part. -/
def im (Z : ℍ_[g]) : Matrix (Fin g) (Fin g) ℝ := Z.toMat.map Complex.im

lemma im_posDef (Z : ℍ_[g]) : Z.im.PosDef := Z.imPosDef

/-- `ℍ_[1]` is in bijection with `UpperHalfPlane`. -/
def genusOneEquiv : ℍ_[1] ≃ UpperHalfPlane := by
  -- routine but uninteresting: pack/unpack the unique entry.
  sorry

/-- `[NEW]` Real dimension of `ℍ_[g]` is `g(g+1)`. -/
lemma real_dim : True := trivial  -- placeholder; the genuine statement requires
                                   -- a `ChartedSpace` instance below.

/-! ### Smooth manifold structure

`ℍ_[g]` is an open subset of `Sym_g(ℂ) ≅ ℂ^{g(g+1)/2}`, hence inherits a
complex manifold structure. mathlib does not currently give this as a one-liner
for `g ≥ 2`; the construction is standard. -/

/-- `[NEW]` Underlying topology, inherited from the ambient matrix space via
the open embedding `toMat`. -/
instance instTopologicalSpace : TopologicalSpace (ℍ_[g]) :=
  TopologicalSpace.induced toMat inferInstance

/-- `[NEW]` Charted-space / smooth-manifold instance. -/
instance instChartedSpace :
    ChartedSpace (Matrix (Fin g) (Fin g) ℂ) (ℍ_[g]) := by
  -- inherit from the open embedding `toMat`; standard.
  sorry

/-! ### Symplectic action

`Sp(2g, ℝ)` acts on `ℍ_[g]` by `Z ↦ (AZ + B)(CZ + D)⁻¹`. mathlib has
`symplecticGroup (Fin g) ℝ` but not its action on the Siegel space. -/

/-- The `2g × 2g` symplectic group, written as `Sp(2g, R)`. -/
abbrev Sp2 (R : Type*) [CommRing R] := symplecticGroup (Fin g) R

/-- `[NEW]` Block decomposition `(A B; C D)` of a symplectic matrix. -/
def blocks (γ : Sp2 (g := g) ℝ) :
    Matrix (Fin g) (Fin g) ℝ × Matrix (Fin g) (Fin g) ℝ ×
    Matrix (Fin g) (Fin g) ℝ × Matrix (Fin g) (Fin g) ℝ := by
  -- pick out the four `g × g` blocks of the underlying `(Fin g ⊕ Fin g)` matrix.
  sorry

/-- `[NEW]` Action `γ • Z = (AZ+B)(CZ+D)⁻¹`. Well-definedness — invertibility
of `CZ+D` for `Z ∈ ℍ_[g]` and `γ ∈ Sp(2g,ℝ)` — is classical
(Klingen, *Introductory Lectures on Siegel Modular Forms*, Lemma I.1). -/
instance : SMul (Sp2 (g := g) ℝ) (ℍ_[g]) where
  smul γ Z := by
    -- (A Z + B) * (C Z + D)⁻¹, symmetry & positivity of imaginary part proved
    -- in Klingen Lemma I.1.
    sorry

/-- `[NEW]` Group action axioms — Klingen, op. cit. -/
instance : MulAction (Sp2 (g := g) ℝ) (ℍ_[g]) := by sorry

/-- `[NEW]` Factor of automorphy `j(γ, Z) := det(CZ + D)`. -/
def jFactor (γ : Sp2 (g := g) ℝ) (Z : ℍ_[g]) : ℂ := by sorry

end SiegelHalfSpace

/-! ## §1.2 Siegel modular forms and Sturm bound -/

/-- `[NEW]` A principal congruence subgroup `Γ_g(N) ≤ Sp(2g,ℤ)`.
For `g = 1` this is mathlib's `Subgroup.Gamma N` (under the canonical embedding
`SL(2,ℤ) ↪ Sp(2,ℤ)`). -/
def SiegelGamma (g N : ℕ) : Subgroup (SiegelHalfSpace.Sp2 (g := g) ℤ) := by sorry

/-- `[NEW]` Siegel modular forms of degree `g`, level `N`, weight `k`.

A holomorphic `F : ℍ_[g] → ℂ` satisfying
`F(γ • Z) = j(γ, Z)^k · F(Z)` for all `γ ∈ Γ_g(N)`, plus the Koecher
boundedness condition (automatic for `g ≥ 2`, hence absorbed here). -/
structure SiegelModularForm (g : ℕ) (N : ℕ) (k : ℤ) where
  toFun : SiegelHalfSpace g → ℂ
  holomorphic : True  -- TODO: replace with `MDifferentiable` once a sufficiently
                      -- rich complex-manifold API is in mathlib.
  slash :
    ∀ (γ : SiegelHalfSpace.Sp2 (g := g) ℤ) (_ : γ ∈ SiegelGamma g N)
      (Z : SiegelHalfSpace g),
        toFun (by
          -- cast `γ` to `Sp(2g,ℝ)` and act on `Z`. Skipped: routine.
          sorry : SiegelHalfSpace g) =
          (SiegelHalfSpace.jFactor
            (by sorry : SiegelHalfSpace.Sp2 (g := g) ℝ) Z) ^ k * toFun Z

notation "M_[" g "," N "," k "]" => SiegelModularForm g N k

/-- For `g = 1` this collapses (under the canonical embedding
`SL(2,ℤ) ↪ GL₂(ℝ)`) to mathlib's `ModularForm`. -/
def genusOneToModularForm
    (Γ : Subgroup (GL (Fin 2) ℝ)) (F : M_[1, N, k]) : ModularForm Γ k := by
  -- routine repackaging through `SiegelHalfSpace.genusOneEquiv`; needs `Γ`
  -- to contain (the image of) `CongruenceSubgroup.Gamma N`.
  sorry

/-! ### Fourier expansion

Every `F ∈ M_[g, N, k]` admits an absolutely convergent expansion
`F(Z) = Σ_{T ≥ 0, half-integral, symmetric} a_T · exp(2πi · tr(T Z))`,
indexed by `T ∈ HalfIntPosSemiSymm g`. -/

/-- `[NEW]` Half-integral positive-semidefinite symmetric `g × g` matrices. -/
structure HalfIntPosSemiSymm (g : ℕ) where
  toMat : Matrix (Fin g) (Fin g) ℚ
  twoToMat_integer : ∀ i j, (2 * toMat i j).den = 1
  diag_integer : ∀ i, (toMat i i).den = 1
  isSymm : toMat.IsSymm
  posSemidef : (toMat.map (Rat.cast : ℚ → ℝ)).PosSemidef

/-- `[NEW]` The Fourier coefficient `a_T(F)`. Existence and uniqueness follow
from the periodicity `F(Z + S) = F(Z)` for `S` half-integral symmetric; see
Klingen §II.4 or Andrianov, *Quadratic Forms and Hecke Operators*, §3.1. -/
def fourierCoeff (F : M_[g, N, k]) (T : HalfIntPosSemiSymm g) : ℂ := by sorry

/-! ### Sturm bound

A Siegel modular form `F ∈ M_[g, N, k]` is uniquely determined by `a_T(F)`
for `T` ranging over the *Sturm set*: those `T` with `tr(T) ≤ B(g, k, N)`
for an effective bound `B`. -/

/-- `[NEW]` Effective Sturm bound for `M_[g, N, k]`. Existence proved by Choi,
Choie & Kikuta, "Sturm-type theorem for Siegel modular forms",
*Compositio Math.* **147** (2011), 1163–1170. -/
def sturmBound (g N : ℕ) (k : ℤ) : ℝ := by sorry

/-- The Sturm-indexing set. -/
def SturmSet (g N : ℕ) (k : ℤ) : Set (HalfIntPosSemiSymm g) :=
  { T | (T.toMat.trace : ℝ) ≤ sturmBound g N k }

/-- `[NEW]` Sturm's theorem for Siegel forms — Choi–Choie–Kikuta op. cit. -/
theorem sturm_uniqueness
    (F₁ F₂ : M_[g, N, k])
    (h : ∀ T ∈ SturmSet g N k, fourierCoeff F₁ T = fourierCoeff F₂ T) :
    F₁ = F₂ := by sorry

/-- `[NEW]` The Sturm set is finite. (Combinatorial; `T` ranges over a bounded
lattice in `Sym_g(ℝ)`.) -/
instance instFintypeSturm : Fintype (SturmSet g N k) := by sorry

/-- Half-integral PSD symmetric matrices are countable but not finite; for the
convolution sum below we restrict to the Sturm set, which *is* finite. -/
instance instFintypeHalfIntInSturm :
    Fintype { p : HalfIntPosSemiSymm g × HalfIntPosSemiSymm g
              // p.1 ∈ SturmSet g N k ∧ p.2 ∈ SturmSet g N k } := by sorry

/-! ## §1.3 Hecke operators and eigenforms

Mathlib does not yet have Siegel-Hecke operators. For `g = 1` the structure
exists in spirit through `ModularForm.mul` and Eisenstein series; for `g ≥ 2`
we declare the interface. -/

/-- `[NEW]` The Hecke operator `T_p` on `M_[g, N, k]`. Andrianov,
*Quadratic Forms and Hecke Operators*, Ch. 3.

We use a plain `Function` rather than `→ₗ[ℂ]` because endowing
`SiegelModularForm` with the requisite `AddCommGroup`/`Module ℂ` structure is
another piece of mathlib-not-yet-there machinery. -/
def heckeOp (p : ℕ) (_hp : Nat.Prime p) :
    M_[g, N, k] → M_[g, N, k] := by sorry

/-- Pointwise scalar action `μ ⊙ F`. Defined here pending a proper
`Module ℂ M_[g,N,k]` instance. -/
def smulMF (μ : ℂ) (F : M_[g, N, k]) : M_[g, N, k] := by sorry

/-- `F` is a Hecke eigenform iff every `T_p` acts on `F` by a scalar. -/
def IsHeckeEigenform (F : M_[g, N, k]) : Prop :=
  ∀ p, ∀ hp : Nat.Prime p,
    ∃ μ : ℂ, heckeOp (g := g) (N := N) (k := k) p hp F = smulMF μ F

/-- `[NEW]` Andrianov–Hecke recurrence: for a Hecke eigenform, every Fourier
coefficient `a_T` is determined by the prime-indexed coefficients
`{a_p : p prime}` via the local Euler factors. Andrianov, op. cit., Thm 3.3.16. -/
theorem fourier_determined_by_primes
    (F₁ F₂ : M_[g, N, k])
    (h₁ : IsHeckeEigenform F₁) (h₂ : IsHeckeEigenform F₂)
    (hprimes : ∀ p (_hp : Nat.Prime p),
        let T_p : HalfIntPosSemiSymm g := by sorry
        fourierCoeff F₁ T_p = fourierCoeff F₂ T_p) :
    F₁ = F₂ := by sorry

/-! ## §2 The HSLN architecture -/

/-- The state space of an `HSLN` of genus `g`. -/
abbrev State (g : ℕ) := SiegelHalfSpace g

/-- The DNA — finite vector of Fourier coefficients on the Sturm set. -/
abbrev DNA (g N : ℕ) (k : ℤ) := SturmSet g N k → ℂ

/-- `[NEW]` Assemble a (truncated) modular form from a DNA vector. Existence
within the space `M_[g,N,k]` is **not** automatic for arbitrary `θ`; the
truncated sum `Σ a_T e^{2πi tr(T Z)}` is a holomorphic function on `ℍ_[g]`,
but it is Γ-invariant only for `θ` in the image of the coefficient map. -/
def truncatedForm (θ : DNA g N k) : SiegelHalfSpace g → ℂ := fun Z =>
  ∑ T : SturmSet g N k,
    θ T * Complex.exp
      (2 * Real.pi * Complex.I *
        ((T.val.toMat.map (Rat.cast : ℚ → ℂ)) * Z.toMat).trace)

/-- `θ` is *admissible* iff its truncated form genuinely extends to a Siegel
modular form. -/
def Admissible (θ : DNA g N k) : Prop :=
  ∃ F : M_[g, N, k], ∀ Z : SiegelHalfSpace g, F.toFun Z = truncatedForm θ Z

/-! ### §2.1 Input encoding `B : ℝ^d → T_Z ℍ_[g]`

In the spec this is *any* fixed linear map into the tangent bundle. We model
it as a continuous linear map on the ambient symmetric-matrix space and let
the manifold's smooth structure do the projection. -/

/-- `[NEW]` Encoder. -/
abbrev Encoder (g d : ℕ) := (Fin d → ℝ) →L[ℝ] Matrix (Fin g) (Fin g) ℂ

/-! ### §2.2 Neurons = zeros of `F` -/

/-- The neuron / attractor set. -/
def neurons (F : M_[g, N, k]) : Set (SiegelHalfSpace g) := { Z | F.toFun Z = 0 }

/-- `[NEW]` Minimum-modulus principle on `ℍ_[g]`: if `F` is holomorphic and
nonzero on an open set `U`, then `|F|` attains no local minimum on `U`.

This is the *minimum*-modulus principle (cf. spec, which says "maximum"; the
spec's intent is the standard consequence below).

Mathlib has the genus-1 / planar case; the Siegel case follows because `ℍ_[g]`
is locally biholomorphic to `ℂ^{g(g+1)/2}`. -/
theorem no_local_min_off_zeros
    (F : M_[g, N, k]) (Z₀ : SiegelHalfSpace g) (hF : F.toFun Z₀ ≠ 0) :
    ¬ IsLocalMin (fun Z => ‖F.toFun Z‖) Z₀ := by sorry

/-! ### §2.3 Forward dynamics: gradient flow

We need the *Riemannian* gradient on `ℍ_[g]` w.r.t. its Sp(2g,ℝ)-invariant
metric (the Siegel metric). Mathlib has `mfderiv` and an embryonic
`Geometry.Manifold.Riemannian.*`; the full Siegel metric is not yet there. -/

/-- `[NEW]` The Sp-invariant Siegel Riemannian metric on `ℍ_[g]`. -/
def siegelMetric : True := trivial -- placeholder for a `RiemannianMetric` instance.

/-- `[NEW]` Riemannian gradient of a smooth real function on `ℍ_[g]`.
Reduces to the Euclidean gradient pulled back by the inverse metric tensor. -/
def riemGrad
    (φ : SiegelHalfSpace g → ℝ) (Z : SiegelHalfSpace g) :
    Matrix (Fin g) (Fin g) ℂ := by sorry

/-- The forward dynamics as a relation between a trajectory `Z(·)`, a control
input `u(·)`, the chosen DNA `θ`, and an encoder `B`. -/
def IsForwardTrajectory
    {g d : ℕ} {N : ℕ} {k : ℤ}
    (α : ℝ) (F : M_[g, N, k]) (B : Encoder g d)
    (u : ℝ → Fin d → ℝ) (Z : ℝ → SiegelHalfSpace g) : Prop :=
  ∀ t, ∃ Ż : Matrix (Fin g) (Fin g) ℂ,
        -- formally: `mfderiv … Z t` reads off the tangent vector.
        Ż = -α • riemGrad (fun W => ‖F.toFun W‖ ^ 2) (Z t) + B (u t)

/-! ### §2.4 Spike emission -/

/-- The neuron-proximity spike. -/
def spike (F : M_[g, N, k]) (ε : ℝ) (Z : SiegelHalfSpace g) : Bool :=
  decide (ε * ‖F.toFun Z‖ < 1)

/-! ## §3 Learning rule -/

/-- The learnable "prime-indexed" coefficients. -/
def PrimeDNA (_g _N : ℕ) (_k : ℤ) :=
  (p : ℕ) → Nat.Prime p →
    -- one coefficient per prime, indexed by the canonical `T_p`-element.
    ℂ

/-- `[NEW]` Andrianov reconstruction: extend the prime-indexed coefficients
into a full DNA satisfying the Hecke recurrence. -/
def reconstructDNA (θ₀ : PrimeDNA g N k) : DNA g N k := by sorry

/-- Reconstruction produces an admissible (Hecke-eigenform) DNA. -/
theorem reconstructDNA_admissible (θ₀ : PrimeDNA g N k) :
    Admissible (reconstructDNA θ₀) := by sorry

/-- `[NEW]` Reconstruction lands inside the Hecke-eigenform locus. -/
theorem reconstructDNA_isEigenform
    (θ₀ : PrimeDNA g N k)
    (F : M_[g, N, k])
    (hF : ∀ Z, F.toFun Z = truncatedForm (reconstructDNA θ₀) Z) :
    IsHeckeEigenform F := by sorry

/-! ## §4 Exact algebraic composition (model merging)

`(F₁ · F₂)(Z) = F₁(Z) · F₂(Z)` and the zero sets union exactly. The
ring/multiplication structure on `ModularForm Γ k` for `g = 1` is in mathlib;
for `g ≥ 2` we declare the analogue. -/

/-- `[NEW]` Pointwise product on Siegel modular forms. -/
def mul {g N : ℕ} {k₁ k₂ : ℤ}
    (F₁ : M_[g, N, k₁]) (F₂ : M_[g, N, k₂]) : M_[g, N, k₁ + k₂] := by sorry

scoped infixl:70 " ⋆ " => HSLN.mul

/-- Fourier coefficients of a product = Cauchy convolution of coefficients.

Direct from
`exp(2πi tr(T₁ Z)) · exp(2πi tr(T₂ Z)) = exp(2πi tr((T₁+T₂) Z))`. -/
theorem fourierCoeff_mul
    {g N : ℕ} {k₁ k₂ : ℤ}
    (F₁ : M_[g, N, k₁]) (F₂ : M_[g, N, k₂]) (T : HalfIntPosSemiSymm g) :
    fourierCoeff (F₁ ⋆ F₂) T =
      -- Cauchy convolution over the decomposition antidiagonal
      --   { (T₁, T₂) : T₁ + T₂ = T }.
      -- The sum is finite because each `T_i ≤ T` lies in a bounded sub-lattice.
      ∑' p : { p : HalfIntPosSemiSymm g × HalfIntPosSemiSymm g //
                ∀ i j, p.1.toMat i j + p.2.toMat i j = T.toMat i j },
        fourierCoeff F₁ p.val.1 * fourierCoeff F₂ p.val.2 := by sorry

/-- **Composition Theorem (Zero-Set Union).**

The single non-trivial *new* theorem of the architecture: the attractors of
the merged model are exactly the union of the parents'.

This is a direct consequence of `ℂ` being an integral domain. -/
theorem neurons_mul
    {g N : ℕ} {k₁ k₂ : ℤ}
    (F₁ : M_[g, N, k₁]) (F₂ : M_[g, N, k₂]) :
    neurons (F₁ ⋆ F₂) = neurons F₁ ∪ neurons F₂ := by
  ext Z
  -- Once `mul` is defined so that `(F₁ ⋆ F₂).toFun Z = F₁.toFun Z * F₂.toFun Z`
  -- (this is the *defining property* of pointwise multiplication and will hold
  -- in any reasonable implementation of `mul` above), the proof is:
  --   `mul_eq_zero` in `ℂ`.
  -- We discharge it modulo that property.
  show (F₁ ⋆ F₂).toFun Z = 0 ↔ F₁.toFun Z = 0 ∨ F₂.toFun Z = 0
  have hmul : (F₁ ⋆ F₂).toFun Z = F₁.toFun Z * F₂.toFun Z := by sorry
  rw [hmul, mul_eq_zero]

/-! ## §5 Minimal proof-of-concept blueprint

Topological constants:
* genus `g = 2`
* level `N = 11`
* weight `k = 4`

These give a non-trivial cusp-form space of degree 2 (the first non-zero
cusp-form weight at level 11 for `Sp(4,ℤ)`); see van der Geer,
*Siegel Modular Forms and their Applications* (2008), §16, Table 9. -/

abbrev PoCGenus  : ℕ := 2
abbrev PoCLevel  : ℕ := 11
abbrev PoCWeight : ℤ := 4

/-- A concrete proof-of-concept network. -/
structure HSLN_PoC where
  α       : ℝ
  α_pos   : 0 < α
  θ       : DNA PoCGenus PoCLevel PoCWeight
  θ_adm   : Admissible θ
  encoder : Encoder PoCGenus 2          -- temporal-XOR has `d = 2`
  ε       : ℝ
  ε_pos   : 0 < ε

/-! ## §6 Eta-quotient DNA and the composition monoid

A genus-1 sub-family of the DNA that makes §4 composition *linear* and keeps it
provably inside the space of modular forms.

An eta quotient on `Γ₀(N)` is `f_r(τ) = ∏_{d ∣ N} η(d τ)^{r_d}`, encoded by the
integer exponent vector `r : ℕ → ℤ` (only the values on `d ∣ N` are used). Three
facts make this the right "composable basis":

* **multiplication is addition of exponent vectors** — `f_r · f_s = f_{r+s}`
  (because `η(dτ)^{r_d} η(dτ)^{s_d} = η(dτ)^{r_d+s_d}`), and the weight
  `k = ½ ∑_d r_d` adds linearly;
* **modularity is a linear constraint** — Newman's two congruences
  (`24 ∣ ∑ d r_d`, `24 ∣ ∑ (N/d) r_d`) and Ligozat's cusp-order inequalities are
  linear in `r`;
* hence **the admissible vectors form an additive sub-monoid**: composing two
  valid networks yields a valid network, *by construction*.

Numerically corroborated in `viz/eta_compose.py` (figure 21). The analytic facts
(`η` modular of weight ½; Newman/Ligozat criteria) are `sorry`-ed with references;
the closure algebra below is proved outright. -/

namespace EtaQuotient

/-- Integer exponent vector of an eta quotient. Only the values on `d ∣ N` matter. -/
abbrev Exp := ℕ → ℤ

variable {N : ℕ}

/-- First Newman sum `∑_{d∣N} d · r_d`. -/
def newmanA (N : ℕ) (r : Exp) : ℤ := ∑ d ∈ N.divisors, (d : ℤ) * r d

/-- Second Newman sum `∑_{d∣N} (N/d) · r_d`. -/
def newmanB (N : ℕ) (r : Exp) : ℤ := ∑ d ∈ N.divisors, ((N / d : ℕ) : ℤ) * r d

/-- Ligozat order of vanishing at the cusp indexed by `c ∣ N`
(Ligozat, *Courbes modulaires de genre 1*, 1975; see also Rouse–Webb,
arXiv:1311.1460 §2). Linear in `r`. -/
def ord (N c : ℕ) (r : Exp) : ℚ :=
  ((N : ℚ) / 24) * ∑ d ∈ N.divisors,
    ((Nat.gcd c d : ℚ) ^ 2 / (Nat.gcd c (N / c) * c * d : ℚ)) * (r d : ℚ)

/-- Weight `k = ½ ∑_d r_d`. -/
def weight (N : ℕ) (r : Exp) : ℚ := (1 / 2 : ℚ) * ∑ d ∈ N.divisors, (r d : ℚ)

/-! ### The three "additive" lemmas — proved, no `sorry`. -/

@[simp] lemma newmanA_add (r s : Exp) : newmanA N (r + s) = newmanA N r + newmanA N s := by
  simp only [newmanA, Pi.add_apply, mul_add, Finset.sum_add_distrib]

@[simp] lemma newmanB_add (r s : Exp) : newmanB N (r + s) = newmanB N r + newmanB N s := by
  simp only [newmanB, Pi.add_apply, mul_add, Finset.sum_add_distrib]

lemma ord_add (c : ℕ) (r s : Exp) : ord N c (r + s) = ord N c r + ord N c s := by
  simp only [ord, Pi.add_apply, Int.cast_add, mul_add, Finset.sum_add_distrib, Finset.mul_sum]

theorem weight_add (r s : Exp) : weight N (r + s) = weight N r + weight N s := by
  simp only [weight, Pi.add_apply, Int.cast_add, Finset.sum_add_distrib]
  ring

@[simp] lemma newmanA_zero : newmanA N 0 = 0 := by simp [newmanA]
@[simp] lemma newmanB_zero : newmanB N 0 = 0 := by simp [newmanB]

/-! ### Admissibility and the composition monoid. -/

/-- The congruence (Newman) part of admissibility. -/
def IsCong (N : ℕ) (r : Exp) : Prop := (24 : ℤ) ∣ newmanA N r ∧ (24 : ℤ) ∣ newmanB N r

/-- The holomorphy (Ligozat cone) part: every cusp order is `≥ 0`. -/
def IsHolo (N : ℕ) (r : Exp) : Prop := ∀ c ∈ N.divisors, 0 ≤ ord N c r

/-- `r` is admissible iff `f_r` is a holomorphic modular form on `Γ₀(N)`. -/
def Admissible (N : ℕ) (r : Exp) : Prop := IsCong N r ∧ IsHolo N r

theorem admissible_zero : Admissible N 0 := by
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · simp
  · simp
  · intro c _; simp [ord]

theorem admissible_add {r s : Exp} (hr : Admissible N r) (hs : Admissible N s) :
    Admissible N (r + s) := by
  obtain ⟨⟨ha, hb⟩, hr'⟩ := hr
  obtain ⟨⟨ha', hb'⟩, hs'⟩ := hs
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · rw [newmanA_add]; exact dvd_add ha ha'
  · rw [newmanB_add]; exact dvd_add hb hb'
  · intro c hc; rw [ord_add]; exact add_nonneg (hr' c hc) (hs' c hc)

/-- **Composability guarantee.** The admissible eta-quotient exponent vectors form
an additive sub-monoid of `ℕ → ℤ`. Equivalently: model-merging by multiplication
(§4) restricted to this family is the monoid operation `r + s`, and it never
leaves the space of holomorphic modular forms. This is the formal core of the
"composition with guarantees" claim. -/
def admissibleMonoid (N : ℕ) : AddSubmonoid Exp where
  carrier := { r | Admissible N r }
  zero_mem' := admissible_zero
  add_mem' := by intro a b ha hb; exact admissible_add ha hb

/-- Weight is the additive monoid hom downstairs: `k(f_r · f_s) = k(f_r) + k(f_s)`. -/
theorem weight_mem_add {r s : Exp}
    (_hr : r ∈ admissibleMonoid N) (_hs : s ∈ admissibleMonoid N) :
    weight N (r + s) = weight N r + weight N s := weight_add r s

/-- `[NEW, analytic — sorry]` The eta quotient as a function on `ℍ`. Realising it
as an element of `ModularForm (Γ₀ N) k` requires `η`'s weight-½ modularity
(not yet in mathlib) and the Newman/Ligozat criteria. -/
def etaForm (N : ℕ) (r : Exp) : UpperHalfPlane → ℂ := by sorry

/-- `[NEW, analytic — sorry]` The linearisation identity: multiplying eta quotients
adds exponent vectors. This is the statement that the §4 product `⋆`, restricted to
this family, *is* vector addition. (Pointwise it is immediate from
`η^{r} · η^{s} = η^{r+s}`; verified numerically to 6e-16 in `eta_compose.py`.) -/
theorem etaForm_mul_eq_add (N : ℕ) (r s : Exp) :
    (fun τ => etaForm N r τ * etaForm N s τ) = etaForm N (r + s) := by sorry

end EtaQuotient

/-! ## §7 Gravity = the off-diagonal coupling preserves the equilibria

Composition by *direct sum* (genus 2, `Z = diag(τ₁,τ₂)` plus off-diagonal `z`) is
robust: dialling the off-diagonal coupling bends the gradient-flow trajectory but
cannot move its fixed points. Formally, the Siegel metric contributes a
*positive-definite* mixing matrix `K = Y(·)Y`, and the coupled flow `Ż = -K ∇V`
and the bare flow `Ż = -∇V` have the **same critical points**, because a
positive-definite `K` has trivial kernel. This is the algebraic content of
`viz/coupling_sweep.py` (figure 22, left/middle panels): routing error stays `0`
for every coupling `κ ∈ [0,1)` while the path visibly warps. -/

/-- `[NEW]` For a positive-definite metric `K`, the metric-coupled gradient flow
shares its equilibria with the bare flow: `K v = 0 ↔ v = 0`. Hence turning on the
gravitational off-diagonal coupling warps trajectories but preserves the neurons
(the zeros where `∇V = 0`).

Proof: if `K.mulVec v = 0` then `star v ⬝ᵥ (K *ᵥ v) = 0`, but positive-definiteness
forces it `> 0` for `v ≠ 0`; so `v = 0`. The converse is `Matrix.mulVec_zero`.
Verified sorry-free against mathlib v4.30.0-rc2 (see `HSLNVerify.lean`). -/
theorem gravity_preserves_equilibria {n : ℕ}
    {K : Matrix (Fin n) (Fin n) ℝ} (hK : K.PosDef) (v : Fin n → ℝ) :
    K.mulVec v = 0 ↔ v = 0 := by
  constructor
  · intro h
    by_contra hv
    have hpos := hK.dotProduct_mulVec_pos hv
    rw [h] at hpos
    simp at hpos
  · rintro rfl; simp

end HSLN
