/-
HSLNStructureNotSearch.lean — the graded-ring operations expose structure, never manufacture
a divisor. Machine-checked; the arbiter is the kernel (`#print axioms`), not the prose.

What this file proves, and ONLY this:

  Modelling a trained landscape (DNA coefficient vector) as `ℕ → ℂ`, with the divisor
  landscape `divisorLandscape N` whose spikes are exactly the divisors of `N`:

    • `lie`  (the grading generator θ = q d/dq, `a_k ↦ k·a_k`) is support-NON-INCREASING:
      a θ-spike at `k` forces an original spike at `k`  (`lie_spike_imp`, `lie_support_subset`).
    • `lieIter` (any power θ^m) likewise manufactures no spike (`lieIter_spike_imp`).
    • `cup` (the HSLN composition `F ⋆ G`, zero-sets union) has support = the UNION of the
      parents' supports (`cup_support`).
    • Consequently, building from the divisor landscapes of `A` and `B` by θ and cup, every
      index that lights up is a divisor of `A` or of `B` (`cup_divisor_no_new`,
      `lie_divisor_is_divisor`). The operations COMPOSE and REWEIGHT known divisor structure;
      they never DISCOVER an index that was not already a divisor of an input.

What this file does NOT prove (stated so the prose cannot outrun the kernel):
  • nothing about computational hardness, factoring cost, RSA, or any specific number;
  • nothing about elliptic-curve discrete logs / Bitcoin keys;
  • not that any number is prime or composite.
These are structural support facts about the operators, full stop. The detector linkage
`D(k,N) ≠ 0 ↔ k ∣ N` itself is in `HSLNFactor.lean`.
-/
import Mathlib

namespace HSLNStructure

/-- A landscape / DNA coefficient vector: complex coefficients indexed by `ℕ`. -/
abbrev Landscape := ℕ → ℂ

/-- The divisor-indicator landscape of `N`: `a_k = 1` exactly when `k ≠ 0` and `k ∣ N`,
else `0`. The support side of the roots-of-unity detector (`HSLNFactor`: `D(k,N) ≠ 0 ↔ k ∣ N`). -/
def divisorLandscape (N : ℕ) : Landscape :=
  fun k => if k ≠ 0 ∧ k ∣ N then 1 else 0

/-- A spike of the divisor landscape is exactly a nonzero divisor of `N`. -/
theorem mem_support_divisorLandscape {N k : ℕ} :
    divisorLandscape N k ≠ 0 ↔ (k ≠ 0 ∧ k ∣ N) := by
  unfold divisorLandscape
  split <;> simp_all

/-- The Lie derivative (grading generator) `θ = q d/dq` on a landscape: `a_k ↦ k · a_k`. -/
def lie (f : Landscape) : Landscape := fun k => (k : ℂ) * f k

/-- The iterated Lie derivative `θ^m`: `a_k ↦ k^m · a_k`. -/
def lieIter (m : ℕ) (f : Landscape) : Landscape := fun k => (k : ℂ) ^ m * f k

/-- **θ never manufactures a spike.** If the Lie derivative is nonzero at `k`, the original
landscape was already nonzero at `k`: differentiating along the grading reweights existing
spikes, it cannot create one. -/
theorem lie_spike_imp (f : Landscape) (k : ℕ) (h : lie f k ≠ 0) : f k ≠ 0 := by
  intro hf; exact h (by simp [lie, hf])

/-- No power of θ manufactures a spike. -/
theorem lieIter_spike_imp (m : ℕ) (f : Landscape) (k : ℕ) (h : lieIter m f k ≠ 0) :
    f k ≠ 0 := by
  intro hf; exact h (by simp [lieIter, hf])

/-- `support (θ f) ⊆ support f`: the Lie derivative is support-non-increasing. -/
theorem lie_support_subset (f : Landscape) :
    Function.support (lie f) ⊆ Function.support f :=
  fun _ hk => lie_spike_imp f _ hk

/-- The cup product on landscapes (HSLN composition `F ⋆ G`, zero-sets union):
a spike where either factor spikes. -/
noncomputable def cup (f g : Landscape) : Landscape :=
  fun k => if f k = 0 ∧ g k = 0 then 0 else 1

/-- **cup = union of supports.** The landscape-level form of the proved law
`neurons (F ⋆ G) = neurons F ∪ neurons G`: a spike of the cup product is a spike of a parent. -/
theorem cup_support (f g : Landscape) :
    Function.support (cup f g) = Function.support f ∪ Function.support g := by
  ext k
  simp only [Function.mem_support, Set.mem_union, cup]
  by_cases hf : f k = 0 <;> by_cases hg : g k = 0 <;> simp [hf, hg]

/-- **No new divisor (the headline).** Cup-product the divisor landscapes of `A` and `B`;
every index that lights up is a divisor of `A` or a divisor of `B`. The operation composes
known divisor structure — it never discovers an index that was not already a divisor of an
input. -/
theorem cup_divisor_no_new (A B k : ℕ)
    (h : cup (divisorLandscape A) (divisorLandscape B) k ≠ 0) :
    (k ≠ 0 ∧ k ∣ A) ∨ (k ≠ 0 ∧ k ∣ B) := by
  have hk : k ∈ Function.support (cup (divisorLandscape A) (divisorLandscape B)) := h
  rw [cup_support] at hk
  rcases hk with hA | hB
  · exact Or.inl (mem_support_divisorLandscape.mp hA)
  · exact Or.inr (mem_support_divisorLandscape.mp hB)

/-- A θ-spike of a divisor landscape is itself a divisor: differentiation surfaces only
divisors that were already present. -/
theorem lie_divisor_is_divisor (N k : ℕ) (h : lie (divisorLandscape N) k ≠ 0) :
    k ≠ 0 ∧ k ∣ N :=
  mem_support_divisorLandscape.mp (lie_spike_imp _ k h)

/-- **Summary (structure, not search).** (1) divisor-landscape spikes are exactly the nonzero
divisors; (2) θ is support-non-increasing; (3) cup is support-union; (4) hence any index
surfacing from the divisor landscapes of `A`, `B` under θ and cup was already a divisor of an
input. Proven; the open content — actually FINDING a divisor of a given `N` — requires
evaluating the detector at `k` (testing `k ∣ N`), which this algebra does not shortcut. -/
theorem structure_not_search_summary (A B : ℕ) :
    (∀ k, divisorLandscape A k ≠ 0 ↔ (k ≠ 0 ∧ k ∣ A)) ∧
    (Function.support (lie (divisorLandscape A)) ⊆ Function.support (divisorLandscape A)) ∧
    (Function.support (cup (divisorLandscape A) (divisorLandscape B))
      = Function.support (divisorLandscape A) ∪ Function.support (divisorLandscape B)) :=
  ⟨fun _ => mem_support_divisorLandscape,
   lie_support_subset _,
   cup_support _ _⟩

end HSLNStructure
