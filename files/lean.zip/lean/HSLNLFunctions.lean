/-
L-functions: the family of generators — machine-checked.
========================================================

L-functions are what you get when you replace `ζ`'s coefficients (all ones) by a
**Dirichlet character** `χ` (a completely multiplicative arithmetic function periodic mod N).
Same Euler product, same Lie derivative, same group inverse — only the generator changes:

    L(s, χ)  =  ∑_n  χ(n) / n^s  =  ∏_p  (1 − χ(p) · p^{-s})^{-1}.

The two pillars from `HSLNZeta.lean` carry over verbatim:

  * `L_functional_equation`  : the completed L-function satisfies
        `Λ_χ(1 − s) = N^{s − 1/2} · W(χ) · Λ_{χ⁻¹}(s)`
    for every PRIMITIVE `χ` (mathlib: `completedLFunction_one_sub`). The fixed axis of the
    involution `s ↦ 1 − s` is again `Re s = 1/2`.
  * `half_is_the_symmetry_axis` : `Re s = 1/2` ↔ `Re (1 − s) = 1/2`  (same proof as ζ).

A nontrivial bonus mathlib already gives us — **Dirichlet non-vanishing**:

  * `L_one_ne_zero` : for any nontrivial `χ`, `L(1, χ) ≠ 0`.
    (mathlib: `LFunction_apply_one_ne_zero`.) This is the analytic ingredient behind
    Dirichlet's theorem on primes in arithmetic progressions.

  * `GeneralizedRiemannHypothesis χ : Prop` — every zero in the critical strip lies on the
    critical line. We do not prove it (open).

Honest scope (same as ζ): we have the SYMMETRY side cold; the prime/Euler-product side is
what is load-bearing for GRH and Dirichlet-class results, and is the frontier.
-/
import Mathlib

open Complex DirichletCharacter

namespace HSLNLFunctions

/-- **The functional equation for primitive Dirichlet L-functions.** For any primitive
character `χ` mod `N`,  `Λ_χ(1 − s) = N^{s − 1/2} · W(χ) · Λ_{χ⁻¹}(s)`. This generalises the
zeta functional equation (case `N = 1`, `χ = 1`, `W(χ) = 1`). -/
theorem L_functional_equation {N : ℕ} [NeZero N] {χ : DirichletCharacter ℂ N}
    (hχ : IsPrimitive χ) (s : ℂ) :
    completedLFunction χ (1 - s) =
      (N : ℂ) ^ (s - 1 / 2) * rootNumber χ * completedLFunction χ⁻¹ s :=
  hχ.completedLFunction_one_sub s

/-- The critical line `Re s = 1/2`. -/
def CriticalLine (s : ℂ) : Prop := s.re = 1 / 2

/-- **`Re s = 1/2` is exactly the axis fixed by `s ↦ 1 − s`** — the same 1/2 as for ζ. The
"1/2" of every Dirichlet L-function is *one and the same* axis: the fixed point of the
involution that the functional equation pairs values across. -/
theorem half_is_the_symmetry_axis (s : ℂ) :
    CriticalLine (1 - s) ↔ CriticalLine s := by
  simp only [CriticalLine, Complex.sub_re, Complex.one_re]
  constructor <;> intro h <;> linarith

/-- **Dirichlet non-vanishing at `s = 1`.** For any nontrivial Dirichlet character `χ`,
`L(1, χ) ≠ 0`. This is the analytic ingredient behind Dirichlet's theorem on primes in
arithmetic progressions. (Provided by mathlib; `sorry`-free here.) -/
theorem L_one_ne_zero {N : ℕ} [NeZero N] {χ : DirichletCharacter ℂ N} (hχ : χ ≠ 1) :
    LFunction χ 1 ≠ 0 :=
  LFunction_apply_one_ne_zero hχ

/-- **The Generalized Riemann Hypothesis for `L(s, χ)`** (as a `Prop`): every zero of
`L(·, χ)` in the open critical strip `0 < Re s < 1` lies on the critical line. The case
`N = 1`, `χ = 1` is RH; the family is GRH. We do not prove it (open). -/
def GeneralizedRiemannHypothesis {N : ℕ} [NeZero N] (χ : DirichletCharacter ℂ N) : Prop :=
  ∀ s : ℂ, 0 < s.re → s.re < 1 → LFunction χ s = 0 → CriticalLine s

end HSLNLFunctions
