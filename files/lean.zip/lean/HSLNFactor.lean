/-
The factoring conjecture, machine-checked.
==========================================

[REDACTED NAME]'s conjecture (geometric form): take `N = p·q`, drive a "gravity DNA" to pull a
marker onto `N`; the bent path through the lattice crosses exactly the points that are the
prime factors, and the projection reveals them.

E8 / the Coxeter plane is the *picture*. The *engine* is an arithmetic identity we already
use elsewhere (the roots-of-unity sieve / inverse Euler product, `viz/prime_sieve.py`,
commit "Primes by composition"). This file isolates that engine and proves the conjecture's
honest, precise core SORRY-FREE against mathlib:

  detector k N  :=  Σ_{j<k} ω^j      with ω = exp(2πi·N/k)

  * `detector_eq`         : detector k N = k if k ∣ N, else 0   (geometric sum of roots of unity)
  * `detector_fires`      : detector k N ≠ 0  ↔  k ∣ N          (the "projection lights up" at divisors)
  * `factors_revealed`    : for a *prime* k, the projection of N = p·q fires ⇔ k = p ∨ k = q
  * `primeFactors_mul_prime` / `two_points` : N = p·q has exactly the two prime factors {p,q}
  * `primeFactors_three`  : N = p·q·r reveals {p,q,r}  — the "with 3 it would work" generalisation
  * `semiprime_factors_revealed` : the capstone, all of the above bundled.

Link to the Siegel/modular side: the divisor sum `σ` is the Fourier DNA of the weight-4
Eisenstein series E₄ = Θ(E8) (see `HSLNBridge`/`HSLN`). `fires_iff_mem_divisors` shows the
detector's support is exactly `N.divisors`, i.e. the support of that DNA. So the projection
that "shows the factors" is reading the divisor structure carried by the modular form.

Honest scope: this proves the factors are exactly the points the projection selects; it is
NOT a sub-√N algorithm (the detector scans k up to the least factor). No RSA break is claimed.
-/
import Mathlib

open Complex Real

namespace HSLNFactor

/-! ## §1 The roots-of-unity detector (the "projection") -/

/-- The base `k`-th root carrying the phase of `N`: `ω = exp(2πi·N/k)`. -/
noncomputable def zetaRoot (k N : ℕ) : ℂ :=
  Complex.exp (2 * (π : ℂ) * I * (N : ℂ) / (k : ℂ))

/-- The detector / projection: the geometric sum `Σ_{j<k} ω^j`. This is the inverse
Euler-product probe — a sum of `k`-th roots of unity that resonates iff `k ∣ N`. -/
noncomputable def detector (k N : ℕ) : ℂ :=
  ∑ j ∈ Finset.range k, zetaRoot k N ^ j

/-- `ω^k = 1`: the base really is a `k`-th root of unity. -/
lemma zetaRoot_pow_self (hk : 0 < k) (N : ℕ) : zetaRoot k N ^ k = 1 := by
  have hk' : (k : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr hk.ne'
  unfold zetaRoot
  rw [← Complex.exp_nat_mul]
  have hcast : (k : ℂ) * (2 * (π : ℂ) * I * (N : ℂ) / (k : ℂ))
      = (N : ℂ) * (2 * (π : ℂ) * I) := by
    field_simp
    ring
  rw [hcast, Complex.exp_nat_mul, Complex.exp_two_pi_mul_I, one_pow]

/-- The resonance condition: `ω = 1` exactly when `k ∣ N`. -/
lemma zetaRoot_eq_one_iff (hk : 0 < k) (N : ℕ) : zetaRoot k N = 1 ↔ k ∣ N := by
  have hk' : (k : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr hk.ne'
  have h2 : (2 * (π : ℂ) * I) ≠ 0 :=
    mul_ne_zero (mul_ne_zero two_ne_zero (by exact_mod_cast Real.pi_ne_zero)) Complex.I_ne_zero
  unfold zetaRoot
  rw [Complex.exp_eq_one_iff]
  constructor
  · rintro ⟨n, hn⟩
    rw [div_eq_iff hk'] at hn
    have hNC : (N : ℂ) = (n : ℂ) * (k : ℂ) :=
      mul_left_cancel₀ h2 (by linear_combination hn)
    have hZ : (N : ℤ) = n * (k : ℤ) := by exact_mod_cast hNC
    have hdvdZ : (k : ℤ) ∣ (N : ℤ) := ⟨n, by rw [hZ]; ring⟩
    exact_mod_cast hdvdZ
  · rintro ⟨m, rfl⟩
    refine ⟨(m : ℤ), ?_⟩
    push_cast
    field_simp
    ring

/-- **The detector identity.** `detector k N = k` if `k ∣ N`, and `0` otherwise.
The exact "projection reveals divisors" statement. -/
theorem detector_eq (hk : 0 < k) (N : ℕ) :
    detector k N = if k ∣ N then (k : ℂ) else 0 := by
  unfold detector
  by_cases h : k ∣ N
  · rw [if_pos h, (zetaRoot_eq_one_iff hk N).mpr h]
    simp
  · rw [if_neg h]
    have hne : zetaRoot k N ≠ 1 := fun hc => h ((zetaRoot_eq_one_iff hk N).mp hc)
    rw [geom_sum_eq hne k, zetaRoot_pow_self hk N]
    simp

/-- The projection "lights up" exactly at the divisors of `N`. -/
theorem detector_fires (hk : 0 < k) (N : ℕ) : detector k N ≠ 0 ↔ k ∣ N := by
  rw [detector_eq hk]
  split_ifs with h
  · rw [ne_eq, Nat.cast_eq_zero]; exact iff_of_true hk.ne' h
  · exact iff_of_false (by simp) h

/-- The detector's support is exactly the divisor set — the support of the modular
divisor-DNA `σ` (E₄ = Θ(E8) Fourier coefficients). -/
theorem fires_iff_mem_divisors (hk : 0 < k) (hN : 0 < N) :
    detector k N ≠ 0 ↔ k ∈ N.divisors := by
  rw [detector_fires hk, Nat.mem_divisors]
  exact ⟨fun h => ⟨h, hN.ne'⟩, fun h => h.1⟩

/-! ## §2 The factors are exactly what the projection selects -/

/-- **The conjecture, prime form.** For `N = p·q` the projection fires on a prime `k`
iff `k` is one of the two factors. (No false positives, no missed factors.) -/
theorem factors_revealed {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    {k : ℕ} (hk : k.Prime) :
    detector k (p * q) ≠ 0 ↔ k = p ∨ k = q := by
  rw [detector_fires hk.pos, hk.dvd_mul,
      Nat.prime_dvd_prime_iff_eq hk hp, Nat.prime_dvd_prime_iff_eq hk hq]

/-- A semiprime's prime factors are exactly `{p, q}`. -/
theorem primeFactors_mul_prime {p q : ℕ} (hp : p.Prime) (hq : q.Prime) :
    (p * q).primeFactors = {p, q} := by
  rw [Nat.primeFactors_mul hp.pos.ne' hq.pos.ne', hp.primeFactors, hq.primeFactors,
      Finset.singleton_union]

/-- "Exactly two points on the way to N": the count of prime factors of `p·q` is `2`
(for distinct primes). -/
theorem two_points {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) :
    (p * q).primeFactors.card = 2 := by
  rw [primeFactors_mul_prime hp hq, Finset.card_insert_of_not_mem (by simp [hpq]),
      Finset.card_singleton]

/-- **"With 3 it would work."** A product of three primes reveals all three.
(`{p,q,r}` as a set; equal to the three factors regardless of repetition, and of
cardinality 3 when distinct.) -/
theorem primeFactors_three {p q r : ℕ} (hp : p.Prime) (hq : q.Prime) (hr : r.Prime) :
    (p * q * r).primeFactors = {p, q, r} := by
  rw [Nat.primeFactors_mul (mul_pos hp.pos hq.pos).ne' hr.pos.ne',
      primeFactors_mul_prime hp hq, hr.primeFactors]
  ext x
  simp [Finset.mem_insert, or_assoc]

/-! ## §3 The capstone -/

/-- **The factoring conjecture, precise and proved.**
For a semiprime `N = p·q` with `p ≠ q` prime:
1. the roots-of-unity projection fires on a prime `k` iff `k` is a factor;
2. the prime factors are exactly `{p, q}`;
3. there are exactly two of them.
E8 / the Coxeter plane is the picture; this identity is the engine. -/
theorem semiprime_factors_revealed {p q : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) :
    (∀ k : ℕ, k.Prime → (detector k (p * q) ≠ 0 ↔ k = p ∨ k = q)) ∧
      (p * q).primeFactors = {p, q} ∧
      (p * q).primeFactors.card = 2 :=
  ⟨fun _ hk => factors_revealed hp hq hk, primeFactors_mul_prime hp hq, two_points hp hq hpq⟩

end HSLNFactor
