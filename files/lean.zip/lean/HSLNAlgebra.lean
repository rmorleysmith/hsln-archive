/-
The DNA algebra: composition IS the Dirichlet ring of arithmetic functions — machine-checked.
=============================================================================================

User's question: "we have all the operations right? we could derive some kind of group."
Here is that question made precise and verified against mathlib.

A "DNA" is an arithmetic function  f : ℕ → R  (the Dirichlet / q-expansion coefficients we
train and compose). Under  (pointwise +, Dirichlet convolution *)  these form a COMMUTATIVE
RING — the compose-operations we have been using ARE the ring operations:

  * `dna_ring`              : `ArithmeticFunction ℝ` is a `CommRing`  (+, *, and the unit δ).
  * `delta_is_identity`     : the convolution unit is  δ = [1,0,0,…]  (the "do-nothing" DNA).
  * `zeta_inv_is_moebius`   : the GROUP fact — DNA_ζ (all ones) is a unit and its Dirichlet
                              inverse is the Möbius DNA_μ:   ζ * μ = δ.  (Möbius inversion.)
  * `zeta_squared_counts_divisors` : DNA_ζ * DNA_ζ  =  the divisor-count function  d(n).

The "Lie derivative" of the generator. The map  D f (n) = f(n)·log n  is a DERIVATION of this
ring (Leibniz holds because log(d·e) = log d + log e). Applied to ζ it produces `log`; dividing
by ζ (i.e. multiplying by the inverse μ) extracts the PRIMES. This is exactly  −ζ'/ζ = Λ, the
von Mangoldt prime-power spectrum that drives the explicit formula:

  * `lie_derivative_of_zeta` : Λ * ζ = log     (the log-derivative of the generator)
  * `primes_from_log_deriv`  : log * μ = Λ      (… normalised by ζ⁻¹ = μ  →  the primes)

All `sorry`-free against mathlib's `ArithmeticFunction` API.
-/
import Mathlib

open ArithmeticFunction
open scoped ArithmeticFunction.zeta ArithmeticFunction.Moebius ArithmeticFunction.sigma

namespace HSLNAlgebra

/-- **The DNA ring.** Arithmetic functions — our Dirichlet / q-expansion DNAs — form a
commutative ring under pointwise `+` and Dirichlet convolution `*`. "We have all the
operations" is literally this `CommRing` instance. -/
@[reducible] def dna_ring : CommRing (ArithmeticFunction ℝ) := inferInstance

/-- The convolution identity is `δ = [1,0,0,…]`: `δ(1)=1` and `δ(n)=0` for `n ≠ 1`. The
"do-nothing" DNA — composing with it changes nothing. -/
theorem delta_is_identity :
    (1 : ArithmeticFunction ℝ) 1 = 1 ∧ ∀ n, n ≠ 1 → (1 : ArithmeticFunction ℝ) n = 0 :=
  ⟨by simp, fun _ h => one_apply_ne h⟩

/-- **The group inverse.** DNA_ζ (all ones) is a unit of the ring and its Dirichlet inverse is
the Möbius DNA_μ:  `ζ * μ = δ`. This is Möbius inversion, stated as a group identity. -/
theorem zeta_inv_is_moebius : (ζ * μ : ArithmeticFunction ℝ) = 1 :=
  coe_zeta_mul_coe_moebius

/-- **DNA_ζ * DNA_ζ = the divisor function.** Convolving the all-ones DNA with itself counts
the divisors of `n` — `ζ²` in the Dirichlet ring. -/
theorem zeta_squared_counts_divisors (n : ℕ) : (ζ * ζ) n = n.divisors.card := by
  have h : (σ 0 : ArithmeticFunction ℕ) = ζ * ζ := by
    rw [← zeta_mul_pow_eq_sigma, pow_zero_eq_zeta]
  rw [← h]; exact sigma_zero_apply n

/-- **The Lie derivative of the generator.** The derivation `D f (n) = f(n)·log n` applied to
`ζ` gives `log`; equivalently `Λ * ζ = log`, where `Λ` is the von Mangoldt prime-power
spectrum. -/
theorem lie_derivative_of_zeta : (Λ * ζ : ArithmeticFunction ℝ) = log :=
  vonMangoldt_mul_zeta

/-- **The primes, from the log-derivative.** Normalising the derivative by `ζ⁻¹ = μ` extracts
the prime powers: `log * μ = Λ`. This is `−ζ'/ζ = Λ`, the engine of the explicit formula. -/
theorem primes_from_log_deriv : (log * μ : ArithmeticFunction ℝ) = Λ :=
  log_mul_moebius_eq_vonMangoldt

/-- **Leibniz rule for the log-derivation.** Pointwise multiplication by `log` is a derivation
of the Dirichlet ring: `D(f * g) = D(f) * g + f * D(g)`, where `D h := h.pmul log`. Holds
because for `d · e = n` (both nonzero), `log n = log d + log e`. -/
theorem leibniz_log (f g : ArithmeticFunction ℝ) :
    (f * g).pmul log = f.pmul log * g + f * g.pmul log := by
  ext n
  rcases Nat.eq_zero_or_pos n with rfl | hn
  · simp
  simp only [pmul_apply, mul_apply, add_apply, log_apply]
  rw [Finset.sum_mul, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun p hp => ?_
  obtain ⟨hp_eq, hn0⟩ := Nat.mem_divisorsAntidiagonal.mp hp
  have hp1 : (p.1 : ℕ) ≠ 0 := fun h => hn0 (by rw [← hp_eq, h, zero_mul])
  have hp2 : (p.2 : ℕ) ≠ 0 := fun h => hn0 (by rw [← hp_eq, h, mul_zero])
  have hlog : Real.log (n : ℝ) = Real.log p.1 + Real.log p.2 := by
    rw [show (n : ℝ) = (p.1 : ℝ) * (p.2 : ℝ) by exact_mod_cast hp_eq.symm]
    exact Real.log_mul (by exact_mod_cast hp1) (by exact_mod_cast hp2)
  rw [hlog]; ring

/-- **The Lie derivative of ζ².** By Leibniz on the log-derivation,
`D(ζ · ζ) = D(ζ) · ζ + ζ · D(ζ) = 2 · log · ζ = 2 · Λ · ζ²`, using `D(ζ) = ζ.pmul log = log`
(`zeta_pmul`) and `log = Λ * ζ` (`vonMangoldt_mul_zeta`). Pointwise this says
`d(n) · log n = 2 · ∑_{d·e=n} Λ(d) · d(e)` — the log-derivative of the divisor function equals
twice von Mangoldt convolved with the divisor function. -/
theorem lie_derivative_of_zeta_squared :
    (ζ * ζ : ArithmeticFunction ℝ).pmul log = 2 * (Λ * (ζ * ζ)) := by
  rw [leibniz_log, zeta_pmul]
  have h : (Λ * (ζ * ζ) : ArithmeticFunction ℝ) = log * ζ := by
    rw [← mul_assoc, vonMangoldt_mul_zeta]
  rw [h]; ring

end HSLNAlgebra
