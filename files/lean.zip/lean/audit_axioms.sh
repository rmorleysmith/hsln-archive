#!/usr/bin/env bash
# audit_axioms.sh — kernel ledger for the HSLN repo: which theorems are PROVEN vs OPEN.
#
# A theorem is PROVEN iff its axiom dependency set is exactly {propext, Classical.choice,
# Quot.sound} (mathlib's standard trusted axioms). If `sorryAx` appears, the proof has an
# unfilled hole — it is OPEN (an open conjecture or a cited-but-unformalised theorem).
#
# Usage: ./audit_axioms.sh [path-to-mathlib4]   (default ../mathlib4)
# Works by appending `#print axioms <thm>` to a temp copy of each file and running
# `lake env lean`, then classifying each "depends on axioms" line.
set -uo pipefail
MATHLIB="${1:-../mathlib4}"
HERE="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

audit () {                       # audit <file.lean> <fully.qualified.thm> ...
  local file="$1"; shift
  local tmp="$TMP/$file"
  cp "$HERE/$file" "$tmp"
  { printf '\n'; for t in "$@"; do printf '#print axioms %s\n' "$t"; done; } >> "$tmp"
  ( cd "$MATHLIB" && lake env lean "$tmp" 2>/dev/null ) \
    | grep "depends on axioms" \
    | while IFS= read -r line; do
        name=$(printf '%s' "$line" | sed "s/^'\([^']*\)'.*/\1/")
        if printf '%s' "$line" | grep -q sorryAx; then
          printf '  OPEN    %s\n' "$name"
        else
          printf '  PROVEN  %s\n' "$name"
        fi
      done
}

echo "============================================================================"
echo " HSLN axiom ledger — PROVEN = {propext, Classical.choice, Quot.sound} only"
echo "                     OPEN   = axiom set contains sorryAx (unfilled hole)"
echo "============================================================================"
echo "── Hilbert–Pólya (honest wiring) ──"
audit HSLNHilbertPolya.lean \
  HSLNHilbertPolya.symmetric_eigenvalue_real \
  HSLNHilbertPolya.riemannHypothesis_of_hilbertPolyaOperator \
  HSLNHilbertPolya.Spec.Tdiag_symm \
  HSLNHilbertPolya.exists_selfAdjoint_realising \
  HSLNHilbertPolya.hilbertPolyaOperator_of_riemannHypothesis \
  HSLNHilbertPolya.riemannHypothesis_iff_hilbertPolyaOperator
echo "── Spectral zeta / ζ-criticality (Minakshisundaram–Pleijel, nuclear) ──"
audit HSLNSpectral.lean \
  HSLNSpectral.eigenvalue_real_of_symmetric \
  HSLNSpectral.eigenvalue_smul \
  HSLNSpectral.criticality_scale \
  HSLNSpectral.criticality_scale_real \
  HSLNSpectral.zero_eigenvalue_preserved \
  HSLNSpectral.riemannHypothesis_of_spectralZeta \
  HSLNSpectral.spectral_summary \
  HSLNSpectral.exists_selfAdjoint_realising \
  HSLNSpectral.spectralZetaOperator_of_riemannHypothesis \
  HSLNSpectral.riemannHypothesis_iff_spectralZetaOperator
echo "── Trace formula / Weil positivity (the refined operator hunt) ──"
audit HSLNTraceFormula.lean \
  HSLNTraceFormula.weilSpectralForm_nonneg \
  HSLNTraceFormula.weil_geom_nonneg \
  HSLNTraceFormula.riemannHypothesis_of_weilPositivity \
  HSLNTraceFormula.weilPositivity_of_traceFormula \
  HSLNTraceFormula.riemannHypothesis_of_traceFormula \
  HSLNTraceFormula.diagReal_isHermitian \
  HSLNTraceFormula.eulerMatrix_isHermitian \
  HSLNTraceFormula.traceFormulaRealization_trivially_satisfiable \
  HSLNTraceFormula.trace_formula_summary
echo "── Yang–Mills mass gap (Millennium; spectral gap) ──"
audit HSLNYangMills.lean \
  HSLNYangMills.massGap_eigenvalue_real \
  HSLNYangMills.eigenvalue_smul \
  HSLNYangMills.massGap_mono \
  HSLNYangMills.massGap_smul \
  HSLNYangMills.yangMills_positive_mass \
  HSLNYangMills.yangMillsMassGap_trivially_satisfiable \
  HSLNYangMills.zero_not_massGapFaithful \
  HSLNYangMills.action_nonneg \
  HSLNYangMills.yang_mills_summary
echo "── Hodge conjecture (Millennium; Chern-character bridge) ──"
audit HSLNHodge.lean \
  HSLNHodge.hodge_mul \
  HSLNHodge.hodgeConjecture_iff_eq \
  HSLNHodge.alg_subset_hodge \
  HSLNHodge.chern_mem_hodge \
  HSLNHodge.alg_mul_mem_hodge \
  HSLNHodge.integralHodgeModTorsion_iff_of_torsionFree \
  HSLNHodge.integralHodgeModTorsion_of_integralHodge \
  HSLNHodge.hodge_summary
echo "── Langlands skeleton (the bridge as a submonoid) ──"
audit HSLNLanglands.lean \
  HSLNLanglands.langlands_product_mem \
  HSLNLanglands.zeta_mul_moebius_mem \
  HSLNLanglands.zeta_sq_mem \
  HSLNLanglands.target_mem_of_functoriality \
  HSLNLanglands.langlands_summary
echo "── SpectralArithmetic: the first-class object (RH = QM = arithmetic, one structure) ──"
audit SpectralArithmetic.lean \
  SpectralArith.diagonalOp_isSymmetric \
  SpectralArith.diagonalOp_hasEigenvalue \
  SpectralArith.System.eigenvalue_real \
  SpectralArith.System.expectation_real \
  SpectralArith.hilbertPolya_eq_quantum \
  SpectralArith.spectral_arithmetic_unifies
echo "── Torsion of a twisted E8×E8 pair (commutator observable; physics = labelled conjecture) ──"
audit SpectralTorsion.lean \
  SpectralTorsion.torsion_zero_iff_commute \
  SpectralTorsion.torsion_self \
  SpectralTorsion.torsion_antisymm \
  SpectralTorsion.torsion_smul \
  SpectralTorsion.torsion_zero_of_zero_coupling \
  SpectralTorsion.torsion_antiHermitian \
  SpectralTorsion.i_torsion_isHermitian \
  SpectralTorsion.torsion_summary
echo "── Shor: period→factor reduction (the classical core) ──"
audit SpectralShor.lean \
  SpectralShor.sq_one_factor \
  SpectralShor.gcd_nontrivial \
  SpectralShor.order_pow_eq_one \
  SpectralShor.even_order_sqrt \
  SpectralShor.shor_reduction
echo "── Bosons / fermions / classical observables on the System space ──"
audit SpectralBosonFermion.lean \
  SpectralBosonFermion.pauli_exclusion \
  SpectralBosonFermion.fermion_antisymm \
  SpectralBosonFermion.expectation_real \
  SpectralBosonFermion.mass_additive \
  SpectralBosonFermion.integerSpin_boson \
  SpectralBosonFermion.halfIntegerSpin_fermion \
  SpectralBosonFermion.boson_fermion_summary
echo "── P vs NP and the composition/verification asymmetry ──"
audit HSLNComplexity.lean \
  HSLNComplexity.inP_subseteq_inNP \
  HSLNComplexity.pneqnp_iff_not_peqnp \
  HSLNComplexity.witnessRelation_inNP \
  HSLNComplexity.pNeqNP_of_asymmetry \
  HSLNComplexity.asymmetry_iff_separation \
  HSLNComplexity.complexity_summary
echo "── Quantum state on the finite-support space ──"
audit HSLNQuantumState.lean \
  HSLNQuantumState.expectation_real \
  HSLNQuantumState.globalPhase_norm \
  HSLNQuantumState.globalPhase_expectation \
  HSLNQuantumState.bornProb_sum_eq_one \
  HSLNQuantumState.divisorObs_isSymmetric \
  HSLNQuantumState.divisorObs_expectation_real \
  HSLNQuantumState.quantum_state_axioms
echo "── Divisor L-function Euler product (σ₃ ↔ ζ·ζ(·−3) ↔ E₄/E8) ──"
audit HSLNDivisorEuler.lean \
  HSLNDivisorEuler.sigma_eq_zeta_mul_pow \
  HSLNDivisorEuler.sigma_isMultiplicative \
  HSLNDivisorEuler.sigma_prime_pow \
  HSLNDivisorEuler.sigma3_eq_zeta_mul_pow3 \
  HSLNDivisorEuler.divisor_euler_bridge
echo "── Weil / Li positivity (the RH frontier node) ──"
audit HSLNWeilPositivity.lean \
  HSLNWeilPositivity.riemannHypothesis_of_weilPositivity \
  HSLNWeilPositivity.weilPositivity_of_riemannHypothesis \
  HSLNWeilPositivity.riemannHypothesis_of_liPositivity \
  HSLNWeilPositivity.not_riemannHypothesis_of_neg_liCoeff \
  HSLNWeilPositivity.weilPositivity_iff_liPositivity \
  HSLNWeilPositivity.frontier_summary
echo "── Millennium frontier map ──"
audit HSLNFrontier.lean \
  HSLNFrontier.riemannHypothesis_reducesTo_weilPositivity \
  HSLNFrontier.bsd_reducesTo_highRank \
  HSLNFrontier.hodge_reducesTo_higherCodim \
  HSLNFrontier.yangMills_reducesTo_existence \
  HSLNFrontier.millennium_frontier
echo "── K-theory / Grothendieck–Riemann–Roch ──"
audit HSLNKTheory.lean \
  HSLNKTheory.chernChar_dirichlet \
  HSLNKTheory.chernChar_add \
  HSLNKTheory.cauchy_mem_ker \
  HSLNKTheory.chernChar_divisor \
  HSLNKTheory.grr_summary
echo "── Riemann Hypothesis ──"
audit HSLNRH.lean \
  HSLNRH.riemannHypothesis_of_HilbertPolya \
  HSLNRH.riemannHypothesis_iff_nontrivial_zeros_on_line \
  HSLNRH.hadamard_dlVP_zero_free \
  HSLNRH.riemann_hypothesis_proof \
  HSLNRH.hilbertPolya_conjecture
echo "── Birch–Swinnerton-Dyer ──"
audit HSLNBSD.lean \
  HSLNBSD.fixedAxis_eq_one \
  HSLNBSD.BSDRank_prod \
  HSLNBSD.birch_swinnerton_dyer_rank \
  HSLNBSD.kolyvagin_theorem \
  HSLNBSD.bsd_rank_high
echo "── proven cores (the real, sorry-free mathematics) ──"
audit HSLNZeta.lean HSLNZeta.functional_equation HSLNZeta.half_is_the_symmetry_axis
audit HSLNAlgebra.lean HSLNAlgebra.zeta_inv_is_moebius HSLNAlgebra.primes_from_log_deriv
audit HSLNHecke.lean HSLNHecke.fourier_determined_by_primes_genus1
audit HSLNVerify.lean EtaQuotient.admissible_add gravity_preserves_equilibria
echo "============================================================================"
echo " The OPEN rows are the frontier. Everything else is machine-checked, no sorry."
echo "============================================================================"
