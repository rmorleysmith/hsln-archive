/-
The bridge: two rings on ℕ → R, and the Hecke / Langlands locus where they intersect.
======================================================================================

We have been working in two genuinely different ring structures on the same underlying
type `ArithmeticFunction R = (ℕ → R with f 0 = 0)`:

  * **Ring A — Cauchy / q-expansion product** (this file's `cauchyMul`, `⋆`):
       `(f ⋆ g)(n) = ∑_{i+j=n} f(i)·g(j)`
    This is `HSLN.mul`'s coefficient rule (`HSLN.fourierCoeff_mul`) — the product of
    modular forms as functions on ℍ_g, expressed on Fourier coefficients via the
    ADDITIVE monoid `(ℕ, +)` (matrices under `+` in higher genus).

  * **Ring B — Dirichlet convolution** (mathlib's `*` on `ArithmeticFunction R`,
    used throughout `HSLNAlgebra`, `HSLNZeta`, `HSLNLFunctions`):
       `(f * g)(n) = ∑_{d·e=n} f(d)·g(e)`
    This is the product of Dirichlet series `(∑ f(n)/nˢ)·(∑ g(n)/nˢ)` — the L-function
    operation.

`HSLN.fourierCoeff_mul` (line 365) is Ring A. `HSLNAlgebra.zeta_inv_is_moebius`,
`HSLNAlgebra.zeta_squared_counts_divisors`, the Lie-derivative identities, and all the
L-function work are Ring B. Both products live on the same data, but they are NOT the same
operation, and conflating them obscures what is going on.

The Langlands picture: for a Hecke eigenform `f` (e.g. a weight-2 newform attached to an
elliptic curve via modularity), the q-expansion coefficients `(aₙ)` are a MULTIPLICATIVE
arithmetic function, so the same sequence sits in BOTH rings. The Dirichlet ring's group
of multiplicative units `{f : f(1) = 1}` is closed under `*` (mathlib's
`IsMultiplicative.mul`) — this is the algebraic core of "L-functions of Hecke eigenforms
compose by `*`", e.g. `ζ · L(s, χ_D) = ζ_K` for `K = ℚ(√D)`. The Cauchy product `f ⋆ g`
of two such sequences is NOT (in general) the q-expansion of any well-known L-function;
that is why modular-form multiplication and L-function multiplication are different
operations.

`sorry`-free against mathlib.
-/
import Mathlib

open ArithmeticFunction Finset
open scoped ArithmeticFunction.zeta ArithmeticFunction.Moebius

namespace HSLNBridge

variable {R : Type*} [Semiring R]

/-- **The Cauchy / q-expansion convolution.** `(f ⋆ g)(n) = ∑_{i+j=n} f(i)·g(j)`. This is
the OTHER ring product on `ArithmeticFunction R` — the one `HSLN.mul`'s Fourier-coefficient
rule (`HSLN.fourierCoeff_mul` in `HSLN.lean`) gives at genus 1. -/
def cauchyMul (f g : ArithmeticFunction R) : ArithmeticFunction R where
  toFun n := ∑ p ∈ antidiagonal n, f p.1 * g p.2
  map_zero' := by simp

@[simp] theorem cauchyMul_apply (f g : ArithmeticFunction R) (n : ℕ) :
    cauchyMul f g n = ∑ p ∈ antidiagonal n, f p.1 * g p.2 := rfl

@[inherit_doc] scoped infixl:70 " ⋆ " => cauchyMul

/-- **Cauchy at `n = 1` is always zero.** The only decompositions `i + j = 1` are `(0, 1)`
and `(1, 0)`, and both summands vanish because `f 0 = g 0 = 0` (the `ArithmeticFunction`
zero-condition). So the Cauchy product can NEVER produce the Dirichlet identity `δ`. -/
theorem cauchy_apply_one_eq_zero (f g : ArithmeticFunction R) : (f ⋆ g) 1 = 0 := by
  simp [cauchyMul_apply, antidiagonal]

/-- **Dirichlet at `n = 1`.** `(f * g)(1) = f(1) · g(1)`. This is mathlib's
`mul_apply_one`. The contrast with `cauchy_apply_one_eq_zero` is the cleanest concrete
witness that the two rings differ. -/
theorem dirichlet_apply_one (f g : ArithmeticFunction R) : (f * g) 1 = f 1 * g 1 :=
  mul_apply_one

/-- **The two rings genuinely disagree on ζ.** `(ζ ⋆ ζ)(1) = 0` (Cauchy is zero at 1) but
`(ζ * ζ)(1) = 1` (Dirichlet preserves the n=1 value). This is the simplest concrete proof
that the modular-form product and the L-series product are NOT the same operation. -/
theorem rings_disagree_on_zeta :
    ((ζ : ArithmeticFunction ℝ) ⋆ ζ) 1 = 0 ∧ ((ζ : ArithmeticFunction ℝ) * ζ) 1 = 1 := by
  refine ⟨cauchy_apply_one_eq_zero _ _, ?_⟩
  rw [dirichlet_apply_one]; simp

/-! ### The Hecke / Langlands bridge: the multiplicative locus is closed under Ring B. -/

/-- **The bridge.** The multiplicative locus of the Dirichlet ring (arithmetic functions
`f` with `f(1) = 1` and `f(m·n) = f(m)·f(n)` for `gcd(m,n) = 1`) is CLOSED under Dirichlet
convolution. So multiplicative functions form a sub-monoid of `(ArithmeticFunction R, *)`.

For Hecke eigenforms `f, g` (e.g. weight-2 newforms attached to elliptic curves), the
q-expansion coefficient sequences `(aₙ), (bₙ)` are multiplicative — so the same data
sits inside the Dirichlet ring as a unit, and their L-functions multiply by `*` here:
`L(f, s) · L(g, s) = L(f * g, s)` at the level of Dirichlet coefficients. This is the
algebraic core of "abelian Langlands": e.g. `ζ · L(s, χ_D) = ζ_K` (Dedekind zeta of
`K = ℚ(√D)`) holds because both sides are multiplicative and agree on prime powers. -/
theorem dirichlet_preserves_multiplicative
    {f g : ArithmeticFunction ℝ}
    (hf : f.IsMultiplicative) (hg : g.IsMultiplicative) :
    (f * g).IsMultiplicative :=
  hf.mul hg

/-- **Concrete Langlands witness.** `ζ * μ` is multiplicative — both factors are, and the
result is the identity `δ` (Möbius inversion as the inverse element in the multiplicative
group). This is the "trivial representation" case: the L-function `L(triv, s) · L(triv, s)⁻¹
= 1`. -/
theorem zeta_mul_moebius_isMultiplicative :
    ((ζ * μ : ArithmeticFunction ℤ)).IsMultiplicative :=
  isMultiplicative_zeta.natCast.mul isMultiplicative_moebius

/-- **`ζ * ζ` is multiplicative.** Hence the divisor function `d(n) = (ζ * ζ)(n)` is
multiplicative — a classical fact, and a direct consequence of the bridge. -/
theorem zeta_squared_isMultiplicative :
    ((ζ * ζ : ArithmeticFunction ℕ)).IsMultiplicative :=
  isMultiplicative_zeta.mul isMultiplicative_zeta

/-- **The Hecke / Langlands moral**: a Hecke eigenform's q-expansion sequence is BOTH a
Ring-A object (modular-form Fourier vector under Cauchy `⋆`) AND a Ring-B object
(multiplicative arithmetic function under Dirichlet `*`). Different products on the same
data: `f ⋆ g` is the q-expansion of the form-level product `f · g`; `f * g` is the L-series
of the convolution. Conflating them obscures the Langlands content. -/
theorem hecke_bridge_summary :
    -- the Hecke / multiplicative locus, where Ring B turns into a genuine group:
    ((ζ : ArithmeticFunction ℝ).IsMultiplicative) ∧
    ((ζ * μ : ArithmeticFunction ℤ).IsMultiplicative) ∧
    -- and yet at `n = 1` the Cauchy and Dirichlet products always disagree:
    (((ζ : ArithmeticFunction ℝ) ⋆ ζ) 1 = 0 ∧ ((ζ : ArithmeticFunction ℝ) * ζ) 1 = 1) :=
  ⟨isMultiplicative_zeta.natCast,
   isMultiplicative_zeta.natCast.mul isMultiplicative_moebius,
   rings_disagree_on_zeta⟩

end HSLNBridge
