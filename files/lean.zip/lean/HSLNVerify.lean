/-
Formally verified core of the HSLN composition claims.
=====================================================

This is the machine-checked extraction of `HSLN.lean` §6–§7 — the parts that make
mathematical (number-theoretic) claims, separated from the architecture skeleton so
they compile cleanly and sorry-free.

  * §6  eta-quotient DNA: the admissible exponent vectors form an additive
        sub-monoid (composition = vector addition stays inside the modular forms).
  * §7  gravity (a positive-definite Siegel metric) preserves the equilibria of the
        gradient flow: it warps the route, not the destination.

Verified against mathlib `v4.30.0-rc2` (pinned in `lean-toolchain`). To reproduce,
with the sibling `../mathlib4` checkout built (`lake exe cache get`):

    cd ../mathlib4 && lake env lean ../quantum-neural-network/HSLNVerify.lean

Exit code 0 and no output == every theorem below holds with no `sorry`.
-/
import Mathlib

noncomputable section
open Matrix

/-! ## §6  Eta-quotient composition monoid -/

namespace EtaQuotient

/-- Integer exponent vector of an eta quotient `∏_{d∣N} η(dτ)^{r_d}`. -/
abbrev Exp := ℕ → ℤ

variable {N : ℕ}

/-- First Newman sum `∑_{d∣N} d·r_d`. -/
def newmanA (N : ℕ) (r : Exp) : ℤ := ∑ d ∈ N.divisors, (d : ℤ) * r d

/-- Second Newman sum `∑_{d∣N} (N/d)·r_d`. -/
def newmanB (N : ℕ) (r : Exp) : ℤ := ∑ d ∈ N.divisors, ((N / d : ℕ) : ℤ) * r d

/-- Ligozat order of vanishing at the cusp `c ∣ N` (linear in `r`). -/
def ord (N c : ℕ) (r : Exp) : ℚ :=
  ((N : ℚ) / 24) * ∑ d ∈ N.divisors,
    ((Nat.gcd c d : ℚ) ^ 2 / (Nat.gcd c (N / c) * c * d : ℚ)) * (r d : ℚ)

/-- Weight `k = ½ ∑_d r_d`. -/
def weight (N : ℕ) (r : Exp) : ℚ := (1 / 2 : ℚ) * ∑ d ∈ N.divisors, (r d : ℚ)

/-- Composition adds the first Newman sum. -/
@[simp] lemma newmanA_add (r s : Exp) : newmanA N (r + s) = newmanA N r + newmanA N s := by
  simp only [newmanA, Pi.add_apply, mul_add, Finset.sum_add_distrib]

/-- Composition adds the second Newman sum. -/
@[simp] lemma newmanB_add (r s : Exp) : newmanB N (r + s) = newmanB N r + newmanB N s := by
  simp only [newmanB, Pi.add_apply, mul_add, Finset.sum_add_distrib]

/-- Composition adds the cusp orders (so the holomorphy cone is closed under +). -/
lemma ord_add (c : ℕ) (r s : Exp) : ord N c (r + s) = ord N c r + ord N c s := by
  simp only [ord, Pi.add_apply, Int.cast_add, mul_add, Finset.sum_add_distrib, mul_add,
    Finset.mul_sum]

/-- Composition adds the weight: `k(f_r · f_s) = k(f_r) + k(f_s)`. -/
theorem weight_add (r s : Exp) : weight N (r + s) = weight N r + weight N s := by
  simp only [weight, Pi.add_apply, Int.cast_add, Finset.sum_add_distrib]
  ring

@[simp] lemma newmanA_zero : newmanA N 0 = 0 := by simp [newmanA]
@[simp] lemma newmanB_zero : newmanB N 0 = 0 := by simp [newmanB]

/-- Newman's two congruences hold (the form lives on `Γ₀(N)`). -/
def IsCong (N : ℕ) (r : Exp) : Prop := (24 : ℤ) ∣ newmanA N r ∧ (24 : ℤ) ∣ newmanB N r

/-- Ligozat holomorphy: every cusp order is `≥ 0`. -/
def IsHolo (N : ℕ) (r : Exp) : Prop := ∀ c ∈ N.divisors, 0 ≤ ord N c r

/-- `r` is admissible iff `f_r` is a holomorphic modular form on `Γ₀(N)`. -/
def Admissible (N : ℕ) (r : Exp) : Prop := IsCong N r ∧ IsHolo N r

/-- The trivial network (constant `1`) is admissible. -/
theorem admissible_zero : Admissible N 0 := by
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · simp
  · simp
  · intro c _; simp [ord]

/-- **Composition stays admissible.** If two exponent vectors each give a holomorphic
modular form, so does their sum — i.e. multiplying the two networks. -/
theorem admissible_add {r s : Exp} (hr : Admissible N r) (hs : Admissible N s) :
    Admissible N (r + s) := by
  obtain ⟨⟨ha, hb⟩, hr'⟩ := hr
  obtain ⟨⟨ha', hb'⟩, hs'⟩ := hs
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · rw [newmanA_add]; exact dvd_add ha ha'
  · rw [newmanB_add]; exact dvd_add hb hb'
  · intro c hc; rw [ord_add]; exact add_nonneg (hr' c hc) (hs' c hc)

/-- **The composability guarantee.** Admissible eta-quotient exponent vectors form an
additive sub-monoid of `ℕ → ℤ`: composing valid networks (adding exponent vectors =
multiplying forms) never leaves the space of holomorphic modular forms. -/
def admissibleMonoid (N : ℕ) : AddSubmonoid Exp where
  carrier := { r | Admissible N r }
  zero_mem' := admissible_zero
  add_mem' := by intro a b ha hb; exact admissible_add ha hb

end EtaQuotient

/-! ## §7  Gravity preserves the equilibria -/

/-- For a positive-definite Siegel metric `K`, the metric-coupled gradient flow
`Ż = −K∇V` shares its equilibria with the bare flow `Ż = −∇V`, because `K v = 0 ↔
v = 0`. Turning on the gravitational off-diagonal coupling warps trajectories but
fixes the neurons (the zeros of `∇V`). This is the formal content of the
routing-robustness result in `viz/coupling_sweep.py` (figure 22). -/
theorem gravity_preserves_equilibria {n : ℕ}
    {K : Matrix (Fin n) (Fin n) ℝ} (hK : K.PosDef) (v : Fin n → ℝ) :
    K.mulVec v = 0 ↔ v = 0 := by
  constructor
  · intro h
    by_contra hv
    have hpos := hK.dotProduct_mulVec_pos hv
    rw [h] at hpos
    simp at hpos
  · rintro rfl; simp
