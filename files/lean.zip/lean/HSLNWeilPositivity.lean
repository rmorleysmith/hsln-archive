/-
HSLNWeilPositivity.lean — the positivity frontier of RH, wired sorry-free.
==========================================================================

This file makes precise, and machine-checks, the *exact* sense in which the Riemann
Hypothesis reduces to a single positivity statement. The honest structure throughout:

  • an **equivalence** ("criterion ⟺ RH") is a PROVEN theorem of the literature — we carry it
    as a hypothesis `Prop` so the file stays sorry-free and nothing false is asserted;
  • the **positivity itself** (that the functional is actually ≥ 0) is the OPEN content — it
    *is* RH — and lives in a single `def` with no incoming proven arrow.

Everything else is a sorry-free implication. The contribution is a verified *frontier map*: RH
is isolated to exactly one node (`WeilPositivity` / `LiPositivity`), with proven arrows from
that node to RH, and from the Hilbert–Pólya / spectral picture into that node.

Two classical reformulations are wired:

  1. **Weil's explicit-formula positivity** (Weil 1952; Bombieri, *Remarks on Weil's quadratic
     functional…*, 2000). RH ⟺ the quadratic functional `B(g,g) = ∑_ρ ĝ(ρ)` (equivalently the
     explicit-formula pairing) is `≥ 0` for all admissible test functions `g`.
  2. **Li's criterion** (Xian-Jin Li, *The positivity of a sequence of numbers and the Riemann
     Hypothesis*, J. Number Theory 65 (1997) 325–333). RH ⟺ `λₙ ≥ 0` for every `n ≥ 1`, where
     `λₙ = ∑_ρ (1 − (1 − 1/ρ)ⁿ)` (sum over nontrivial zeros).

Both equivalences are PROVEN in the literature; both positivities are OPEN (= RH). We model
each functional abstractly (`ℕ → ℝ` for the Li coefficients, `TestFn → ℝ` for Weil) so the file
is self-contained against current mathlib — which has `RiemannHypothesis`, `riemannZeta`,
`vonMangoldt`, the functional equation, but NOT the explicit formula or these criteria.

`sorry`-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
-/
import Mathlib

open scoped BigOperators

namespace HSLNWeilPositivity

/-! ### Generic positivity-criterion plumbing -/

/-- A **positivity criterion** for a proposition `Target` (here always `RiemannHypothesis`): an
indexed family of real quantities `c : ι → ℝ` together with the *proven* equivalence
"`(∀ i, 0 ≤ c i) ↔ Target`". The equivalence is the published theorem (Weil 1952 / Li 1997); we
carry it as data so no unproven claim is asserted. -/
structure PositivityCriterion (ι : Type*) (Target : Prop) where
  /-- the family of real "coefficients" whose nonnegativity is the criterion -/
  coeff : ι → ℝ
  /-- the PROVEN equivalence: all coefficients nonneg ⟺ the target holds -/
  equiv : (∀ i, 0 ≤ coeff i) ↔ Target

/-- **Positivity ⇒ Target** — sorry-free. If every coefficient of a positivity criterion is
nonnegative, the target proposition holds. This is the forward use of the (carried) equivalence. -/
theorem target_of_positive {ι : Type*} {Target : Prop}
    (C : PositivityCriterion ι Target) (h : ∀ i, 0 ≤ C.coeff i) : Target :=
  C.equiv.mp h

/-- **Target ⇒ Positivity** — sorry-free. Conversely the target forces all coefficients
nonnegative. So the criterion is genuinely *equivalent* to the target, not merely sufficient. -/
theorem positive_of_target {ι : Type*} {Target : Prop}
    (C : PositivityCriterion ι Target) (h : Target) : ∀ i, 0 ≤ C.coeff i :=
  C.equiv.mpr h

/-- **A single negative coefficient refutes the target** — sorry-free. The contrapositive: if
any coefficient is `< 0`, the target fails. (This is how a criterion could in principle
*disprove* RH — exhibit one negative `λₙ`.) -/
theorem not_target_of_neg {ι : Type*} {Target : Prop}
    (C : PositivityCriterion ι Target) {i : ι} (h : C.coeff i < 0) : ¬ Target :=
  fun ht => absurd (positive_of_target C ht i) (not_le.mpr h)

/-! ### Weil's explicit-formula positivity criterion -/

/-- An admissible test function for the explicit formula, modelled abstractly (an even,
compactly-supported smooth function in the literature; here an opaque index type carrying no
structure we rely on). -/
opaque WeilTestFn : Type

/-- **Weil's quadratic functional** `B(g, g)`, modelled as a real number per test function. In
the literature `B(g,g) = ∑_ρ ĝ(ρ)` = (archimedean term) − (prime-power sum), and RH ⟺ `B ≥ 0`. -/
opaque weilFunctional : WeilTestFn → ℝ

/-- **Weil's positivity criterion** (Weil 1952; Bombieri 2000) — the PROVEN equivalence, carried
as a hypothesis. `RH ⟺ B(g,g) ≥ 0 for all g`. -/
def WeilCriterion : Prop :=
  (∀ g, 0 ≤ weilFunctional g) ↔ RiemannHypothesis

/-- **The open positivity node.** That Weil's functional is actually nonnegative everywhere.
This is OPEN — it *is* RH. No proven arrow points into this `def`. -/
def WeilPositivity : Prop := ∀ g, 0 ≤ weilFunctional g

/-- **Weil positivity ⇒ RH** — sorry-free, given the cited criterion. The single open node
`WeilPositivity`, once filled, closes RH through Weil's published equivalence. -/
theorem riemannHypothesis_of_weilPositivity
    (hcrit : WeilCriterion) (hpos : WeilPositivity) : RiemannHypothesis :=
  hcrit.mp hpos

/-- **RH ⇒ Weil positivity** — sorry-free, given the criterion. The converse, so the node is
genuinely equivalent to RH. -/
theorem weilPositivity_of_riemannHypothesis
    (hcrit : WeilCriterion) (h : RiemannHypothesis) : WeilPositivity :=
  hcrit.mpr h

/-- **The Weil frontier, packaged.** Bundling `weilFunctional` and the cited criterion into a
`PositivityCriterion WeilTestFn RiemannHypothesis`: RH is exactly the nonnegativity of one
explicit real-valued functional on test functions. -/
def weilFrontier (hcrit : WeilCriterion) : PositivityCriterion WeilTestFn RiemannHypothesis where
  coeff := weilFunctional
  equiv := hcrit

/-! ### Li's criterion -/

/-- **The Li coefficients** `λₙ = ∑_ρ (1 − (1 − 1/ρ)ⁿ)`, modelled abstractly as `ℕ → ℝ` (their
closed form, `λₙ = (1/(n−1)!) dⁿ/dsⁿ [sⁿ⁻¹ log ξ(s)]|_{s=1}`, is a theorem of Li 1997). -/
opaque liCoeff : ℕ → ℝ

/-- **Li's criterion** (Li 1997) — the PROVEN equivalence, carried as a hypothesis.
`RH ⟺ λₙ ≥ 0 for all n ≥ 1`. -/
def LiCriterion : Prop := (∀ n, 0 ≤ liCoeff n) ↔ RiemannHypothesis

/-- **The open positivity node (Li form).** That every Li coefficient is nonnegative. OPEN = RH. -/
def LiPositivity : Prop := ∀ n, 0 ≤ liCoeff n

/-- **Li positivity ⇒ RH** — sorry-free, given Li's criterion. -/
theorem riemannHypothesis_of_liPositivity
    (hcrit : LiCriterion) (hpos : LiPositivity) : RiemannHypothesis :=
  hcrit.mp hpos

/-- **RH ⇒ Li positivity** — sorry-free, given the criterion. -/
theorem liPositivity_of_riemannHypothesis
    (hcrit : LiCriterion) (h : RiemannHypothesis) : LiPositivity :=
  hcrit.mpr h

/-- **A single negative Li coefficient disproves RH** — sorry-free. The concrete falsification
route: exhibit `n` with `λₙ < 0`. -/
theorem not_riemannHypothesis_of_neg_liCoeff
    (hcrit : LiCriterion) {n : ℕ} (h : liCoeff n < 0) : ¬ RiemannHypothesis :=
  not_target_of_neg (⟨liCoeff, hcrit⟩ : PositivityCriterion ℕ RiemannHypothesis) h

/-! ### The two criteria agree (both are RH) -/

/-- **Weil positivity ⟺ Li positivity**, given both criteria — sorry-free. Both are equivalent
to RH, hence to each other: two faces of the same single open node. (This is the transitivity of
two published equivalences; no new mathematics, just the wiring made explicit.) -/
theorem weilPositivity_iff_liPositivity
    (hW : WeilCriterion) (hL : LiCriterion) : WeilPositivity ↔ LiPositivity :=
  hW.trans hL.symm

/-- **Frontier summary.** Given the two cited equivalences: (1) Weil positivity ⇒ RH;
(2) Li positivity ⇒ RH; (3) RH ⇒ both; (4) the two positivities coincide. RH is pinned to a
single open node, reachable four equivalent ways, every arrow sorry-free. -/
theorem frontier_summary (hW : WeilCriterion) (hL : LiCriterion) :
    (WeilPositivity → RiemannHypothesis) ∧
    (LiPositivity → RiemannHypothesis) ∧
    (RiemannHypothesis → WeilPositivity ∧ LiPositivity) ∧
    (WeilPositivity ↔ LiPositivity) :=
  ⟨riemannHypothesis_of_weilPositivity hW,
   riemannHypothesis_of_liPositivity hL,
   fun h => ⟨weilPositivity_of_riemannHypothesis hW h, liPositivity_of_riemannHypothesis hL h⟩,
   weilPositivity_iff_liPositivity hW hL⟩

end HSLNWeilPositivity
