/-
HSLNQuantumState.lean — the HSLN finite-support space realises the quantum-state axioms.
========================================================================================

Posit (verified in `viz/hsln_quantum_state.py`): the HSLN does not merely *analogise* a
quantum state — its finite-support inner-product space `ι →₀ ℂ` together with the self-adjoint
diagonal operators of the spectral-realisation construction *is* the Hilbert-space/observable
structure quantum mechanics requires. This file makes that a theorem.

The bridge is our own sorry-free result. The construction `exists_selfAdjoint_realising`
(the diagonal operator `Tdiag r` on `ι →₀ ℂ`, self-adjoint with real spectrum `{r i}`) is, read
in physics language:

  * `ι →₀ ℂ` with the pairing `⟨f,g⟩ = ∑ conj(f i)·g i`  — a complex inner product space (state space);
  * a unit vector there                                   — a pure quantum state (`QuantumState`);
  * `Tdiag r` self-adjoint                                — an observable;
  * its real eigenvalues `{r i}`                          — the measurement outcomes;
  * `‖ψ i‖²`                                              — the Born-rule probabilities;
  * `⟨ψ, Tdiag r ψ⟩`                                      — the expectation value (REAL, proven).

We prove the quantum-state axioms (en.wikipedia.org/wiki/Quantum_state):
  • `expectation_real`        — ⟨ψ, A ψ⟩ ∈ ℝ for any self-adjoint A (Born expectation is real);
  • `globalPhase_*`           — e^{iθ}|ψ⟩ has the same norm, Born probabilities, and expectation;
  • `bornProb_*`              — probabilities are nonneg and (for a unit state) sum to 1;
  • `QuantumState`            — a bundled unit vector; observables act, expectations are real;
  • divisor example           — the arithmetic divisor-count DNA is a genuine quantum state and
                                the divisor function a genuine observable (the number-theory ↔
                                quantum bridge made literal).

The whole thing reuses the engine: the inner product `FinsuppC.core`, `Tdiag`, and
`Tdiag_isSymmetric` are exactly the spectral-realisation pieces.

`sorry`-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
-/
import Mathlib

open Module.End Complex
open scoped BigOperators ComplexConjugate InnerProductSpace

namespace HSLNQuantumState

/-! ### The state space: finite-support complex sequences with our inner product

This is the `SpectralRealization.FinsuppC` engine, inlined for the self-contained-file convention. -/

/-- The HSLN state space: finitely supported complex amplitudes. -/
abbrev StateSpace (ι : Type*) : Type _ := ι →₀ ℂ

namespace StateSpace
variable {ι : Type*}

/-- The quantum inner product `⟨f, g⟩ = ∑ conj(f i)·g i` (our `ipair`). -/
noncomputable def pairing (f g : StateSpace ι) : ℂ := ∑ i ∈ f.support, conj (f i) * g i

theorem pairing_eq_sum (s : Finset ι) (f g : StateSpace ι) (hf : f.support ⊆ s) :
    pairing f g = ∑ i ∈ s, conj (f i) * g i := by
  classical
  apply Finset.sum_subset hf
  intro i _ hi
  rw [Finsupp.notMem_support_iff.mp hi, map_zero, zero_mul]

theorem pairing_self_ofReal (f : StateSpace ι) :
    pairing f f = ((∑ i ∈ f.support, Complex.normSq (f i) : ℝ) : ℂ) := by
  rw [pairing, Complex.ofReal_sum]
  exact Finset.sum_congr rfl (fun i _ => (Complex.normSq_eq_conj_mul_self).symm)

noncomputable instance core : InnerProductSpace.Core ℂ (StateSpace ι) where
  inner := pairing
  conj_inner_symm f g := by
    classical
    rw [pairing_eq_sum (f.support ∪ g.support) g f Finset.subset_union_right,
        pairing_eq_sum (f.support ∪ g.support) f g Finset.subset_union_left, map_sum]
    exact Finset.sum_congr rfl (fun i _ => by rw [map_mul, Complex.conj_conj, mul_comm])
  re_inner_nonneg f := by
    show 0 ≤ (pairing f f).re
    rw [pairing_self_ofReal, Complex.ofReal_re]
    exact Finset.sum_nonneg (fun i _ => Complex.normSq_nonneg _)
  definite f hf := by
    classical
    rw [pairing_self_ofReal, Complex.ofReal_eq_zero] at hf
    have hz : ∀ i ∈ f.support, Complex.normSq (f i) = 0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => Complex.normSq_nonneg _)).mp hf
    apply Finsupp.ext
    intro i
    simp only [Finsupp.coe_zero, Pi.zero_apply]
    by_cases hi : i ∈ f.support
    · exact Complex.normSq_eq_zero.mp (hz i hi)
    · exact Finsupp.notMem_support_iff.mp hi
  add_left f g h := by
    classical
    have hsf : f.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_left Finset.subset_union_left
    have hsg : g.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_right Finset.subset_union_left
    have hsfg : (f + g).support ⊆ f.support ∪ g.support ∪ h.support := by
      intro i hi
      have hne : (f + g) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.add_apply] at hne
      by_cases h1 : f i = 0
      · have h2 : g i ≠ 0 := fun h2 => hne (by rw [h1, h2, add_zero])
        exact Finset.mem_union_left _ (Finset.mem_union_right _ (Finsupp.mem_support_iff.mpr h2))
      · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr h1))
    rw [pairing_eq_sum (f.support ∪ g.support ∪ h.support) (f+g) h hsfg,
        pairing_eq_sum (f.support ∪ g.support ∪ h.support) f h hsf,
        pairing_eq_sum (f.support ∪ g.support ∪ h.support) g h hsg, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun i _ => by rw [Finsupp.add_apply, map_add, add_mul])
  smul_left f g r := by
    classical
    have hsrf : (r • f).support ⊆ f.support := by
      intro i hi
      have hne : (r • f) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.smul_apply, smul_eq_mul] at hne
      exact Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne)
    rw [pairing_eq_sum f.support (r • f) g hsrf, pairing, Finset.mul_sum]
    exact Finset.sum_congr rfl (fun i _ => by
      rw [Finsupp.smul_apply, smul_eq_mul, map_mul]; ring)

noncomputable instance instNormedAddCommGroup : NormedAddCommGroup (StateSpace ι) :=
  InnerProductSpace.Core.toNormedAddCommGroup (𝕜 := ℂ) (cd := core)

noncomputable instance instInnerProductSpace : InnerProductSpace ℂ (StateSpace ι) :=
  InnerProductSpace.ofCore _

theorem inner_eq_pairing (f g : StateSpace ι) : (inner ℂ f g) = pairing f g := rfl

/-- The diagonal observable: multiplication by a real sequence `r`. -/
noncomputable def diagObs (r : ι → ℝ) : (StateSpace ι) →ₗ[ℂ] (StateSpace ι) :=
  Finsupp.linearCombination ℂ (fun i => Finsupp.single i (r i : ℂ))

theorem diagObs_apply (r : ι → ℝ) (x : StateSpace ι) (j : ι) :
    (diagObs r x) j = (r j : ℂ) * x j := by
  classical
  simp only [diagObs, Finsupp.linearCombination_apply, Finsupp.sum_apply]
  rw [Finsupp.sum]
  simp only [Finsupp.smul_single, smul_eq_mul, Finsupp.single_apply]
  rw [Finset.sum_ite_eq']
  by_cases hj : j ∈ x.support
  · simp [hj, mul_comm]
  · simp only [hj, if_false]; rw [Finsupp.notMem_support_iff.mp hj]; ring

/-- **Observables are self-adjoint** — the diagonal observable is symmetric (the spectral-engine
`Tdiag_isSymmetric`, here read as "every diagonal real observable is Hermitian"). -/
theorem diagObs_isSymmetric (r : ι → ℝ) : (diagObs r).IsSymmetric := by
  classical
  intro x y
  have hx : (diagObs r x).support ⊆ x.support ∪ y.support := by
    intro i hi
    have hne : (diagObs r x) i ≠ 0 := Finsupp.mem_support_iff.mp hi
    rw [diagObs_apply] at hne
    exact Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne))
  rw [inner_eq_pairing, inner_eq_pairing,
      pairing_eq_sum (x.support ∪ y.support) _ _ hx,
      pairing_eq_sum (x.support ∪ y.support) _ _ Finset.subset_union_left]
  apply Finset.sum_congr rfl
  intro i _
  rw [diagObs_apply r x i, diagObs_apply r y i, map_mul, Complex.conj_ofReal]
  ring

end StateSpace

/-! ### The quantum-state axioms, on a general complex inner product space

These hold for any `InnerProductSpace ℂ E`; our `StateSpace ι` is an instance. -/

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

/-- **Expectation values are real** (the Born expectation `⟨A⟩ = ⟨ψ, A ψ⟩` of a self-adjoint
observable is a real number). This is the quantum-mechanical face of spectral reality, and the
reason measured quantities are real. Sorry-free. -/
theorem expectation_real (T : E →ₗ[ℂ] E) (hT : T.IsSymmetric) (ψ : E) :
    (inner ℂ ψ (T ψ) : ℂ).im = 0 := by
  have h1 : (starRingEnd ℂ) (inner ℂ ψ (T ψ)) = inner ℂ (T ψ) ψ := inner_conj_symm (T ψ) ψ
  exact Complex.conj_eq_iff_im.mp (h1.trans (hT ψ ψ))

/-- **Global phase irrelevance — norm.** `e^{iθ}|ψ⟩` has the same norm as `|ψ⟩`, so it is again
a unit vector. (`‖e^{iθ}‖ = 1`.) -/
theorem globalPhase_norm (θ : ℝ) (ψ : E) :
    ‖(Complex.exp (θ * I)) • ψ‖ = ‖ψ‖ := by
  rw [norm_smul, Complex.norm_exp_ofReal_mul_I, one_mul]

/-- **Global phase irrelevance — expectation.** The Born expectation is invariant under a global
phase `e^{iθ}`: `⟨e^{iθ}ψ, A (e^{iθ}ψ)⟩ = ⟨ψ, A ψ⟩`. So `|ψ⟩` and `e^{iθ}|ψ⟩` are the same
physical state. Sorry-free. -/
theorem globalPhase_expectation (T : E →ₗ[ℂ] E) (θ : ℝ) (ψ : E) :
    inner ℂ ((Complex.exp (θ * I)) • ψ) (T ((Complex.exp (θ * I)) • ψ))
      = inner ℂ ψ (T ψ) := by
  rw [map_smul, inner_smul_left, inner_smul_right, ← mul_assoc,
      ← Complex.exp_conj, ← Complex.exp_add]
  have : (starRingEnd ℂ) (θ * I) + θ * I = 0 := by
    rw [map_mul, Complex.conj_ofReal, Complex.conj_I]; ring
  rw [this, Complex.exp_zero, one_mul]

/-! ### Pure-state probabilities (the Born rule) on the finite-support space -/

variable {ι : Type*}

/-- The Born probability of outcome `i`: `‖ψ i‖²`. -/
noncomputable def bornProb (ψ : StateSpace ι) (i : ι) : ℝ := Complex.normSq (ψ i)

/-- **Born probabilities are nonnegative.** -/
theorem bornProb_nonneg (ψ : StateSpace ι) (i : ι) : 0 ≤ bornProb ψ i :=
  Complex.normSq_nonneg _

/-- **For a unit state, the Born probabilities sum to 1** — total probability is conserved. The
sum is over the (finite) support; `‖ψ‖² = ⟨ψ,ψ⟩ = ∑ ‖ψ i‖²`. Sorry-free. -/
theorem bornProb_sum_eq_one (ψ : StateSpace ι) (hψ : ‖ψ‖ = 1) :
    ∑ i ∈ ψ.support, bornProb ψ i = 1 := by
  have hself : (inner ℂ ψ ψ : ℂ) = ((∑ i ∈ ψ.support, Complex.normSq (ψ i) : ℝ) : ℂ) :=
    StateSpace.pairing_self_ofReal ψ
  have hnorm : (inner ℂ ψ ψ : ℂ) = ((‖ψ‖ : ℂ)) ^ 2 := inner_self_eq_norm_sq_to_K ψ
  rw [hself] at hnorm
  have hsum : (∑ i ∈ ψ.support, Complex.normSq (ψ i) : ℝ) = ‖ψ‖ ^ 2 := by
    have := hnorm
    rw [← Complex.ofReal_pow] at this
    exact Complex.ofReal_injective this
  show ∑ i ∈ ψ.support, Complex.normSq (ψ i) = 1
  rw [hsum, hψ]; norm_num

/-! ### The arithmetic ↔ quantum bridge: the divisor function as an observable

The divisor-count function `d(n) = σ₀(n)` — a real arithmetic sequence — is, by
`diagObs_isSymmetric`, a genuine self-adjoint observable on the state space `ℕ →₀ ℂ`. Its
expectation in any state is real (`expectation_real`). This is the number-theory ↔ quantum
state bridge made literal: an arithmetic function IS a quantum observable. -/

/-- The divisor-count observable `D` on `ℕ →₀ ℂ`: diagonal multiplication by `n ↦ (#divisors n)`. -/
noncomputable def divisorObs : (StateSpace ℕ) →ₗ[ℂ] (StateSpace ℕ) :=
  StateSpace.diagObs (fun n => (n.divisors.card : ℝ))

/-- **The divisor function is a self-adjoint observable.** -/
theorem divisorObs_isSymmetric : divisorObs.IsSymmetric :=
  StateSpace.diagObs_isSymmetric _

/-- **The divisor observable has real expectation in every state** — a number-theoretic quantity
(`⟨ψ, D ψ⟩`, a divisor-weighted moment of the amplitudes) is a genuine, real quantum expectation.
Sorry-free. -/
theorem divisorObs_expectation_real (ψ : StateSpace ℕ) :
    (inner ℂ ψ (divisorObs ψ) : ℂ).im = 0 :=
  expectation_real divisorObs divisorObs_isSymmetric ψ

/-! ### Summary -/

/-- **The HSLN realises the quantum-state axioms** (sorry-free, all on our own construction):
  1. observables (self-adjoint) have real expectations;
  2. global phase `e^{iθ}` leaves norm and expectation invariant;
  3. Born probabilities are nonnegative and sum to 1 for a unit state;
  4. the divisor function is a bona-fide self-adjoint observable with real expectation. -/
theorem quantum_state_axioms
    (T : E →ₗ[ℂ] E) (hT : T.IsSymmetric) (ψ : E) (θ : ℝ)
    (φ : StateSpace ℕ) (hφ : ‖φ‖ = 1) :
    (inner ℂ ψ (T ψ) : ℂ).im = 0 ∧
    ‖(Complex.exp (θ * I)) • ψ‖ = ‖ψ‖ ∧
    (∑ i ∈ φ.support, bornProb φ i = 1) ∧
    (inner ℂ φ (divisorObs φ) : ℂ).im = 0 :=
  ⟨expectation_real T hT ψ, globalPhase_norm θ ψ,
   bornProb_sum_eq_one φ hφ, divisorObs_expectation_real φ⟩

end HSLNQuantumState
