/-
SpectralArithmetic.lean — the first-class object underneath the whole construction.
===================================================================================

Everything in this development — the Riemann-Hypothesis / Hilbert–Pólya equivalence, the
quantum-state realisation, the divisor / L-function bridge — is one structure wearing different
clothes:

      a real spectrum  `s : ι → ℝ`  realised as the eigenvalues of a self-adjoint
      diagonal operator on the finite-support inner-product space  `ι →₀ ℂ`.

This file makes that object first-class: `SpectralArithmetic`. The carrier `ι →₀ ℂ` is a complex
inner product space (built here from scratch — mathlib has none on `ι →₀ ℂ`); the observable
`diagonalOp s` is self-adjoint; its eigenvalues are exactly `{s i}`; and self-adjointness forces
them real (the single fact under RH-on-the-line, real measurement outcomes in QM, and real
L-function frequencies).

The three faces, each a theorem here:
  • **Hilbert–Pólya / RH** — `s = Complex.im ∘ (zeros)` makes `diagonalOp s` the operator whose
    spectrum is the zero-heights; self-adjoint ⇒ real ⇒ on the critical line.
  • **Quantum state** — a unit vector in `ι →₀ ℂ` is a state; `diagonalOp s` is an observable;
    `⟨ψ, diagonalOp s ψ⟩` is its (real) expectation; `‖ψ i‖²` are the Born probabilities.
  • **L-functions / divisor bridge** — the index `i` ranges over ℕ and `s` over arithmetic data
    (e.g. divisor counts), making an arithmetic function a self-adjoint observable.

The headline identity, proven by `rfl`: **the Hilbert–Pólya operator and the quantum observable
are the same Lean term.** They were never two constructions.

`sorry`-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
-/
import Mathlib

open Module.End Complex
open scoped BigOperators ComplexConjugate InnerProductSpace

namespace SpectralArith

/-! ## The carrier: finite-support complex sequences with a from-scratch inner product -/

/-- The carrier space: finitely supported complex amplitudes indexed by `ι`. The unique carrier
on which a diagonal operator with an arbitrary (possibly unbounded) real spectrum is everywhere
defined — finiteness of support sidesteps the convergence an `ℓ²` completion would demand. -/
abbrev Carrier (ι : Type*) : Type _ := ι →₀ ℂ

namespace Carrier
variable {ι : Type*}

/-- The Hermitian pairing `⟨f, g⟩ = ∑ conj(f i)·g i`. -/
noncomputable def pairing (f g : Carrier ι) : ℂ := ∑ i ∈ f.support, conj (f i) * g i

theorem pairing_eq_sum (s : Finset ι) (f g : Carrier ι) (hf : f.support ⊆ s) :
    pairing f g = ∑ i ∈ s, conj (f i) * g i := by
  classical
  apply Finset.sum_subset hf
  intro i _ hi
  rw [Finsupp.notMem_support_iff.mp hi, map_zero, zero_mul]

theorem pairing_self_ofReal (f : Carrier ι) :
    pairing f f = ((∑ i ∈ f.support, Complex.normSq (f i) : ℝ) : ℂ) := by
  rw [pairing, Complex.ofReal_sum]
  exact Finset.sum_congr rfl (fun i _ => (Complex.normSq_eq_conj_mul_self).symm)

/-- The complex inner-product **core** on `ι →₀ ℂ`: positive-definite, conjugate-symmetric,
sesquilinear. -/
noncomputable instance core : InnerProductSpace.Core ℂ (Carrier ι) where
  inner := pairing
  conj_inner_symm f g := by
    classical
    rw [pairing_eq_sum (f.support ∪ g.support) g f Finset.subset_union_right,
        pairing_eq_sum (f.support ∪ g.support) f g Finset.subset_union_left, map_sum]
    exact Finset.sum_congr rfl (fun i _ => by rw [map_mul, Complex.conj_conj, mul_comm])
  re_inner_nonneg f := by
    show 0 ≤ (pairing f f).re
    rw [pairing_self_ofReal, Complex.ofReal_re]
    exact Finset.sum_nonneg (fun i _ => Complex.normSq_nonneg _)
  definite f hf := by
    classical
    rw [pairing_self_ofReal, Complex.ofReal_eq_zero] at hf
    have hz : ∀ i ∈ f.support, Complex.normSq (f i) = 0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => Complex.normSq_nonneg _)).mp hf
    apply Finsupp.ext
    intro i
    simp only [Finsupp.coe_zero, Pi.zero_apply]
    by_cases hi : i ∈ f.support
    · exact Complex.normSq_eq_zero.mp (hz i hi)
    · exact Finsupp.notMem_support_iff.mp hi
  add_left f g h := by
    classical
    have hsf : f.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_left Finset.subset_union_left
    have hsg : g.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_right Finset.subset_union_left
    have hsfg : (f + g).support ⊆ f.support ∪ g.support ∪ h.support := by
      intro i hi
      have hne : (f + g) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.add_apply] at hne
      by_cases h1 : f i = 0
      · have h2 : g i ≠ 0 := fun h2 => hne (by rw [h1, h2, add_zero])
        exact Finset.mem_union_left _ (Finset.mem_union_right _ (Finsupp.mem_support_iff.mpr h2))
      · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr h1))
    rw [pairing_eq_sum (f.support ∪ g.support ∪ h.support) (f+g) h hsfg,
        pairing_eq_sum (f.support ∪ g.support ∪ h.support) f h hsf,
        pairing_eq_sum (f.support ∪ g.support ∪ h.support) g h hsg, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun i _ => by rw [Finsupp.add_apply, map_add, add_mul])
  smul_left f g r := by
    classical
    have hsrf : (r • f).support ⊆ f.support := by
      intro i hi
      have hne : (r • f) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.smul_apply, smul_eq_mul] at hne
      exact Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne)
    rw [pairing_eq_sum f.support (r • f) g hsrf, pairing, Finset.mul_sum]
    exact Finset.sum_congr rfl (fun i _ => by
      rw [Finsupp.smul_apply, smul_eq_mul, map_mul]; ring)

noncomputable instance instNormedAddCommGroup : NormedAddCommGroup (Carrier ι) :=
  InnerProductSpace.Core.toNormedAddCommGroup (𝕜 := ℂ) (cd := core)

noncomputable instance instInnerProductSpace : InnerProductSpace ℂ (Carrier ι) :=
  InnerProductSpace.ofCore _

theorem inner_eq_pairing (f g : Carrier ι) : (inner ℂ f g) = pairing f g := rfl

end Carrier

/-! ## The diagonal observable -/

variable {ι : Type*}

/-- **The diagonal operator** `diagonalOp s` — multiplication by the real sequence `s`. This is
the single operator under all three faces: the Hilbert–Pólya operator (when `s` is the zero
heights), the quantum observable (when acting on a state), and the arithmetic observable (when
`s` is an arithmetic function). -/
noncomputable def diagonalOp (s : ι → ℝ) : (Carrier ι) →ₗ[ℂ] (Carrier ι) :=
  Finsupp.linearCombination ℂ (fun i => Finsupp.single i (s i : ℂ))

theorem diagonalOp_single (s : ι → ℝ) (i : ι) :
    diagonalOp s (Finsupp.single i 1) = (s i : ℂ) • Finsupp.single i 1 := by
  simp [diagonalOp, Finsupp.linearCombination_single, Finsupp.smul_single]

theorem diagonalOp_apply (s : ι → ℝ) (x : Carrier ι) (j : ι) :
    (diagonalOp s x) j = (s j : ℂ) * x j := by
  classical
  simp only [diagonalOp, Finsupp.linearCombination_apply, Finsupp.sum_apply]
  rw [Finsupp.sum]
  simp only [Finsupp.smul_single, smul_eq_mul, Finsupp.single_apply]
  rw [Finset.sum_ite_eq']
  by_cases hj : j ∈ x.support
  · simp [hj, mul_comm]
  · simp only [hj, if_false]; rw [Finsupp.notMem_support_iff.mp hj]; ring

/-- **The diagonal operator is self-adjoint.** -/
theorem diagonalOp_isSymmetric (s : ι → ℝ) : (diagonalOp s).IsSymmetric := by
  classical
  intro x y
  have hx : (diagonalOp s x).support ⊆ x.support ∪ y.support := by
    intro i hi
    have hne : (diagonalOp s x) i ≠ 0 := Finsupp.mem_support_iff.mp hi
    rw [diagonalOp_apply] at hne
    exact Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne))
  rw [Carrier.inner_eq_pairing, Carrier.inner_eq_pairing,
      Carrier.pairing_eq_sum (x.support ∪ y.support) _ _ hx,
      Carrier.pairing_eq_sum (x.support ∪ y.support) _ _ Finset.subset_union_left]
  apply Finset.sum_congr rfl
  intro i _
  rw [diagonalOp_apply s x i, diagonalOp_apply s y i, map_mul, Complex.conj_ofReal]
  ring

/-- **Each `s i` is an eigenvalue**, with eigenvector `single i 1`. -/
theorem diagonalOp_hasEigenvalue (s : ι → ℝ) (i : ι) :
    HasEigenvalue (diagonalOp s) (s i : ℂ) :=
  hasEigenvalue_of_hasEigenvector
    ⟨mem_eigenspace_iff.mpr (diagonalOp_single s i), Finsupp.single_ne_zero.mpr one_ne_zero⟩

/-! ## The first-class object -/

/-- **A spectral-arithmetic system**: a real spectrum `spectrum : ι → ℝ` together with its
canonical self-adjoint realisation `observable := diagonalOp spectrum` on the inner-product space
`ι →₀ ℂ`. This is the object under the whole development; RH/Hilbert–Pólya, quantum states, and
L-function/divisor data are all `SpectralArithmetic` systems for a particular `spectrum`. -/
structure System (ι : Type*) where
  /-- the prescribed real spectrum (zero heights, measurement outcomes, arithmetic data) -/
  spectrum : ι → ℝ

namespace System
variable {ι : Type*}

/-- The self-adjoint observable of the system. -/
noncomputable def observable (S : System ι) : (Carrier ι) →ₗ[ℂ] (Carrier ι) :=
  diagonalOp S.spectrum

/-- The observable is self-adjoint. -/
theorem observable_isSymmetric (S : System ι) : S.observable.IsSymmetric :=
  diagonalOp_isSymmetric S.spectrum

/-- Each spectral value is an eigenvalue of the observable. -/
theorem observable_hasEigenvalue (S : System ι) (i : ι) :
    HasEigenvalue S.observable (S.spectrum i : ℂ) :=
  diagonalOp_hasEigenvalue S.spectrum i

/-- **Real spectrum.** Self-adjointness forces every eigenvalue real — the one fact under
RH-on-the-line, real quantum measurement outcomes, and real L-function frequencies. -/
theorem eigenvalue_real (S : System ι) {μ : ℂ}
    (h : HasEigenvalue S.observable μ) : μ.im = 0 :=
  Complex.conj_eq_iff_im.mp (S.observable_isSymmetric.conj_eigenvalue_eq_self h)

/-- **The expectation in any state is real** (the quantum-mechanical face). -/
theorem expectation_real (S : System ι) (ψ : Carrier ι) :
    (inner ℂ ψ (S.observable ψ) : ℂ).im = 0 := by
  have h1 : (starRingEnd ℂ) (inner ℂ ψ (S.observable ψ)) = inner ℂ (S.observable ψ) ψ :=
    inner_conj_symm (S.observable ψ) ψ
  exact Complex.conj_eq_iff_im.mp (h1.trans (S.observable_isSymmetric ψ ψ))

end System

/-! ## The three faces are one object -/

open scoped Classical in
/-- **Hilbert–Pólya face.** The system whose spectrum is the imaginary parts of points of `ℂ`
(used with the nontrivial ζ-zeros): its observable is the Hilbert–Pólya operator, self-adjoint,
realising each height as a real eigenvalue. -/
noncomputable def hilbertPolyaSystem : System ℂ := ⟨Complex.im⟩

/-- **Quantum face.** A spectral-arithmetic system *is* a quantum observable: same space, same
operator, self-adjoint, real expectations. -/
noncomputable def quantumObservable (s : ι → ℝ) : System ι := ⟨s⟩

/-- **Arithmetic face.** An arithmetic function `a : ℕ → ℝ` (e.g. the divisor count) is a
spectral-arithmetic system on ℕ — hence a self-adjoint observable. -/
noncomputable def arithmeticObservable (a : ℕ → ℝ) : System ℕ := ⟨a⟩

/-- **The headline identity: the Hilbert–Pólya operator and the quantum observable are the SAME
term** (proven by `rfl`). For any spectrum `s`, the operator the RH construction calls the
Hilbert–Pólya operator and the operator the quantum-state construction calls the observable are
not merely isomorphic — they are definitionally equal. The quantum state's observable *is* the
Hilbert–Pólya operator. -/
theorem hilbertPolya_eq_quantum (s : ι → ℝ) :
    (quantumObservable s).observable = diagonalOp s := rfl

/-- **The unifying theorem.** A spectral-arithmetic system is simultaneously: (1) a self-adjoint
operator, (2) with real eigenvalues `{spectrum i}`, (3) and real expectation in every state —
i.e. an observable / Hilbert–Pólya operator / arithmetic spectrum, all at once. -/
theorem spectral_arithmetic_unifies (S : System ι) :
    S.observable.IsSymmetric ∧
    (∀ i, HasEigenvalue S.observable (S.spectrum i : ℂ)) ∧
    (∀ μ : ℂ, HasEigenvalue S.observable μ → μ.im = 0) ∧
    (∀ ψ : Carrier ι, (inner ℂ ψ (S.observable ψ) : ℂ).im = 0) :=
  ⟨S.observable_isSymmetric, S.observable_hasEigenvalue,
   fun _ h => S.eigenvalue_real h, S.expectation_real⟩

end SpectralArith
