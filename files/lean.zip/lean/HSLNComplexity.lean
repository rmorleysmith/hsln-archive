/-
HSLNComplexity.lean — P, NP, and the composition/verification asymmetry, wired honestly.
=========================================================================================

A faithful Lean statement of P vs NP, with the open separation isolated as a single `def`,
and the HSLN "composition builds, it can't un-build" asymmetry wired as a clearly-labelled
*reformulation candidate* — carried as a hypothesis-iff, never asserted as fact.

mathlib has Turing machines and `TM2ComputableInPolyTime`, but the latter is `Type`-valued
evidence, not a `Prop`, and there is no `P`/`NP`/Cook–Levin. So we model the standard textbook
definitions abstractly: a decision problem is a predicate on inputs; "poly-time computable" and
"poly-time verifiable" are carried as abstract predicates with exactly the closure properties
the definitions require. Everything that is *claimed* (P ⊆ NP; the asymmetry ⇒ separation) is
proven sorry-free; the genuinely open content (`PNeqNP`) is one `def` with no incoming proof.

The HSLN angle (the combinatorial content [REDACTED NAME] is after). Our factoring work
(`viz/hsln_two_rings.py`) established: the composition map `(p, q) ↦ p·q` — a single convolution
in the Cauchy/Dirichlet ring — is cheap (forward = poly-time, "P-like"), but its inverse
(recover `p, q` from `N`) is the factoring wall (search = "NP-like"). This is the *general*
shape of P vs NP: a relation `R x w` ("`w` is a witness for `x`") whose forward check is easy but
whose witness-search is hard. We make that precise: `VerificationAsymmetry R` says the verifier
is poly-time but the search is not — and we prove (sorry-free) that this asymmetry, for an
NP relation, *implies* `P ≠ NP`. Whether any concrete composition (factoring, subset-sum, …)
*has* the asymmetry is the open content — exactly P vs NP.

`sorry`-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
-/
import Mathlib

namespace HSLNComplexity

/-! ### Decision problems and an abstract poly-time predicate -/

/-- A **decision problem / language**: a predicate on binary strings (inputs). -/
abbrev Language : Type := List Bool → Prop

/-- An **abstract "poly-time computable" predicate** on decision problems, carrying exactly the
two closure properties the textbook definition guarantees:
  • `decClosure` — if `L` is poly-time decidable and `M` agrees with `L` on all inputs, then `M`
    is poly-time decidable (extensionality / well-definedness);
  • `verifierClosure` — "ignore the certificate": a poly-time *decider* for `L` yields a poly-time
    *verifier* for `L` (the witness of `P ⊆ NP`). Modelled by: poly-time-decidable `L` implies the
    relation `fun x _ => L x` (a verifier that ignores its certificate) is poly-time. -/
structure PolyModel where
  /-- `L` is decidable in polynomial time -/
  polyDecidable : Language → Prop
  /-- a 2-argument relation (input, certificate) is checkable in polynomial time -/
  polyCheckable : (List Bool → List Bool → Prop) → Prop
  /-- poly-time decidability respects pointwise equality of languages -/
  decClosure : ∀ {L M : Language}, polyDecidable L → (∀ x, L x ↔ M x) → polyDecidable M
  /-- "ignore the certificate": a poly decider gives a poly checker that drops its 2nd arg -/
  ignoreCert : ∀ {L : Language}, polyDecidable L → polyCheckable (fun x _ => L x)

variable (Φ : PolyModel)

/-! ### P and NP -/

/-- **The class P** (relative to a poly model): the poly-time-decidable languages. -/
def inP (L : Language) : Prop := Φ.polyDecidable L

/-- **The class NP**: `L` is in NP iff there is a poly-time-checkable relation `V` (the verifier)
and a polynomial certificate-length bound `b : ℕ → ℕ` such that `x ∈ L` iff some certificate of
length `≤ b |x|` makes `V` accept. -/
def inNP (L : Language) : Prop :=
  ∃ (V : List Bool → List Bool → Prop) (b : ℕ → ℕ),
    Φ.polyCheckable V ∧ ∀ x, L x ↔ ∃ w : List Bool, w.length ≤ b x.length ∧ V x w

/-- **P ⊆ NP** — sorry-free. A poly-time decider is a poly-time verifier that ignores its
certificate (certificate length bound `0`, the constant polynomial). -/
theorem inP_subseteq_inNP {L : Language} (h : inP Φ L) : inNP Φ L := by
  refine ⟨fun x _ => L x, fun _ => 0, Φ.ignoreCert h, ?_⟩
  intro x
  constructor
  · intro hx; exact ⟨[], by simp, hx⟩
  · rintro ⟨w, _, hx⟩; exact hx

/-- **P = NP** as a proposition: the two classes coincide (every NP language is in P). -/
def PeqNP : Prop := ∀ L, inNP Φ L → inP Φ L

/-- **P ≠ NP** — the open separation: some NP language is not in P. This is the single open
node; no proven arrow points into it. -/
def PNeqNP : Prop := ∃ L, inNP Φ L ∧ ¬ inP Φ L

/-- **`P ≠ NP` is the negation of `P = NP`** — sorry-free. The two formulations are
classically equivalent (`PeqNP ↔ ¬ PNeqNP`), so the open node is exactly "P = NP fails". -/
theorem pneqnp_iff_not_peqnp : PNeqNP Φ ↔ ¬ PeqNP Φ := by
  constructor
  · rintro ⟨L, hNP, hnP⟩ hPeq; exact hnP (hPeq L hNP)
  · intro h
    by_contra hcon
    apply h
    intro L hNP
    by_contra hnP
    exact hcon ⟨L, hNP, hnP⟩

/-! ### The composition / verification asymmetry — the HSLN reformulation candidate

Our factoring result: `(p,q) ↦ p·q` is one cheap convolution forward, but inverting it is the
search wall. Abstractly: a witness relation `R x w` whose *forward check* is poly-time but whose
*witness search* is not. We make this precise and prove it forces a separation. -/

/-- A **witness relation** `R x w` ("`w` certifies `x`") together with a certificate bound `b`,
defining the NP language `fun x => ∃ w, |w| ≤ b|x| ∧ R x w` — e.g. `R N (p,q-encoded) := N = p·q`,
whose language is "is composite". -/
structure WitnessRelation where
  /-- the relation: `R x w` means `w` is a witness for `x` -/
  R : List Bool → List Bool → Prop
  /-- polynomial certificate-length bound -/
  bound : ℕ → ℕ
  /-- the verifier is poly-time (forward check is cheap — e.g. one multiplication) -/
  verifier_poly : Φ.polyCheckable R

/-- The NP language defined by a witness relation. -/
def WitnessRelation.lang (W : WitnessRelation Φ) : Language :=
  fun x => ∃ w : List Bool, w.length ≤ W.bound x.length ∧ W.R x w

/-- **The language of a witness relation is in NP** — sorry-free. Its verifier is poly-time by
construction; this is exactly the "easy to check a witness" half. (For factoring: checking
`N = p·q` is one multiplication, but the language "N is composite" needs the witness `(p,q)`.) -/
theorem witnessRelation_inNP (W : WitnessRelation Φ) : inNP Φ W.lang :=
  ⟨W.R, W.bound, W.verifier_poly, fun _ => Iff.rfl⟩

/-- **The verification/search asymmetry**: the witness relation's *language* is NOT poly-time
decidable — i.e. checking a given witness is easy (built in) but *deciding membership without a
witness* (the inverse/search problem) is hard. This is the HSLN "composition builds, it can't
un-build" made into a complexity statement. -/
def VerificationAsymmetry (W : WitnessRelation Φ) : Prop := ¬ inP Φ W.lang

/-- **The asymmetry implies P ≠ NP** — sorry-free. If any witness relation has the
verification/search asymmetry (cheap to verify, hard to decide), then P ≠ NP: its language is in
NP (`witnessRelation_inNP`) but, by hypothesis, not in P. This is the precise sense in which the
factoring-style "2-from-1 collapse" *is* the P vs NP separation — a single hard-to-invert
composition certifies it. -/
theorem pNeqNP_of_asymmetry {W : WitnessRelation Φ} (h : VerificationAsymmetry Φ W) :
    PNeqNP Φ :=
  ⟨W.lang, witnessRelation_inNP Φ W, h⟩

/-- **Reformulation candidate (carried, not asserted).** Conversely, if `P ≠ NP` then *some*
witness relation must exhibit the asymmetry — the separation is *witnessed* by a concrete
hard-to-invert composition. We carry this direction as a hypothesis (it is the substantive
content of "every NP-hard problem gives such a relation"); together with `pNeqNP_of_asymmetry`
it makes the asymmetry *equivalent* to the separation. Whether a *specific* composition
(factoring, subset-sum, …) realises it is the open combinatorial question. -/
def AsymmetryWitnessesSeparation : Prop :=
  PNeqNP Φ → ∃ W : WitnessRelation Φ, VerificationAsymmetry Φ W

/-- **The asymmetry is equivalent to the separation** — sorry-free, given the carried converse.
`P ≠ NP ⟺ some hard-to-invert composition exists`. The forward direction is proven outright
(`pNeqNP_of_asymmetry`); the reverse is the cited/carried `AsymmetryWitnessesSeparation`. -/
theorem asymmetry_iff_separation (hconv : AsymmetryWitnessesSeparation Φ) :
    (∃ W : WitnessRelation Φ, VerificationAsymmetry Φ W) ↔ PNeqNP Φ :=
  ⟨fun ⟨_, h⟩ => pNeqNP_of_asymmetry Φ h, hconv⟩

/-! ### Summary -/

/-- **The complexity frontier, assembled** (sorry-free): P ⊆ NP; `P ≠ NP ⟺ ¬(P = NP)`; the
verification/search asymmetry of a hard-to-invert composition implies the separation; and (given
the carried converse) is equivalent to it. The open node is `PNeqNP` — equivalently, the
existence of one composition that is cheap to verify but hard to invert. -/
theorem complexity_summary (hconv : AsymmetryWitnessesSeparation Φ) :
    (∀ L, inP Φ L → inNP Φ L) ∧
    (PNeqNP Φ ↔ ¬ PeqNP Φ) ∧
    (∀ W : WitnessRelation Φ, VerificationAsymmetry Φ W → PNeqNP Φ) ∧
    ((∃ W : WitnessRelation Φ, VerificationAsymmetry Φ W) ↔ PNeqNP Φ) :=
  ⟨fun _ => inP_subseteq_inNP Φ,
   pneqnp_iff_not_peqnp Φ,
   fun _ => pNeqNP_of_asymmetry Φ,
   asymmetry_iff_separation Φ hconv⟩

end HSLNComplexity
