/-
HSLNHodge.lean — the Hodge conjecture through the Chern-character bridge.
========================================================================

The **Hodge conjecture** (Clay Millennium): on a smooth projective complex variety `X`, every
rational Hodge class — a class in `H^{2k}(X,ℚ) ∩ H^{k,k}(X)` — is a `ℚ`-linear combination of
classes of algebraic cycles of codimension `k`. Equivalently, the cycle class map is surjective
onto the Hodge classes.

This sits *directly* on top of `HSLNKTheory.lean`. There the **Chern character** is a ring
homomorphism `ch : K(X) → H*(X,ℚ)`; here the precise relevant facts are:

  * **Algebraic ⊆ Hodge** (a THEOREM): the class of any algebraic cycle / the Chern class of any
    algebraic bundle is a Hodge class of the correct type `(k,k)`. So `ch(K_alg(X)) ⊆ ⊕ₖ Hdg^k`.
  * **The conjecture is the REVERSE** (open): every Hodge class is algebraic, i.e. `ch`
    restricted to algebraic K-theory is *surjective* onto the Hodge classes.

The genuinely sorry-free content here:
  • the **Hodge decomposition** as an abstract bigrading, with the multiplicativity
    `H^{p,q}·H^{p',q'} ⊆ H^{p+p',q+q'}`;
  • **Hodge classes form a graded subring**: `hodge_mul` — the cup product of two Hodge classes
    is a Hodge class (the diagonal `H^{k,k}` is closed under `⌣`). This is the structural reason
    `ch` (a ring hom) lands its image inside the Hodge ring;
  • **Algebraic ⊆ Hodge** carried as the proven inclusion, and `hodgeConjecture_iff_eq`: the
    conjecture ⇔ the two `ℚ`-subspaces coincide (sorry-free, `le_antisymm`);
  • the conjecture stated as `HodgeConjecture : Prop` — the lone open core.

Essential caveats (documented, not stated as theorems): the **integral** Hodge conjecture is
FALSE (Atiyah–Hirzebruch 1962, via topological K-theory torsion — note the K-theory link!), so
the `ℚ` coefficients are necessary; and the **Kähler** (non-projective) version is FALSE (Voisin
2002). The proven case is **Lefschetz `(1,1)`** (`k = 1`, divisors; Lefschetz 1924).

Verified sorry-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`); exercised
in `viz/hsln_hodge.py`.

Refs: Hodge conjecture (Clay Millennium problem description); Lefschetz (1924); Atiyah–Hirzebruch,
*Analytic cycles on complex manifolds* (1962); Voisin (2002); Grothendieck (Chern character).
-/
import Mathlib

namespace HSLNHodge

variable {A : Type*} [CommRing A] [Algebra ℚ A]

/-! ### The Hodge decomposition as an abstract bigrading -/

/-- **An abstract Hodge structure** on a `ℚ`-cohomology algebra `A`. The pieces `comp p q` model
`H^{p,q}(X)` (the rational shadow of the Hodge decomposition `Hⁿ(X,ℂ) = ⊕_{p+q=n} H^{p,q}`),
with the cup-product compatibility `H^{p,q} ⌣ H^{p',q'} ⊆ H^{p+p', q+q'}`. This is the
formalizable linear-algebra core — no geometry required. -/
structure HodgeStr (A : Type*) [CommRing A] [Algebra ℚ A] where
  /-- the `(p,q)` Hodge piece (rational model of `H^{p,q}`) -/
  comp : ℕ → ℕ → Submodule ℚ A
  /-- cup product respects the bigrading: `H^{p,q} ⌣ H^{p',q'} ⊆ H^{p+p', q+q'}` -/
  mul_mem' : ∀ {p q p' q' : ℕ} {a b : A}, a ∈ comp p q → b ∈ comp p' q' →
    a * b ∈ comp (p + p') (q + q')

/-- **Hodge classes in degree `2k`.** The "diagonal" piece `H^{k,k}` — the rational classes of
type `(k,k)`, where Hodge classes live. -/
def hodgeClass (H : HodgeStr A) (k : ℕ) : Submodule ℚ A := H.comp k k

/-- **Hodge classes form a graded subring** (the key structural theorem). The cup product of a
Hodge class of degree `k` and one of degree `k'` is a Hodge class of degree `k + k'`: the
diagonal `H^{k,k}` is closed under `⌣`. This is exactly why the Chern character (a ring
homomorphism) lands its image inside the Hodge ring. Sorry-free. -/
theorem hodge_mul (H : HodgeStr A) {k k' : ℕ} {a b : A}
    (ha : a ∈ hodgeClass H k) (hb : b ∈ hodgeClass H k') :
    a * b ∈ hodgeClass H (k + k') :=
  H.mul_mem' ha hb

/-! ### Algebraic classes, the proven inclusion, and the conjecture -/

/-- **The Hodge picture as data.** A `HodgeStr` together with the algebraic classes `alg k`
(the `ℚ`-span of codimension-`k` cycle classes / Chern classes of algebraic bundles) and the
**proven inclusion** `alg k ≤ hodgeClass k` (algebraic ⇒ Hodge of type `(k,k)`; standard Hodge
theory). The inclusion is the proven direction; the conjecture is its reverse. -/
structure HodgeData (A : Type*) [CommRing A] [Algebra ℚ A] where
  /-- the Hodge bigrading -/
  H : HodgeStr A
  /-- algebraic classes in codimension `k` (`ℚ`-span of cycle / Chern classes) -/
  alg : ℕ → Submodule ℚ A
  /-- **the proven direction**: every algebraic class is a Hodge class (Hodge theory) -/
  alg_le_hodge : ∀ k, alg k ≤ hodgeClass H k

/-- **The Hodge conjecture** — the OPEN core, stated honestly. Every Hodge class is algebraic:
`hodgeClass k ≤ alg k` for every `k`. Combined with the proven `alg_le_hodge`, this is the
equality of the two `ℚ`-subspaces. -/
def HodgeConjecture (D : HodgeData A) : Prop := ∀ k, hodgeClass D.H k ≤ D.alg k

/-- **The conjecture ⇔ the two subspaces coincide** — sorry-free. Given the proven inclusion
`alg ≤ Hodge`, the Hodge conjecture is exactly the statement that algebraic classes and Hodge
classes are *equal* in every codimension. (`le_antisymm` in the `Submodule` lattice.) -/
theorem hodgeConjecture_iff_eq (D : HodgeData A) :
    HodgeConjecture D ↔ ∀ k, D.alg k = hodgeClass D.H k := by
  constructor
  · intro h k; exact le_antisymm (D.alg_le_hodge k) (h k)
  · intro h k; rw [h k]

/-- **Algebraic classes are Hodge classes** — sorry-free (it is `D.alg_le_hodge`, surfaced as a
theorem). The cleanly-proven half of the picture: `alg k ⊆ Hdg^k`. The conjecture is the only
missing inclusion. -/
theorem alg_subset_hodge (D : HodgeData A) (k : ℕ) : D.alg k ≤ hodgeClass D.H k :=
  D.alg_le_hodge k

/-! ### The Chern-character bridge to K-theory -/

/-- **Chern classes are Hodge classes** (the K-theory bridge), modelled abstractly. If a class
`c` lies in the algebraic classes `alg k` — e.g. `c = chₖ(E)` for an algebraic bundle `E`, via
the `HSLNKTheory.chernChar` ring homomorphism — then `c` is a Hodge class. So the Chern
character of algebraic K-theory lands inside the Hodge ring; the Hodge conjecture is precisely
the *surjectivity* of that map onto the Hodge classes. Sorry-free. -/
theorem chern_mem_hodge (D : HodgeData A) {k : ℕ} {c : A} (hc : c ∈ D.alg k) :
    c ∈ hodgeClass D.H k :=
  D.alg_le_hodge k hc

/-- **The Chern image is closed under cup product inside the Hodge ring.** Products of algebraic
Hodge classes are Hodge classes (`hodge_mul`): the algebraic classes map into a graded subring
of the Hodge ring. This is the structural shadow of "`chernChar` is a ring homomorphism"
(`HSLNKTheory.chernChar_dirichlet`) transported to the Hodge setting. Sorry-free. -/
theorem alg_mul_mem_hodge (D : HodgeData A) {k k' : ℕ} {a b : A}
    (ha : a ∈ D.alg k) (hb : b ∈ D.alg k') :
    a * b ∈ hodgeClass D.H (k + k') :=
  hodge_mul D.H (D.alg_le_hodge k ha) (D.alg_le_hodge k' hb)

/-! ### Proven case, and the false generalisations (documented as Props) -/

/-- **The Lefschetz `(1,1)`-theorem** (Lefschetz 1924) — the PROVEN case `k = 1`: every Hodge
class of degree 2 is algebraic (a `ℚ`-combination of divisor classes). Stated as a `Prop`
(citing Lefschetz; the proof needs the exponential sheaf sequence / Picard group, beyond our
abstract substrate). -/
def Lefschetz_11 (D : HodgeData A) : Prop := hodgeClass D.H 1 ≤ D.alg 1

/-- **The integral Hodge conjecture** — FALSE (Atiyah–Hirzebruch 1962). The naive `ℤ`-coefficient
version (every integral `(k,k)` class is an *integral* combination of cycle classes) fails; the
obstruction is detected by **topological K-theory** (Atiyah–Hirzebruch spectral-sequence
differentials) — a direct K-theory link. We model the integral classes as a sub-`ℤ`-structure
`algℤ k` inside `hdgℤ k`; the integral conjecture `hdgℤ k ≤ algℤ k` is the statement known to be
false in general. Documented as a `Prop`, NOT asserted. -/
def IntegralHodgeConjecture (hdgℤ algℤ : ℕ → Submodule ℤ A) : Prop := ∀ k, hdgℤ k ≤ algℤ k

/-! ### Integral Hodge modulo torsion — and why E8×E8 lives in the clean regime

The Atiyah–Hirzebruch counterexamples to the *integral* Hodge conjecture are **torsion classes**
(detected by topological-K-theory torsion — the free/torsion split that `HSLNKTheory`'s
`K₀(point) = ℤ` and reduced `K̃₀` already make precise). So the natural refinement is "integral
Hodge **modulo torsion**": every integral Hodge class is (algebraic) + (torsion). On a
**torsion-free** coefficient lattice the torsion term vanishes and this collapses back to the
plain integral statement.

This is exactly the E8×E8 regime. The E8 lattice is **even, unimodular, torsion-free**, so the
E8×E8 DNA lattice carries no torsion — the "modulo torsion" qualifier is *vacuous* there, and the
Atiyah–Hirzebruch obstruction (which is pure torsion) cannot even arise. The HSLN projection onto
E8×E8 therefore lives in precisely the regime where integral-Hodge-mod-torsion = integral Hodge,
and where rationalising (`⊗ ℚ`) loses nothing. -/

/-- **Integral Hodge modulo torsion** (Wikipedia's refined statement): every class in
`H^{2k}(X,ℤ) ∩ H^{k,k}` is the sum of a **torsion class** and the class of an integral algebraic
cycle, i.e. `hdgℤ k ≤ algℤ k ⊔ tors`. Stated as a `Prop` — still FALSE in general (Kollár 1992;
Benoist–Ottem give *non-torsion* counterexamples), so NOT asserted; but it is the form the E8×E8
torsion-free lattice makes clean. -/
def IntegralHodgeModTorsion (hdgℤ algℤ : ℕ → Submodule ℤ A) (tors : Submodule ℤ A) : Prop :=
  ∀ k, hdgℤ k ≤ algℤ k ⊔ tors

/-- **On a torsion-free lattice, "modulo torsion" is vacuous** — sorry-free. If the torsion
submodule is trivial (`tors = ⊥`, the E8×E8 even-unimodular case), then integral-Hodge-modulo-
torsion is *exactly* the integral Hodge conjecture: the torsion correction term `⊔ ⊥` collapses.
This is the precise sense in which the HSLN E8×E8 projection sits in the clean regime — the
Atiyah–Hirzebruch torsion obstruction cannot arise on a torsion-free lattice. -/
theorem integralHodgeModTorsion_iff_of_torsionFree
    (hdgℤ algℤ : ℕ → Submodule ℤ A) (tors : Submodule ℤ A) (htf : tors = ⊥) :
    IntegralHodgeModTorsion hdgℤ algℤ tors ↔ IntegralHodgeConjecture hdgℤ algℤ := by
  subst htf; simp [IntegralHodgeModTorsion, IntegralHodgeConjecture]

/-- **The torsion correction only ever weakens the statement** — sorry-free. The plain integral
Hodge conjecture implies its modulo-torsion form (adding `⊔ tors` can only enlarge the target).
So modulo-torsion is the genuinely weaker, more believable statement — and on E8×E8 (`tors = ⊥`)
the two coincide by `integralHodgeModTorsion_iff_of_torsionFree`. -/
theorem integralHodgeModTorsion_of_integralHodge
    (hdgℤ algℤ : ℕ → Submodule ℤ A) (tors : Submodule ℤ A)
    (h : IntegralHodgeConjecture hdgℤ algℤ) :
    IntegralHodgeModTorsion hdgℤ algℤ tors :=
  fun k => le_trans (h k) le_sup_left

/-! ### Summary -/

/-- **The Hodge picture, assembled.** (1) Hodge classes form a graded subring (the diagonal is
closed under `⌣`); (2) algebraic ⊆ Hodge (the proven direction); (3) products of algebraic
classes are Hodge; (4) the conjecture ⇔ equality of the two subspaces. Everything proven except
the surjectivity `Hodge ⊆ algebraic` — `HodgeConjecture`, the open Millennium core, which is the
surjectivity of the `HSLNKTheory` Chern character onto the Hodge classes. -/
theorem hodge_summary (D : HodgeData A) :
    (∀ {k k' : ℕ} {a b : A}, a ∈ hodgeClass D.H k → b ∈ hodgeClass D.H k' →
        a * b ∈ hodgeClass D.H (k + k')) ∧
    (∀ k, D.alg k ≤ hodgeClass D.H k) ∧
    (HodgeConjecture D ↔ ∀ k, D.alg k = hodgeClass D.H k) :=
  ⟨fun ha hb => hodge_mul D.H ha hb, alg_subset_hodge D, hodgeConjecture_iff_eq D⟩

end HSLNHodge
