/-
HSLNSerre.lean — the Serre (graded-covariant) derivative, plumbed into the HSLN ring.
====================================================================================

The Lie-derivative figure (viz/hsln_lie_landscape.py / figure 63) exercised the Serre
derivative  ϑ_k = D − (k/12)·E₂  numerically: it is the *covariant* version of the grading
generator θ = q d/dq, the one that keeps a weight-k form inside the graded ring (it lands in
weight k+2). [REDACTED NAME] asked us to make the "we use the proven Serre derivative" claim literally
true in the Lean build rather than only in prose.

This file does NOT re-prove the Serre derivative — mathlib already has it, sorry-free, as
`Derivative.serreDerivative` (Mathlib/NumberTheory/ModularForms/Derivative.lean, Seewoo Lee,
PR #36405). We *import* it and prove the structural facts our graded-ring story needs:

  • `serre_add`, `serre_smul`  — ϑ_k is ℂ-linear;
  • `serre_leibniz`            — the **graded Leibniz rule**: ϑ is a degree-(+2) graded
                                 derivation, ϑ_{k₁+k₂}(F·G) = (ϑ_{k₁}F)·G + F·(ϑ_{k₂}G).
                                 This is the formal core of "the covariant derivative stays in
                                 the ring" — the same closure HSLNHodge proves for cup product;
  • `serre_leibniz₃`           — falls straight out of the binary rule applied twice: the
                                 covariant derivative distributes across THREE weight-graded
                                 factors (composing three networks' landscapes);
  • `serre_mdiff`              — ϑ maps the smooth (MDifferentiable) landscape ring to itself.

HONEST SCOPE.  mathlib's file lists "Serre derivative preserves modularity (ϑ_k M_k ⊆ M_{k+2})"
and "Ramanujan's identities" as explicit TODOs. So the weight-raising witness ϑ₄E₄ = −E₆/3 that
figure 63 shows numerically is NOT yet machine-checked anywhere — we do not claim it here. What
IS machine-checked is the operator and its derivation algebra, which is exactly what makes ϑ a
graded derivation on the HSLN composition ring.
-/
import Mathlib

open UpperHalfPlane hiding I
open Real Complex
open scoped Manifold

namespace HSLNSerre

open Derivative

/-- ϑ_k is additive (one half of ℂ-linearity). Thin re-export of mathlib's
`serreDerivative_add` in our namespace's vocabulary. -/
theorem serre_add (k : ℂ) (F G : ℍ → ℂ) (hF : MDiff F) (hG : MDiff G) :
    serreDerivative k (F + G) = serreDerivative k F + serreDerivative k G :=
  serreDerivative_add k F G hF hG

/-- ϑ_k commutes with scalars (the other half of ℂ-linearity). -/
theorem serre_smul (k c : ℂ) (F : ℍ → ℂ) (hF : MDiff F) :
    serreDerivative k (c • F) = c • serreDerivative k F :=
  serreDerivative_smul k c F hF

/-- **Graded Leibniz rule.** The Serre derivative is a degree-`(+2)` graded derivation on the
graded ring of modular forms: differentiating a weight-`k₁` form times a weight-`k₂` form gives
the weight-`(k₁+k₂)` Serre derivative, split by Leibniz. This is the infinitesimal companion of
the closure theorem `HSLNHodge.hodge_mul` (cup product stays in the graded subring): the
covariant grading flow never leaves the ring. -/
theorem serre_leibniz (k₁ k₂ : ℂ) (F G : ℍ → ℂ) (hF : MDiff F) (hG : MDiff G) :
    serreDerivative (k₁ + k₂) (F * G)
      = serreDerivative k₁ F * G + F * serreDerivative k₂ G :=
  serreDerivative_mul k₁ k₂ F G hF hG

/-- **Triple graded Leibniz** — falls naturally out of the binary rule applied twice.
Composing three trained landscapes `F ⋆ G ⋆ H` (the HSLN composition is pointwise product),
the covariant derivative distributes across all three weight-graded factors. -/
theorem serre_leibniz₃ (k₁ k₂ k₃ : ℂ) (F G H : ℍ → ℂ)
    (hF : MDiff F) (hG : MDiff G) (hH : MDiff H) :
    serreDerivative (k₁ + k₂ + k₃) (F * G * H)
      = serreDerivative k₁ F * G * H
        + F * serreDerivative k₂ G * H
        + F * G * serreDerivative k₃ H := by
  have hFG : MDiff (F * G) := hF.mul hG
  rw [serreDerivative_mul (k₁ + k₂) k₃ (F * G) H hFG hH,
      serreDerivative_mul k₁ k₂ F G hF hG]
  ring

/-- ϑ_k preserves MDifferentiability: it maps the smooth landscape ring into itself, so the
graded derivation can be iterated (e.g. `serre_leibniz₃` needs `MDiff (F*G)`, supplied by
`MDifferentiable.mul`). -/
theorem serre_mdiff (k : ℂ) {F : ℍ → ℂ} (hF : MDiff F) :
    MDiff (serreDerivative k F) :=
  serreDerivative_mdifferentiable k hF

end HSLNSerre
