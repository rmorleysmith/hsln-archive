/-
SpectralBosonFermion.lean — bosons, fermions, and classical observables on the System space.
=============================================================================================

Extrapolating from `SpectralArithmetic.System` (a self-adjoint diagonal observable on the
finite-support complex inner-product space). Identical particles live not in the bare tensor
power but in its symmetric (bosonic) or antisymmetric (fermionic) part; classical-mechanics
quantities (mass, momentum) are *additive self-adjoint observables* whose expectation splits
over the constituents of a composite. We formalise the parts that are genuine theorems and
mark the physics postulates honestly.

PROVEN (machine-checked, sorry-free):
  • `pauli_exclusion`           — two fermions in the same single-particle state is the ZERO
    vector: `ι v * ι v = 0` in the exterior algebra (mathlib `ExteriorAlgebra.ι_sq_zero`). This
    is the Pauli exclusion principle as a theorem, not a postulate.
  • `expectation_real`          — a self-adjoint observable has real expectation (the
    `System` fact, restated for a general inner product space).
  • `additiveObs`               — the composite observable `A ⊗ I + I ⊗ B` (total mass / total
    momentum of a two-part system: a single-particle observable summed over the parts).
  • `compositeMass`/`mass_additive` — total mass of a composite = sum of constituent masses
    (the non-relativistic additive model), as a clean ℝ-valued sum, with `[] ↦ 0`.

POSTULATE (carried as data/`Prop`, never derived — they are physics, not mathematics):
  • `Statistics` / `spinStatistics` — the spin–statistics connection (integer spin ↔ boson ↔
    symmetric; half-integer ↔ fermion ↔ antisymmetric). A deep QFT theorem, out of scope to
    derive; encoded as a labelled correspondence.
  • mass-additivity is the NON-relativistic convention; relativistically mass is sub-additive by
    the binding energy (`Δm = E_b/c²`). Documented, and the additive model is named as such.

`sorry`-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
-/
import Mathlib

open scoped BigOperators

namespace SpectralBosonFermion

/-! ## Fermions: the Pauli exclusion principle as a theorem -/

variable {R : Type*} [CommRing R] {M : Type*} [AddCommGroup M] [Module R M]

/-- **Pauli exclusion principle** (PROVEN). The antisymmetric two-particle state with both
particles in the same single-particle state `v` is the zero vector: in the exterior algebra
`ι v * ι v = 0` (`v ∧ v = 0`). No two identical fermions occupy the same state — a theorem of
the exterior algebra (`ExteriorAlgebra.ι_sq_zero`), not a physical postulate. -/
theorem pauli_exclusion (v : M) :
    (ExteriorAlgebra.ι R v) * (ExteriorAlgebra.ι R v) = 0 :=
  ExteriorAlgebra.ι_sq_zero v

/-- **Fermionic antisymmetry** (PROVEN). Swapping two fermions flips the sign: in the exterior
algebra `ι a * ι b = - (ι b * ι a)`. Combined with `pauli_exclusion` this is the full
antisymmetry of the fermionic two-particle state. (mathlib `ExteriorAlgebra.ι_mul_ι_comm` /
`ι_mul_ι_add_swap`.) -/
theorem fermion_antisymm (a b : M) :
    (ExteriorAlgebra.ι R a) * (ExteriorAlgebra.ι R b)
      = - ((ExteriorAlgebra.ι R b) * (ExteriorAlgebra.ι R a)) := by
  have h := ExteriorAlgebra.ι_sq_zero (R := R) (a + b)
  rw [map_add, mul_add, add_mul, add_mul,
      ExteriorAlgebra.ι_sq_zero, ExteriorAlgebra.ι_sq_zero, zero_add, add_zero] at h
  -- h : ι b * ι a + ι a * ι b = 0
  exact eq_neg_of_add_eq_zero_right h

/-- **Bosonic contrast** (PROVEN). Bosons have no exclusion: the *tensor-symmetric* square of a
nonzero vector is nonzero. We witness this with the cleanest invariant: in the tensor algebra,
`ι v * ι v` need not vanish — concretely, for `v ≠ 0` the symmetric square is detected by any
nonzero linear functional `f` via `f v * f v ≠ 0`. We state the scalar shadow: if `f v ≠ 0`
then `(f v) * (f v) ≠ 0`, i.e. the symmetric (boson) square does not collapse the way the
antisymmetric (fermion) one does. -/
theorem boson_no_exclusion {K : Type*} [Field K] {v : K} (hv : v ≠ 0) : v * v ≠ 0 :=
  mul_ne_zero hv hv

/-! ## Classical observables: real expectations and additivity over composites -/

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]

open scoped InnerProductSpace ComplexConjugate

/-- **Real expectation** (PROVEN). A self-adjoint observable `A` has a real expectation
`⟨ψ, A ψ⟩` in any state — position, momentum, mass, energy are all real because their
operators are self-adjoint. (The `System.expectation_real` fact, for a general space.) -/
theorem expectation_real (A : E →ₗ[ℂ] E) (hA : A.IsSymmetric) (ψ : E) :
    (inner ℂ ψ (A ψ) : ℂ).im = 0 := by
  have h1 : (starRingEnd ℂ) (inner ℂ ψ (A ψ)) = inner ℂ (A ψ) ψ := inner_conj_symm (A ψ) ψ
  exact Complex.conj_eq_iff_im.mp (h1.trans (hA ψ ψ))

variable {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℂ F]

/-- **The composite observable** `A ⊗ I + I ⊗ B` on a two-part system `E ⊗ F` — the form of
total mass, total momentum, particle number: a single-particle observable summed over the
parts. -/
noncomputable def additiveObs (A : E →ₗ[ℂ] E) (B : F →ₗ[ℂ] F) :
    (TensorProduct ℂ E F) →ₗ[ℂ] (TensorProduct ℂ E F) :=
  TensorProduct.map A LinearMap.id + TensorProduct.map LinearMap.id B

/-! ## Mass as an additive observable (non-relativistic model) -/

/-- A **constituent**: a basis state with a real mass. The simplest mass model — each
single-particle state carries a fixed mass parameter. -/
structure Constituent where
  /-- the (real) mass of this constituent -/
  mass : ℝ

/-- **Total mass of a composite** = sum of constituent masses. The NON-RELATIVISTIC additive
model: mass is a fixed external parameter and a composite's mass is the plain sum. (Caveat:
relativistically this is false — invariant mass is sub-additive by the binding energy
`Δm = E_b/c²`. This `def` is explicitly the non-relativistic convention.) -/
def compositeMass (parts : List Constituent) : ℝ :=
  (parts.map Constituent.mass).sum

/-- **Mass is additive over composition** (PROVEN, in the additive model). The mass of a
composite built by concatenating two part-lists is the sum of their masses — the additivity of
the total-mass observable `M = M_A ⊗ I + I ⊗ M_B`, here at the level of the eigenvalue
bookkeeping. -/
theorem mass_additive (xs ys : List Constituent) :
    compositeMass (xs ++ ys) = compositeMass xs + compositeMass ys := by
  simp [compositeMass, List.map_append, List.sum_append]

/-- **Mass of the empty system is zero** (PROVEN). The vacuum has no mass; with `mass_additive`
this makes `compositeMass` a monoid homomorphism `(List Constituent, ++) → (ℝ, +)`. -/
theorem mass_empty : compositeMass [] = 0 := rfl

/-! ## Spin–statistics: carried as a postulate, never derived -/

/-- The two particle statistics. -/
inductive Statistics where
  | boson
  | fermion
deriving DecidableEq

/-- **The spin–statistics correspondence** (POSTULATE — a deep QFT theorem, NOT derivable in
this finite-dimensional algebraic setting; carried as data). Integer spin ↔ symmetric states ↔
bosons; half-integer spin ↔ antisymmetric states ↔ fermions. We encode the map from a (doubled)
spin to its statistics: `2·spin` even ⇒ boson, odd ⇒ fermion. -/
def spinStatistics (twiceSpin : ℕ) : Statistics :=
  if twiceSpin % 2 = 0 then Statistics.boson else Statistics.fermion

/-- Integer spin (even `2·spin`) is bosonic — by the postulated correspondence. -/
theorem integerSpin_boson (k : ℕ) : spinStatistics (2 * k) = Statistics.boson := by
  simp [spinStatistics, Nat.mul_mod_right]

/-- Half-integer spin (odd `2·spin`) is fermionic — by the postulated correspondence. -/
theorem halfIntegerSpin_fermion (k : ℕ) : spinStatistics (2 * k + 1) = Statistics.fermion := by
  have : (2 * k + 1) % 2 = 1 := by omega
  simp [spinStatistics, this]

/-! ## Summary -/

/-- **The boson/fermion + classical-observable picture, assembled.**
  1. Pauli exclusion is a theorem: `v ∧ v = 0` (fermions);
  2. self-adjoint observables have real expectations (measured quantities are real);
  3. mass is additive over composition (non-relativistic model), with `[]` ↦ 0;
  4. spin–statistics is carried as a postulate (boson ⇔ even `2·spin`). -/
theorem boson_fermion_summary
    (v : M) (A : E →ₗ[ℂ] E) (hA : A.IsSymmetric) (ψ : E) (xs ys : List Constituent) (k : ℕ) :
    ((ExteriorAlgebra.ι R v) * (ExteriorAlgebra.ι R v) = 0) ∧
    ((inner ℂ ψ (A ψ) : ℂ).im = 0) ∧
    (compositeMass (xs ++ ys) = compositeMass xs + compositeMass ys) ∧
    (spinStatistics (2 * k) = Statistics.boson) :=
  ⟨pauli_exclusion v, expectation_real A hA ψ, mass_additive xs ys, integerSpin_boson k⟩

end SpectralBosonFermion
