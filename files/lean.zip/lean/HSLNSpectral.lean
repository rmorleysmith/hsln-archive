/-
HSLNSpectral.lean — spectral zeta, the Hilbert–Pólya spectrum, and ζ-criticality.
================================================================================

Three a-priori-unrelated appearances of "ζ as an eigenvalue story", unified by ONE
sorry-free fact from mathlib — a self-adjoint operator has a **real spectrum**:

  1. **Spectral zeta functions** (Minakshisundaram–Pleijel). For a (Laplace-type) operator
     with eigenvalues `λₙ`, organise them into a Dirichlet series `ζ_T(s) = ∑ λₙ^{-s}`.
     The "frequencies" `λₙ` are the eigenvalues; self-adjointness makes them real, so
     `ζ_T` is a genuine real-frequency Dirichlet series (the same shape as the Riemann ζ,
     which is `ζ_T` for the operator with spectrum `{n}`).

  2. **Riemann zeros & random matrices** (Hilbert–Pólya / Montgomery–Odlyzko). The dream:
     the nontrivial zeros `ρ = ½ + iγ` are eigenvalues of a self-adjoint operator `T`. Then
     each height `γ` is real (spectral reality) ⇒ every `ρ` has real part exactly `½` ⇒ RH.
     The GUE statistics of the zeros are the empirical fingerprint of this hidden operator
     (verified numerically in `viz/spectral.py`, fig 34; deepened in `viz/hsln_spectral.py`).

  3. **Nuclear ζ-eigenvalue criticality.** Reactor criticality scales the operator (atomic
     densities) by a real factor `ζ` until the dominant eigenvalue is exactly `1` (k_eff = 1).
     That is literally eigenvalue rescaling: if `μ` is an eigenvalue of `T` then `c·μ` is an
     eigenvalue of `c • T`, and the critical scale `ζ = μ⁻¹` drives it to `1`. For a
     self-adjoint `T` that critical `ζ` is *real* — a physically meaningful control.

The single load-bearing theorem under all three is `eigenvalue_real_of_symmetric`
(`LinearMap.IsSymmetric.conj_eigenvalue_eq_self`, mathlib). This file is the spectral
companion to `HSLNHilbertPolya.lean`; it adds the ζ-criticality rescaling lemmas (genuinely
new, sorry-free) and the spectral form of "gravity preserves destination".

The CONSTRUCTIVE CONVERSE is now landed: `exists_selfAdjoint_realising` builds an explicit
self-adjoint diagonal operator realising any real spectrum on the finite-support carrier
`ι →₀ ℂ` (the inner product built from scratch via `InnerProductSpace.ofCore`), giving
`riemannHypothesis_iff_spectralZetaOperator` — the `def` is *equivalent* to RH, sorry-free.

Verified sorry-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
Numerically exercised in `viz/hsln_spectral.py`.
-/
import Mathlib

open Module.End Complex
open scoped InnerProductSpace BigOperators ComplexConjugate

namespace HSLNSpectral

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] {T : E →ₗ[ℂ] E}

/-! ### Spectral reality — the one fact under all three stories -/

/-- **Spectral reality** (sorry-free, mathlib). A self-adjoint operator's eigenvalues are
real: `μ.im = 0`. These `μ` are the *frequencies* of the spectral zeta `ζ_T(s) = ∑ μ^{-s}`,
so `ζ_T` is a real-frequency Dirichlet series — and they are the heights `γ` of the Riemann
zeros in the Hilbert–Pólya picture, so reality ⇒ zeros on the critical line. -/
theorem eigenvalue_real_of_symmetric (hT : T.IsSymmetric) {μ : ℂ}
    (h : HasEigenvalue T μ) : μ.im = 0 :=
  Complex.conj_eq_iff_im.mp (hT.conj_eigenvalue_eq_self h)

/-- **Hecke realises the Hilbert–Pólya dream.** Hecke operators are self-adjoint for the
Petersson inner product, so a Hecke eigenvalue `μ = aₚ` satisfies `conj μ = μ` — it is real.
This is a *theorem* (the spectral interpretation succeeds for modular forms), and it is the
exact template the ζ case aspires to. -/
theorem hecke_eigenvalue_real (hT : T.IsSymmetric) {μ : ℂ}
    (h : HasEigenvalue T μ) : (starRingEnd ℂ) μ = μ :=
  hT.conj_eigenvalue_eq_self h

/-! ### Nuclear ζ-eigenvalue criticality: rescaling the spectrum -/

/-- **Eigenvalue rescaling.** If `μ` is an eigenvalue of `T`, then `c·μ` is an eigenvalue of
`c • T` (same eigenvector). This is the algebra under the reactor ζ-eigenvalue equation:
scaling the operator (atomic densities) by `c` scales every eigenvalue by `c`. Sorry-free. -/
theorem eigenvalue_smul (c : ℂ) {μ : ℂ} (h : HasEigenvalue T μ) :
    HasEigenvalue (c • T) (c * μ) := by
  obtain ⟨x, hx⟩ := h.exists_hasEigenvector
  have hmem : T x = μ • x := mem_eigenspace_iff.mp hx.1
  refine hasEigenvalue_of_hasEigenvector ⟨?_, hx.2⟩
  rw [mem_eigenspace_iff, LinearMap.smul_apply, hmem, smul_smul]

/-- **ζ-criticality.** For a nonzero eigenvalue `μ`, the scale `ζ = μ⁻¹` drives the system
to criticality: `μ⁻¹ • T` has eigenvalue exactly `1` (k_eff = 1). This is the nuclear
ζ-eigenvalue equation — solve for the density scale that makes the dominant mode critical.
Sorry-free. -/
theorem criticality_scale {μ : ℂ} (hμ : μ ≠ 0) (h : HasEigenvalue T μ) :
    HasEigenvalue (μ⁻¹ • T) 1 := by
  have h2 := eigenvalue_smul (T := T) μ⁻¹ h
  rwa [inv_mul_cancel₀ hμ] at h2

/-- **The critical scale is real for a self-adjoint operator.** Combining spectral reality
with `criticality_scale`: the ζ that criticalises a self-adjoint `T` is real, `(μ⁻¹).im = 0`
— a physically meaningful (real) control parameter, not a complex artefact. Sorry-free. -/
theorem criticality_scale_real (hT : T.IsSymmetric) {μ : ℂ}
    (h : HasEigenvalue T μ) : (μ⁻¹).im = 0 := by
  have him : μ.im = 0 := eigenvalue_real_of_symmetric hT h
  simp [Complex.inv_im, him]

/-! ### Gravity preserves destination, in spectral form -/

/-- **Gravity warps the flow but preserves the destination** (spectral form). Turning on the
gravitational coupling strength `c ≠ 0` rescales every *nonzero* eigenvalue (`μ ↦ c·μ`,
the trajectory warping) but leaves the **equilibrium eigenvalue `0`** — the actual neuron /
destination where `∇V = 0` — exactly where it was. This is the eigenvalue-level companion of
`HSLN.gravity_preserves_equilibria` (`K v = 0 ↔ v = 0` for a positive-definite metric).
Sorry-free. -/
theorem zero_eigenvalue_preserved (c : ℂ) (hc : c ≠ 0) :
    HasEigenvalue T 0 ↔ HasEigenvalue (c • T) 0 := by
  constructor
  · intro h
    have h2 := eigenvalue_smul (T := T) c h
    rwa [mul_zero] at h2
  · intro h
    have h2 := eigenvalue_smul (T := c • T) c⁻¹ h
    rwa [mul_zero, inv_smul_smul₀ hc] at h2

/-! ### The spectral-zeta Hilbert–Pólya operator ⇒ RH -/

/-- **The spectral-zeta Hilbert–Pólya hypothesis** — the OPEN existence claim. There is a
self-adjoint operator `T` whose spectral zeta `∑ μ^{-s}` encodes the Riemann zeros: every
nontrivial ζ-zero is `s = ½ + μ·i` for an eigenvalue `μ` of `T`. (Same honest shape as
`HSLNHilbertPolya.HilbertPolyaOperator`, here phrased around the spectral zeta function.) -/
def SpectralZetaOperator : Prop :=
  ∃ (E : Type) (_ : NormedAddCommGroup E) (_ : InnerProductSpace ℂ E) (T : E →ₗ[ℂ] E),
    T.IsSymmetric ∧
    ∀ s : ℂ, riemannZeta s = 0 → (¬ ∃ n : ℕ, s = -2 * (n + 1)) → s ≠ 1 →
      ∃ μ : ℂ, HasEigenvalue T μ ∧ s = ((1 / 2 : ℝ) : ℂ) + μ * I

/-- **Spectral-zeta Hilbert–Pólya ⇒ RH** — sorry-free. Self-adjointness forces each
eigenvalue `μ` real (the spectral zeta has real frequencies), so `s = ½ + μ·i` has real part
exactly `½`. The whole of RH is reduced to the single open sentence "such an operator
exists". -/
theorem riemannHypothesis_of_spectralZeta (h : SpectralZetaOperator) :
    RiemannHypothesis := by
  obtain ⟨E, _, _, T, hT, hcorr⟩ := h
  intro s hz htriv hone
  obtain ⟨μ, hμ, hsμ⟩ := hcorr s hz htriv hone
  have him : μ.im = 0 := eigenvalue_real_of_symmetric hT hμ
  rw [hsμ, Complex.add_re, Complex.ofReal_re, Complex.mul_re, Complex.I_re, Complex.I_im, him]
  norm_num

/-- **The spectral summary.** Real spectrum ⇒ (a) spectral-zeta frequencies are real,
(b) the ζ-criticality scale is real, and (c) the spectral-zeta operator hypothesis closes
RH. One self-adjointness fact, three faces. -/
theorem spectral_summary (hT : T.IsSymmetric) :
    (∀ μ : ℂ, HasEigenvalue T μ → μ.im = 0) ∧
    (∀ μ : ℂ, HasEigenvalue T μ → (μ⁻¹).im = 0) ∧
    (SpectralZetaOperator → RiemannHypothesis) :=
  ⟨fun _ h => eigenvalue_real_of_symmetric hT h,
   fun _ h => criticality_scale_real hT h,
   riemannHypothesis_of_spectralZeta⟩

/-! ### The constructive engine + the reverse direction (RH builds the spectral-zeta operator)

The diagonal engine: any prescribed real spectrum is realised by a self-adjoint operator on the
finite-support carrier `Spec ι = ι →₀ ℂ` (the only carrier where an UNBOUNDED diagonal is total).
This upgrades `SpectralZetaOperator` from a one-directional sufficient condition into a genuine
EQUIVALENCE with RH — the operator is constructed, not merely hoped for. The inner product on
`ι →₀ ℂ` is built from scratch via `InnerProductSpace.ofCore` (mathlib has none). -/

abbrev Spec (ι : Type) : Type := ι →₀ ℂ

namespace Spec
variable {ι : Type}

/-- the pairing, as a plain function (no `Inner` instance yet) -/
noncomputable def ipair (f g : Spec ι) : ℂ := ∑ i ∈ f.support, conj (f i) * g i

theorem ipair_eq_sum (s : Finset ι) (f g : Spec ι) (hf : f.support ⊆ s) :
    ipair f g = ∑ i ∈ s, conj (f i) * g i := by
  classical
  apply Finset.sum_subset hf
  intro i _ hi
  rw [Finsupp.notMem_support_iff.mp hi, map_zero, zero_mul]

theorem ipair_self_ofReal (f : Spec ι) :
    ipair f f = ((∑ i ∈ f.support, Complex.normSq (f i) : ℝ) : ℂ) := by
  rw [ipair, Complex.ofReal_sum]
  exact Finset.sum_congr rfl (fun i _ => (Complex.normSq_eq_conj_mul_self).symm)

noncomputable instance core : InnerProductSpace.Core ℂ (Spec ι) where
  inner := ipair
  conj_inner_symm f g := by
    classical
    show conj (ipair g f) = ipair f g
    rw [ipair_eq_sum (f.support ∪ g.support) g f Finset.subset_union_right,
        ipair_eq_sum (f.support ∪ g.support) f g Finset.subset_union_left, map_sum]
    exact Finset.sum_congr rfl (fun i _ => by rw [map_mul, Complex.conj_conj, mul_comm])
  re_inner_nonneg f := by
    show 0 ≤ (ipair f f).re
    rw [ipair_self_ofReal, Complex.ofReal_re]
    exact Finset.sum_nonneg (fun i _ => Complex.normSq_nonneg _)
  definite f hf := by
    classical
    rw [ipair_self_ofReal, Complex.ofReal_eq_zero] at hf
    have hz : ∀ i ∈ f.support, Complex.normSq (f i) = 0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => Complex.normSq_nonneg _)).mp hf
    apply Finsupp.ext
    intro i
    simp only [Finsupp.coe_zero, Pi.zero_apply]
    by_cases hi : i ∈ f.support
    · exact Complex.normSq_eq_zero.mp (hz i hi)
    · exact Finsupp.notMem_support_iff.mp hi
  add_left f g h := by
    classical
    show ipair (f + g) h = ipair f h + ipair g h
    have hsf : f.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_left Finset.subset_union_left
    have hsg : g.support ⊆ f.support ∪ g.support ∪ h.support :=
      Finset.Subset.trans Finset.subset_union_right Finset.subset_union_left
    have hsfg : (f + g).support ⊆ f.support ∪ g.support ∪ h.support := by
      intro i hi
      have hne : (f + g) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.add_apply] at hne
      by_cases h1 : f i = 0
      · have h2 : g i ≠ 0 := fun h2 => hne (by rw [h1, h2, add_zero])
        exact Finset.mem_union_left _ (Finset.mem_union_right _ (Finsupp.mem_support_iff.mpr h2))
      · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr h1))
    rw [ipair_eq_sum (f.support ∪ g.support ∪ h.support) (f+g) h hsfg,
        ipair_eq_sum (f.support ∪ g.support ∪ h.support) f h hsf,
        ipair_eq_sum (f.support ∪ g.support ∪ h.support) g h hsg, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun i _ => by rw [Finsupp.add_apply, map_add, add_mul])
  smul_left f g r := by
    classical
    show ipair (r • f) g = conj r * ipair f g
    have hsrf : (r • f).support ⊆ f.support := by
      intro i hi
      have hne : (r • f) i ≠ 0 := Finsupp.mem_support_iff.mp hi
      rw [Finsupp.smul_apply, smul_eq_mul] at hne
      exact Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne)
    rw [ipair_eq_sum f.support (r • f) g hsrf, ipair, Finset.mul_sum]
    exact Finset.sum_congr rfl (fun i _ => by
      rw [Finsupp.smul_apply, smul_eq_mul, map_mul]; ring)

noncomputable instance instNACG : NormedAddCommGroup (Spec ι) :=
  InnerProductSpace.Core.toNormedAddCommGroup (𝕜 := ℂ) (cd := core)

noncomputable instance instIPS : InnerProductSpace ℂ (Spec ι) := InnerProductSpace.ofCore _

open scoped InnerProductSpace

theorem inner_eq_ipair (f g : Spec ι) : (inner ℂ f g) = ipair f g := rfl

/-- Diagonal multiplication by a real sequence `r` (the possibly-unbounded operator). -/
noncomputable def Tdiag (r : ι → ℝ) : (Spec ι) →ₗ[ℂ] (Spec ι) :=
  Finsupp.linearCombination ℂ (fun i => Finsupp.single i (r i : ℂ))

theorem Tdiag_single (r : ι → ℝ) (i : ι) :
    Tdiag r (Finsupp.single i 1) = (r i : ℂ) • Finsupp.single i 1 := by
  simp [Tdiag, Finsupp.linearCombination_single, Finsupp.smul_single]

theorem Tdiag_apply (r : ι → ℝ) (x : Spec ι) (j : ι) :
    (Tdiag r x) j = (r j : ℂ) * x j := by
  classical
  simp only [Tdiag, Finsupp.linearCombination_apply, Finsupp.sum_apply]
  rw [Finsupp.sum]
  simp only [Finsupp.smul_single, smul_eq_mul, Finsupp.single_apply]
  rw [Finset.sum_ite_eq']
  by_cases hj : j ∈ x.support
  · simp [hj, mul_comm]
  · simp only [hj, if_false]; rw [Finsupp.notMem_support_iff.mp hj]; ring

/-- **The diagonal operator is self-adjoint** — the unbounded-spectrum, infinite-dimensional
avatar of `HSLNTraceFormula.diagReal_isHermitian`. Sorry-free. -/
theorem Tdiag_symm (r : ι → ℝ) : (Tdiag r).IsSymmetric := by
  classical
  intro x y
  have hx : (Tdiag r x).support ⊆ x.support ∪ y.support := by
    intro i hi
    have hne : (Tdiag r x) i ≠ 0 := Finsupp.mem_support_iff.mp hi
    rw [Tdiag_apply] at hne
    exact Finset.mem_union_left _ (Finsupp.mem_support_iff.mpr (right_ne_zero_of_mul hne))
  rw [inner_eq_ipair, inner_eq_ipair,
      ipair_eq_sum (x.support ∪ y.support) _ _ hx,
      ipair_eq_sum (x.support ∪ y.support) _ _ Finset.subset_union_left]
  apply Finset.sum_congr rfl
  intro i _
  rw [Tdiag_apply r x i, Tdiag_apply r y i, map_mul, Complex.conj_ofReal]
  ring

end Spec

/-- **The engine.** ANY prescribed real spectrum `(r i)` is realised by a self-adjoint operator
on a genuine complex inner product space — sorry-free, for an arbitrary (possibly *unbounded*)
real sequence. The real-diagonal-is-Hermitian fact lifted to the infinite carrier the
Riemann-zero spectrum requires (finite support makes the unbounded diagonal total). -/
theorem exists_selfAdjoint_realising {ι : Type} (r : ι → ℝ) :
    ∃ (E : Type) (_ : NormedAddCommGroup E) (_ : InnerProductSpace ℂ E) (T : E →ₗ[ℂ] E),
      T.IsSymmetric ∧ ∀ i, HasEigenvalue T (r i : ℂ) := by
  refine ⟨Spec ι, inferInstance, inferInstance, Spec.Tdiag r, Spec.Tdiag_symm r, ?_⟩
  intro i
  exact hasEigenvalue_of_hasEigenvector
    ⟨mem_eigenspace_iff.mpr (Spec.Tdiag_single r i), Finsupp.single_ne_zero.mpr one_ne_zero⟩

/-- **RH builds the spectral-zeta operator** — sorry-free. Under RH the zero-heights are real,
so the engine's diagonal operator (`ι = ℂ`, `r = Complex.im`) realises every height as an
eigenvalue: the converse of `riemannHypothesis_of_spectralZeta`. -/
theorem spectralZetaOperator_of_riemannHypothesis (h : RiemannHypothesis) :
    SpectralZetaOperator := by
  obtain ⟨E, i1, i2, T, hT, hr⟩ := exists_selfAdjoint_realising (ι := ℂ) Complex.im
  refine ⟨E, i1, i2, T, hT, ?_⟩
  intro s hz htriv hone
  refine ⟨(s.im : ℂ), hr s, ?_⟩
  have hre : s.re = 1 / 2 := h s hz htriv hone
  apply Complex.ext
  · rw [Complex.add_re, Complex.ofReal_re, Complex.mul_re, Complex.I_re, Complex.I_im,
      Complex.ofReal_re, Complex.ofReal_im, hre]; ring
  · rw [Complex.add_im, Complex.ofReal_im, Complex.mul_im, Complex.I_re, Complex.I_im,
      Complex.ofReal_re, Complex.ofReal_im]; ring

/-- **The spectral-zeta operator exists IF AND ONLY IF RH holds** — sorry-free. The `def` is
logically equivalent to the Riemann Hypothesis, with the operator explicitly constructed in the
reverse direction. -/
theorem riemannHypothesis_iff_spectralZetaOperator :
    RiemannHypothesis ↔ SpectralZetaOperator :=
  ⟨spectralZetaOperator_of_riemannHypothesis, riemannHypothesis_of_spectralZeta⟩

end HSLNSpectral
