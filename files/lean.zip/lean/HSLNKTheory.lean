/-
K-theory and Grothendieck–Riemann–Roch on the two rings.
========================================================

This file plants the K-theory / GRR flag in the HSLN landscape. The bridge is one
observation that ties everything together:

  > The **Chern character** of Grothendieck–Riemann–Roch is a *ring homomorphism*
  > `ch : K(X) → H*(X, ℚ)`. In our two-ring world, the **Euler characteristic / rank**
  > `χ : f ↦ f(1)` (evaluation of an arithmetic function at `n = 1`) is exactly such a
  > ring homomorphism — but only for Ring B (Dirichlet). Against Ring A (Cauchy) it is
  > identically zero. So `χ` is the lens that *sees* the L-function ring and is *blind* to
  > the modular-form ring.

The K-theory dictionary (see `math-connections.md` for the prose companion):

  | K-theory / GRR                          | HSLN                                            |
  |-----------------------------------------|-------------------------------------------------|
  | Chern character `ch : K(X) → H*(X)`     | `chernChar : ArithmeticFunction R →+* R`        |
  | `ch` is a **ring homomorphism**         | `χ(f * g) = χ(f) · χ(g)` (Dirichlet, Ring B)    |
  | Euler characteristic is **additive**    | `χ(f + g) = χ(f) + χ(g)`  (Riemann–Roch χ)      |
  | reduced K-theory `K̃₀ = ker(rank)`       | augmentation ideal `ker χ = {f : f(1) = 0}`     |
  | Ring A products are *virtual / reduced* | every `f ⋆ g` lies in `ker χ`                   |
  | K-theory rank `K₀(X) → ℤ` on units      | `rank : (ArithmeticFunction R)ˣ →* Rˣ`          |
  | `K₀(point) = ℤ` (completion of `(ℕ,+)`) | coefficient cast `ℕ ↪ ℤ`                        |

The Grothendieck group `K₀` is the universal group completion of a commutative monoid of
(iso classes of) vector bundles under `⊕`, with the tensor product `⊗` giving the ring
multiplication. The completion of the additive monoid `(ℕ, +)` is `(ℤ, +)` — that is
literally `K₀(point)`, and it is the same map `ℕ ↪ ℤ` that turns the effective divisor
count `d(n) = (ζ * ζ)(n) ∈ ℕ` into a virtual (signed) K-theory class in `ℤ`.

`cauchyMul` (Ring A) is restated locally so this file is self-contained (`import Mathlib`
only), matching the repo convention. It is the same operation as `HSLNBridge.cauchyMul`.

Verified sorry-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`). The
mathematical content is also checked numerically in `viz/hsln_ktheory.py`.
-/
import Mathlib

open ArithmeticFunction Finset
open scoped ArithmeticFunction.zeta ArithmeticFunction.Moebius

namespace HSLNKTheory

variable {R : Type*} [CommSemiring R]

/-! ### Ring A (Cauchy / q-expansion product), restated locally -/

/-- **The Cauchy / q-expansion convolution.** `(f ⋆ g)(n) = ∑_{i+j=n} f(i)·g(j)` — Ring A,
the modular-form product on Fourier coefficients (same as `HSLNBridge.cauchyMul`). -/
def cauchyMul (f g : ArithmeticFunction R) : ArithmeticFunction R where
  toFun n := ∑ p ∈ antidiagonal n, f p.1 * g p.2
  map_zero' := by simp

@[simp] theorem cauchyMul_apply (f g : ArithmeticFunction R) (n : ℕ) :
    cauchyMul f g n = ∑ p ∈ antidiagonal n, f p.1 * g p.2 := rfl

@[inherit_doc] scoped infixl:70 " ⋆ " => cauchyMul

/-- Cauchy at `n = 1` is always zero: the only `i+j=1` splits are `(0,1)` and `(1,0)`, both
killed by the `f 0 = 0` convention. -/
theorem cauchy_apply_one_eq_zero (f g : ArithmeticFunction R) : (f ⋆ g) 1 = 0 := by
  simp [cauchyMul_apply, antidiagonal]

/-! ### The Chern character / Euler characteristic as a ring homomorphism -/

/-- **The Chern character of HSLN.** Evaluation at `n = 1`, `χ(f) = f(1)`, packaged as a
ring homomorphism out of the **Dirichlet ring** `(ArithmeticFunction R, *)`. This is the
exact analogue of the GRR Chern character `ch : K(X) → H*(X, ℚ)`: a *multiplicative*
characteristic class. -/
def chernChar : ArithmeticFunction R →+* R where
  toFun f := f 1
  map_one' := by simp
  map_zero' := by simp
  map_mul' f g := by simp
  map_add' f g := by simp

@[simp] theorem chernChar_apply (f : ArithmeticFunction R) : chernChar f = f 1 := rfl

/-- **GRR multiplicativity (Ring B).** `ch` is a ring homomorphism, so it carries the
Dirichlet product to the product of L-values: `χ(f * g) = χ(f) · χ(g)`. The HSLN shadow of
"the Chern character is a ring homomorphism" — the algebraic core of GRR. -/
theorem chernChar_dirichlet (f g : ArithmeticFunction R) :
    chernChar (f * g) = chernChar f * chernChar g :=
  map_mul chernChar f g

/-- **Riemann–Roch additivity.** The Euler characteristic is additive: `χ(f + g) = χ(f) +
χ(g)`. In GRR this is `χ(F) = Σ (-1)ⁱ dim Hⁱ(F)` being additive on short exact sequences. -/
theorem chernChar_add (f g : ArithmeticFunction R) :
    chernChar (f + g) = chernChar f + chernChar g :=
  map_add chernChar f g

/-! ### Reduced K-theory: Ring A lives in the augmentation ideal -/

/-- **Ring A is reduced / virtual.** Every Cauchy (q-expansion) product `f ⋆ g` is killed
by the Chern character: `χ(f ⋆ g) = 0`. So the modular-form product never produces a class
of nonzero rank — it lands entirely in the **augmentation ideal** `ker χ`, the HSLN avatar
of *reduced* K-theory `K̃₀`. -/
theorem chernChar_cauchy (f g : ArithmeticFunction R) :
    chernChar (f ⋆ g) = 0 :=
  cauchy_apply_one_eq_zero f g

/-- **Cauchy products are reduced classes.** `f ⋆ g ∈ ker(chernChar)`. The kernel of the
rank map *is* reduced K-theory `K̃₀`, so Ring A's image sits inside it. -/
theorem cauchy_mem_ker (f g : ArithmeticFunction R) :
    f ⋆ g ∈ RingHom.ker (chernChar (R := R)) :=
  RingHom.mem_ker.mpr (chernChar_cauchy f g)

/-! ### The K-theory rank on the Grothendieck group of units -/

/-- **The rank map `K₀ → ℤ` on units.** The Chern character restricts to a group
homomorphism on the units of the Dirichlet ring, `rank : (ArithmeticFunction R)ˣ →* Rˣ`.
The unit group is the genuinely *invertible* part of the Dirichlet monoid — its Grothendieck
group — and `rank` is the K-theory rank functor `K₀ → ℤ` evaluated on it. -/
def rank : (ArithmeticFunction R)ˣ →* Rˣ := Units.map chernChar.toMonoidHom

@[simp] theorem rank_apply (u : (ArithmeticFunction R)ˣ) :
    (rank u : R) = (u : ArithmeticFunction R) 1 := rfl

/-! ### `K₀(point) = ℤ`: the Grothendieck completion of `(ℕ, +)` -/

/-- **`K₀(point) = ℤ`.** The Grothendieck group of the additive monoid `(ℕ, +)` of effective
classes is `(ℤ, +)`, and the universal completion map is the injection `ℕ ↪ ℤ`. This is the
*same* map that lifts the effective divisor count `d(n) = (ζ * ζ)(n) ∈ ℕ` to a virtual
(signed) K-theory class in `ℤ`. -/
theorem k0_point_completion_injective : Function.Injective ((↑) : ℕ → ℤ) :=
  Nat.cast_injective

/-! ### Concrete witnesses on `ζ` and the divisor function -/

/-- **The divisor function as an effective K-theory class.** `d(n) = (ζ * ζ)(n)` is an
ℕ-valued (effective) class; its Chern character / rank at `n = 1` is `d(1) = 1` — the
"line bundle `O`" of rank one. -/
theorem chernChar_divisor : chernChar ((ζ * ζ : ArithmeticFunction ℕ)) = 1 := by
  simp [chernChar_apply]

/-- **GRR summary on HSLN.** All four pillars at once:
  1. `χ` is multiplicative on Ring B (Chern character is a ring hom);
  2. `χ` is additive (Riemann–Roch Euler characteristic);
  3. Ring A lands in `ker χ` (Cauchy products are reduced / virtual classes);
  4. `K₀(point) = ℤ` is the injective completion of `(ℕ, +)`. -/
theorem grr_summary :
    (∀ f g : ArithmeticFunction R, chernChar (f * g) = chernChar f * chernChar g) ∧
    (∀ f g : ArithmeticFunction R, chernChar (f + g) = chernChar f + chernChar g) ∧
    (∀ f g : ArithmeticFunction R, f ⋆ g ∈ RingHom.ker (chernChar (R := R))) ∧
    Function.Injective ((↑) : ℕ → ℤ) :=
  ⟨chernChar_dirichlet, chernChar_add, cauchy_mem_ker, k0_point_completion_injective⟩

end HSLNKTheory
