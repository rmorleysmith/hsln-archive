/-
HSLNLanglands.lean — the bridge as a submonoid: the algebraic skeleton of Langlands.
====================================================================================

The single structural fact under the whole construction, stated at its sharpest:

  > The **Hecke / Langlands locus** — multiplicative arithmetic functions
  > `{f : f(1) = 1, f(mn) = f(m)f(n) for gcd(m,n)=1}` — is a **submonoid** of the Dirichlet
  > ring `(ArithmeticFunction R, *)` (mathlib's `IsMultiplicative.mul` + `isMultiplicative_one`).

Everything else is a corollary of *this is a monoid*:

  * **Abelian Langlands** (`ζ · L(s, χ_D) = ζ_K`): both factors live in the locus, the product
    is forced to be in the locus, and multiplicativity + agreement on prime powers pins it to
    the Dedekind zeta. The *product staying in the locus* is `langlands_product_mem`.
  * **Rankin–Selberg** (`GL_n × GL_m → GL_{nm}`): the L-function of the product representation is
    the Dirichlet product of the factors — again `langlands_product_mem`. The bridge does NOT
    know it lands on a *single eigenform* (that is Rankin–Selberg theory, open as functoriality);
    but it knows, sorry-free, that it stays **automorphic** (in the locus).
  * **Functoriality** = a locus-preserving transfer. Abstractly a ring endomorphism of the
    Dirichlet ring that maps the locus into itself; `LanglandsTransfer` packages exactly that.
    Transfers **compose** (`LanglandsTransfer.comp`) and the **identity is a transfer**
    (`LanglandsTransfer.id`) — the functoriality of the L-group correspondence, as monoid
    algebra. This is why the bridge "changes everything": the same `IsMultiplicative.mul` that
    gives ζ·L = ζ_K is the closure law that lets transfers chain — abelian Langlands,
    Rankin–Selberg, BSD-under-products (`HSLNBSD.BSDRank_prod`), and two-eigenform composition
    (`HSLNHecke`) are ALL the monoid operation in one realisation.

The trace formula (`HSLNTraceFormula`) is Langlands' actual *tool* for proving functoriality;
the Chern character (`HSLNKTheory`) is the same "multiplicative-class is a ring hom" shape one
categorical level up. Here we isolate the algebra: a submonoid and its endomorphisms.

Verified sorry-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`); exercised
in `viz/hsln_langlands.py`. The lone open core is `LanglandsFunctoriality` (existence of the
transfer realising a given L-group map) — non-abelian Langlands itself.

Refs: Langlands, *Problems in the theory of automorphic forms* (1970); the bridge prose in
`math-connections.md`; mathlib `ArithmeticFunction.IsMultiplicative`.
-/
import Mathlib

open ArithmeticFunction
open scoped ArithmeticFunction.zeta ArithmeticFunction.Moebius

namespace HSLNLanglands

/-! ### The Hecke / Langlands locus as a submonoid -/

/-- **The Hecke / Langlands locus is a submonoid of the Dirichlet ring.** Its carrier is the
multiplicative arithmetic functions; it contains the identity `δ` (`isMultiplicative_one`) and
is closed under Dirichlet convolution (`IsMultiplicative.mul`). This *single fact* — that the
locus is a monoid — is the algebraic skeleton of Langlands: automorphic L-data is closed under
the product that realises functoriality. -/
def langlandsLocus (R : Type*) [CommSemiring R] : Submonoid (ArithmeticFunction R) where
  carrier := {f | f.IsMultiplicative}
  mul_mem' hf hg := hf.mul hg
  one_mem' := isMultiplicative_one

@[simp] theorem mem_langlandsLocus {R : Type*} [CommSemiring R]
    {f : ArithmeticFunction R} : f ∈ langlandsLocus R ↔ f.IsMultiplicative := Iff.rfl

/-- **The bridge product law** (abelian Langlands / Rankin–Selberg skeleton). The product of two
locus elements is in the locus — `ζ · L(s, χ_D) = ζ_K`, `L(f,s)·L(g,s)`, all stay automorphic.
This is `IsMultiplicative.mul` read as "the locus is closed", the law that makes everything
compose. -/
theorem langlands_product_mem {R : Type*} [CommSemiring R]
    {f g : ArithmeticFunction R} (hf : f ∈ langlandsLocus R) (hg : g ∈ langlandsLocus R) :
    f * g ∈ langlandsLocus R :=
  (langlandsLocus R).mul_mem hf hg

/-! ### Concrete abelian witnesses: ζ, μ, and ζ * μ = δ -/

/-- **ζ is in the locus** (the trivial automorphic representation / Riemann generator). -/
theorem zeta_mem : (ζ : ArithmeticFunction ℤ) ∈ langlandsLocus ℤ :=
  mem_langlandsLocus.mpr isMultiplicative_zeta.natCast

/-- **μ is in the locus** (the inverse / contragredient). -/
theorem moebius_mem : (μ : ArithmeticFunction ℤ) ∈ langlandsLocus ℤ :=
  mem_langlandsLocus.mpr isMultiplicative_moebius

/-- **Abelian Langlands witness, sorry-free.** `ζ * μ = δ` lands in the locus — the product of
the trivial representation with its inverse is the identity (`L(triv) · L(triv)⁻¹ = 1`). The
closure law `langlands_product_mem` is exactly what guarantees the composite is automorphic. -/
theorem zeta_mul_moebius_mem : (ζ * μ : ArithmeticFunction ℤ) ∈ langlandsLocus ℤ :=
  langlands_product_mem zeta_mem moebius_mem

/-- **`ζ * ζ` (the divisor L-function) is in the locus.** `d(n) = (ζ*ζ)(n)` is multiplicative —
the Rankin–Selberg `ζ ⊠ ζ` skeleton: the product of two copies of the trivial rep stays
automorphic. Sorry-free. -/
theorem zeta_sq_mem : (ζ * ζ : ArithmeticFunction ℤ) ∈ langlandsLocus ℤ :=
  langlands_product_mem zeta_mem zeta_mem

/-! ### Functoriality as a locus-preserving transfer -/

/-- **A Langlands transfer.** A ring endomorphism `φ` of the Dirichlet ring that maps the
Hecke / Langlands locus into itself: the algebraic shadow of a functorial transfer of
automorphic representations along a map of L-groups (which must send automorphic L-data to
automorphic L-data). The data is `φ` plus the proof that it preserves the locus. -/
structure LanglandsTransfer (R : Type*) [CommSemiring R] where
  /-- the underlying ring endomorphism of the Dirichlet ring -/
  φ : ArithmeticFunction R →+* ArithmeticFunction R
  /-- it preserves the Hecke / Langlands locus (sends automorphic to automorphic) -/
  preserves : ∀ {f}, f ∈ langlandsLocus R → φ f ∈ langlandsLocus R

/-- **The identity is a transfer** (functoriality of the identity L-group map). Sorry-free. -/
def LanglandsTransfer.id (R : Type*) [CommSemiring R] : LanglandsTransfer R where
  φ := RingHom.id _
  preserves h := h

/-- **Transfers compose** (functoriality is a category: composite of L-group maps ↦ composite
transfer). The composite ring hom still preserves the locus, because each factor does.
Sorry-free — this is the functoriality that "changes everything". -/
def LanglandsTransfer.comp {R : Type*} [CommSemiring R]
    (S T : LanglandsTransfer R) : LanglandsTransfer R where
  φ := S.φ.comp T.φ
  preserves h := S.preserves (T.preserves h)

/-- **A transfer carries automorphic data to automorphic data** — the defining property,
surfaced. `φ` of anything in the locus is in the locus. Sorry-free. -/
theorem LanglandsTransfer.maps_locus {R : Type*} [CommSemiring R]
    (Φ : LanglandsTransfer R) {f : ArithmeticFunction R} (hf : f ∈ langlandsLocus R) :
    Φ.φ f ∈ langlandsLocus R :=
  Φ.preserves hf

/-! ### Non-abelian Langlands as the open core -/

/-- **Langlands functoriality** — the OPEN core, stated honestly. For a given automorphic
`source` and `target`, there EXISTS a transfer realising it: a locus-preserving `φ` with
`φ source = target`. The abelian case (class field theory) is known; the general (non-abelian,
GLₙ) case is open. Like `HSLNHilbertPolya.HilbertPolyaOperator`, the implication-content is
proven; only the *existence of the transfer* is the open conjecture. -/
def LanglandsFunctoriality (R : Type*) [CommSemiring R]
    (source target : ArithmeticFunction R) : Prop :=
  source ∈ langlandsLocus R → target ∈ langlandsLocus R →
    ∃ Φ : LanglandsTransfer R, Φ.φ source = target

/-- **A realised transfer keeps the target automorphic** — sorry-free. If functoriality provides
a transfer taking `source` to `target`, then `target` is automatically in the locus (it was
required to be, and the transfer preserves it). The honest content: *given* a transfer, the
algebra is forced; only the transfer's existence is open. -/
theorem target_mem_of_functoriality {R : Type*} [CommSemiring R]
    {source target : ArithmeticFunction R}
    (hs : source ∈ langlandsLocus R) (ht : target ∈ langlandsLocus R)
    (h : LanglandsFunctoriality R source target) :
    ∃ Φ : LanglandsTransfer R, Φ.φ source = target ∧ Φ.φ source ∈ langlandsLocus R := by
  obtain ⟨Φ, hΦ⟩ := h hs ht
  exact ⟨Φ, hΦ, hΦ ▸ ht⟩

/-! ### Summary -/

/-- **The Langlands skeleton, assembled.** (1) the Hecke / Langlands locus is a submonoid;
(2) it is closed under the product (abelian Langlands / Rankin–Selberg); (3) `ζ * μ = δ` and
`ζ * ζ` are concrete in-locus witnesses; (4) transfers form a monoid under composition with the
identity transfer. Everything proven except the *existence* of the non-abelian transfer —
`LanglandsFunctoriality`, the open core. The one closure law `IsMultiplicative.mul` underlies
the whole tower: ζ·L=ζ_K, Rankin–Selberg, `HSLNBSD.BSDRank_prod`, `HSLNHecke` composition. -/
theorem langlands_summary :
    (∀ f g : ArithmeticFunction ℤ, f ∈ langlandsLocus ℤ → g ∈ langlandsLocus ℤ →
        f * g ∈ langlandsLocus ℤ) ∧
    ((ζ * μ : ArithmeticFunction ℤ) ∈ langlandsLocus ℤ) ∧
    ((ζ * ζ : ArithmeticFunction ℤ) ∈ langlandsLocus ℤ) ∧
    ((LanglandsTransfer.id ℤ).φ = RingHom.id _) :=
  ⟨fun _ _ hf hg => langlands_product_mem hf hg,
   zeta_mul_moebius_mem, zeta_sq_mem, rfl⟩

end HSLNLanglands
