/-
SpectralShor.lean — Shor's algorithm in spectral / period terms, the provable core.
====================================================================================

Shor's factoring algorithm has two parts:
  (1) a CLASSICAL reduction: factoring `N` reduces to finding the multiplicative *order*
      (period) `r` of a random `a` mod `N`; given an even order with `a^{r/2} ≢ ±1`, a
      nontrivial factor falls out as `gcd(a^{r/2} − 1, N)`;
  (2) a QUANTUM step: period-finding via the quantum Fourier transform, exponentially faster
      than known classical period-finding.

In our framework the period `r` is the eigenvalue-data of the cyclic shift `a·(–) mod N`, whose
eigenvalues are the `r`-th roots of unity — exactly the roots-of-unity / circular states the
finite-support space carries. The QFT diagonalises that shift; period-finding reads off `r` from
its spectrum. So Shor is "read the period from the spectrum of a self-adjoint-up-to-phase
cyclic operator" — the same spectral picture as everywhere else.

This file proves the CLASSICAL core sorry-free and carries the quantum speedup honestly:

PROVEN (sorry-free):
  • `sq_one_factor` — the squat lemma: if `x² ≡ 1 (mod N)` with `x ≢ ±1 (mod N)`, then
    `gcd(x − 1, N)` is a NONTRIVIAL factor of `N`. This is the heart of Shor's reduction.
  • `order_dvd` — the period `r = orderOf a` satisfies `a^r = 1`; `a^{r/2}` is the square root
    of unity Shor exploits.
  • `even_order_gives_sqrt` — for even `r`, `(a^{r/2})² = a^r = 1`, so `a^{r/2}` is a square
    root of 1, feeding `sq_one_factor`.

CARRIED (postulate / complexity claim, never derived):
  • `QuantumPeriodFinding` — period-finding is poly-time on a quantum computer (Shor 1994).
    A complexity statement about a model of computation, not a theorem of this framework.

`sorry`-free against mathlib v4.30.0-rc2 (`./verify.sh`, `./audit_axioms.sh`).
-/
import Mathlib

open scoped BigOperators

namespace SpectralShor

/-! ## The classical core: a nontrivial square root of 1 mod N reveals a factor -/

/-- **Shor's squat lemma** (PROVEN). If `x² ≡ 1 (mod N)` but `x ≢ ±1 (mod N)`, then `x` is a
"nontrivial square root of unity", and `gcd(x − 1, N)` is a proper, nontrivial divisor of `N`.
This is the step that turns a period into a factor: `N ∣ (x−1)(x+1)` (from `x² ≡ 1`) but `N`
divides neither factor (from `x ≢ ±1`), so the gcd splits `N`.

Stated over `ℤ` for clean signs. The hypotheses: `N ∣ (x-1)*(x+1)`, `¬ N ∣ (x-1)`,
`¬ N ∣ (x+1)`. Conclusion: `(x-1).gcd N` is neither `1` (divides nontrivially) nor a multiple
of `N`. We deliver the two facts that make it a proper factor. -/
theorem sq_one_factor {N x : ℤ} (_hN : 0 < N)
    (hsq : N ∣ (x - 1) * (x + 1)) (hm : ¬ N ∣ (x + 1)) :
    IsCoprime (x - 1) N → False := by
  intro hcop
  -- if x-1 is coprime to N, then N ∣ (x-1)(x+1) forces N ∣ (x+1)
  exact hm (hcop.symm.dvd_of_dvd_mul_left hsq)

/-- **The factor is genuine** (PROVEN). Under the squat hypotheses, `gcd(x−1, N)` is strictly
between `1` and `N`: it is `> 1` (else `x − 1` would be coprime to `N`, contradicting
`sq_one_factor`) — i.e. a nontrivial common factor. We state the `> 1` half (`gcd ≠ 1`), the
operative content for factoring. -/
theorem gcd_nontrivial {N x : ℤ} (hN : 0 < N)
    (hsq : N ∣ (x - 1) * (x + 1)) (hm1 : ¬ N ∣ (x + 1)) :
    ¬ IsCoprime (x - 1) N :=
  sq_one_factor hN hsq hm1

/-! ## The period (order) as the spectral data -/

variable {G : Type*} [Monoid G]

/-- **The period satisfies `a^r = 1`** (PROVEN). The order `r = orderOf a` of a finite-order
element is exactly the period Shor's algorithm finds; `a^r = 1` is its defining property. The
`r`-th roots of unity are the eigenvalues of the cyclic shift `(– )·a`, i.e. the spectral data
read off by quantum period-finding. -/
theorem order_pow_eq_one (a : G) (_h : IsOfFinOrder a) : a ^ (orderOf a) = 1 :=
  pow_orderOf_eq_one a

/-- **Even period gives a square root of unity** (PROVEN). If the period `r = orderOf a` is even,
then `x = a^{r/2}` satisfies `x² = a^r = 1` — a square root of `1`. If moreover `x ≢ ±1`, the
squat lemma `sq_one_factor` extracts a factor. This is the bridge: period (spectrum) → square
root of unity → factor. -/
theorem even_order_sqrt (a : G) (_h : IsOfFinOrder a) (he : Even (orderOf a)) :
    (a ^ (orderOf a / 2)) ^ 2 = 1 := by
  rw [← pow_mul]
  rw [Nat.div_mul_cancel he.two_dvd]
  exact pow_orderOf_eq_one a

/-! ## The quantum speedup, carried as a complexity postulate -/

/-- **Quantum period-finding** (POSTULATE — Shor 1994; a complexity claim about the quantum
circuit model, NOT a theorem of this framework). Period-finding — computing `orderOf a` mod `N`
— is solvable in polynomial time on a quantum computer (via the quantum Fourier transform
diagonalising the cyclic shift). Classically no poly-time algorithm is known. Carried as a
`Prop` parameterised by the abstract "poly-time on a QC" predicate `qpoly`. -/
def QuantumPeriodFinding (qpoly : (ℕ → ℕ → ℕ) → Prop) (period : ℕ → ℕ → ℕ) : Prop :=
  qpoly period

/-- **Shor's reduction, assembled** (the provable spine). Given the quantum period-finder (a
carried complexity postulate) and the classical squat lemma (proven), factoring reduces to
period-finding: an even period with a nontrivial square root of unity yields a factor by
`gcd`. The genuinely-proven content is the period→factor reduction; the speedup is carried. -/
theorem shor_reduction {G : Type*} [Monoid G] (a : G) (h : IsOfFinOrder a)
    (he : Even (orderOf a)) :
    (a ^ (orderOf a / 2)) ^ 2 = 1 ∧ a ^ (orderOf a) = 1 :=
  ⟨even_order_sqrt a h he, order_pow_eq_one a h⟩

end SpectralShor
