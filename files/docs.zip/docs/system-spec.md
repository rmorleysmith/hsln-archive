# Heterotic Spiking Liquid Network (HSLN) — Mathematical Specification

A continuous-time spiking reservoir whose state space is the Siegel upper
half-space, whose energy landscape is sculpted by a Siegel modular form built
from the E8 lattice, and whose learnable parameters ("DNA") are the Fourier
coefficients of that modular form. The architecture aims to permit exact
algebraic composition of trained models via the Hecke algebra, Eichler–Shimura
cohomology, and the graded-ring structure on modular forms.

This document fixes notation, states the load-bearing theorems explicitly with
sources, and audits which parts of the design are watertight, which need more
argument, and which are currently metaphorical.

---

## 1. Mathematical preliminaries

### 1.1 The E8 lattice

**Definition (E8 lattice).** $E_8$ is the unique positive-definite, even,
unimodular lattice of rank 8 (up to isometry). It can be realised as
$$
E_8 = \left\{ (x_1, \ldots, x_8) \in \mathbb{Z}^8 \cup (\mathbb{Z}+\tfrac12)^8 : \sum x_i \in 2\mathbb{Z} \right\}.
$$

> *Source:* [Wikipedia — E8 lattice](https://en.wikipedia.org/wiki/E8_lattice). The
> dimension is forced: even unimodular lattices exist only in ranks divisible by 8,
> and $E_8$ is the unique such lattice in rank 8.

The minimal norm is $2$, and the lattice contains $240$ vectors of norm $2$
(the E8 root system).

### 1.2 Theta function of E8 = the Eisenstein series $E_4$

**Definition (lattice theta function).** For a lattice $\Lambda$,
$$
\Theta_\Lambda(\tau) = \sum_{v \in \Lambda} e^{\pi i \tau \|v\|^2}, \qquad \tau \in \mathbb{H} = \{z \in \mathbb{C} : \operatorname{Im} z > 0\}.
$$

**Theorem (E8 theta function).** With $q = e^{2\pi i \tau}$,
$$
\Theta_{E_8}(\tau) = 1 + 240 \sum_{n \geq 1} \sigma_3(n)\, q^{2n} = 1 + 240\, q^2 + 2160\, q^4 + 6720\, q^6 + \cdots,
$$
where $\sigma_3(n) = \sum_{d \mid n} d^3$. This function is a modular form of
weight 4 for $\mathrm{SL}(2,\mathbb{Z})$, and equals (up to normalisation) the
weight‑4 Eisenstein series $E_4(\tau) = G_4(\tau)/2\zeta(4)$.

> *Sources:* [Wikipedia — E8 lattice](https://en.wikipedia.org/wiki/E8_lattice)
> ("the theta function for the E8 lattice must then be proportional to $G_4(\tau)$");
> [video — Counting points on the E8 lattice](https://www.youtube.com/watch?v=AxPwhJTHxSg).

The proof has two ingredients: (i) the Poisson summation formula applied to a
self-dual lattice gives the $\tau \mapsto -1/\tau$ transformation, and (ii) the
even-lattice property gives the $\tau \mapsto \tau + 1$ transformation; together
these are generators of $\mathrm{SL}(2,\mathbb{Z})$. The weight is half the rank.

### 1.3 Modular forms for $\mathrm{SL}(2,\mathbb{Z})$

**Definition.** A holomorphic function $f: \mathbb{H} \to \mathbb{C}$ is a modular
form of weight $k$ for $\Gamma \leq \mathrm{SL}(2,\mathbb{Z})$ if
$$
f\!\left(\frac{a\tau+b}{c\tau+d}\right) = (c\tau+d)^k f(\tau) \quad \text{for all } \begin{pmatrix}a&b\\c&d\end{pmatrix}\in\Gamma,
$$
and $f$ is holomorphic at all cusps. Write $M_k(\Gamma)$ for the space and
$S_k(\Gamma) \subset M_k(\Gamma)$ for the cusp forms (vanishing at cusps).

**Dimension formula.** For the full modular group,
$$
\dim_{\mathbb{C}} M_k(\mathrm{SL}(2,\mathbb{Z})) = \begin{cases} 0 & k \text{ odd or } k < 0 \\ \lfloor k/12 \rfloor & k \equiv 2 \pmod{12} \\ \lfloor k/12 \rfloor + 1 & k \geq 0, k \text{ even}, k \not\equiv 2 \pmod{12}. \end{cases}
$$
In particular $\dim M_4 = \dim M_6 = \dim M_8 = \dim M_{10} = 1$, $\dim M_{12} = 2$.

> *Source:* [Wikipedia — Modular form](https://en.wikipedia.org/wiki/Modular_form).

**Valence formula.** For non-zero $f \in M_k(\mathrm{SL}(2,\mathbb{Z}))$, the
total order of vanishing across $\mathbb{H}/\mathrm{SL}(2,\mathbb{Z})$ plus the
cusp obeys
$$
\operatorname{ord}_\infty(f) + \tfrac12 \operatorname{ord}_i(f) + \tfrac13 \operatorname{ord}_\rho(f) + \sum_{\tau \neq i, \rho} \operatorname{ord}_\tau(f) = \frac{k}{12},
$$
where $\rho = e^{2\pi i/3}$.

> *Source:* [Wikipedia — Modular form](https://en.wikipedia.org/wiki/Modular_form). This
> directly limits the number of zeros — the "neurons" — to roughly $k/12$ per
> fundamental domain.

**Sturm's bound (level 1).** A modular form $f \in M_k(\mathrm{SL}(2,\mathbb{Z}))$
is uniquely determined by its first $\lfloor k/12 \rfloor + 1$ Fourier
coefficients. For general $\Gamma_0(N)$, the bound is
$$
B = \left\lfloor \frac{k \cdot [\mathrm{SL}(2,\mathbb{Z}) : \Gamma_0(N)]}{12} \right\rfloor, \qquad [\mathrm{SL}(2,\mathbb{Z}) : \Gamma_0(N)] = N \prod_{p \mid N}\!\Bigl(1 + \tfrac{1}{p}\Bigr).
$$
> *Source:* J. Sturm, "On the congruence of modular forms" (1987); equivalent
> level-1 statement is the dimension formula on Wikipedia's
> [Modular form](https://en.wikipedia.org/wiki/Modular_form) page.

### 1.4 The Siegel upper half-space and Siegel modular forms

**Definition (Siegel upper half-space of degree $g$).**
$$
\mathbb{H}_g = \{Z \in \mathrm{Sym}_g(\mathbb{C}) : \operatorname{Im}(Z) \succ 0\}.
$$
$\mathbb{H}_g$ has complex dimension $g(g+1)/2$ and real dimension $g(g+1)$.

> *Source:* [Wikipedia — Siegel modular form](https://en.wikipedia.org/wiki/Siegel_modular_form).

**Symmetry group.** The symplectic group $\mathrm{Sp}(2g, \mathbb{R})$ acts on
$\mathbb{H}_g$ by $Z \mapsto (AZ+B)(CZ+D)^{-1}$ for $\bigl(\begin{smallmatrix}A & B \\ C & D\end{smallmatrix}\bigr) \in \mathrm{Sp}(2g, \mathbb{R})$.

**Definition (Siegel modular form, scalar weight).** Holomorphic $f: \mathbb{H}_g \to \mathbb{C}$ with
$$
f((AZ+B)(CZ+D)^{-1}) = \det(CZ+D)^k\, f(Z)
$$
for all symplectic matrices in $\mathrm{Sp}(2g, \mathbb{Z})$, plus a Koecher
boundedness condition (automatic for $g \geq 2$).

> *Source:* [Wikipedia — Siegel modular form](https://en.wikipedia.org/wiki/Siegel_modular_form).

**Siegel theta series of a lattice.** For an even unimodular lattice $\Lambda$ of
rank $2k$ and any $g \geq 1$,
$$
\Theta^{(g)}_\Lambda(Z) = \sum_{v_1, \ldots, v_g \in \Lambda} \exp\!\left(\pi i \operatorname{tr}\!\left[(v_i \cdot v_j)_{ij} \cdot Z\right]\right)
$$
is a Siegel modular form of weight $k$ and degree $g$ for $\mathrm{Sp}(2g, \mathbb{Z})$.
For $\Lambda = E_8$ and $g = 1$, $\Theta^{(1)}_{E_8} = \Theta_{E_8}$ from §1.2.

> *Source:* Siegel theta series of even unimodular lattices is a standard result;
> see Freitag, *Siegel modular forms* (Springer LNM 254); summarised on
> [Wikipedia — Siegel modular form](https://en.wikipedia.org/wiki/Siegel_modular_form).

**Ring of Siegel modular forms (small genus).**
- $g = 1$: $\bigoplus_k M_k = \mathbb{C}[E_4, E_6]$.
- $g = 2$: ring has 4 algebraic generators (Igusa, 1962); the cusp form
  $\chi_{10}$ first appears in weight 10.
- $g = 3$: 34 generators (Tsuyumine, 1986).

> *Source:* [Wikipedia — Siegel modular form](https://en.wikipedia.org/wiki/Siegel_modular_form). The
> ring of Siegel modular forms grows rapidly in generator count with $g$.

---

## 2. The HSLN architecture

### 2.1 State space

Fix a degree $g \geq 1$. The state of the network at continuous time $t$ is
$$
Z(t) \in \mathbb{H}_g.
$$
$\mathbb{H}_g$ is a non-compact symmetric space of rank $g$ and constant negative
curvature in the $g = 1$ case (it is the standard hyperbolic plane). For $g > 1$
it is not constant-curvature but is still a Hermitian symmetric space with
exponential volume growth toward the boundary — the "Poincaré-disk edge"
intuition extends.

### 2.2 DNA (learnable parameters)

Fix a level $N$, weight $k$, and degree $g$. The **DNA** is the finite vector of
Fourier coefficients
$$
\theta = (a_T)_{T \in \mathcal{S}_{\text{Sturm}}} \in \mathbb{C}^d,
$$
where $T$ ranges over half-integral symmetric positive semi-definite matrices
indexing the Siegel Fourier expansion, and $\mathcal{S}_{\text{Sturm}}$ is the
finite set bounded by the (genus-$g$) Sturm bound for $(k, N)$ — the smallest
set of Fourier indices such that two Siegel modular forms in
$M_k^{(g)}(\Gamma_g(N))$ agreeing on $\mathcal{S}_{\text{Sturm}}$ are equal.

> *Sources:* Sturm-style bounds for Siegel modular forms exist but are more
> elaborate than the level-1 classical case; see Choi & Kim (2007), "Sturm-type
> theorem for Siegel modular forms of genus 2 modulo $p$." For genus 1 the bound
> is just $\lfloor k [\mathrm{SL}_2 : \Gamma_0(N)] / 12 \rfloor + 1$.

**The manifold generator.** The truncated modular form
$$
F(Z; \theta) = \sum_{T \in \mathcal{S}_{\text{Sturm}}} a_T \cdot e^{2\pi i \operatorname{tr}(TZ)}
$$
is the network's energy landscape. By the Sturm bound, $F$ is the unique
element of $M_k^{(g)}(\Gamma_g(N))$ with this finite expansion.

### 2.3 Forward dynamics — the ODE

Input $u(t) \in \mathbb{R}^d$ is lifted into $\mathbb{H}_g$ by a fixed linear
encoder $B: \mathbb{R}^d \to T_Z \mathbb{H}_g$. The state evolves as a
gradient-with-driving system:
$$
\dot Z(t) = -\alpha\, \nabla_Z |F(Z; \theta)|^2 \;+\; B(u(t)),
$$
where $\alpha > 0$ is a fixed relaxation rate.

**Geometric reading.** The first term flows $Z(t)$ down the energy landscape
toward zeros of $F$ (which are local minima of $|F|^2$ — see §2.4). The second
term perturbs the trajectory in response to data.

**Liquid Time-Constant (LTC) analogue.** The "effective time constant" of a
classical LTC network — see Tanna et al. 2024,
[10.1109/bigdata62323.2024.10826128](https://doi.org/10.1109/bigdata62323.2024.10826128) —
is here implicitly $\tau_{\text{eff}} \sim 1/\alpha |\nabla F|^2$: it diverges
far from zeros (slow drift) and contracts near zeros (sharp basins). This
recovers the LTC behaviour for free from the geometry.

### 2.4 Neurons (zeros) and spike emission

**Neurons = zeros of $F$.** Define
$$
\mathcal{N}(\theta) = \{Z \in \mathbb{H}_g / \Gamma_g(N) : F(Z; \theta) = 0\}.
$$

By the maximum modulus principle, $|F|$ — and hence $|F|^2$ — has *no local
minima* in $\mathbb{H}_g$ except at the zero set $\mathcal{N}$. So zeros are
exactly the attractors of the unforced dynamics, and the spike threshold
$1/|F|$ peaks precisely at $\mathcal{N}$.

**Spike emission.** With threshold $\varepsilon > 0$,
$$
s(t) = \mathbb{1}\!\left[ \frac{1}{|F(Z(t); \theta)|} > \varepsilon \right].
$$

**Number of attractors.** For $g = 1$, the valence formula bounds $|\mathcal{N}|$
per fundamental domain by $\approx k/12$ (level 1). Increasing $k$, $N$, or $g$
grows the attractor count. *This is a critical design parameter; see §4.*

### 2.5 Learning rule

Continuous-time gradient descent on the DNA:
$$
\dot\theta(t) = -\eta\, \nabla_\theta \mathcal{L}\!\big(s(\cdot), s_{\text{target}}(\cdot)\big),
$$
where $\mathcal{L}$ is a temporal loss between emitted and target spike trains
(e.g. van Rossum distance, or convolved-with-kernel L2).

**Implicit Function Theorem (movement of zeros).** Around a simple zero
$Z_0$ of $F(\cdot; \theta_0)$ — i.e. $F(Z_0; \theta_0) = 0$ and
$\partial F/\partial Z|_{Z_0}$ non-singular — there is a smooth function
$Z^*: U \to \mathbb{H}_g$ on a neighbourhood $U$ of $\theta_0$ with
$F(Z^*(\theta); \theta) = 0$ and
$$
\frac{\partial Z^*}{\partial a_T}\bigg|_{\theta_0} = -\left(\frac{\partial F}{\partial Z}\right)^{-1} \frac{\partial F}{\partial a_T}\bigg|_{Z_0}.
$$
This formalises the user's intuition that tweaking $\theta$ continuously moves
the attractors. **Caveat:** this fails at multiple zeros and at the points where
the discriminant of $F$ vanishes, which is generically a measure-zero set but
which the optimiser may visit during training (zero collision / birth /
annihilation).

---

## 3. Algebraic composition infrastructure

The next four subsections develop the "DNA arithmetic" that the design hopes
permits exact zero-shot model merging.

### 3.1 The DNA as a module

The set of Siegel modular forms of weight $k$, degree $g$, level $N$ with
Fourier coefficients in a ring $R$ is an $R$-module:
$$
M_k^{(g)}(\Gamma_g(N); R) := M_k^{(g)}(\Gamma_g(N)) \cap R\llbracket q \rrbracket.
$$
- If $R = \mathbb{Z}$ or $R = \mathcal{O}_K$ (ring of integers), this is a
  finitely-generated module over a Dedekind domain (in particular a PID for
  $R = \mathbb{Z}$).
- If $R = \mathbb{C}$, it is a finite-dim $\mathbb{C}$-vector space.

> *Sources:* [Wikipedia — Module](https://en.wikipedia.org/wiki/Module_(mathematics));
> [Wikipedia — Structure theorem for finitely generated modules over a PID](https://en.wikipedia.org/wiki/Structure_theorem_for_finitely_generated_modules_over_a_principal_ideal_domain).

**Structure theorem.** Any finitely generated module over a PID decomposes as
$$
M \cong R^n \oplus R/(d_1) \oplus R/(d_2) \oplus \cdots \oplus R/(d_k), \quad d_1 \mid d_2 \mid \cdots \mid d_k.
$$
*What this buys us:* for the $\mathbb{Z}$-module of integral DNA strands, this
gives a canonical "invariant factor" decomposition. For complex coefficients
($R = \mathbb{C}$), the theorem is trivial — every f.g. module is just
$\mathbb{C}^n$ — and gives no new structure beyond dimension. **See §4.2 for a
discussion of how much of the user's hoped-for "individual neuron tuning"
genuinely follows from the structure theorem versus from the much stronger
Hecke decomposition.**

### 3.2 Hecke algebra and the "prime factorisation" of DNA

For each prime $p \nmid N$, the Hecke operator $T_p$ acts on $M_k(\Gamma_0(N))$
by averaging over sublattices of index $p$. The operators $\{T_p\}$ generate a
commutative semisimple subalgebra of $\mathrm{End}(S_k(\Gamma_0(N)))$, so $S_k$
decomposes as a direct sum of simultaneous eigenspaces.

> *Source:* [Wikipedia — Hecke operator](https://en.wikipedia.org/wiki/Hecke_operator).

**Theorem (Atkin–Lehner; Euler product for newforms).** If $f \in S_k(\Gamma_0(N))$
is a normalised newform with $T_p f = a_p f$ for all $p \nmid N$, then its
L-function factors:
$$
L(s, f) = \sum_{n \geq 1} \frac{a_n}{n^s} = \prod_p \left(1 - a_p\, p^{-s} + \chi(p)\, p^{k-1-2s}\right)^{-1}.
$$
> *Source:* [Wikipedia — Hecke operator](https://en.wikipedia.org/wiki/Hecke_operator), §"Euler product."

**Consequence for the DNA.** The "DNA" of a Hecke eigenform is determined by its
**prime-indexed coefficients** $\{a_p\}$, because $a_n$ for general $n$ is
recovered by the Euler-product recurrence
$a_{mn} = a_m a_n$ for $\gcd(m,n)=1$ and
$a_{p^{r+1}} = a_p a_{p^r} - p^{k-1} a_{p^{r-1}}$ for $p \nmid N$.

So if we *constrain training to the Hecke eigenform locus*, the effective
parameter count drops from "full Sturm bound" to "one parameter per prime up to
the Sturm bound." The Hecke algebra acts as a hard prior.

**Andrianov–Hecke theory for Siegel forms.** There is an analogous (but more
elaborate) Hecke theory for Siegel modular forms; the relevant local factors
are degree-$2g$ Euler factors. See Andrianov, *Quadratic Forms and Hecke
Operators* (Springer, 1987).

### 3.3 Eichler–Shimura: forms ↔ cohomology

**Theorem (Eichler–Shimura isomorphism).** For a Fuchsian group $\Gamma$ and
integer $n \geq 0$,
$$
S_{n+2}(\Gamma) \oplus \overline{S_{n+2}(\Gamma)} \;\cong\; H^1_{\mathrm{par}}(\Gamma, V_n),
$$
where $V_n$ is the $\Gamma$-module of homogeneous polynomials of degree $n$ in
two variables (the symmetric power $\mathrm{Sym}^n \mathbb{C}^2$), and
$H^1_{\mathrm{par}}$ is *parabolic* (also called *cuspidal* or *Eichler*)
group cohomology — the kernel of restriction to the cusps.

> *Source:* [Wikipedia — Eichler–Shimura isomorphism](https://en.wikipedia.org/wiki/Eichler%E2%80%93Shimura_isomorphism). The
> classical case: a weight-$k$ cusp form pairs with a $\Gamma$-equivariant
> cocycle by integrating $f(\tau)\,P(\tau, 1)\,d\tau$ along paths in $\mathbb{H}$
> between cusps.

**Geometric reading for HSLN.** A trained network's DNA $\theta$ (a Hecke
eigenform-ish object) corresponds via Eichler–Shimura to a cohomology class in
$H^1_{\mathrm{par}}(\Gamma, V_{k-2})$ — i.e. a "closed strand" in the modular
curve $X_0(N)$. *This is the formal sense in which a trained model is a
"trained path".*

### 3.4 The graded ring — addition, multiplication, Rankin–Selberg

$M_* := \bigoplus_k M_k(\Gamma)$ is a graded $\mathbb{C}$-algebra (a commutative
graded ring) under pointwise multiplication. For $\Gamma = \mathrm{SL}(2,\mathbb{Z})$,
$M_* = \mathbb{C}[E_4, E_6]$.

> *Source:* [Wikipedia — Modular form](https://en.wikipedia.org/wiki/Modular_form).

This gives **three exact composition operations**:

**(a) Addition (within a weight).** For $F_1, F_2 \in M_k(\Gamma)$ with DNAs
$\theta_1, \theta_2$,
$$
F_1 + F_2 \in M_k(\Gamma), \quad \text{DNA} = \theta_1 + \theta_2.
$$
**Subtle warning:** $\mathcal{N}(\theta_1 + \theta_2) \neq \mathcal{N}(\theta_1) \cup \mathcal{N}(\theta_2)$ —
addition does *not* combine attractor sets. It linearly superimposes the energy
landscape; new zeros appear where the two functions' values cancel, which is
almost never at either parent's zeros.

**(b) Multiplication (weight $k_1 + k_2$).** For $F_i \in M_{k_i}$,
$$
F_1 \cdot F_2 \in M_{k_1+k_2}, \quad \text{DNA} = \theta_1 * \theta_2 \;\text{(Cauchy / discrete convolution)}.
$$
$$
(a * b)_n = \sum_{i+j=n} a_i b_j.
$$
**This IS the merge operation.** $\mathcal{N}(F_1 \cdot F_2) = \mathcal{N}(F_1) \cup \mathcal{N}(F_2)$ —
the product vanishes wherever either factor does, so the merged network
inherits *every* attractor from both parents. The weight (and hence the
required state-space dimension / Sturm bound) doubles.

**(c) Rankin–Selberg convolution.** For Hecke eigenforms $f, g$, the
Rankin–Selberg L-function
$$
L(s, f \otimes g) = \sum_n \frac{a_n(f)\, a_n(g)}{n^s}
$$
admits its own Euler factorisation in terms of Satake parameters of $f$ and
$g$, and meromorphic continuation. This packages a "multiplicative pairing" of
two prime-by-prime DNAs into a single L-function.

> *Source:* [Wikipedia — Rankin–Selberg method](https://en.wikipedia.org/wiki/Rankin%E2%80%93Selberg_method).

This is *not* a multiplication in $M_*$; it's a pairing of two L-functions. Its
HSLN reading is more speculative — see §4.3.

### 3.5 Spin(16) and the spinor structure of E8

**Decomposition.** The 248-dimensional Lie algebra $\mathfrak{e}_8$ splits as a
$\mathfrak{so}(16)$-module:
$$
\mathfrak{e}_8 = \mathfrak{so}(16) \;\oplus\; \mathbf{128},
$$
where $\mathbf{128}$ is one of the two half-spin (Weyl–Majorana) representations
of $\mathrm{Spin}(16)$. Dimensions: $120 + 128 = 248$.

> *Source:* [Wikipedia — E8 (mathematics)](https://en.wikipedia.org/wiki/E8_(mathematics)).

**Maximal compact subgroup.** $\mathrm{Spin}(16)/(\mathbb{Z}/2\mathbb{Z})$ is the
maximal compact subgroup of the split real form $E_{8(8)}$.

**Physical content.** Spinor representations require a $4\pi$ rotation to return
to the identity (the defining feature of the double cover
$\mathrm{Spin}(n) \to \mathrm{SO}(n)$). If we choose to use the $\mathbf{128}$
representation as the carrier of input data, the network's data inherits
fermionic transformation behaviour: a $2\pi$ rotation acts as $-1$.

**Honest assessment.** The Spin(16) angle is *geometrically present* in $E_8$,
but it's not yet clear how it enters HSLN computation. See §4.3.

---

## 4. Critical analysis

### 4.1 Watertight (load-bearing claims that hold)

1. **$E_8$ theta function = $E_4$, weight 4, level 1.** Classical and verified.
2. **Sturm's bound makes DNA finite.** A modular form is determined by finitely
   many Fourier coefficients — this is mathematically precise and gives the
   network a discrete parameter set despite living in an infinite-dimensional
   function space.
3. **Implicit function theorem moves zeros.** Around simple zeros, the
   attractor positions are smooth functions of $\theta$, so gradient descent on
   $\theta$ is well-defined locally.
4. **Holomorphic energy landscape ⇒ zeros are the only minima of $|F|^2$.**
   Max modulus principle — clean.
5. **Multiplication of modular forms unions the zero sets.** This *is* a real
   model-merging operation with the exact semantics ("attractors of both") the
   user hoped for.
6. **Hecke eigenforms have Euler products.** Newforms factor over primes; the
   DNA of a newform is essentially $\{a_p\}_p$.
7. **Eichler–Shimura identifies cusp forms with parabolic cohomology.** This is
   the precise sense in which a trained model is a "closed path" in cohomology.

### 4.2 Needs more argument

1. **State-space dimension matches input dimension.** $E_8$ is 8-dimensional;
   $\mathbb{H}_g$ has *complex* dimension $g(g+1)/2$. For $g=1$, state is
   2-real-dimensional — too small. For $g=8$, state is 72-real-dimensional —
   plenty, but evaluating $\Theta^{(8)}_{E_8}$ numerically is hard. *We need a
   choice of $g$ and a justification.* Plausible: $g = 4$ gives complex dim 10,
   real dim 20.

2. **Parameter count vs Sturm bound.** Level-1 weight-4 has $\dim M_4 = 1$ —
   one parameter, useless. To get the user's "25-digit DNA" we must either:
   - raise the level (use $\Gamma_0(N)$ for $N \gg 1$), which gives $\dim M_4(\Gamma_0(N)) \sim N/3$;
   - raise the weight (but weight is forced to $\text{rank}/2 = 4$ if we want $\Theta_{E_8}$); or
   - raise the genus $g$ (Siegel forms in higher degree have rapidly more
     coefficients — at $g = 2$, $\dim M_k^{(2)}$ grows roughly cubically in $k$).
     *The user's "9^25 DNA strands" mental model requires committing to one of
     these directions. Recommend genus $\geq 2$ with non-trivial level.*

3. **Structure theorem ≠ "individual neuron tuning".** The PID structure
   theorem applied to the $\mathbb{C}$-vector space of forms gives just
   $\mathbb{C}^n$ — no extra structure. The "tune one coefficient → tune one
   neuron" idea actually rides on the **Implicit Function Theorem applied to
   the Jacobian of $F$ around its zeros**, *not* on the structure theorem. We
   should drop the structure theorem framing — it's not what's doing the work.

4. **Hecke decomposition as model factorisation.** The Hecke algebra
   diagonalises the space of cusp forms into eigenspaces. So a "trained model"
   that *happens to be* a Hecke eigenform can indeed be factored prime-by-prime.
   But there's no guarantee that gradient descent on the full Fourier vector
   lands inside the eigenform locus — generic $\theta$ is *not* an eigenform.
   *Either restrict the optimiser to the eigenform manifold (hard: it's a
   non-linear submanifold), or accept that decomposition is not exact post-training.*

5. **Spin(16) data-twist.** The 248-dim decomposition $\mathfrak{e}_8 = \mathfrak{so}(16) \oplus \mathbf{128}$
   gives a real geometric structure, but the data on the HSLN doesn't naturally
   live in $\mathbf{128}$. *To use it, we'd need an explicit map from input
   data to the spinor space, which we haven't specified.*

### 4.3 Speculative / wrong as stated

1. **"Cup product splices trained strands."** The cup product takes
   $H^p \otimes H^q \to H^{p+q}$. For Eichler–Shimura we're in $H^1$, so the
   cup product lands in $H^2$ — a *different* cohomology group, of a different
   modular curve. There's no obvious sense in which $\alpha \smile \beta$ is "a
   trained model that does both tasks". This claim, as stated by Gemini, is
   metaphorical. The right operation for "do both tasks" is **multiplication
   in the graded ring** (§3.4 (b)), not cup product. *Recommend dropping the
   Eichler–Shimura / cup-product framing for composition.*

2. **Rankin–Selberg as "deeper merge".** RS L-functions pair two automorphic
   forms but the output is an L-function (a sequence), not a modular form on
   the same space. To turn an RS convolution into a *new HSLN model*, we'd need
   to invert it back into a form — which is not a standard operation.

3. **"E8 lattice IS the reservoir."** In the architecture as written, the
   lattice $E_8$ enters only through the choice of theta series. The reservoir
   is $\mathbb{H}_g$, not $E_8$. The lattice provides the *modular form*; it is
   not itself the dynamical space. Fine, but should be stated cleanly.

4. **"Memory at the cusps."** The intuition that long-term memory accumulates
   at the boundary of $\mathbb{H}_g$ (the cusps and rational boundary points)
   is plausible because the hyperbolic metric makes the boundary infinitely
   far away. But the gradient flow $\dot Z = -\alpha \nabla |F|^2$ flows
   *toward zeros*, not toward cusps. Modular forms typically *don't* vanish at
   cusps — they take finite non-zero values. So under this dynamics, memory
   does *not* migrate to the cusps. *Either change the dynamics (e.g. add a
   metric-aware drift) or drop this part of the picture.*

### 4.4 Open questions before committing to a PoC

1. **Genus and level.** Fix $g$ and $N$ to get the parameter count and zero
   count we want. Recommend: try $g = 2$, $N = 11$ (smallest level with
   non-trivial cusp forms), weight $4$. Numerical libraries exist for genus-2.

2. **State-space encoding.** How does input $u(t) \in \mathbb{R}^d$ map into
   $\mathbb{H}_g$ in a way that respects the symplectic structure? A naive
   linear map $B: \mathbb{R}^d \to \mathrm{Sym}_g$ is fine for a first pass.

3. **Loss function.** Spike-train losses (van Rossum, victor-purpura) are
   standard for SNN training. Pair with a regulariser that keeps $F$ away from
   degenerate critical points (collisions of zeros).

4. **Gradient computation.** $\partial F / \partial a_T$ is just the basis
   function $e^{2\pi i \operatorname{tr}(TZ)}$, so the gradient w.r.t. $\theta$
   is cheap. Backprop through the ODE solver is the standard adjoint-method
   trick (Chen et al., Neural ODEs, 2018).

5. **Numerical evaluation of Siegel forms.** Even truncating to Sturm bound,
   evaluating Siegel Fourier sums at arbitrary $Z \in \mathbb{H}_g$ is
   numerically delicate. Use established libraries (Sage, PARI/GP) or
   reimplement.

6. **Verify model merging works.** Train two HSLNs on disjoint tasks, multiply
   their DNAs (Cauchy convolution), confirm the product network solves both —
   this is the cheapest empirical test of the whole architectural claim. *If
   this fails, the algebraic framing is dressing.*

---

## 5. Minimal proof-of-concept plan

A PoC that exercises the load-bearing pieces — and skips the speculative ones —
would consist of:

1. **Pick $(g, k, N) = (1, 4, 11)$ for the first prototype.** Genus 1 means $Z = \tau \in \mathbb{H}$,
   state is 2D — trivial to visualise. Level 11 is the smallest level where
   $\dim S_4(\Gamma_0(11)) > 0$, giving non-trivial DNA. Sturm bound is
   $\lfloor 4 \cdot 12 / 12 \rfloor + 1 = 5$, so DNA has ~5 free coefficients.

2. **Build the truncated form $F(\tau; \theta) = \sum_{n=0}^{5} a_n q^n$.**

3. **Implement the ODE solver** for $\dot\tau = -\alpha \partial_\tau |F|^2 + B u(t)$
   in `diffrax` (JAX) or `torchdiffeq` (PyTorch). Use adjoint sensitivity for
   $\nabla_\theta \mathcal{L}$.

4. **Train on a tiny temporal-XOR task.** Two pulse-encoded inputs, output is a
   spike iff exactly one input was present. If the network can't learn this,
   no point scaling up.

5. **Test merge.** Train another HSLN on a different task; multiply the DNAs
   (Cauchy convolution); confirm the product solves both tasks zero-shot.

6. **If 1–5 succeeds:** scale to $g = 2$, $N = $ something with more parameters,
   and a real time-series task.

The PoC deliberately *omits*: Spin(16) data encoding, Eichler–Shimura cohomology,
Rankin–Selberg convolution, cusp-memory dynamics. These are the parts flagged
in §4.3 as speculative and should be revisited only after the kernel works.

---

## Appendix — sources

- [Wikipedia — E8 lattice](https://en.wikipedia.org/wiki/E8_lattice)
- [Wikipedia — E8 (mathematics)](https://en.wikipedia.org/wiki/E8_(mathematics))
- [Wikipedia — Modular form](https://en.wikipedia.org/wiki/Modular_form)
- [Wikipedia — Siegel modular form](https://en.wikipedia.org/wiki/Siegel_modular_form)
- [Wikipedia — Hecke operator](https://en.wikipedia.org/wiki/Hecke_operator)
- [Wikipedia — Eichler–Shimura isomorphism](https://en.wikipedia.org/wiki/Eichler%E2%80%93Shimura_isomorphism)
- [Wikipedia — Rankin–Selberg method](https://en.wikipedia.org/wiki/Rankin%E2%80%93Selberg_method)
- [Wikipedia — Module (mathematics)](https://en.wikipedia.org/wiki/Module_(mathematics))
- [Wikipedia — Structure theorem for finitely generated modules over a PID](https://en.wikipedia.org/wiki/Structure_theorem_for_finitely_generated_modules_over_a_principal_ideal_domain)
- World Equation — [Counting points on the E8 lattice with modular forms (theta functions) #SoME2](https://www.youtube.com/watch?v=AxPwhJTHxSg)
- Tanna et al. (2024), *Optimizing Liquid Neural Networks*, [doi:10.1109/bigdata62323.2024.10826128](https://doi.org/10.1109/bigdata62323.2024.10826128)
- Chen et al. (2018), *Neural Ordinary Differential Equations*, [arXiv:1806.07366](https://arxiv.org/abs/1806.07366) — adjoint-method backprop through ODEs
- Original Gemini brainstorm transcript: `./gemini-transcript.md`

Specialist references not on Wikipedia (worth pulling if you want primary
sources):
- E. Freitag, *Siegel modular forms*, Springer LNM 254 (1983).
- A. N. Andrianov, *Quadratic Forms and Hecke Operators*, Springer (1987).
- J. Sturm, "On the congruence of modular forms," in *Number Theory* (New York,
  1984–85), LNM 1240 (1987), 275–280 — original Sturm-bound paper.
- W. Stein, *Modular Forms: A Computational Approach*, AMS (2007) — accessible
  treatment of Sturm bound, Hecke operators, computation.
