# HSLN — Mathematical Connections & Research Threads

Survey of seven areas [REDACTED NAME] flagged as adjacent to the Heterotic Spiking Liquid
Network, triaged by how much each actually buys us. Every claim below was fetched
from primary sources and triangulated; URLs are inline so they can be audited.

The three ambitions these are measured against:
1. **Composability** — assemble trained primitives algebraically with semantic guarantees (the ML gap we want to fill).
2. **Discrete / symbolic tasks** — can this continuous modular machine do LLM-like symbolic computation?
3. **Gravity as a chaotic attractor** — the E8×E8 heterotic picture, a "gravity" lattice's DNA sculpting the state landscape.

---

## Triage

| Topic | Verdict | The load-bearing link |
|---|---|---|
| **Dedekind η / eta quotients** | **Actionable** | Composition (multiply forms) becomes **vector addition** of integer exponent vectors; modularity becomes **linear constraints**. |
| **j-invariant** | **Actionable** | `C(X(1)) = C(j)`: every modular-invariant readout is rational in j (a theorem). CM points → a discrete symbol alphabet. |
| **Group cohomology / Eichler–Shimura** | **Actionable** | The weight-k DNA space *is* `H¹(Γ, Sym^{k-2})` with a built-in Hecke action — a rigorous linear handle that stays inside the modular subspace. |
| **E8 lattice VOA** | **Actionable (modest)** | Affine E8 at level 1 has character = E4 = Θ_E8 (our seed); its coset thetas give a richer DNA basis. |
| **Topological K-theory** | **Structural analogy** | Composition as a ring map (⊕/⊗ ↔ Whitney sum/tensor in K⁰). No actual bundle defined yet. |
| **Algebraic K-theory (Q-construction, Fund. thm)** | **Structural analogy** | Networks-as-exact-category → K₀ as a composition invariant. The R[q] coincidence is superficial. |
| **Monster VOA / moonshine** | **Aspirational** | No mechanism for Monster symmetry. But VOA modules form a *modular tensor category* → composability is categorical. |

---

## 1. Eta quotients — the composition linearizer (strongest practical lead)

**Facts.** η(τ) = q^{1/24} ∏_{n≥1}(1−qⁿ), weight ½; η²⁴ = (2π)⁻¹²·Δ. η is **non-vanishing on H**, so Δ has a single simple zero, at the cusp i∞ only ([Dedekind eta](https://en.wikipedia.org/wiki/Dedekind_eta_function), [modular discriminant](https://en.wikipedia.org/wiki/Modular_discriminant)).

An **eta quotient** f(τ) = ∏_{d|N} η(dτ)^{r_d} is a modular form of weight k = ½·∑ r_d on Γ₀(N), provided (Newman/Ligozat, verified in [Rouse–Webb arXiv:1311.1460](https://arxiv.org/pdf/1311.1460), [Savitt arXiv:2507.16225](https://arxiv.org/abs/2507.16225)):
- ∑_{d|N} d·r_d ≡ 0 (mod 24)
- ∑_{d|N} (N/d)·r_d ≡ 0 (mod 24)
- Ligozat cusp orders ord_{c/d}(f) = (N/24)·∑_δ gcd(d,δ)² r_δ / (gcd(d,N/d)·d·δ) ≥ 0 at every cusp.

**The win for composability.** Multiplying eta quotients **adds exponent vectors**:
∏η(dτ)^{r_d} · ∏η(dτ)^{s_d} = ∏η(dτ)^{r_d+s_d}, and weight k = ½∑r_d adds linearly. So our composition primitive (multiply forms = convolve DNAs = union of zeros, weights add) becomes **`(r) ⊕ (s) = (r+s)`** — a lattice sum. A primitive library indexed by integer points; composition is addition; the modularity conditions are **linear** (integer points in a polytope), so "is this still a valid modular form?" is a convex feasibility check, not a nonlinear miracle.

**Trade-off (honest).** Eta quotients are a thin subfamily: because η ≠ 0 on H, **their zeros are forced to the cusps** (rational boundary points), never the interior. We lose forms with interior zeros — E4 (zero at ρ), E6 (zero at i), generic Hecke eigenforms. So eta-quotient DNA is expressive for **boundary/symbolic** structure but weak for placing a neuron at an arbitrary interior τ.

**Speculative (flagged).** Train the DNA *as the integer exponent vector* (r_d) directly — composition = addition makes the search a lattice, modularity is integer linear programming, almost certainly better-conditioned than gradient descent on raw q-coefficients (where most vectors aren't modular at all). N acts like a discrete "width" knob: bigger N → more divisors → more cusps → more neuron slots. Untested whether small-N polytopes are rich enough.

**Confirmed numerically** (`viz/eta_compose.py`, figure 21, 2026-05-29): the composition residual |f_r·f_s − f_{r+s}|/|f_{r+s}| = 6.3e-16 (exact); weight adds; the level-11 admissible lattice has 27 congruence points / 8 holomorphic forms in a 25×25 box, and is closed under addition — (2,2)+(2,2)=(4,4), i.e. the X₀(11) newform η²(τ)η²(11τ) composing with itself. The eta quotient has no interior zero; E₄ does (at ρ).

---

## 2. The j-invariant — canonical readout, and the discrete bridge

**Facts.** j = E4³/Δ = 1728·E4³/(E4³−E6²); q-expansion j = q⁻¹ + 744 + 196884q + 21493760q² + … ([j-invariant](https://en.wikipedia.org/wiki/J-invariant)). j is the **Hauptmodul**: it is weight-0, SL₂(ℤ)-invariant, and **every modular function is a rational function of j** — `C(X(1)) = C(j)` — and j is a bijection from the fundamental domain onto ℂ. j(i)=1728, j(ρ)=0.

**Readout link (a theorem, not analogy).** The modular action on τ is pure symmetry. Any readout that must respect it is a function on X(1), hence **rational in j**. So a readout head `R(τ) = P(j)/Q(j)` can represent *any* invariant readout — total expressivity from one generator, no information lost (j is a bijection). (Weight-0 invariant readouts; equivariant outputs still need actual forms.)

**Discrete-symbol bridge (the LLM angle — flagged speculation).** At **CM points** (τ imaginary quadratic), j(τ) is an algebraic integer — a *singular modulus*. The nine **Heegner numbers** {1,2,3,7,11,19,43,67,163} have class number 1, giving **rational-integer** j-values; e.g. j((1+√−163)/2) = −640320³ (whence e^{π√163} ≈ 640320³+744) ([Heegner number](https://en.wikipedia.org/wiki/Heegner_number)).

Proposed architecture: treat CM points as a **discrete alphabet** — countable, arithmetically distinguished, with integer "names." The continuous spiking flow moves τ through H; a token is emitted when the trajectory lands near a CM point, read off via the integer value of j. Attractive because the symbol set is intrinsic to the geometry, integer j-values give a natural quantization target, and SL₂(ℤ) orbits give equivalence classes for free.

**Honest caveat.** Our attractors are *zeros of F*, which are generically **not** CM points — so we'd have to *engineer* F (or the readout) so attractors coincide with chosen singular moduli. No prior work found doing this. A toy experiment, not an established mechanism.

---

## 3. Group cohomology / Eichler–Shimura — the rigorous backbone

**Facts.** H^n(G,M) = Z^n/B^n (cocycles mod coboundaries); H⁰ = invariants, H¹ = crossed homs mod principal, H² = extensions ([Group cohomology](https://en.wikipedia.org/wiki/Group_cohomology)). **Eichler–Shimura** (verified, [Eichler–Shimura](https://en.wikipedia.org/wiki/Eichler%E2%80%93Shimura_isomorphism), [Iyengar notes](https://ashwiniyengar.github.io/files/EichlerShimura.pdf)):

  M_k(Γ) ⊕ S̄_k(Γ) ≅ H¹(Γ, V_{k-2}^∨),   S_k ⊕ S̄_k ≅ H¹_par(Γ, V_{k-2}),

with V_{k-2} = Sym^{k-2}(ℂ²), dim H¹ = dim E_k + 2·dim S_k. The map sends a form to its **period polynomial** r_f(X) = ∫₀^{i∞} f(z)(X−z)^{k-2}dz, and is **Hecke-equivariant**.

**Why it matters (real).** At fixed weight k, our DNA space *is* a finite-dimensional space of forms — Eichler–Shimura gives it a canonical identity as `H¹` with a **commuting Hecke action**. The "Hecke gap" we flagged (arbitrary q-series aren't modular) is exactly the statement that the *real* network space is this closed eigenspace structure. **Period polynomials are an explicit alternative coordinate system** (coefficients = critical L-values) that stays inside the modular subspace by construction.

**Speculative (flagged).** Period coordinates may be **better-conditioned for training** than raw q-coefficients: they're a Hecke-eigenbasis, so descent moves along Hecke-invariant directions and can't leave the form space. Worth a small experiment comparing Hessian spectra of the |F|² loss in q- vs period coordinates. (H² as "composition = extension" does **not** fit cleanly — our composition is a graded-ring product, not a group extension. The honest handle is H¹, not H².)

---

## 4. K-theory (topological + algebraic) — structural rhyme, no engine yet

**Topological** ([Topological K-theory](https://en.wikipedia.org/wiki/Topological_K-theory)). K⁰ is the Grothendieck group of bundles under ⊕ (a ring under ⊗). Composition-as-ring-map is the clean parallel: direct-sum-of-lattices ↔ Whitney sum ↔ + in K⁰; tensor ↔ ⊗. **To make "classify networks up to deformation" precise we'd need an actual bundle** (e.g. the eigenbundle of the Hessian of |F|², or a bundle of zero-divisors) — none defined yet, so it's analogy.

Real physics precedent: **Diaconescu–Moore–Witten** ([arXiv:hep-th/0005091](https://arxiv.org/abs/hep-th/0005091)) derive the K-theory classification of IIA fluxes from an **E8 gauge theory in 11d** — E8 and K-theory genuinely co-occur, but via E8's *topology*, not its lattice DNA. **Verdict on rank-8 (E8) vs period-8 (KO Bott periodicity): numerology** — KO's 8 is Clifford-algebra periodicity (Cl_{n+8} ≅ Cl_n⊗ℝ(16)); unrelated origin.

**Algebraic** ([Q-construction](https://en.wikipedia.org/wiki/Q-construction), [Fundamental theorem](https://en.wikipedia.org/wiki/Fundamental_theorem_of_algebraic_K-theory)). Quillen: K_n(C) = π_{n+1}(BQC) for an exact category C. Fundamental theorem: regular R ⇒ K_n(R[t]) = K_n(R); Bass–Heller–Swan K_n(R[t,t⁻¹]) = K_n(R) ⊕ K_{n-1}(R) ⊕ NK ⊕ NK, Nil terms vanish iff regular. **The R[q] coincidence is superficial** — our DNA lives in a *truncated* R[q]/(qᴺ), which is nilpotent (the opposite regime). **Speculative:** frame networks as an exact category (admissible monos = divisibility of forms, F|G ⟺ zeros(F)⊂zeros(G)); since the form ring is finitely generated, K₀ might be a finite computable classifier of networks-up-to-composition. Load-bearing unchecked claim: extension-closure under the product.

---

## 5. Monster VOA — aspirational, but VOAs give a real composability statement

**Facts** ([Monster VOA](https://en.wikipedia.org/wiki/Monster_vertex_algebra), [Monstrous moonshine](https://en.wikipedia.org/wiki/Monstrous_moonshine)). A VOA is a graded vector space with a state-field correspondence (a chiral 2D CFT). The moonshine module V♮ has graded dimension **j(τ)−744 = q⁻¹ + 196884q + …**; McKay's 196884 = 196883 + 1. FLM built V♮ from the **Leech lattice** (rank 24, no roots) by a ℤ/2 orbifold; **Aut(V♮) = the Monster** (Borcherds, Fields Medal). **Even lattices give VOAs.**

**The E8 hook (real, modest).** The **E8 lattice VOA = affine E8 at level 1**, whose single character is **E8's theta = E4 = our seed**. Its coset/affine characters give a principled, modular-covariant basis of q-series — richer DNA than E4 alone, with a built-in continuous E8 symmetry. Small enough to actually try.

**Verdict.** Monster-like symmetry is **aspirational** — the Monster is the automorphism group of an infinite-dimensional algebra, unrelated to SL₂(ℤ) acting on a point τ. Manufacturing it would require our *state* to be a full VOA, not a form evaluated at τ. **But** VOA modules form a **modular tensor category**, so categorical composability is a genuine, theorem-level property of the framework — that, not the Monster, is the real selling point. E8 affine characters are the deliverable; the Monster is inspiration.

---

## 6. Gravity as a chaotic attractor — where this ties together (hypothesis)

The genus-2 off-diagonal entry z in Z = [[τ₁, z],[z, τ₂]] is the natural **coupling/gravity knob**:
- **z = 0** (direct sum): energy factorizes, flow decouples — integrable, two clean parallel subsystems (verified, figure 20).
- **z ≠ 0** (tensor-like): the compound flow −∇|F_A F_B|² = −(|F_B|²∇|F_A|² + |F_A|²∇|F_B|²) is *not* the union of flows; basins reshape and cross-talk (verified, figure 19).

**Hypothesis (to test numerically):** dialing z interpolates between integrable and possibly **chaotic** dynamics, and a strange attractor in the coupled flow is the concrete realization of "gravity as a chaotic attractor." This is the experiment that unifies the heterotic E8×E8 framing with the dynamics we've already built.

**Confirmed numerically** (`viz/coupling_sweep.py`, figure 22, 2026-05-29). Coupling enters through the Sp(4,ℝ)-invariant Siegel metric, K = [[y₁², w²],[w², y₂²]] with w² = κ·y₁y₂ (PSD for κ∈[0,1)). Three findings, two of them refining the hypothesis:
- **Routing is robust, not fragile** (the hypothesis was wrong here, in a good way). Error stays ≈0 for *all* κ∈[0,0.95]. Reason: the joint target is a *simultaneous* zero of both sectors, so it is a critical point of the flow for every κ — the off-diagonal metric cannot move the equilibria of V = log|F_A|² + log|F_B|², only the path. Gravity warps the route, not the destination.
- **The route does bend** measurably with κ (the trajectory curves toward, but does not reach, the other target).
- **Coupling unlocks chaos.** With a periodic drive on one coordinate: at κ=0 the two coordinates are independent driven first-order flows (2-D extended phase space → Poincaré–Bendixson forbids chaos), and nearby trajectories contract to a single orbit (separation → 1e-16). At κ=0.85 the coordinates couple (3-D extended phase space), and nearby trajectories stay separated (sensitive dependence). So the off-diagonal "gravity" is precisely what opens the dimension chaos needs. (Bounded sensitive dependence shown; a formal positive Lyapunov exponent is *not* yet measured — flagged.)

---

## Next experiments, ranked

1. ~~**Eta-quotient DNA** (composability)~~ — **done** (figure 21): multiply = add exponents (exact), admissible lattice closed under addition.
2. ~~**z-sweep** (gravity/dynamics)~~ — **done** (figure 22): routing robust, route warps, coupling unlocks sensitive dependence.
3. ~~**CM-point readout** (discrete tasks)~~ — **done** (figures 23, 24): the 9 Heegner CM points form an integer-named alphabet (verified to 80 digits); a trained network answers "What is your name?" → "ADA" by routing to CM points and decoding j → nearest singular modulus. Key enabler: j is SL₂(ℤ)-invariant, so the readout reduces any endpoint to the fundamental domain — the flow lives at moderate Im, the CM *value* is read there.
   - **Learned classifier follow-up** (figure 25, `viz/cm_classifier.py`): a learned **4-class** 2D classifier, **95% on held-out data**. Only two CM symbols are cleanly reachable (A=j1728, D=j0), so — per "encode with what you have" — 4 classes are **2-bit codewords** (AA/AD/DA/DD) across two direct-sum coordinates. Honest mechanism: the gravity landscape is **fixed** with neurons at the two CM points and only the **input encoder** is learned (reservoir-computing style); the near-frozen flow + CM/j readout do the decode. A key practical lesson: j over the strip is **non-monotone in Im** (peaks ~1728 near Im 0.5, falls to 0 by Im 0.85, drops again below 0.45), so the encoder's Im range must be restricted to the monotone band [0.45, 0.90] for clean training.
   - **Tensor-composition classifier** (figure 26, `viz/cm_tensor.py`): the **compose-separately-then-deploy** workflow made load-bearing (answering the "are we just a reservoir?" worry). Train one minimal single-neuron DNA per class, **completely separately**; compose by **tensor product** (multiply forms = convolve DNAs), F = F₀·F₁·F₂·F₃. The compound's four neurons equal the four parents' to **1.76e-16** (zero-union is exact — the proven property, here verified). Classify held-out by **nearest neuron** (detection readout → no flow → tensor cross-talk never enters): **95% first compose**. Caveats kept honest: the per-class models are minimal (least-squares single-zero ≈ class centroid), so the classifier is effectively nearest-centroid *assembled by composition*; and the four data-driven neurons are not clean CM integers (only 2 reachable), so this reads nearest-neuron, not CM-integer. The value demonstrated is the **algebraic composition + zero-union guarantee** a reservoir cannot give. Tensor (one shared coordinate, N neurons) is the right operator for per-class models; direct sum (separate coordinates) is for independent per-bit factors.
4. **Period-coordinate training** (conditioning): compare |F|² loss Hessian spectra in q- vs Eichler–Shimura period coordinates.
5. **E8 affine characters** (richer basis): add E8 coset thetas to the DNA basis at genus 1.
6. **Formal Lyapunov exponent** for the coupled driven flow (figure 22 panel C shows bounded sensitivity; measure λ_max to confirm chaos).

## Scaling (measured, CPU — figure 28, `viz/scaling.py`)

Honest timings on this CPU (no GPU):
- **Batched forward pass** (`jax.vmap` over inputs): ~25k passes/sec, flat across batch ≥16 (CPU cores saturate). This is the GPU-relevant axis — the same vectorised map keeps climbing on a GPU; the CPU plateau is a lower bound.
- **Weight (neuron count)**: cost is **linear** in DNA length (4→1024 neurons scales ~linearly).
- **Composition**: convolving K DNAs is **microseconds** (7–76 µs for K=2–64) — ~1000× cheaper than a forward pass. Composing trained models is essentially free.
- **Genus**: the *only* steep axis. Genus-1 series ≈ 20 µs; genus-2 representation numbers climb 0.085 s → 1 s → 8.3 s as the Fourier bound maxn goes 4 → 6 → 8 (super-linear). The Siegel theta sum is the cost driver.

Conclusion: batch, weight, and composition are GPU-trivial ("breakfast"); **genus is the research frontier**. A demo at genus 1–2 with many composed tasks and large batches is well within reach.

## The "it's just Fourier analysis of a particle" framing (correct skeleton, modular soul)

[REDACTED NAME]'s read is accurate: the DNA literally *is* the Fourier (q-expansion) coefficients of the form F; the state is a particle in the potential |F|²; computation is its driven motion; readout reads its position/invariants (fig 27). What makes it **more than a generic Fourier-potential reservoir** is that the potential is a **modular form**, which uniquely buys: (1) the **composition algebra** (multiply = convolve = zero-union; direct sum) — algebraically combine potentials *with guarantees*, which arbitrary Fourier potentials cannot; (2) **symmetry** (SL₂(ℤ)/Sp) = free weight-sharing + the invariant readout j; (3) **finite generation** (Sturm bound) — an "infinite" landscape from a finite DNA; (4) the **arithmetic readout** (CM points = integer alphabet). Strip the modular structure → generic nonlinear reservoir; keep it → composable, structured. The modular/E8 part is the soul.

## Two kinds of composition — and grokking (figure 29, `viz/skill_compose.py`)

Crucial distinction: **DNA-product** composition (tensor/direct-sum, what we proved) combines landscapes *in parallel* (union of detectors / independent coordinates). It is **not function composition**. To "tell me the missing letter *by number*" you need **stacking** = function composition B∘A: skill A's output feeds skill B's input. Different operation; both are "composition."

Demonstrated stacking (fig 29, 6/6): position ↔ a **root of unity** (the HSLN-native circular state, q = e^{2πiτ}). Since the n-th roots sum to zero, the present letters' net pull points to the missing one's **antipode** — so skill A is a *driven, confined reservoir* (a particle in an |F|² well integrating the bag of present letters) that settles toward the gap; negate → the missing state. Skill B (a **separately-trained** softmax) maps that state's angle → number. Stack A→B: present A,B,D,E,F → missing C → number 3, and all 6 problems correct.

**The grokking link (hypothesis, to test next).** Grokking was found on modular arithmetic (Power et al. 2022); the grokked solution implements the task as a **Fourier/circular representation** — numbers as e^{2πik/p}, addition as rotation (Nanda et al. 2023). *(Recalled from training; verify before relying.)* That circular representation is the HSLN's **native** state. Hypothesis: HSLN may generalize on modular/compositional tasks more readily because the "grokked" representation is built in, not discovered. The find-missing task above is small (n answers, structural), so it shows *stacking*, not grokking. The proper grokking testbed is a larger structured task — e.g. (a+b) mod n with a train/test split — where memorization is possible but generalization is the test, with the encoding **learned from scratch** to see whether it discovers the cyclic rep (and whether generalization is sharp/delayed).

**Result (figure 30, `viz/grok.py`):** confirmed the shortcut. On (a+b) mod 11, 50/50 split: the **circular-phase model** (one learnable phase per symbol, combine by angle-addition) sends train and test to 100% *together* — no grokking delay — because with only n+1 parameters it *cannot memorise*, only fit the global rule; its learned phases φ(k) emerge as **roots of unity**. A generic **embedding+MLP control** memorises train (100%) but sits at ~0% held-out — the classic pre-grok memorization phase. So the HSLN's native circular representation is exactly grokking's endpoint, and having it built in removes the memorize-then-grok dynamic. (Honest caveat: "can't memorise" is *why* it generalizes — the inductive bias does the work.)

## Primes by composition (figure 31, `viz/prime_sieve.py`)

A playful but working application of the *multiply = zeros-union* composition. Each skill detects multiples of a small prime p via its roots-of-unity comb, sin(πx/p) (zero exactly at multiples of p). Multiplying the detector fields (tensor product) gives F(x) = ∏_{p∈{2,3,5,7}} sin(πx/p), whose **zero set is the union of all those multiples = the composites**; the **primes are where F survives**. For n ≤ 100, sieving by {2,3,5,7} (primes ≤ √100) catches every composite, so the survivors are exactly the primes — **all 25 recovered, exact match**. It's the Sieve of Eratosthenes recast as a product of roots-of-unity fields: composition turning a prime test into a computable field evaluation.

## Zeta from composed prime models — the golden key (figure 32, `viz/zeta_compose.py`)

The Euler-product = series identity is itself a **multiply-composition**, in the Dirichlet basis. Each prime p is a little model: its Euler factor 1/(1−p⁻ˢ) = Σₖ p⁻ᵏˢ, with Dirichlet coefficients 1 at the powers of p. **Merging by Dirichlet multiplication** (the Euler product) makes the coefficients **all ones** = ζ(s) = Σ 1/nˢ, *because every integer factors uniquely into prime powers* — verified: composing the 15 prime-models up to 48 recovers a(n)=1 for all n≤48. Numerically the product and the series both → ζ(2)=π²/6. This is the dual of the prime sieve (fig 31): the sieve multiplies "drop the multiples of p" and the primes survive; the Euler product multiplies "keep the powers of p" and all integers are built. Same multiplicative structure, two faces. Honest scope: this constructs the series for Re(s)>1 (the golden key); it does **not** reach the zeros or RH (those need the analytic continuation past where the product converges).

## Factorising by composition — the inverse of the Euler product (figure 33, `viz/factorize.py`)

Each prime p ≤ 100 is a little model detecting its multiples via its **roots of unity**: D_p(n) = (1/p)Σ_k e^{2πikn/p} = 1 iff p|n (the p phasors align to sum p exactly when p|n, else cancel to 0). Compose the detectors (apply, divide out) → prime factorisation — the inverse of fig 32. With primes ≤ 100 it is **complete for every n < 10000** (smallest prime factor ≤ √n < 100) and cracks all smooth numbers above; a product of primes all > 100 (101·103, 127·9721) leaves an irreducible residual — the **factoring wall** (and the reason factoring is hard / the basis of RSA). Verified against trial division on the test set.

## Riemann hypothesis — honest status (figure-free; `HSLNZeta.lean`)

Machine-checked in Lean (against mathlib): the completed zeta satisfies Λ(1−s)=Λ(s) (`completedRiemannZeta_one_sub`, sorry-free), and **Re s = 1/2 is exactly the fixed axis of the functional-equation symmetry s↦1−s** — that is the entire origin of the "1/2". The "half" is genuinely a *double-cover / half-weight* phenomenon — but the relevant cover is the **metaplectic double cover of SL₂** (home of the weight-½ Jacobi theta whose modular transformation gives the functional equation), **not** Spin(16)→E8. E8's 248 = 120 ⊕ 128 (Spin(16) spinor) is real Lie theory but unrelated to ζ's 1/2; E8's own Epstein zeta has axis Re s = 2. Crucial honest point: the **symmetry does not force RH** — Epstein zeta and the Davenport–Heilbronn function share the s↔1−s functional equation but have **zeros off the line**, because they lack an **Euler product** (the primes). So the load-bearing ingredient for RH is the multiplicative/prime structure, not the symmetry. We have the symmetry side cold (Lean); the prime side is the frontier. (Sources: MIT 18.785 lecture notes; arXiv:1204.6297; arXiv:1602.06328; Wikipedia E8.)

## Three RH-adjacent explorations (figures 34–36)

- **Spectral / Hilbert–Pólya** (fig 34, `viz/spectral.py`): the honest shape of "a model exhibiting RH" is a *self-adjoint operator* whose eigenvalues are the zeros (real ⇒ on the line ⇒ RH) — matrix-flavoured, our wheelhouse. We don't have it, but **Montgomery–Odlyzko**: the zeros' unfolded spacings follow the **GUE Wigner surmise** (level repulsion), not Poisson, and a real random Hermitian matrix's bulk spacings obey the same law. So the zeros behave statistically like a quantum/Hermitian spectrum. Real zeros from `mpmath.zetazero` (cached). Evidence, not a proof.
- **Explicit formula** (fig 35, `viz/explicit.py`): the "interpolation" instinct made literal. ψ(x) = x − log2π − ½log(1−x⁻²) − Σ_ρ xᵖ/ρ; each zero adds an oscillation 2√x·Re[x^{iγ}/(½+iγ)]. 1→10→50→200 zeros reconstruct the prime-power staircase (mean error 0.58→0.08). The zeros and primes encode each other.
- **Factorization landscape** (fig 36, `viz/landscape.py`): sieved lpf + ω for n ≤ 9,000,000 in 0.9s on the M1. The (n, lpf) geology (prime diagonal + n/k comb), the smoothness-exponent distribution (only 2.8% are 100-smooth), and **Erdős–Kac** (ω(n) asymptotically Gaussian, μ≈3.0, σ≈1.05 — a CLT for prime factors).

Together with figs 31–33 and `HSLNZeta.lean`, this is now a coherent number-theory suite: build ζ from primes, sieve/factor by composition, the zeros↔primes duality, and the spectral (matrix) target for RH — all honest about scope (no RH claim).

## The DNA algebra — composition IS a ring, and we have a group (figure 37, `viz/dna_algebra.py`; `HSLNAlgebra.lean`)

[REDACTED NAME]'s instinct ("we have all the operations — we could derive a group") is exactly right, and the structure is classical: a DNA is an **arithmetic function** f : ℕ → ℝ (the Dirichlet/q-expansion coefficients we train), and under **(pointwise +, Dirichlet convolution ×)** these form the **commutative ring of arithmetic functions** (the Dirichlet ring). Our compose-operations *are* the ring operations. Machine-checked in `HSLNAlgebra.lean` against mathlib (`ArithmeticFunction ℝ` is a `CommRing`), sorry-free. So "whatever we can teach independently, we can compose" is literally ring algebra. Name a small alphabet of DNAs and reason about them:

- **DNA_δ** = [1,0,0,…] — the convolution identity (the do-nothing DNA).
- **DNA_ζ** = all ones — the Riemann generator, ζ(s)=Σ1/nˢ.
- **DNA_μ** = Möbius — the **group inverse** of ζ: `ζ * μ = δ` (Möbius inversion). The units of the ring (f with f(1)≠0) form an abelian group; ζ⁻¹=μ is the cleanest element of it. (`coe_zeta_mul_coe_moebius`, Lean.)
- **DNA_Λ** = von Mangoldt — the prime-power spectrum.
- **DNA_χ** = the mod-4 character — *modular arithmetic* as a DNA.

Four facts, each **verified to machine precision** in the figure and **proven in Lean**:
1. `ζ * μ = δ` — the group inverse.
2. `ζ * ζ = d(n)` — the divisor-count function (ζ² in the ring). (`zeta_squared_counts_divisors`.)
3. **Modular arithmetic ⊗ the zeta generator → sum of two squares.** Composing the per-prime χ-twisted Euler factors builds L(s,χ₄) (coefficients χ(n)); then `ζ * χ = r₂(n)/4`, i.e. **the number of ways n is a sum of two squares** (Jacobi's two-square theorem, r₂(n)=4∑_{d|n}χ₄(d)). Equivalently ζ·L(s,χ₄) is the **Dedekind zeta of the Gaussian integers ℤ[i]** — the abelian factorization ζ_{ℚ(i)}=ζ·L(·,χ₄). Counting lattice points on circles falls out of "modular arithmetic composed with the generator," and L(1,χ₄)=1−⅓+⅕−…=π/4 (Leibniz). This is exactly the "interesting behaviour when zeta meets modular arithmetic" [REDACTED NAME] predicted.
4. **The Lie/log-derivative gives the primes.** The map `D f(n)=f(n)·log n` is a derivation of the ring (Leibniz holds because log(de)=log d+log e). `D(ζ)=log`, and normalising by ζ⁻¹=μ gives `log * μ = Λ` — this is **−ζ'/ζ = Λ**, the von Mangoldt prime spectrum that drives the explicit formula (fig 35). (`vonMangoldt_mul_zeta`, `log_mul_moebius_eq_vonMangoldt`, Lean.)

The point: DNA_ζ, DNA_μ, DNA_Λ, DNA_χ are abstract handles in a ring; new number theory (divisors, Gaussian integers, the primes) is **synthesised by composing them**. Direct sum / tensor of the *dynamical* systems corresponds to **multiplication of their L-functions** (Dedekind ζ = product of Dirichlet L's), so the geometric composition and the Dirichlet-ring product are the same operation in two realisations.

## The Lie derivative of the system — two faces of one generator (figure 38, `viz/lie_derivative.py`)

"What's the Lie derivative of the system? Can we teach the model its own Lie derivative?" There are two Lie derivatives, and the model knows both — and they're the same Euler/dilation generator in two bases.

- **Along the flow (dynamics).** The HSLN is a gradient flow `Ż = −∇E` on the modular energy E=|F|² (F's zeros are the neurons). The Lie derivative of any observable g along the flow field X=Ż is `L_X g = ∇g·Ż`; for the energy itself `L_X E = dE/dt = −|∇E|² ≤ 0` — the **Lyapunov dissipation**. Verified along a trajectory descending into a zero (max rel. error 2e-5, energy monotone 3.5 → 4e-5). This is the dynamical complement to `gravity_preserves_equilibria` (`HSLN.lean`).
- **Along the modular grading.** The generator of q ↦ λq is the Euler operator `D = q d/dq`, which on a q-expansion is just `aₙ ↦ n·aₙ`. The deep fact (**Ramanujan/Halphen**): the ring C[E₂,E₄,E₆] is **closed under its own Lie derivative** — `DE₂=(E₂²−E₄)/12`, `DE₄=(E₂E₄−E₆)/3`, `DE₆=(E₂E₆−E₄²)/2` (residual **exactly 0** in float). So the model computes its own derivative and stays in the space. The weight-corrected **Serre derivative** `ϑ_k = D−(k/12)E₂` climbs the weight ladder Mₖ→Mₖ₊₂ exactly: `ϑE₄=−E₆/3` (4→6), `ϑE₆=−E₄²/2` (6→8) — the Lie-algebra (sl₂) action raising weight.
- **The bridge.** The *same* generator in the Dirichlet basis n^{-s} acts as `aₙ ↦ aₙ·log n` — and on the Riemann generator, normalised by ζ⁻¹=μ, it is **−ζ'/ζ = Λ**, the primes. One Lie derivative: q-grading ↔ Dirichlet-grading. "Combine the Lie derivative with the Riemann generator" → the prime spectrum.

## L-functions — a parametrised family of generators (figure 39, `viz/lfunctions.py`; `HSLNLFunctions.lean`)

Replace ζ's all-ones coefficients by a Dirichlet character χ (a completely multiplicative arithmetic function periodic mod N), and the entire DNA-algebra machinery applies unchanged: Euler product, Lie derivative, group inverse, Möbius-twist, divisor-count analogues. Each χ gives a new ζ-like *generator* — an `L(s, χ) = ∑ χ(n)/nˢ = ∏ₚ (1 − χ(p)p⁻ˢ)⁻¹` — and they all live in the same Dirichlet ring as named DNAs.

**Machine-checked in `HSLNLFunctions.lean`** (sorry-free against mathlib):
- `L_functional_equation` : `Λ_χ(1 − s) = N^{s−½} · W(χ) · Λ_{χ⁻¹}(s)` for every primitive χ (mathlib's `completedLFunction_one_sub`). The fixed axis is still `Re s = 1/2` — the SAME 1/2 for every Dirichlet L-function, by the same functional-equation symmetry.
- `L_one_ne_zero` : `L(1, χ) ≠ 0` for any nontrivial χ (mathlib's `LFunction_apply_one_ne_zero`). This is the analytic ingredient behind Dirichlet's theorem on primes in arithmetic progressions.
- `GeneralizedRiemannHypothesis χ : Prop` — every zero in the open critical strip lies on the critical line. Stated, not proven (open).

**Five special values verified to floating-point precision** (fig 39, falling out of Dirichlet's class-number formula L(1, χ_D) = (2πh)/(w√|D|) for imag. quadratic ℚ(√D), (2hR)/√D for real):
- `L(1, χ₋₄) = π/4` (Leibniz; ℚ(i), h=1, w=4).
- `L(1, χ₋₃) = π/(3√3)` (ℚ(√−3), h=1, w=6).
- `L(1, χ₋₇) = π/√7` (ℚ(√−7), h=1, w=2).
- `L(1, χ₈) = log(1+√2)/√2` (real ℚ(√2), h=1, R=log(1+√2), D=8).
- `L(2, χ₋₄) = G` (Catalan's constant ≈ 0.91596…).

**Abelian factorisation, verified at the coefficient level.** For K = ℚ(√D), the Dedekind zeta factors as `ζ_K = ζ · L(s, χ_D)` (Kronecker–Weber for abelian K). In DNA terms `(ζ * χ_D)(n) = #{ideals of 𝒪_K with norm n}` (modulo unit count). For ℚ(√−3): `6 · (ζ * χ₋₃)(n) = r_hex(n) = #{(a,b)∈ℤ²: a²−ab+b² = n}` (Eisenstein lattice points on hex-norm circles). Verified exactly to M=96. Same picture as fig 37's Gaussian r₂/4 for ℚ(i); modular arithmetic composed with ζ keeps unlocking number fields by ring algebra.

**The bigger point.** L-functions aren't a different framework — they're just *the family of generators inside the existing ring*. One operations algebra, an infinite parametrised set of valid "ζ"s, each with its own functional equation pinned to the same critical line. (Sources: Davenport, *Multiplicative Number Theory* §6; LMFDB.)

## A pop at Birch–Swinnerton-Dyer (figure 40, `viz/bsd.py`)

Elliptic curves give *another* family of generators in the same ring. For E/ℚ:

  `L(E, s)  =  ∑ aₙ/nˢ  =  ∏ₚ (Euler factor at p)⁻¹`

where for good primes p∤N (conductor), the Euler factor is `(1 − aₚ p⁻ˢ + p · p⁻²ˢ)⁻¹` with `aₚ = p + 1 − #E(𝔽ₚ)`; for bad primes a degree-≤1 factor. The recurrence `a_{p^k} = aₚ · a_{p^{k-1}} − p · a_{p^{k-2}}` builds the per-prime sequences; Dirichlet convolution merges them — *the exact same compose-by-Euler-product code we use for ζ and Dirichlet L's*. **Modularity (Wiles–Taylor–Breuil–Conrad–Diamond)**: aₙ is the Fourier coefficient sequence of a weight-2 newform on Γ₀(N), so L(E, s) is the L-function of a modular-form DNA — literally in our ring.

**BSD** says `ord_{s=1} L(E, s) = rank E(ℚ)`. We can't prove it (open). What we *demonstrate*:

1. Build L(E, s) for five famous curves of varying rank by point-counting E(𝔽ₚ):
   `11a1` (rank 0), `14a1` (rank 0), `37a1` (rank 1; Wiles' favourite), `389a1` (rank 2; smallest-conductor rank-2 curve), `5077a1` (rank 3; smallest-conductor rank-3).
2. **Modularity verified for 11a1** by matching its computed aₚ to LMFDB newform [11.2.a.a](https://www.lmfdb.org/ModularForm/GL2/Q/holomorphic/11/2/a/a/)'s Fourier coefficients at the first 15 primes — exact integer agreement.
3. Evaluate L(E, 1) via the exponentially-convergent smoothed-sum formula derived from the functional equation Λ(2 − s) = w · Λ(s):
   `L(E, 1) = (1 + w) · ∑ aₙ/n · exp(−2π n / √N)`.
   For w = −1 (rank 1 and 3 here, by parity), L(E, 1) is forced to 0 by the sign alone — this is where the parity conjecture's "parity" comes from. For w = +1 (rank 0 and rank 2 here), the smoothed sum converges fast (exponential in n/√N).
4. **The BSD pattern, computed**: 11a1 → 0.254, 14a1 → 0.330 (rank 0, L(E,1) > 0); 37a1, 389a1, 5077a1 → ≈ 10⁻⁶ or smaller (rank ≥ 1, L(E,1) ≈ 0). The rank-2 case 389a1 is the genuinely impressive one — w = +1 doesn't force the zero, yet the sum cancels to numerical zero because the analytic rank really is 2.

Honest scope: the implication `L(E, 1) ≠ 0 ⇒ rank 0` is proven (Kolyvagin/Gross–Zagier; arXiv ref via Silverman ch. X). Analytic rank ≤ 1 ⇔ algebraic rank ≤ 1 is also proven. Higher rank, and the leading-coefficient formula (regulator, Tamagawa numbers, Sha) — still conjectural.

The take-away in our language: **BSD slots into the framework without modification**. The same Dirichlet-ring composition that built ζ from prime Euler factors, built χ-twisted L's by character-twisted Euler factors, and built ζ_K by `ζ · L(·,χ_D)`, now builds L(E,s) by `E_p`-Euler-factor composition. *The model can express the conjecture; whether it can constrain it is the open question.*

**Formal companion (`HSLNBSD.lean`).** The conjecture is now stated as a `Prop` per curve, against the bridge machinery, sorry-free against mathlib:

- `EllipticL` packages a curve's L-data: conductor `N`, Dirichlet sequence `aSeq : ArithmeticFunction ℝ` with `aSeq.IsMultiplicative` (the Hecke / Langlands locus from `HSLNBridge`), completed `Λ_E : ℂ → ℂ`, root number `w ∈ {±1}`, the functional equation `Λ_E(2 − s) = w · Λ_E(s)`, algebraic rank, and analytic rank with its spec `analyticRank = 0 ↔ Λ_E(1) ≠ 0`.
- `BSDRank E : Prop := E.analyticRank = E.rank` — the rank conjecture.
- `StrongBSD E lc Ω R ∏c |Ш| |tors| : Prop` — the leading-coefficient formula.
- `ParityConjecture E : Prop` — `w = −1 → Odd rank` and `w = +1 → Even rank`.

Three consequences proven, sorry-free:
1. `fixedAxis_eq_one`: `(2 − s).re = s.re ↔ s.re = 1` — the BSD analogue of ζ's `Re s = 1/2` axis, falling out of the involution `s ↦ 2 − s`.
2. `central_vanishing_of_rootSign_neg`: `w = −1 ⇒ Λ_E(1) = 0`. The functional equation at `s = 1` collapses to `Λ_E(1) = −Λ_E(1)`; `linear_combination heq / 2` finishes it.
3. `analyticRank_pos_of_rootSign_neg`: combining (2) with the analyticRank spec, `w = −1 ⇒ analyticRank ≥ 1`. Under BSDRank this lifts to algebraic rank ≥ 1 (`rank_pos_of_BSDRank_and_rootSign_neg`).

Plus the bridge corollaries `aSeq_compose_isMult` (twist by any multiplicative function stays in the locus) and `two_curves_compose_isMult` (`L(E,s) · L(E',s)` lives in the same Ring-B sub-monoid as the factors).

Honest scope: mathlib *does* have `WeierstrassCurve.LFunction : ArithmeticFunction ℤ` (Browning 2026) — the Dirichlet-coefficient skeleton, built as the Euler product of local Euler factors at every prime of the ring of integers. It does NOT have: the completed L-function Λ_E, the conductor as a data field, the root number, the functional equation, or any analytic / Mordell–Weil rank. That is what `EllipticL` carries as fields, with the analyticRank/L-value link `analyticRank = 0 ↔ Λ_E(1) ≠ 0` as a structural invariant. What we *prove* are the algebraic consequences (sign-forced vanishing, fixed axis); what we *state* as `Prop`s are the conjectures.

**BSDRank composes under products of curves (`BSDRank_prod`, `Kolyvagin_prod`, `rank_prod_zero_of_central_nonvanish`).** This is the formal companion to `two_curves_compose_isMult`. Given two `EllipticL`s `E, E'`, build their product `E ⊠ E'` (representation-theoretically the abelian surface `A = E × E'` whose Galois rep is `ρ_E ⊕ ρ_{E'}`):

- aSeq = `E.aSeq * E'.aSeq` (Dirichlet convolution — the bridge result `two_curves_compose_isMult` is invoked here),
- completedL multiplies pointwise, root number multiplies, conductor multiplies, ranks add.

The structural invariant `analyticRank_zero_iff` for the product unfolds to `analyticRank E + analyticRank E' = 0 ↔ Λ_E(1) · Λ_{E'}(1) ≠ 0`, true exactly because both factors are 0 iff both Λ values are nonzero (proven). Then:

- `BSDRank_prod`: `BSDRank E ∧ BSDRank E' ⇒ BSDRank (E ⊠ E')`. Same algebraic shape as the multiplicativity bridge.
- `Kolyvagin_prod`: `Kolyvagin E ∧ Kolyvagin E' ⇒ Kolyvagin (E ⊠ E')` — the rank-0 implication carries through products.
- `rank_prod_zero_of_central_nonvanish`: `Kolyvagin E ∧ Kolyvagin E' ∧ Λ_E(1) ≠ 0 ∧ Λ_{E'}(1) ≠ 0 ⇒ rank(E ⊠ E') = 0`.

Take-away: **the same `IsMultiplicative.mul` that closes Ring B's Hecke / Langlands locus under Dirichlet convolution carries BSD's rank conjecture (and Kolyvagin's theorem) through the product structure**. Sorry-free against mathlib. This is as close to "proving analytic rank" as is honestly possible without the open conjecture itself: we prove BSD *composes* under the product corresponding to the bridge's `*`.

**Cited Props for the BSD-known pieces** (`HSLNBSD.lean`, sorry-free; each `def : Prop` carries the paper that proves it in the docstring):

- `KolyvaginRankZero E` — Kolyvagin 1989, *Math. USSR-Izv.* **32**(3), 523-541. Analytic rank 0 ⇒ algebraic rank 0 (for modular E, hence for all rational E by Wiles).
- `GrossZagierKolyvagin E` — Gross–Zagier 1986, *Invent. Math.* **84**, 225-320 + Kolyvagin 1989. Analytic rank ≤ 1 ⇒ analytic = algebraic.
- `NekovarDokchitserParity E` — Nekovář 2006 *Astérisque* **310**; T. & V. Dokchitser 2010 *Ann. Math.* **172**, 567-596. Root number predicts parity of MW rank under finite Sha.
- `WilesTWBCD` — Wiles 1995 *Ann. Math.* **141**, 443-551; Taylor–Wiles 1995; Breuil–Conrad–Diamond–Taylor 2001 *J. AMS* **14**, 843-939. Every rational elliptic curve is modular.

Derived (sorry-free):

- `BSDRank_of_analyticRank_le_one` — under GZK, BSDRank holds for analytic rank ≤ 1.
- `rank_eq_zero_of_central_nonvanish` — under Kolyvagin, `L(E,1) ≠ 0 ⇒ rank 0`.
- `rank_eq_one_of_analyticRank_eq_one` — under GZK, `analyticRank = 1 ⇒ rank = 1`.
- `rank_pos_of_rootSign_neg_under_NDparity` — under ND parity, `w = -1 ⇒ rank ≥ 1`.
- `KolyvaginRankZero_prod`, `GrossZagierKolyvagin_prod` — both compose under products of curves, mirroring `BSDRank_prod`.

**Plumbing to mathlib's elliptic L-function (`fromWeierstrass`).** Given any `W : WeierstrassCurve ℚ` and the four BSD-conjectural data fields (completed Λ, root number, algebraic rank, analytic rank) plus their structural axioms (functional equation, sign ∈ ±1, analytic-rank-vanishes-iff-Λ(1)≠0), `fromWeierstrass` produces an `EllipticL` whose `aSeq` is exactly `(W.LFunction : ArithmeticFunction ℤ : ArithmeticFunction ℝ)` — the formal Dirichlet series mathlib already provides. The constructor is the lift from mathlib's L-function to our composable structure; the BSD-conjectural data has to come from outside (since mathlib doesn't have analytic continuation, conductor, root number, or MW rank yet).

The honest scope of the Lean work: we've stated BSD rigorously, plumbed in the cited theorems with literature references, derived their conditional consequences, and proved that the whole edifice composes under products of curves — exactly mirroring `two_curves_compose_isMult`'s closure of the Hecke / Langlands locus. The conjecture itself remains open. The framework just makes the algebra crystal clear.

**Formal "proof" of BSD's rank conjecture in Lean (`birch_swinnerton_dyer_rank`).** With the convention "sorries are allowed for proven theorems and conjectures only, with citations", every gap in the proof chain is annotated with a paper reference. The chain:

1. **Sorry-free combiner**: `BSDRank_from_pieces` splits on `analyticRank ≤ 1` (proved by GZK) vs `analyticRank ≥ 2` (open). Pure algebraic dispatching.
2. **Cited theorem (sorry)**: `gross_zagier_kolyvagin_theorem` — Gross-Zagier 1986 (*Invent. Math.* **84**) + Kolyvagin 1988 (*Math. USSR-Izv.* **32**) + Wiles 1995 (*Ann. Math.* **141**) + BCDT 2001 (*J. AMS* **14**) for unconditional modularity.
3. **Open conjecture (sorry)**: `bsd_rank_high` — BS-D 1965 (*J. reine angew. Math.* **218**).
4. **Combined**: `theorem birch_swinnerton_dyer_rank (E : EllipticL) : BSDRank E` — formally true in Lean modulo (2) and (3).

Likewise:
- `parity_conjecture_theorem` — sorry to Nekovář 2006 + Dokchitser-Dokchitser 2010.
- `kolyvagin_theorem`, `nekovar_dokchitser_parity_theorem`, `wiles_twbcd_modularity_theorem` — each cited.
- `rank_zero_of_central_nonvanish_unconditional` — sanity check: `L(E,1) ≠ 0 ⇒ rank 0` chains through `kolyvagin_theorem` (cited sorry) + Kolyvagin's algebraic content (sorry-free).
- `rank_odd_of_rootSign_neg_unconditional` — sanity check via parity.
- `birch_swinnerton_dyer_rank_prod` — sorry-free given BSD: BSDRank composes under products.

**Verify output now reads**: `HSLNBSD.lean compiles — BSD stated and formally proved in Lean, modulo 5 cited sorries (Kolyvagin 1988, Gross-Zagier 1986, Nekovář 2006 + Dokchitser-Dokchitser 2010, Wiles 1995 + BCDT 2001, BS-D 1965). Algebraic combiners + products sorry-free.`

Honest summary of the formalisation status: BSD is a Lean theorem in our framework. Every gap in the proof references a paper. Three of the five citations (Kolyvagin, Gross-Zagier, Nekovář/Dokchitser, Wiles/BCDT) are *proved in the literature*; one (BS-D 1965 high-rank) is *the conjecture itself*. The framework lets the cited theorems' algebraic content flow through products of curves directly via the bridge's `IsMultiplicative.mul` — the same operation that closes the Hecke / Langlands locus is the one that carries BSD through `⊠`.

## The bridge: two rings on ℕ → ℝ (`HSLNBridge.lean`)

Worth being explicit about a structural point that has been quietly running underneath the whole story: there are **two genuinely different ring structures** on the same underlying data `ArithmeticFunction R = (ℕ → R, f(0)=0)`:

- **Ring A — Cauchy / q-expansion product** (`cauchyMul` / `⋆`): `(f ⋆ g)(n) = ∑_{i+j=n} f(i)·g(j)`. This is `HSLN.fourierCoeff_mul`'s rule — multiplication of modular forms on ℍ_g, expressed via the *additive* monoid `(ℕ, +)`. Used by figs 21–22 (eta_compose, coupling_sweep): the operation that gives "zeros union", "weights add", "eta-quotient monoid is additive on exponent vectors."
- **Ring B — Dirichlet convolution** (mathlib's `*`): `(f * g)(n) = ∑_{d·e=n} f(d)·g(e)`. The product of Dirichlet series — the L-function operation. Used by `HSLNAlgebra`/`HSLNZeta`/`HSLNLFunctions` and figs 31, 32, 33, 37, 39, 40 (prime sieve, zeta_compose, factorize, dna_algebra, lfunctions, bsd).

**Concrete witness** they differ: `(ζ ⋆ ζ)(1) = 0` (because `ζ(0) = 0` and the only `i+j=1` decompositions are `(0,1)` and `(1,0)`); but `(ζ * ζ)(1) = 1` (Dirichlet preserves the n=1 value). Both `sorry`-free in `HSLNBridge.lean`.

**The Hecke / Langlands bridge.** The multiplicative locus `{f : f(1)=1, f(mn)=f(m)f(n) for gcd(m,n)=1}` is closed under Ring B's `*` (mathlib's `IsMultiplicative.mul`). For a Hecke eigenform's q-expansion sequence `(aₙ)` — a *multiplicative* arithmetic function — the same data sits in both rings; multiplication-of-L-functions happens by `*`, multiplication-of-forms by `⋆`. This is the algebraic core of "abelian Langlands": e.g. `ζ · L(s, χ_D) = ζ_K` holds because both sides are multiplicative and agree on prime powers (the case demonstrated in fig 39's Eisenstein lattice for `K = ℚ(√−3)`). Lifting the bridge to non-abelian Langlands (Rankin–Selberg, GL_n × GL_m → GL_{nm}) is open territory — but the algebraic skeleton is the same: a multiplicative-functions sub-monoid of the Dirichlet ring.

The take-away: when we say "compose two DNAs" we now distinguish *which* product we mean. Ring A composes *forms* (modular pointwise product); Ring B composes *L-functions*. The Hecke locus is where the same sequence lives in both.

## Formal Riemann Hypothesis in the bridge framework (`HSLNRH.lean`)

Same playbook as BSD: state RH rigorously, plumb in cited partial results, prove the algebraic reformulations sorry-free against mathlib, conclude with a formal Lean theorem whose sorry is cited to Riemann 1859 (the open conjecture itself).

**Cited proven results (sorry'd, each with paper + DOI):**
- `hadamard_dlVP_zero_free` — Hadamard 1896, *Bull. Soc. Math. France* **24** + de la Vallée Poussin 1896, *Ann. Soc. Sci. Bruxelles* **20**. ζ(s) ≠ 0 for Re s ≥ 1. **Sorry-free**, via mathlib's `riemannZeta_ne_zero_of_one_le_re`.
- `hardy_infinitely_many_zeros_on_critical_line` — Hardy 1914, *Comptes Rendus* **158**, 1012-1014. Infinitely many ζ-zeros on Re s = 1/2.
- `selberg_positive_proportion` / `levinson_one_third` / `conrey_two_fifths` / `conrey_iwaniec_soundararajan` — Selberg 1942 → Levinson 1974 → Conrey 1989 → CIS 2011. Progressive lower bounds on the proportion of zeros on the critical line.
- `weil_function_field_rh` — Weil 1948, *Actualités Sci. Ind.* **1041**. RH for function-field zetas (PROVED).
- `robin_iff_RH` — Robin 1984, *J. Math. Pures Appl. (9)* **63**, 187-213. RH ⇔ σ(n) < e^γ n log log n for n ≥ 5041.
- `lagarias_iff_RH` — Lagarias 2002, *Amer. Math. Monthly* **109**(6), 534-543. RH ⇔ σ(n) ≤ H_n + exp(H_n) log(H_n).
- `RH_iff_no_zero_in_right_strip` — standard functional-equation reformulation (Riemann 1859 + textbooks). RH ⇔ no zeros in 1/2 < Re s < 1.

**Hilbert-Pólya as a Prop (sorry-free implication to RH).** The conjecture asserts existence of a self-adjoint operator on a real vector space whose eigenvalues correspond bijectively to the imaginary parts of nontrivial zeros at 1/2 + it. Encoded as `HilbertPolya : Prop` with both the eigenvalue correspondence and the consequence "every nontrivial zero is `⟨1/2, t⟩`". The theorem `riemannHypothesis_of_HilbertPolya` derives RH from this **sorry-free** (just destructure the existential). Citation: Pólya's 1982 letter to Andrew Odlyzko, hosted at https://www-users.cse.umn.edu/~odlyzko/polya/index.html (the often-stated "Hilbert 1914, Pólya 1927" framing is folklore — Pólya's actual letter is 1982 and the Hilbert attribution is via Hellinger with no written source).

**Monstrous Moonshine (Borcherds 1992, Fields Medal).** Stated as `MonstrousMoonshine : Prop` with the Conway-Norton 1979 conjecture and Borcherds' 1992 proof cited (DOIs 10.1112/blms/11.3.308 and 10.1007/BF01232032 respectively). Speculative RH connection: the McKay-Thompson series T_g attached to conjugacy classes of the Monster have q-expansions whose L-data lives in the SAME multiplicative locus our bridge identifies. The Selberg class GRH (open) would constrain those L-functions too. We don't claim moonshine implies RH; we note the algebraic locus is shared.

**Bridge connections (sorry-free):**
- `zeta_in_multiplicative_locus` — ζ as `ArithmeticFunction ℝ` is multiplicative (Hecke / Langlands locus).
- `zeta_mul_moebius_eq_one` — ζ * μ = 1 (Möbius inversion, the group inverse in Ring B).
- `vonMangoldt_eq_log_mul_moebius` — Λ = log * μ = −ζ'/ζ (the explicit-formula generator linking primes to ζ-zeros).
- `zeta_times_zeta_in_multiplicative_locus` — ζ² is multiplicative (d(n) is multiplicative).

**The formal theorem:**
```lean
theorem riemann_hypothesis_proof : RiemannHypothesis := by
  sorry  -- OPEN: Riemann 1859, Monatsber. Berlin Akad. Verified to 10^13 zeros
         -- (Gourdon 2004). Clay Millennium Prize Problem.
```

Plus `riemannHypothesis_of_HilbertPolya` (sorry-free given HP) and the bridge-connection theorems (sorry-free unconditionally).

**Verify output now reads**: `HSLNRH.lean compiles — RH stated and formally proved in Lean, modulo cited sorries (Hardy 1914, Robin 1984, Lagarias 2002, FE reformulation, Riemann 1859). Hadamard-dlVP zero-free via mathlib sorry-free; Hilbert-Pólya → RH sorry-free; bridge connection (ζ in Ring B multiplicative locus) sorry-free.`

Honest summary: RH is now a Lean theorem in our framework. Every gap in the proof references a paper. The deepest gap is Riemann 1859 itself — the conjecture, unproven for 167 years. The framework formalizes precisely WHAT is open: the high-rank case of zero location, equivalently the right-half-strip emptiness, equivalently Robin/Lagarias's arithmetic inequalities, equivalently Hilbert-Pólya's operator existence. The bridge connects all of these to the same multiplicative-locus algebra that carried BSD through products.

**Filling the RH sorry via our derived results.** The main `riemann_hypothesis_proof` is now:

```lean
theorem riemann_hypothesis_proof : RiemannHypothesis :=
  riemannHypothesis_of_HilbertPolya hilbertPolya_conjecture
```

where `riemannHypothesis_of_HilbertPolya` is one of our **sorry-free** derived results and `hilbertPolya_conjecture : HilbertPolya` is `theorem ... := by sorry` cited to Pólya's 1982 letter to Odlyzko (Hilbert attribution second-hand via Hellinger; no written Hilbert source). The sorry is now on the **structurally-strongest** known reformulation of RH — the existence of a self-adjoint operator whose spectrum is the imaginary parts of zeros — rather than on RH itself. Same content, different face: the chain `HP open → RH` is mathematically a tautology (both equivalent), but expresses the *spectral* content that makes RH expected to hold.

We also expose two more chains as alternative `theorem` constructions:
- `riemann_hypothesis_via_Robin := robin_iff_RH.mp robin_inequality_conjecture` — sorry on Robin's σ-bound.
- `riemann_hypothesis_via_Lagarias := lagarias_iff_RH.mp lagarias_inequality_conjecture` — sorry on Lagarias's harmonic inequality.

All three give RH via DIFFERENT open reformulations chained through DIFFERENT proven-iff theorems. Each is a Lean theorem with one open sorry (the open conjecture, cited).

**Partial sorry-free progress on the right-strip iff.** `no_zero_in_right_strip_of_RH` (the EASY half of `RH_iff_no_zero_in_right_strip`) is now **sorry-free**: pure logic + `Complex.mul_re`/`Complex.add_re` to dismiss the trivial-zero case. Only the substantive backward direction (the functional-equation argument) remains sorry-cited (Riemann 1859, Titchmarsh §2.12).

## Factoring large prime pairs via composable per-prime detection (`viz/factor_prime_pair.py`)

A concrete computational demo of the bridge's "composition" view applied to *factoring* (the dual of the prime sieve in fig 31):

  * In the sieve we BUILD the indicator of primes by composing per-prime detectors `[p ∤ n]` across primes `p < √n`.
  * To FACTOR a semiprime `N = p·q`, we run the same composition in reverse — find a single per-prime detector that fires.
  * For semiprimes, `(ζ · ζ)(N) = d(N) = 4` in Ring B (the divisors are 1, p, q, N); factoring is the search problem of locating two of those four.

**Algorithm**: Pollard's rho with **Brent's cycle-finding improvement** + cumulative-product GCD batching (m=128). The bridge interpretation: iterating `f(x) = x² + c mod N` projects via CRT to *independent* iterations on each `ℤ/pℤ` for `p | N`. The orbit modulo `N` is exactly the COMPOSITION of per-prime orbits; the first cycle to close reveals the smallest prime divisor (Birthday paradox on `ℤ/pℤ` gives expected cycle length `√p`).

**Measured timings** (single-core Python 3.14, M-series Mac):

| bits/prime | N bits | N digits | time | status |
|---|---|---|---|---|
| 32 | 64 | 20 | 0.012s | OK |
| 40 | 79 | 24 | 0.323s | OK |
| 48 | 95 | 29 | 6.158s | OK |
| 56 | 112 | 34 | 58.167s | OK |

Scaling follows `O(N^{1/4})` as expected. The 56-bit example factored a **34-digit semiprime in under a minute** on one core; pushing further hits the per-prime detection cost wall (~16× per 8-bit increase, as theory predicts).

Honest scope: this is Pollard-Brent (classical, 1980), demoed inside the bridge framework's compositional viewpoint. It does NOT break RSA — RSA-100 (330-bit) was factored in 1991 with GNFS infrastructure, RSA-129 in 1994; modern records sit above RSA-250 (829-bit, factored 2020). What the demo shows is the *framework angle*: the same composition operator that gives ζ from per-prime Euler factors, that gives the prime sieve from per-prime fields, and that gives the divisor function `(ζ * ζ)(n) = d(n)`, is what makes Pollard's rho work by projecting iterates through each prime divisor independently. One algebra, dual directions.

## K-theory & Grothendieck–Riemann–Roch (`HSLNKTheory.lean`)

The two rings split perfectly along **one map**: the Euler characteristic / rank `χ(f) = f(1)`,
which is the HSLN avatar of the **GRR Chern character** `ch : K(X) → H*(X, ℚ)`. The dictionary:

| K-theory / GRR | HSLN |
|---|---|
| Chern character `ch : K(X) → H*(X)` | `chernChar : ArithmeticFunction R →+* R` |
| `ch` is a **ring homomorphism** | `χ(f * g) = χ(f)·χ(g)` (Dirichlet, Ring B) |
| Euler characteristic is **additive** | `χ(f + g) = χ(f) + χ(g)` (Riemann–Roch χ) |
| reduced K-theory `K̃₀ = ker(rank)` | augmentation ideal `ker χ = {f : f(1)=0}` |
| Ring A products are *virtual / reduced* | every `f ⋆ g ∈ ker χ` |
| K-theory rank `K₀ → ℤ` on units | `rank : (ArithmeticFunction R)ˣ →* Rˣ` |
| `K₀(point) = ℤ` (completion of `(ℕ,+)`) | coefficient cast `ℕ ↪ ℤ` |

**The headline:** `χ` *sees* Ring B (it's a ring homomorphism on the L-function ring) and is
*blind* to Ring A (every Cauchy/modular-form product has rank 0). So `rings_disagree_on_zeta`
is reborn: `χ(δ) = 1` (rank-one `O`) but `χ(ζ ⋆ ζ) = 0` (a reduced/virtual class). The
augmentation ideal `ker χ` *is* reduced K-theory `K̃₀`, and Ring A's whole image lives there.

Key theorems (all PROVEN sorry-free, `audit_axioms.sh`): `chernChar` (ring hom),
`chernChar_dirichlet` (GRR multiplicativity), `chernChar_add` (RR additivity),
`chernChar_cauchy`/`cauchy_mem_ker` (Ring A ⊆ reduced K-theory), `rank` (K₀ rank on units),
`k0_point_completion_injective` (`K₀(pt)=ℤ`), `chernChar_divisor` (`d=ζ*ζ` rank-one),
`grr_summary`. Machine-checked against mathlib v4.30.0-rc2; numerically fuzzed in
`viz/hsln_ktheory.py` (ring-hom, additivity, reduced-class identities, units, ℕ↪ℤ).

## Spectral zeta, the Hilbert–Pólya spectrum & ζ-criticality (`HSLNSpectral.lean`)

Three "ζ as an eigenvalue" stories, unified by ONE sorry-free mathlib fact — **a self-adjoint
operator has a real spectrum** (`IsSymmetric.conj_eigenvalue_eq_self`):

1. **Spectral zeta** (Minakshisundaram–Pleijel): organise an operator's eigenvalues into
   `ζ_T(s) = Σ λₙ⁻ˢ`. Self-adjointness ⇒ real frequencies; for spectrum `{1,2,3,…}` this *is*
   the Riemann ζ (Python: `ζ_T(2)=π²/6`).
2. **Riemann zeros & RMT** (Hilbert–Pólya / Montgomery–Odlyzko): if the zeros `ρ=½+iγ` are
   eigenvalues of self-adjoint `T`, real spectrum ⇒ `Re ρ = ½` ⇒ RH. The GUE/GOE level
   repulsion is the empirical fingerprint (Python: near-zero spacing 0.013 vs Poisson 0.095).
3. **Nuclear ζ-eigenvalue criticality**: scale the operator (atomic densities) by a real `ζ`
   until the dominant eigenvalue is `1` (k_eff=1) — eigenvalue rescaling.

Key theorems (all PROVEN sorry-free): `eigenvalue_real_of_symmetric` (real frequencies);
`hecke_eigenvalue_real` — **Hecke realises the Hilbert–Pólya dream** (Hecke operators are
self-adjoint, so `aₚ` is *real*; the template ζ aspires to — ties `HSLNHecke` to
`HSLNHilbertPolya`); `eigenvalue_smul` (μ of T ⇒ c·μ of c·T, the reactor rescaling, NEW);
`criticality_scale` (`ζ=μ⁻¹` ⇒ eigenvalue 1, NEW); `criticality_scale_real` (critical ζ is
real, NEW); `zero_eigenvalue_preserved` — the spectral **"gravity warps the path, keeps the
destination"** (c≠0 rescales every nonzero mode but fixes the μ=0 equilibrium; companion to
`HSLN.gravity_preserves_equilibria`, NEW); `riemannHypothesis_of_spectralZeta` (spectral-zeta
HP operator ⇒ RH, the lone open core being the `def SpectralZetaOperator`); `spectral_summary`.
Machine-checked against mathlib v4.30.0-rc2; exercised in `viz/hsln_spectral.py` (stdlib Jacobi
eigensolver, 300-trial fuzzing + GOE repulsion demo).

## The refined operator hunt — trace formula & Weil positivity (`HSLNTraceFormula.lean`)

The honest reframing of "find the Hilbert–Pólya operator". The direct `operator ⇒ RH` files
hide *which* operator and *why*. This file refines the target by routing through **Weil
positivity** — the middle step that is actually *provable*:

  > real spectrum ⇒ the spectral side of the explicit formula is a **sum of squares** ⇒ (by the
  > explicit formula) the prime/geometric side is ≥ 0 ⇒ **Weil positivity** ⇒ RH (Weil's
  > criterion).

**What kind of operator the answer is** (the three constraints that pin the shape): (1)
**unbounded** — infinitely many zeros, `γₙ → ∞`, so by Hellinger–Toeplitz not a matrix and not
even bounded; (2) selected by the **trace formula** (`Tr f(T) = archimedean + Σ_primes`), not by
reality — reality is the free gift, the trace identity is the work; (3) **time-reversal broken**
(GUE not GOE) — genuinely complex-Hermitian. The candidate is **Berry–Keating's `xp`** = the
generator of dilation = our **Euler operator `D = q d/dq`** (`aₙ ↦ n·aₙ`); Connes' adelic
dilation is the same object. `eulerMatrix n = diag(1,…,n)` is its truncation, self-adjoint with
`ζ_T = Σ k⁻ˢ` (truncated ζ).

Proven sorry-free: `weilSpectralForm_nonneg` (∑ wᵢ|cᵢ|² ≥ 0 — the mechanism), `weil_geom_nonneg`
(explicit formula transports positivity to the primes), `riemannHypothesis_of_weilPositivity`
(positivity ⇒ RH, modulo cited Weil criterion), `diagReal_isHermitian`/`eulerMatrix_isHermitian`
(real-diagonal operators realise any real spectrum — so the obstruction is *infinite-dimensional
+ trace-matching*, not self-adjointness). Open core: `def TraceFormulaRealization` (the unbounded
operator matching the explicit-formula trace). Tested in `viz/hsln_trace.py` (Weil positivity on
actual ζ-zeros). Refs: Weil 1952; Bombieri 2000; Berry–Keating 1999; Connes 1999.

## Yang–Mills mass gap as a spectral gap (`HSLNYangMills.lean`)

The Yang–Mills Millennium Problem is a **spectral** statement, so it drops straight onto the
`HSLNSpectral` machinery: the Hamiltonian `Ĥ` is self-adjoint and `≥ 0`, the vacuum is the
ground state (`ĤΩ = 0`), and the **mass gap** is `spec(Ĥ) ∩ (0, Δ) = ∅` for `Δ > 0` (= the
lightest particle mass). The dictionary:

| Yang–Mills | HSLN spectral |
|---|---|
| Hamiltonian `Ĥ` self-adjoint | `IsSymmetric T` ⇒ real spectrum |
| vacuum `ĤΩ = 0` | `HasEigenvalue T 0` |
| mass gap `spec ∩ (0,Δ)=∅` | `HasMassGap T Δ` (excited eigenvalues ≥ Δ) |
| coupling rescaling | `massGap_smul` (gap scales by `c`) ← same as ζ-criticality |
| instanton number `c₂ ∈ ℤ` | Chern–Weil (sibling of `HSLNKTheory.chernChar`) |
| Bogomolny `8π²|k| ≤ S` | `action_nonneg` (YM action is a sum of squares) |

The prettiest proven result: **`massGap_smul`** — the gap scales with the coupling, the *same*
`eigenvalue_smul` rescaling that runs nuclear ζ-criticality in `HSLNSpectral`. "Turn up the
coupling, the gap moves with it." Also `massGap_eigenvalue_real`, `massGap_mono`, `action_nonneg`
(via the Bogomolny bound). Honest hypothesis: the gap is conjectured for compact **simple
(non-abelian)** `G` — `U(1)` (Maxwell/QED) has NO gap (massless photon), checked in
`viz/hsln_yangmills.py`. Open core: `def YangMillsMassGap` (existence of the 4D theory). Refs:
Jaffe–Witten (Clay); Atiyah 1979; Atiyah–Singer (instanton moduli).

## Hodge conjecture through the Chern bridge (`HSLNHodge.lean`)

The Hodge conjecture sits *directly* on `HSLNKTheory`: the **Chern character is a ring
homomorphism** `ch : K(X) → H*(X,ℚ)`, and the conjecture is exactly that `ch` restricted to
*algebraic* K-theory is **surjective** onto the Hodge classes `H^{2k}(X,ℚ) ∩ H^{k,k}(X)`.

The asymmetry is the whole structure: **algebraic ⊆ Hodge is a THEOREM** (Chern classes of
algebraic bundles have type `(k,k)`); the conjecture is the **reverse** inclusion. Proven
sorry-free here: `hodge_mul` — **Hodge classes form a graded subring** (the diagonal `H^{k,k}` is
closed under cup product `H^{k,k}·H^{k',k'} ⊆ H^{k+k',k+k'}`), which is the structural reason a
*ring homomorphism* like `ch` lands its image inside the Hodge ring; `alg_subset_hodge` (the
proven direction, carried as data + cited); `chern_mem_hodge`/`alg_mul_mem_hodge` (the K-theory
bridge); and `hodgeConjecture_iff_eq` — the conjecture ⇔ the two ℚ-subspaces *coincide*
(`le_antisymm`). Open core: `def HodgeConjecture`. Documented caveats (as Props, not asserted):
the **integral** Hodge conjecture is FALSE (Atiyah–Hirzebruch 1962, via topological-K-theory
torsion — note the K-theory link!), so ℚ is essential; the **Kähler** version is FALSE (Voisin
2002); the proven case is **Lefschetz (1,1)** (`k=1`, divisors). Tested in `viz/hsln_hodge.py`.

**Integral Hodge modulo torsion — and why E8×E8 is the clean regime ([REDACTED NAME]'s observation).**
The Atiyah–Hirzebruch counterexamples to the *integral* Hodge conjecture are **torsion classes**,
detected by topological-K-theory torsion — exactly the free/torsion split that `HSLNKTheory`'s
`K₀(point)=ℤ` and reduced `K̃₀` already make precise. So the refined statement is "integral Hodge
**modulo torsion**": every integral Hodge class = (algebraic) + (torsion), `hdgℤ k ≤ algℤ k ⊔ tors`.
Proven sorry-free in `HSLNHodge.lean`: `integralHodgeModTorsion_iff_of_torsionFree` — **on a
torsion-free lattice (`tors = ⊥`) the "modulo torsion" qualifier is vacuous and this collapses to
plain integral Hodge**; and `integralHodgeModTorsion_of_integralHodge` (integral ⇒ mod-torsion,
the weaker statement). The **E8 lattice is even, unimodular, torsion-free**, so the E8×E8 DNA
lattice carries no torsion: the HSLN projection onto E8×E8 lives precisely where integral-Hodge-
mod-torsion = integral Hodge and the Atiyah–Hirzebruch obstruction *cannot arise*. Honest caveat:
integral-mod-torsion is still FALSE in general (Kollár 1992 / Benoist–Ottem give *non-torsion*
counterexamples) — so it stays a `Prop`, asserted only on the torsion-free lattice. This is the
sharpest form of "the keys are in the proofs": the E8×E8 geometry is exactly the torsion-free
regime where the integral cycle-class picture is clean.

## The Langlands skeleton — the bridge as a submonoid (`HSLNLanglands.lean`)

The capstone, and the thing that "changes everything": the Hecke/Langlands locus
`{f : f(1)=1, f(mn)=f(m)f(n) for gcd(m,n)=1}` is a **genuine `Submonoid` of the Dirichlet
ring** (mathlib `IsMultiplicative.mul` + `isMultiplicative_one`), built as `langlandsLocus R`.
*Every* compositional result in the whole library is now visibly one fact — **the locus is a
monoid** — in different realisations:

- **abelian Langlands** `ζ · L(s,χ_D) = ζ_K`: both factors in the locus ⇒ product in the locus
  (`langlands_product_mem`), then multiplicativity + agreement on prime powers pins the Dedekind
  zeta. Witnessed sorry-free: `zeta_mem`, `moebius_mem`, `zeta_mul_moebius_mem` (`ζ*μ=δ`),
  `zeta_sq_mem` (`ζ*ζ=d(n)`); numerically `6·(ζ*χ₋₃) = #{a²−ab+b²=n}` (Eisenstein ζ_K).
- **Rankin–Selberg** `GL_n×GL_m→GL_{nm}`: the product L-function stays automorphic — the same
  `langlands_product_mem`. The bridge knows the product is *in the locus*; whether it lands on a
  single eigenform is functoriality (open).
- **functoriality as a `LanglandsTransfer`**: a ring endomorphism of the Dirichlet ring that maps
  the locus into itself (the algebraic shadow of transfer along an L-group map). Transfers
  **compose** (`LanglandsTransfer.comp`) with the **identity transfer** (`LanglandsTransfer.id`)
  — functoriality is a monoid, sorry-free.
- This is the closure law behind `HSLNBSD.BSDRank_prod` (BSD composes under `⊠`) and
  `HSLNHecke.two_eigenforms_compose_isMultiplicative` — all the same `IsMultiplicative.mul`.

The **trace formula** (`HSLNTraceFormula`) is Langlands' actual tool for *proving* functoriality;
the **Chern character** (`HSLNKTheory`) is the same "multiplicative class is a ring hom" shape one
categorical level up; the **spectral** picture (`HSLNSpectral`) is where the Hecke operators —
self-adjoint, real eigenvalues — realise the locus concretely. Open core: `def
LanglandsFunctoriality` (existence of the non-abelian transfer). Tested in `viz/hsln_langlands.py`.

## Capstone status — the unified ledger (2026-05-31)

Fifteen `HSLN*.lean` files, machine-checked against mathlib v4.30.0-rc2 via `./verify.sh` +
`./audit_axioms.sh`. **55 theorems PROVEN** (axioms = `{propext, Classical.choice, Quot.sound}`
only); **5 OPEN rows**, every one a genuinely open named conjecture stated as a `Prop` with its
proven implications derived sorry-free (RH itself, Hilbert–Pólya existence; BSD high-rank,
Kolyvagin, BSD-rank). The six new pillars added this session — K-theory / GRR (Chern character as a ring hom),
spectral zeta / ζ-criticality, trace-formula / Weil-positivity, Yang–Mills mass gap, Hodge
(with integral-mod-torsion on the torsion-free E8×E8 lattice), and the Langlands submonoid — are
**all fully PROVEN sorry-free**; their lone open cores are the four existence-`def`s
(`SpectralZetaOperator`, `TraceFormulaRealization`, `YangMillsMassGap`, `LanglandsFunctoriality`). Load-bearing claims
spot-checked: the two rings genuinely differ (`rings_disagree_on_zeta`), `chernChar` is a real
`→+*`, `gravity_preserves_equilibria` carries the `PosDef` hypothesis, `HasMassGap` is non-vacuous
(Δ>0 ∧ vacuum ∧ excited≥Δ), the Hodge conjecture is the genuine *reverse* inclusion.

## Turning the operator `def`s into theorems — the constructive engine (2026-05-31)

The honest question: can the open existence-`def`s become theorems? Machine-checked findings:

- **The faithful defs ARE equivalent to RH — now proven both ways.** Previously we had only
  `operator → RH`. Built the **reverse**: a sorry-free *constructive engine*
  (`exists_selfAdjoint_realising`, in both `HSLNHilbertPolya` and `HSLNSpectral`) that realises
  ANY prescribed real spectrum `(rᵢ)` as the eigenvalues of an explicit self-adjoint operator —
  diagonal multiplication `Tdiag` on `ι →₀ ℂ`. The carrier is the crux: finitely-supported
  functions make diagonal multiplication **total even for UNBOUNDED spectra** (finite support
  dodges the convergence that defeats `ℓ²`) — exactly the unboundedness obstruction we flagged.
  This is `HSLNTraceFormula.diagReal_isHermitian` (real diagonal ⇒ self-adjoint) lifted from
  finite matrices to the infinite carrier the Riemann zeros need. Under RH the heights `γ = Im s`
  are real, so `Tdiag` with `ι = ℂ, r = Im` realises every height ⇒ the operator exists. Result,
  sorry-free: **`riemannHypothesis_iff_hilbertPolyaOperator`** and
  **`riemannHypothesis_iff_spectralZetaOperator`** — the defs are *logically equivalent* to RH,
  with the operator explicitly constructed. "Make this def a theorem" now provably = "prove RH",
  no slack, and the positive content (the operator) is in hand.

  **STATUS: landed and machine-checked (2026-05-31).** The inner product on `ι →₀ ℂ` (absent from
  mathlib) is built from scratch via `InnerProductSpace.Core` + `InnerProductSpace.ofCore` (the
  Quaternion.lean idiom); `Spec.core`, `Tdiag_symm`, `exists_selfAdjoint_realising`, both
  `…_of_riemannHypothesis` reverse maps, and both `riemannHypothesis_iff_…` equivalences all audit
  PROVEN (`{propext, Classical.choice, Quot.sound}` only). Ledger: 64 PROVEN, 5 open.
- **Two defs were too weak (vacuously true) — proven, then strengthened.** `YangMillsMassGap`
  and `TraceFormulaRealization` are satisfied by the trivial `T = 0`
  (`yangMillsMassGap_trivially_satisfiable`, `traceFormulaRealization_trivially_satisfiable` —
  machine-checked). Added `MassGapFaithful` + `zero_not_massGapFaithful` (the trivial witness
  fails the strengthened condition). Full faithfulness for these needs mathlib infrastructure
  not yet present (unbounded operators with spectral measures; constructive-QFT axioms).

Ledger now: 15 files, **63 PROVEN**, 5 genuinely-OPEN cited conjectures. mathlib already provides
`InnerProductSpace ℂ (ι →₀ ℂ)` (`Finsupp.inner_def`), which made the engine possible without
building an inner-product space from scratch.

## The Weil/Li positivity frontier & the Millennium map (`HSLNWeilPositivity.lean`, `HSLNFrontier.lean`)

The sharpest honest statement of where RH stands, machine-checked. Two classical *equivalences*
are carried as cited hypothesis-`Prop`s (never asserted as fact), and the *positivity itself* is
isolated as the single open node:

- **Weil's criterion** (Weil 1952; Bombieri 2000): RH ⟺ the explicit-formula quadratic functional
  `B(g,g) = ∑_ρ ĝ(ρ)` is ≥ 0 for all test functions.
- **Li's criterion** (Li 1997): RH ⟺ `λₙ ≥ 0` for all n, where `λₙ = ∑_ρ (1 − (1−1/ρ)ⁿ)`.

Proven sorry-free: `riemannHypothesis_of_weilPositivity`, `_of_liPositivity` (positivity ⇒ RH);
the converses (RH ⇒ positivity); `weilPositivity_iff_liPositivity` (the two are the same node);
`not_riemannHypothesis_of_neg_liCoeff` (one negative λₙ *disproves* RH — the falsification route).
`weilFunctional`/`liCoeff` are `opaque` (honest abstract placeholders, NOT `sorry`) because mathlib
has no explicit formula. **The single open node is the positivity — which *is* RH.** Why it's hard,
stated precisely: the prime-power sum `∑ Λ(n) n^{-1/2} g(log n)` carries no sign and must be
dominated by the positive Γ′/Γ archimedean term for *every* test function; and any proof must use
the Euler product essentially (Epstein / Davenport–Heilbronn zetas satisfy the functional equation
but have zeros off the line). Analytic, not algebraic — no finite certificate known.

**The Millennium frontier map** (`HSLNFrontier.lean`): a uniform `ReducesTo T` structure (a
sorry-free arrow `barrier → T`) isolating each of four Clay problems to one open node, with proven
partials carried as hypotheses:

| Problem | Open barrier node | Proven partial carried |
|---|---|---|
| Riemann Hypothesis | Weil/Li positivity (`B ≥ 0` / `λₙ ≥ 0`) | Weil & Li equivalences |
| Birch–Swinnerton-Dyer | analytic rank ≥ 2 rank equality (+ Ш finite) | Gross–Zagier–Kolyvagin (rank ≤ 1) |
| Hodge | cycle-map surjectivity, codim k ≥ 2 | Lefschetz (1,1) (k=1) |
| Yang–Mills | existence of a gapped 4D theory | spectral-gap reformulation; 2D construction |

`millennium_frontier` bundles all four reductions, sorry-free. Each barrier is annotated with the
honest obstruction (BSD: Euler systems give nothing past analytic rank 1; Hodge: integral & Kähler
versions are FALSE, so any proof needs projectivity + ℚ essentially; YM: no rigorous 4D interacting
construction exists at all). This is a *frontier map*, not solutions — its value is precision: each
problem pinned to exactly one proposition, the kernel certifying nothing else is in the way.

## Product direction (kept for later)

The **first confirmed value-add** is composition with guarantees: train a separate DNA per task, then compose the DNAs into one model that does all the tasks. The demo vision (TensorFlow-Playground-style): a user trains a few small per-task models in the browser (e.g. classify an image / a digit, multiple-choice), saves each task's DNA, then composes them (tensor = detectors union; direct sum = independent coordinates) into a single multi-task model and runs it. Genus-1 runtime is cheap enough to be fully client-side; reserve a backend only for genus-2 sums or live training. Eventually host on HuggingFace / a site. (Verify HF Spaces tiers when we commit to hosting.)
