# Security & Cryptographic Impact Assessment

**Subject:** The Lean 4 formalisation `riemannHypothesis_iff_hilbertPolyaOperator`
**Author:** Security & cryptography impact analyst
**Date:** 2026-05-31
**Verdict in one line:** No cryptographic, security, or humanitarian impact — positive or negative — flows from this result. It is purely foundational mathematics. Even the hypothetical event it relates to (a *proof* of the Riemann Hypothesis) would not break RSA, and this work does not produce such a proof.

---

## Executive Summary

This project has machine-checked, sorry-free against mathlib, a **logical equivalence**:

> The Riemann Hypothesis (RH) holds **if and only if** a Hilbert–Pólya operator exists
> (`riemannHypothesis_iff_hilbertPolyaOperator : RiemannHypothesis ↔ HilbertPolyaOperator`).

It does **not** prove RH. RH remains open; in this very project it is one of the conjectures that bottoms out in `sorryAx` / is treated as an open hypothesis. The "construction" supplied for the reverse direction (`hilbertPolyaOperator_of_riemannHypothesis`) is the textbook diagonal operator whose spectrum *is* the set of zero-heights — it is faithful precisely because it is circular: you must already know the heights are real (i.e. assume RH) before you can build it.

Three claims, stated plainly and calibrated:

1. **Proving RH would not break RSA.** This is the central myth, and it is false. RH governs the *distribution* of primes (error terms in the prime-counting function), not the *difficulty of factoring* a specific semiprime. A proof of RH yields no factoring algorithm. (Multi-source; see below.)
2. **This specific result has zero cryptographic implication.** It is an equivalence, not a proof, and the equivalence direction it constructs is already classical mathematical folklore. Nothing here is new leverage on primes, zeros, or factoring.
3. **The genuinely cryptography-relevant things are different objects entirely** — an *effective* (constructive, with explicit bounds) result, or a fast factoring algorithm (which is unrelated to RH). None of those is present.

---

## What Was Actually Proven

From `HSLNHilbertPolya.lean`:

- `HilbertPolyaOperator : Prop` — the *open* existence claim: that there is a self-adjoint operator whose eigenvalues are the imaginary parts of the non-trivial zeta zeros. No RH is "bundled in" to this proposition.
- `hilbertPolyaOperator_of_riemannHypothesis (h : RiemannHypothesis) : HilbertPolyaOperator` — **sorry-free.** Given RH (so the zero-heights are real), it constructs an explicit self-adjoint diagonal operator on the finite-support space `ι →₀ ℂ`, with a from-scratch inner product, realising those heights as its real spectrum.
- `riemannHypothesis_of_hilbertPolyaOperator (h : HilbertPolyaOperator) : RiemannHypothesis` — the converse.
- `riemannHypothesis_iff_hilbertPolyaOperator : RiemannHypothesis ↔ HilbertPolyaOperator` — the conjunction; the headline theorem.

**What this is.** A rigorous, formally verified statement that two open problems are the same open problem. It is a *reduction*: "construct the operator unconditionally" ⇔ "prove RH". Either one, done unconditionally, gives the other.

**What this is not.**
- Not a proof of RH. RH is still open.
- Not a new bound on the location or spacing of zeros.
- Not an algorithm to find zeros faster.
- Not a new construction in any meaningful research sense — "diagonal operator with the zeros as its spectrum" is the trivial direction of the Hilbert–Pólya idea, known for decades. The hard, open content of Hilbert–Pólya (find a *natural* operator that produces the zeros *without* assuming they are real) is untouched.

The formalisation's value is mathematical hygiene: it certifies, in a proof assistant, that the equivalence holds with no hidden gaps. That is a real (if modest) contribution to formal mathematics. It is not a contribution to cryptanalysis.

---

## The RH–Cryptography Relationship (Myth vs Reality)

### The myth

"If someone proves the Riemann Hypothesis, RSA / all encryption is broken." This circulates widely on Quora, LinkedIn, Hacker News and popular write-ups. It is **wrong**.

### Why it is wrong

RSA's security rests on the conjectured hardness of **integer factorization**: given `n = p·q`, recover `p` and `q`. The Riemann Hypothesis is a statement about the **distribution** of primes — equivalently, the size of the error term in the prime-counting function `π(x)`, equivalently that all non-trivial zeros of `ζ(s)` have real part `1/2`. These are different questions:

- RH tells you *how primes are spread out* (sharper error bounds, e.g. von Koch's `π(x) = Li(x) + O(√x log x)` under RH).
- RH tells you *nothing about how to factor a given semiprime faster*.

There is **no known reduction** from "RH is true" to "factoring is easy," and no expert expects one. As one community summary puts it bluntly: "There is no reason to expect that a proof of the Riemann Hypothesis, or a refutation of it, will have any effect whatsoever on Integer Factorization." A proof of RH is non-constructive with respect to factoring — it would not hand you a factoring algorithm, fast or otherwise.

*(Caveat, marked honestly: a small number of preprints — e.g. on preprints.org — claim RH-conditional integer-reconstruction schemes. These are non-peer-reviewed, single-source, and outside the mainstream consensus. I give them no weight; flagging them only because the brief asked for adversarial completeness.)*

### Where RH *does* touch algorithms — and why it still doesn't break RSA

The real, established links run through the **Generalized** Riemann Hypothesis (GRH), not the classical RH, and they make *good* algorithms work, not *attacks*:

- **Deterministic primality testing (Miller's test).** Under GRH, Miller (1976) showed a deterministic polynomial-time primality test; Bach (1990) made the witness bound explicit at `≤ 2(log n)²` (the "Bach bound"). This is GRH being *used constructively* to test primality — which *supports* key generation, it does not attack it. And critically, it has been **superseded unconditionally**: the AKS test (Agrawal–Kayal–Saxena, 2002, "PRIMES is in P") is deterministic, polynomial-time, and depends on *no* unproven hypothesis. So even the one place GRH gave a deterministic primality result is no longer load-bearing.
- **Finding quadratic non-residues / primitive roots in polynomial time** — conditional on GRH.
- **Deterministic factoring of *polynomials over finite fields*** (Ivanyos–Karpinski–Saxena) — conditional on GRH. Note carefully: this is factoring *polynomials in F_q[x]*, **not** factoring integers. It does not touch RSA.

The pattern is consistent: GRH, where it bites, *unlocks constructive algorithms for problems already known to be easy or in P*. None of these is an attack on a hardness assumption underpinning deployed cryptography. RSA, Diffie–Hellman, and elliptic-curve cryptography rely on factoring / discrete-log hardness, which RH and GRH leave entirely intact.

---

## Impact If RH Were Proven (Hypothetically, In General)

Suppose RH were proven tomorrow, by anyone, by any method. Realistic consequences:

- **Analytic number theory:** Hundreds of "conditional on RH" theorems become unconditional. Error terms in `π(x)` and related sums tighten from heuristic/conditional to proven. This is large *for mathematics*.
- **Cryptographic parameter-setting confidence:** Marginal at most. Some primality/parameter heuristics that are stated "under GRH" would gain rigour — but in practice the field already uses probabilistic Miller–Rabin and Baillie–PSW (fast, overwhelming confidence) or unconditional AKS where determinism is needed. No deployed system is waiting on RH to be safe or to function.
- **No break of any hardness assumption.** Factoring stays hard, discrete log stays hard. No webpage becomes decryptable. No bank, no TLS session, no messaging app is affected.

The honest framing: a proof of RH would be a monumental event in *mathematics* and a near-non-event in *operational security*.

---

## Impact Of This Specific Result

Essentially none, on any security or cryptographic axis:

- It is an **equivalence, not a proof** — it changes nothing about whether RH is true.
- The constructive direction is **classical and trivial** (diagonal operator with the zeros as spectrum). It introduces no new mathematical capability — no bound, no algorithm, no zero-localisation.
- It produces **no algorithm** that touches primes, factoring, discrete logs, or zero-finding.

Even granting the (false) premise that proving RH would break crypto, *this work does not prove RH*. So the impact is the impact of "we formally verified that two open problems are equivalent": a contribution to formal mathematics, indexed to mathlib, with no downstream cryptanalytic content.

---

## Humanitarian Considerations

The humanitarian-scale anxieties sometimes attached to RH ("global financial system collapses if RH is proven") are **unfounded**:

- Banking, secure communications (TLS/HTTPS), messaging, and authentication rely on factoring / discrete-log / lattice hardness, none of which RH addresses.
- The *actual* near-term humanitarian-scale cryptographic risk is **quantum computing** (Shor's algorithm breaks RSA and ECC by factoring / discrete log directly) — a completely separate track from RH, and the reason for the ongoing migration to post-quantum cryptography. This project has no bearing on that either.

So: realistic humanitarian impact of RH being proven = small and indirect (better mathematical bounds, slightly firmer footing for some parameter heuristics). Humanitarian impact of *this specific equivalence result* = none.

---

## Dual-Use & Disclosure Verdict

**Verdict: Safe to publish. No dual-use concern. No responsible-disclosure obligation.**

- There is no weaponizable component. The work contains no attack, no exploit, no algorithm against any cryptographic primitive, and no new mathematical leverage that could be repurposed into one.
- It does not prove or disprove RH, does not improve any explicit bound, and does not yield a factoring or discrete-log method.
- Publishing it cannot advance an adversary's ability to break anything.

The only thing to guard against is **misrepresentation**: this result must not be framed as "proving RH," "cracking primes," or "breaking encryption." It is a formally verified statement of a known equivalence between two open problems. Stated accurately, it carries zero security risk and warrants no embargo.

---

## Sources

- [Is it true that if RH is true, no encrypted webpage would remain safe? — Quora](https://www.quora.com/Is-it-true-that-if-the-Riemann-Hypothesis-is-true-no-encrypted-webpage-would-remain-safe) — community consensus that RH does not make factoring easier; RSA unaffected.
- [Does a solution to the Riemann hypothesis render RSA encryption obsolete? — Hacker News discussion](https://news.ycombinator.com/item?id=15933893) — debunking the myth.
- [Generalized Riemann hypothesis — Wikipedia](https://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis) — list of GRH-conditional algorithmic consequences (Miller's deterministic primality test; primitive roots; polynomial factoring over finite fields) vs unconditional results (AKS, Shanks–Tonelli).
- [Miller–Rabin primality test — Wikipedia](https://en.wikipedia.org/wiki/Miller%E2%80%93Rabin_primality_test) — Miller's GRH-conditional deterministic test; Bach bound `2(log n)²`; note that the deterministic variant is not used in practice.
- [Keith Conrad, "The Miller–Rabin Test" (UConn)](https://kconrad.math.uconn.edu/blurbs/ugradnumthy/millerrabin.pdf) — primary-source treatment of the GRH-conditional witness bound.
- [Eric Bach, "Explicit bounds for primality testing and related problems," Math. Comp. 55 (1990)](https://ui.adsabs.harvard.edu/abs/1990MaCom..55..355B/abstract) — origin of the `2(log n)²` Bach bound under GRH.
- [AKS primality test — Wikipedia](https://en.wikipedia.org/wiki/AKS_primality_test) — unconditional, deterministic, polynomial-time primality test (2002); does not depend on GRH/RH.
- [Generalized Riemann hypothesis and factoring polynomials over finite fields — ScienceDirect](https://www.sciencedirect.com/science/article/abs/pii/019667749190014P) — GRH-conditional polynomial factoring over finite fields (distinct from integer factoring).
- *(Flagged as non-mainstream / unverified, given no weight:)* [Riemann Hypothesis and Polynomial-Time Factorization — preprints.org](https://www.preprints.org/frontend/manuscript/46e724230e7d17cea3762d15b9861a69/download_pub) — non-peer-reviewed preprint claiming an RH-conditional integer-reconstruction scheme; outside consensus.

**Project files referenced:** `~/Work/Maths/quantum-neural-network/HSLNHilbertPolya.lean` (theorem statements), `HSLNRH.lean`, `HSLNVerify.lean`.
