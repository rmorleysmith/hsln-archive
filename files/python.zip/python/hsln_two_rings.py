"""hsln_two_rings.py — the two rings on ℕ→ℂ, and why one builds while the other factors.

HSLNBridge.lean (machine-checked, sorry-free) proves there are TWO different products
on arithmetic functions, and they genuinely disagree:

  Ring A — Cauchy / q-expansion :  (f ⋆ g)(n) = Σ_{i+j=n} f(i)·g(j)      ADDITIVE monoid (i+j=n)
  Ring B — Dirichlet            :  (f * g)(n) = Σ_{d·e=n} f(d)·g(e)      MULTIPLICATIVE monoid (d·e=n)

`hsln.tensor` (= np.convolve) and the pos() encoding live in Ring A. Factoring lives in
Ring B. This script shows, at the coefficient level, on a KNOWN semiprime:

  (1) Ring A composes p,q → N additively (pos(pq)=pos(p)+pos(q) mod 1) and CANNOT be
      inverted — the preimage of pos(N) is a 1-parameter family of fake pairs.
  (2) Ring B is where N=p·q actually lives: δ_p * δ_q = δ_N exactly. But you must already
      know p,q to build δ_p, δ_q. The ring encodes factoring; it does not shortcut it.
  (3) The machine-checked bridge witness reproduced numerically:
      (ζ ⋆ ζ)(1) = 0   but   (ζ * ζ)(1) = 1.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import hsln_factor_dna as hfd

# Known small semiprime (the figure-46 case) — we KNOW the factors, so we can check.
p0 = 2029073
q0 = 1265981
N0 = p0 * q0

LANE_Y = hsln.LANE_Y


def atomic_dna(pos: float) -> np.ndarray:
    """The order-1 HSLN 'atom' with a single zero on the lane at position `pos`:
    F(q) = 1 - (q_zero/q?)…  → DNA [-q_pos, 1], zero at q = exp(2πi(pos + i·LANE_Y))."""
    q_pos = np.exp(2j * np.pi * pos) * np.exp(-2 * np.pi * LANE_Y)
    return np.array([-q_pos, 1.0 + 0j])


def pos_of_dna(dna: np.ndarray) -> float:
    """Recover the on-lane position of an order-1 atom from its DNA: zero at q=-a0/a1."""
    qr = -dna[0] / dna[1]
    return (math.atan2(qr.imag, qr.real) / (2 * math.pi)) % 1.0


def dirichlet_conv_at(f, g, n: int) -> complex:
    """(f * g)(n) = Σ_{d | n} f(d)·g(n/d)  — Ring B, the multiplicative monoid."""
    s = 0j
    d = 1
    while d * d <= n:
        if n % d == 0:
            e = n // d
            s += f(d) * g(e)
            if e != d:
                s += f(e) * g(d)
        d += 1
    return s


def num_divisors(n: int) -> int:
    """d(n) = (ζ * ζ)(n)  — Ring B convolution of the all-ones DNA with itself."""
    cnt = 0
    d = 1
    while d * d <= n:
        if n % d == 0:
            cnt += 1 if d * d == n else 2
        d += 1
    return cnt


def main():
    print("=" * 78)
    print(f"  small semiprime   N0 = p0·q0 = {p0} · {q0} = {N0}")
    print(f"  N0 has {N0.bit_length()} bits;  p0·q0 == N0 ?  {p0 * q0 == N0}")
    print("=" * 78)

    # ─────────────────────────────────────────────────────────────────────────
    #  RING A  (Cauchy / q-expansion = hsln.tensor = np.convolve)  — what we train.
    # ─────────────────────────────────────────────────────────────────────────
    print("\n┌── RING A — Cauchy convolution (hsln.tensor / np.convolve): ADDITIVE ──")
    pp, pq = hfd.pos_of(p0), hfd.pos_of(q0)
    pN = hfd.pos_of(N0)
    Fp = atomic_dna(pp)
    Fq = atomic_dna(pq)
    Fp_net = hsln.Network(1, Fp)
    Fq_net = hsln.Network(1, Fq)
    FN = np.asarray(hsln.tensor(Fp_net, Fq_net).dna)   # Cauchy product of the atoms

    print(f"│  DNA F_p0 = [{Fp[0]:+.5f}, {Fp[1]:+.1f}]   zero at pos(p0) = {pp:.6f}")
    print(f"│  DNA F_q0 = [{Fq[0]:+.5f}, {Fq[1]:+.1f}]   zero at pos(q0) = {pq:.6f}")
    print(f"│  F_p0 ⋆ F_q0 (convolve) = [{FN[0]:+.5f}, {FN[1]:+.5f}, {FN[2]:+.1f}]")
    print(f"│")
    print(f"│  pos(p0) + pos(q0) mod 1 = {(pp + pq) % 1.0:.6f}")
    print(f"│  pos(N0)                 = {pN:.6f}   ← the additive homomorphism collapses 2→1")
    print(f"│  match: {abs(((pp + pq) % 1.0) - pN) < 1e-9}")

    # The collapse made explicit: pos(N0) has a 1-parameter family of preimages.
    print(f"│")
    print(f"│  INVERSE PROBLEM: every α gives a 'fake factor pair' (α, pos(N0)−α) that")
    print(f"│  reproduces pos(N0) EXACTLY but does NOT divide N0:")
    rng = np.random.default_rng(0)
    for α in [pp, *(float(x) for x in rng.uniform(0.05, 0.95, 3))]:
        partner = (pN - α) % 1.0
        # try to realise α at p0's bit-shelf and see if it divides
        k = p0.bit_length() - 1
        cand = round(2 ** (k + α))
        divides = (cand > 1) and (N0 % cand == 0)
        tag = "  ← the TRUE pos(p0)" if abs(α - pp) < 1e-9 else ""
        print(f"│     α={α:.6f}  partner={partner:.6f}  α+partner≡pos(N0) ✓   "
              f"2^(k+α)={cand} divides N0? {divides}{tag}")
    print(f"│  → the convolution preserves pos(N0); it does not preserve which (p,q) made it.")

    # ─────────────────────────────────────────────────────────────────────────
    #  RING B  (Dirichlet)  — where N = p·q actually lives.
    # ─────────────────────────────────────────────────────────────────────────
    print("\n┌── RING B — Dirichlet convolution: MULTIPLICATIVE (d·e = n) ──")
    δp = lambda n: 1.0 if n == p0 else 0.0
    δq = lambda n: 1.0 if n == q0 else 0.0
    # δ_p * δ_q evaluated at N0 and at a few decoys
    val_N0 = dirichlet_conv_at(δp, δq, N0)
    val_dec = dirichlet_conv_at(δp, δq, N0 + 2)
    print(f"│  (δ_p0 * δ_q0)(N0)   = {val_N0.real:.1f}   ← spikes EXACTLY at N0 = p0·q0")
    print(f"│  (δ_p0 * δ_q0)(N0+2) = {val_dec.real:.1f}   ← zero everywhere else")
    print(f"│  d(N0) = (ζ * ζ)(N0) = {num_divisors(N0)}   ← =4 ⇒ semiprime signature (1,p0,q0,N0)")
    print(f"│  BUT: building δ_p0, δ_q0 requires already knowing p0, q0.")
    print(f"│  Ring B *encodes* the factorisation; it gives no shortcut to *compute* it.")

    # ─────────────────────────────────────────────────────────────────────────
    #  THE BRIDGE WITNESS  (HSLNBridge.rings_disagree_on_zeta, machine-checked)
    # ─────────────────────────────────────────────────────────────────────────
    print("\n┌── BRIDGE WITNESS — the two rings provably differ (reproduced numerically) ──")
    M = 64
    ζ = np.ones(M)            # all-ones DNA, ζ(n)=1 for n≥1 (index n)
    ζ[0] = 0.0                # arithmetic-function convention f(0)=0
    cauchy_zz = np.convolve(ζ, ζ)        # Ring A
    dirichlet_zz_1 = sum(1.0 for d in [1])  # (ζ*ζ)(1) = Σ_{d|1} 1 = 1
    print(f"│  (ζ ⋆ ζ)(1)  [Cauchy]    = {cauchy_zz[1]:.1f}   (always 0 at n=1)")
    print(f"│  (ζ * ζ)(1)  [Dirichlet] = {dirichlet_zz_1:.1f}   (= d(1) = 1)")
    print(f"│  0 ≠ 1  → the modular-form product and the L-function product are NOT the same op.")
    print(f"│  This is HSLNBridge.rings_disagree_on_zeta, proved sorry-free in your repo.")

    print("\n" + "=" * 78)
    print("  VERDICT")
    print("=" * 78)
    print("  • Recovery is a one-way bijection: GIVEN pos(p), p = round(2^(k+pos(p))).")
    print("  • Training onto pos(N) puts the neuron at pos(N), not pos(p): nothing to invert.")
    print("  • pos is a homomorphism (ℕ,×)→(ℝ/ℤ,+); factoring = inverting a 2-input map from")
    print("    its 1 output. Additive (Ring A) or multiplicative (Hecke a_N=a_p·a_q, Ring B),")
    print("    it is the SAME 2-from-1 collapse. Composition builds; it cannot un-build.")


if __name__ == "__main__":
    main()
