"""Stacking two skills: find-missing (A) THEN count (B) -> "which letter is missing,
by number".

This is FUNCTION composition  B(A(x))  -- a 2-layer pipeline, NOT the DNA-product
(tensor/direct-sum) composition. Skill A's output feeds skill B's input.

Encoding (native to the HSLN): position p <-> a root of unity, direction
(cos 2*pi*p/n, sin 2*pi*p/n). Because the n-th roots of unity sum to zero, the present
letters' net pull points to the ANTIPODE of the missing one. Skill A is a CONFINED,
DRIVEN reservoir (a particle in an |F|^2 well, integrating the bag of present letters):
it settles displaced toward that antipode; negating gives the missing position's state.
Skill B -- trained SEPARATELY -- is a counting readout mapping that state's angle to a
number. Stack A->B and read off the answer.

The roots-of-unity / circular representation is exactly the Fourier solution that grokking
networks slowly discover on modular-arithmetic tasks; here it is the HSLN's native state.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

import modular

N = 6
LETTERS = "ABCDEF"
CENTER = np.array([0.5, 0.5])
_qc = np.exp(2j * np.pi * (CENTER[0] + 1j * CENTER[1]))
DNA = np.array([-_qc, 1.0 + 0j])                 # confining neuron (zero of F) at CENTER


def roots(n):
    th = 2 * np.pi * np.arange(n) / n
    return np.stack([np.cos(th), np.sin(th)], axis=1)


DIR = roots(N)                                   # position -> root-of-unity direction


# --------------------------------------------------------------------------- #
#  Skill A: confined, driven HSLN reservoir that finds the missing letter      #
# --------------------------------------------------------------------------- #
def _grad_E(xy):
    F, Fp = modular.qpoly_grad(DNA, np.array([xy[0] + 1j * xy[1]]))
    F, Fp = F[0], Fp[0]
    cF = np.conj(F)
    return np.array([2 * np.real(cF * Fp), -2 * np.imag(cF * Fp)])


def find_missing(present, dirs=DIR, steps=600, dt=0.01, alpha=0.5, Bd=0.05):
    """Drive the well with the bag of present letters; settle; the displacement points
    to the missing one's antipode -> negate to get the missing direction."""
    D = dirs[present].sum(axis=0)                # reservoir integrates the present letters
    xy = CENTER.copy()
    traj = [xy.copy()]
    for _ in range(steps):
        xy = xy - dt * alpha * _grad_E(xy) + dt * Bd * D
        xy = np.clip(xy, [0.12, 0.22], [0.88, 0.78])
        traj.append(xy.copy())
    disp = xy - CENTER
    missing_dir = -disp / (np.linalg.norm(disp) + 1e-12)
    return xy, missing_dir, np.array(traj)


# --------------------------------------------------------------------------- #
#  Skill B: a SEPARATELY-trained counting readout (angle/state -> number)      #
# --------------------------------------------------------------------------- #
def train_count(positions, dirs=DIR, seed=0, steps=500, lr=0.4):
    rng = np.random.default_rng(seed)
    Xs, ys = [], []
    for p in positions:
        for _ in range(80):
            v = dirs[p] + 0.10 * rng.standard_normal(2)
            Xs.append(v / (np.linalg.norm(v) + 1e-9)); ys.append(p)
    Xs, ys = np.array(Xs), np.array(ys)
    W = 0.1 * rng.standard_normal((N, 2)); b = np.zeros(N)
    for _ in range(steps):
        Z = Xs @ W.T + b
        Z -= Z.max(1, keepdims=True)
        P = np.exp(Z); P /= P.sum(1, keepdims=True)
        G = P.copy(); G[np.arange(len(ys)), ys] -= 1
        W -= lr * (G.T @ Xs) / len(ys)
        b -= lr * G.mean(0)
    return W, b


def count(W, b, v):
    return int((W @ v + b).argmax())


# --------------------------------------------------------------------------- #
def run(make_fig=True):
    # train skill B on its own, on clean position->number examples
    W, b = train_count(range(N))

    rows, trajs = [], {}
    correct = 0
    for m in range(N):
        present = [p for p in range(N) if p != m]
        xy, mdir, tr = find_missing(present)
        num = count(W, b, mdir)            # stack: B(A(present))
        ok = num == m
        correct += ok
        rows.append((m, present, xy, mdir, num, ok))
        trajs[m] = (tr, mdir)
        seq = ",".join(LETTERS[p] for p in present)
        print(f"present [{seq}]  ->  missing is letter {LETTERS[m]}  ->  reservoir says "
              f"number {num + 1}  {'OK' if ok else 'WRONG'}")
    print(f"\ncomposed (find-missing then count) accuracy: {correct}/{N}")

    if make_fig:
        _figure(rows, trajs, W, b)
    return correct


def _figure(rows, trajs, W, b):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, NEURON, GREEN = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A"

    fig, ax = plt.subplots(1, 2, figsize=(13.8, 6.2))

    # --- A: one solved problem, on the cyclic encoding --- #
    a = ax[0]
    a.set_facecolor("#0b0b14")
    m = 2                                            # missing letter C (position 2)
    present = [p for p in range(N) if p != m]
    th = 2 * np.pi * np.arange(361) / 360
    a.plot(CENTER[0] + 0.28 * np.cos(th), CENTER[1] + 0.28 * np.sin(th), color="#333", lw=1)
    for p in range(N):
        pt = CENTER + 0.28 * DIR[p]
        col = "#555" if p == m else TEAL
        a.plot(*pt, "o", color=col, ms=14, mec="white", mew=0.6, zorder=4)
        a.annotate(LETTERS[p] + ("  (missing)" if p == m else ""), pt,
                   textcoords="offset points", xytext=(10, 6), color=col, fontsize=10)
    tr, mdir = trajs[m]
    a.plot(tr[:, 0], tr[:, 1], color=GOLD, lw=1.6, zorder=3, alpha=0.9)
    a.annotate("", xy=tr[-1], xytext=tuple(CENTER),
               arrowprops=dict(arrowstyle="->", color=GOLD, lw=2))
    a.annotate("net pull of present\nletters → antipode", tr[-1],
               textcoords="offset points", xytext=(-4, -34), color=GOLD, fontsize=8.5)
    # recovered missing direction (negated)
    rec = CENTER + 0.28 * mdir
    a.annotate("", xy=rec, xytext=tuple(CENTER),
               arrowprops=dict(arrowstyle="->", color=NEURON, lw=2.2))
    a.annotate(f"recovered missing → '{LETTERS[m]}' = number {count(W,b,mdir)+1}", rec,
               textcoords="offset points", xytext=(8, 8), color=NEURON, fontsize=9)
    a.plot(*CENTER, "+", color="white", ms=10)
    a.set_xlim(0.12, 0.92); a.set_ylim(0.16, 0.86)
    a.set_aspect("equal")
    a.set_xlabel(r"$\mathrm{Re}\,\tau$"); a.set_ylabel(r"$\mathrm{Im}\,\tau$")
    a.set_title("skill A (find-missing): a driven reservoir settles\ntoward the gap's antipode",
                fontsize=12)

    # --- B: the stacked pipeline solving all problems --- #
    b_ax = ax[1]
    truth = [r[0] + 1 for r in rows]
    pred = [r[4] + 1 for r in rows]
    okall = all(r[5] for r in rows)
    b_ax.plot(range(1, N + 1), truth, "o", color="#888", ms=16, mfc="none", mew=2,
              label="missing letter's true number")
    b_ax.plot(range(1, N + 1), pred, "x", color=GREEN, ms=12, mew=2.5,
              label="pipeline output (A→B)")
    for r in rows:
        b_ax.annotate(LETTERS[r[0]], (r[0] + 1, r[0] + 1), textcoords="offset points",
                      xytext=(8, -4), color=TEAL, fontsize=10)
    b_ax.plot([0.5, N + 0.5], [0.5, N + 0.5], color="#333", lw=0.8, zorder=0)
    b_ax.set_xticks(range(1, N + 1)); b_ax.set_yticks(range(1, N + 1))
    b_ax.set_xlabel("problem (which letter is missing)")
    b_ax.set_ylabel("answer: its number")
    b_ax.set_title(f"stacked: find-missing ∘ count  →  {'all correct' if okall else 'errors'}",
                   fontsize=12)
    b_ax.legend(loc="upper left", fontsize=9, framealpha=0.3)

    fig.suptitle("Function composition (stacking): skill A finds the missing letter, skill B "
                 "(trained apart) names its number", fontsize=13, y=0.99)
    out = Path(__file__).parent / "figures" / "29_skill_compose.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
