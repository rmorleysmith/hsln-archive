#!/usr/bin/env python3
"""hecke_compression.py — Andrianov-Hecke compression of an L-function in pictures.

Empirical companion to HSLNHecke.lean.

For a Hecke eigenform `f`, the Dirichlet coefficient sequence `(a_n)` is determined
by its prime-indexed values `(a_p)_{p prime}`:
  1. Hecke recursion at each prime:  `a_{p^{r+2}} = a_p · a_{p^{r+1}} − p^{k-1} · a_{p^r}`
  2. Multiplicativity:                `a_{mn} = a_m · a_n`  for  `gcd(m, n) = 1`

Curve: E_{37}: y² + y = x³ − x  (Cremona 37a1; conductor 37 prime; rank 1).
The L-function of E_{37} is attached to a weight-2 normalised Hecke newform of
level Γ₀(37), so `(a_p)_p` IS the compressed DNA we visualise.

Plus a "big-ish prime" demo: compute `a_p` directly from #E(𝔽_p) at p ≈ 10⁶, then
unroll the Hecke recursion to get `a_{p^r}` for r up to 15 — no further point
counting needed.

References:
* Hecke 1937, Math. Ann. 114, 1-28 (genus-1 determination by prime values).
* Cremona's tables: 37a1.
* Sato-Tate conjecture proved for non-CM elliptic curves: Taylor + collaborators,
  "Automorphy and the Sato-Tate conjecture", Ann. Math. 2011.
"""

import time
from math import gcd, sqrt, log
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'axes.edgecolor': '#333333',
    'axes.labelcolor': '#222222',
    'xtick.color': '#222222',
    'ytick.color': '#222222',
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'legend.fontsize': 9,
    'font.family': 'sans-serif',
})

FIG_DIR = Path('~/Work/Maths/quantum-neural-network/viz/figures')


# ────────────────────────────────────────────────────────────────────────────────
#   Curve E_37: y² + y = x³ − x  (Cremona 37a1; conductor 37, rank 1)
# ────────────────────────────────────────────────────────────────────────────────

CONDUCTOR = 37
WEIGHT = 2  # for elliptic-curve newforms


def count_points_37a1(p: int) -> int:
    """#E(𝔽_p) for E: y² + y = x³ − x. p must be odd."""
    if p == 2:
        return 5  # known: a_2 = -2 for 37a1
    count = 1  # point at infinity
    # Equation: y² + y ≡ x³ − x. Multiply by 4: (2y+1)² ≡ 4(x³−x) + 1.
    # For each x, count solutions y mod p via the Legendre symbol of disc = 4(x³−x)+1.
    for x in range(p):
        c = (x * x * x - x) % p
        disc = (4 * c + 1) % p
        if disc == 0:
            count += 1
        else:
            ls = pow(disc, (p - 1) // 2, p)
            if ls == 1:
                count += 2
    return count


def a_p_curve(p: int) -> int:
    """a_p = p + 1 − #E(𝔽_p)."""
    return p + 1 - count_points_37a1(p)


def primes_up_to(N: int) -> list[int]:
    sieve = bytearray([1]) * (N + 1)
    sieve[0] = sieve[1] = 0
    for i in range(2, int(N ** 0.5) + 1):
        if sieve[i]:
            for j in range(i * i, N + 1, i):
                sieve[j] = 0
    return [i for i in range(N + 1) if sieve[i]]


# ────────────────────────────────────────────────────────────────────────────────
#   Hecke recursion + multiplicativity (the "decompression" of the prime DNA)
# ────────────────────────────────────────────────────────────────────────────────

def a_prime_power(p: int, r: int, ap: int, weight: int = WEIGHT) -> int:
    """a_{p^r} via the Hecke recursion. NO further point counting needed."""
    if r == 0:
        return 1
    if r == 1:
        return ap
    pk = p ** (weight - 1)
    prev_prev, prev = 1, ap  # a_{p^0}, a_{p^1}
    for _ in range(2, r + 1):
        prev_prev, prev = prev, ap * prev - pk * prev_prev
    return prev


def a_n_from_dna(n: int, a_p_dict: dict[int, int]) -> int | None:
    """a_n via multiplicativity + Hecke recursion from prime DNA. None if a
    prime factor of n isn't in the DNA."""
    if n == 1:
        return 1
    result = 1
    temp = n
    p = 2
    while p * p <= temp:
        if temp % p == 0:
            e = 0
            while temp % p == 0:
                temp //= p
                e += 1
            if p not in a_p_dict:
                return None
            result *= a_prime_power(p, e, a_p_dict[p])
        p += 1
    if temp > 1:
        if temp not in a_p_dict:
            return None
        result *= a_p_dict[temp]
    return result


# ────────────────────────────────────────────────────────────────────────────────
#   Compute the prime DNA up to a bound + a single big-prime evaluation
# ────────────────────────────────────────────────────────────────────────────────

def compute_prime_dna(bound: int, big_prime: int) -> tuple[dict[int, int], int]:
    print(f"  Sieving primes up to {bound:,} ...")
    pr = primes_up_to(bound)
    print(f"  → {len(pr)} primes. Computing a_p for each (point-counting mod p)...")

    a_p_dict = {}
    t0 = time.perf_counter()
    for i, p in enumerate(pr):
        if p == CONDUCTOR:
            # Bad reduction at conductor 37 (non-split multiplicative): a_37 = +1.
            # See LMFDB 37.a1 / Cremona's tables.
            a_p_dict[p] = 1
        else:
            a_p_dict[p] = a_p_curve(p)
        if (i + 1) % 200 == 0:
            print(f"    ... {i + 1}/{len(pr)} primes ({time.perf_counter() - t0:.1f}s)")
    print(f"  ✓ Prime DNA up to {bound:,} computed in {time.perf_counter() - t0:.1f}s\n")

    print(f"  Now evaluating a_p at the big-ish prime p = {big_prime:,} ...")
    print(f"  → counting #E(𝔽_p) directly (one-shot)")
    t0 = time.perf_counter()
    big_ap = a_p_curve(big_prime)
    t_big = time.perf_counter() - t0
    print(f"  ✓ a_{big_prime:,} = {big_ap}  ({t_big:.1f}s, ~{big_prime/t_big/1000:.0f}k pts/s)")
    a_p_dict[big_prime] = big_ap
    return a_p_dict, big_ap


# ────────────────────────────────────────────────────────────────────────────────
#   Visualisations
# ────────────────────────────────────────────────────────────────────────────────

def fig1_prime_barcode_and_sato_tate(a_p_dict, primes, ap_for_satotate):
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))

    # ── Panel A: prime barcode (small primes) ─────────────────────────────────
    ax = axes[0, 0]
    sub = [p for p in primes if p <= 200]
    aps = [a_p_dict[p] for p in sub]
    ax.vlines(sub, 0, aps, linewidth=0.9, color='#1f77b4', alpha=0.85)
    ax.scatter(sub, aps, s=14, color='#1f77b4', zorder=3)
    ax.axhline(0, color='black', linewidth=0.6)
    # Hasse curves: ±2√p
    p_range = np.linspace(2, 200, 400)
    ax.plot(p_range, 2 * np.sqrt(p_range), 'r--', alpha=0.4, label=r'Hasse bound $\pm 2\sqrt{p}$')
    ax.plot(p_range, -2 * np.sqrt(p_range), 'r--', alpha=0.4)
    ax.set_xlabel('prime p')
    ax.set_ylabel(r'$a_p$')
    ax.set_title('A. Prime DNA: $a_p$ for primes p ≤ 200\n(the compressed L-function fingerprint)')
    ax.legend(loc='upper right')
    ax.grid(alpha=0.3)

    # ── Panel B: prime barcode (extended) ─────────────────────────────────────
    ax = axes[0, 1]
    sub2 = [p for p in primes if p <= 5000]
    aps2 = [a_p_dict[p] for p in sub2]
    ax.scatter(sub2, aps2, s=4, color='#1f77b4', alpha=0.55)
    p_range = np.linspace(2, 5000, 1000)
    ax.plot(p_range, 2 * np.sqrt(p_range), 'r--', alpha=0.4, label=r'Hasse bound $\pm 2\sqrt{p}$')
    ax.plot(p_range, -2 * np.sqrt(p_range), 'r--', alpha=0.4)
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_xlabel('prime p')
    ax.set_ylabel(r'$a_p$')
    ax.set_title(f'B. Prime DNA: $a_p$ for primes p ≤ 5000 ({sum(1 for p in sub2)} points)\nThe Hasse envelope is filled in.')
    ax.legend(loc='upper right')
    ax.grid(alpha=0.3)

    # ── Panel C: Sato-Tate angle histogram ────────────────────────────────────
    ax = axes[1, 0]
    angles = []
    for p in primes:
        if p == CONDUCTOR:
            continue
        ap = a_p_dict[p]
        cos_theta = np.clip(ap / (2 * sqrt(p)), -1.0, 1.0)
        angles.append(np.arccos(cos_theta))
    ax.hist(angles, bins=42, density=True, alpha=0.7, color='#2ca02c',
            edgecolor='black', linewidth=0.4)
    theta = np.linspace(0, np.pi, 200)
    sato_tate_density = (2 / np.pi) * np.sin(theta) ** 2
    ax.plot(theta, sato_tate_density, color='#d62728', linewidth=2.5,
            label=r'Sato-Tate: $\frac{2}{\pi}\sin^2\theta$')
    ax.set_xlabel(r'angle $\theta_p = \arccos(a_p / 2\sqrt{p})$')
    ax.set_ylabel('density')
    ax.set_title(f'C. Sato-Tate distribution over {len(angles)} primes\n(conjecture proved 2011 for non-CM curves)')
    ax.legend(loc='upper center')
    ax.grid(alpha=0.3)

    # ── Panel D: prime barcode, normalised by Hasse ───────────────────────────
    ax = axes[1, 1]
    xs = []
    ys = []
    for p in primes:
        if p == CONDUCTOR:
            continue
        xs.append(p)
        ys.append(a_p_dict[p] / (2 * sqrt(p)))
    ax.scatter(xs, ys, s=4, alpha=0.5, color='#ff7f0e')
    ax.axhline(1, color='red', linestyle='--', alpha=0.4)
    ax.axhline(-1, color='red', linestyle='--', alpha=0.4)
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_xscale('log')
    ax.set_xlabel('prime p (log scale)')
    ax.set_ylabel(r'$a_p / 2\sqrt{p} \in [-1, 1]$')
    ax.set_title('D. Normalised prime fingerprint\n(unit-bounded → semicircle by Sato-Tate)')
    ax.set_ylim(-1.15, 1.15)
    ax.grid(alpha=0.3, which='both')

    plt.tight_layout()
    out = FIG_DIR / '41_hecke_prime_dna.png'
    plt.savefig(out, dpi=140, bbox_inches='tight')
    plt.close()
    print(f"  ✓ {out.name}")


def fig2_hecke_tensor_and_multiplicativity(a_p_dict, primes):
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))

    # ── Panel A: heatmap of a_{p^r} normalised by Deligne ─────────────────────
    ax = axes[0, 0]
    heat_primes = [p for p in primes if p <= 200 and p != CONDUCTOR]
    R_MAX = 12
    heat = np.zeros((R_MAX + 1, len(heat_primes)))
    for j, p in enumerate(heat_primes):
        ap = a_p_dict[p]
        for r in range(R_MAX + 1):
            apr = a_prime_power(p, r, ap)
            # Deligne: |a_{p^r}| ≤ (r+1) · p^{r/2}
            norm = (r + 1) * (p ** (r / 2))
            heat[r, j] = apr / norm if norm > 0 else 0
    im = ax.imshow(heat, aspect='auto', cmap='RdBu_r', vmin=-1, vmax=1, origin='lower',
                   extent=[heat_primes[0] - 0.5, heat_primes[-1] + 0.5, -0.5, R_MAX + 0.5])
    ax.set_xlabel('prime p')
    ax.set_ylabel('exponent r')
    ax.set_title(r'A. Hecke tensor $a_{p^r}/[(r+1)\,p^{r/2}]$' +
                 '\n(every column generated from row r=1 via the recursion)')
    plt.colorbar(im, ax=ax, label='normalised value')

    # ── Panel B: a_{p^r} for a few specific primes vs r ───────────────────────
    ax = axes[0, 1]
    SHOW_PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23]
    colors = plt.cm.viridis(np.linspace(0, 0.9, len(SHOW_PRIMES)))
    rs = np.arange(0, R_MAX + 1)
    for p, c in zip(SHOW_PRIMES, colors):
        ap = a_p_dict[p]
        apr_vals = [a_prime_power(p, r, ap) for r in rs]
        # Normalise by p^{r/2} (the Hasse-ish bound is (r+1) p^{r/2})
        normed = [apr / (p ** (r / 2)) for r, apr in zip(rs, apr_vals)]
        ax.plot(rs, normed, '-o', color=c, label=f'p = {p}, $a_p$ = {ap}',
                markersize=5, linewidth=1.5, alpha=0.85)
    # Deligne envelope: ±(r+1)
    ax.fill_between(rs, -(rs + 1), rs + 1, alpha=0.08, color='red',
                    label=r'Deligne envelope $\pm(r+1)$')
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_xlabel('r')
    ax.set_ylabel(r'$a_{p^r} / p^{r/2}$')
    ax.set_title('B. Hecke recursion unrolled per prime\n(rank-2 linear recurrence per p)')
    ax.legend(loc='lower left', ncols=2, fontsize=8)
    ax.grid(alpha=0.3)

    # ── Panel C: multiplicativity verification ────────────────────────────────
    ax = axes[1, 0]
    # For coprime m, n ≤ 100 with m·n ≤ 5000, verify a_{mn} via direct
    # (multiplicativity from the DNA) vs as a product a_m · a_n.
    pairs = []
    products = []
    differences = []
    for m in range(2, 200):
        for n in range(m + 1, 200):
            if gcd(m, n) != 1:
                continue
            if m * n > 5000:
                continue
            am = a_n_from_dna(m, a_p_dict)
            an = a_n_from_dna(n, a_p_dict)
            amn = a_n_from_dna(m * n, a_p_dict)
            if am is None or an is None or amn is None:
                continue
            pairs.append((m, n))
            products.append(am * an)
            differences.append(amn - am * an)
    differences = np.array(differences)
    ax.scatter(products, differences, alpha=0.55, s=15, color='#17becf')
    ax.axhline(0, color='red', linewidth=1.0)
    ax.set_xlabel(r'$a_m \cdot a_n$')
    ax.set_ylabel(r'$a_{mn} - a_m \cdot a_n$')
    max_err = int(np.max(np.abs(differences))) if len(differences) > 0 else 0
    ax.set_title(f'C. Multiplicativity check on {len(pairs)} coprime pairs\n'
                 f'(max |error| = {max_err} ✓)')
    ax.grid(alpha=0.3)

    # ── Panel D: divisor function via Hecke recursion ─────────────────────────
    ax = axes[1, 1]
    # Show a_n for n up to ~1000, computed via DNA. Coloured bar plot.
    N_BARS = 200
    ns = list(range(1, N_BARS + 1))
    ans = []
    ok = []
    for n in ns:
        an = a_n_from_dna(n, a_p_dict)
        if an is None:
            ans.append(0)
            ok.append(False)
        else:
            ans.append(an)
            ok.append(True)
    colors_n = ['#1f77b4' if o else '#888888' for o in ok]
    ax.bar(ns, ans, color=colors_n, width=0.8)
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_xlabel('n')
    ax.set_ylabel(r'$a_n$')
    ax.set_title(f'D. Decompressed L-coefficient sequence: $a_n$ for n ≤ {N_BARS}\n(every value reconstructed from the prime DNA)')
    ax.grid(alpha=0.3)

    plt.tight_layout()
    out = FIG_DIR / '42_hecke_tensor.png'
    plt.savefig(out, dpi=140, bbox_inches='tight')
    plt.close()
    print(f"  ✓ {out.name}")


def fig3_big_prime_and_compression(a_p_dict, primes, big_ap, BIG_P):
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))

    # ── Panel A: Hecke recursion at the BIG prime ─────────────────────────────
    ax = axes[0, 0]
    R = 15
    apr_vals = [a_prime_power(BIG_P, r, big_ap) for r in range(R + 1)]
    apr_normed = [apr / (BIG_P ** (r / 2)) for r, apr in enumerate(apr_vals)]
    markerline, stemlines, baseline = ax.stem(range(R + 1), apr_normed, basefmt=' ',
                                              linefmt='b-', markerfmt='bo')
    plt.setp(markerline, markersize=8)
    plt.setp(stemlines, linewidth=2)
    rs = np.arange(R + 1)
    ax.fill_between(rs, -(rs + 1), rs + 1, alpha=0.12, color='red',
                    label=r'Deligne envelope $\pm(r+1)$')
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_xlabel('r')
    ax.set_ylabel(rf'$a_{{p^r}} / p^{{r/2}}$,  p = {BIG_P:,}')
    ax.set_title(f'A. Hecke recursion at the big prime p = {BIG_P:,}\n'
                 rf'$a_p$ = {big_ap}; all $a_{{p^r}}$ derived by recurrence')
    ax.legend(loc='upper left')
    ax.grid(alpha=0.3)

    # ── Panel B: information-theoretic compression ────────────────────────────
    ax = axes[0, 1]
    Ns = np.unique(np.logspace(1, 6, 200).astype(int))
    primes_arr = np.array(primes)
    pi_counts = [int((primes_arr <= N).sum()) for N in Ns]
    ax.loglog(Ns, Ns, 'k--', linewidth=1.4, label='all integers n ≤ N')
    ax.loglog(Ns, pi_counts, color='#1f77b4', linewidth=2.4, label='primes p ≤ N (DNA)')
    ax.loglog(Ns, [N / log(N) for N in Ns], 'r:', linewidth=1.6, label=r'$N / \log N$ (PNT)')
    ax.set_xlabel('N')
    ax.set_ylabel('count')
    ax.set_title('B. Compression ratio: |DNA| vs |full L-sequence|\n(prime DNA is logarithmically smaller)')
    ax.legend(loc='lower right')
    ax.grid(alpha=0.3, which='both')

    # ── Panel C: Euler product convergence at s = 1 ───────────────────────────
    ax = axes[1, 0]
    # Partial Euler product:  ∏_{p ≤ X} (1 − a_p p^{-1} + p^{1-2})^{-1}
    #                       = ∏_{p ≤ X} (1 − a_p/p + 1/p)^{-1}
    # For 37a1 rank 1, L(E, 1) = 0; root number w = -1 forces central vanishing.
    # So partial products should → 0.
    sub = [p for p in primes if 2 <= p <= 5000 and p != CONDUCTOR]
    Xs, partials = [], []
    prod = 1.0
    for p in sub:
        ap = a_p_dict[p]
        local = 1.0 / (1.0 - ap / p + 1.0 / p)
        prod *= local
        Xs.append(p)
        partials.append(prod)
    ax.semilogx(Xs, partials, color='#d62728', linewidth=1.6)
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_xlabel('prime cutoff X (log scale)')
    ax.set_ylabel(r'partial $\prod_{p \leq X} L_p^{-1}(s=1)$')
    ax.set_title(r'C. Euler product at $s = 1$ for $E_{37}$' +
                 f'\n(L(E_{{37}}, 1) = 0 since rank 1, root number $w = -1$)')
    ax.grid(alpha=0.3, which='both')

    # ── Panel D: reconstruction efficiency curve ──────────────────────────────
    ax = axes[1, 1]
    Xs2 = [3, 5, 7, 11, 17, 31, 53, 89, 151, 257, 433, 743, 1259, 2153, 3677]
    N_eval = 10000
    pct_reconstructible = []
    for X in Xs2:
        primes_le_X = {p for p in primes if p <= X}
        good = 0
        for n in range(1, N_eval + 1):
            temp = n
            ok = True
            p = 2
            while p * p <= temp:
                if temp % p == 0:
                    while temp % p == 0:
                        temp //= p
                    if p not in primes_le_X:
                        ok = False
                        break
                p += 1
            if ok and (temp == 1 or temp in primes_le_X):
                good += 1
        pct_reconstructible.append(100 * good / N_eval)
    ax.semilogx(Xs2, pct_reconstructible, 'o-', color='#9467bd',
                markersize=8, linewidth=2)
    ax.fill_between(Xs2, 0, pct_reconstructible, alpha=0.15, color='#9467bd')
    ax.set_xlabel('prime cutoff X (log scale)')
    ax.set_ylabel(rf'% of $a_n$ recoverable, n ≤ {N_eval}')
    ax.set_title(f'D. Reconstruction efficiency\n'
                 rf'(given $a_p$ for p ≤ X, fraction of $a_n$ obtainable for n ≤ {N_eval})')
    ax.set_ylim(0, 105)
    ax.grid(alpha=0.3, which='both')

    plt.tight_layout()
    out = FIG_DIR / '43_hecke_big_prime.png'
    plt.savefig(out, dpi=140, bbox_inches='tight')
    plt.close()
    print(f"  ✓ {out.name}")


# ────────────────────────────────────────────────────────────────────────────────
#   Main
# ────────────────────────────────────────────────────────────────────────────────

def main():
    print("=" * 78)
    print(" Andrianov-Hecke compression of an elliptic-curve L-function")
    print(" Curve E_37: y² + y = x³ − x  (Cremona 37a1, conductor 37, rank 1)")
    print("=" * 78)
    print()

    BOUND = 5000        # prime DNA bound
    BIG_P = 1_000_003   # big-ish prime (20-bit)

    a_p_dict, big_ap = compute_prime_dna(BOUND, BIG_P)
    primes = sorted(p for p in a_p_dict if p != BIG_P)

    print(f"\n  ─── Hecke recursion at p = {BIG_P:,} ───")
    print(f"  Recurrence: a_{{p^{{r+2}}}} = a_p · a_{{p^{{r+1}}}} − p · a_{{p^r}}")
    print(f"  Base: a_{{p^0}} = 1, a_p = {big_ap}\n")
    print(f"    r  |   a_{{p^r}}")
    print(f"  -----+----------------------------------")
    for r in range(11):
        apr = a_prime_power(BIG_P, r, big_ap)
        print(f"    {r:2d} |  {apr:+,d}")
    print()

    print("  ─── Generating figures ───")
    fig1_prime_barcode_and_sato_tate(a_p_dict, primes, None)
    fig2_hecke_tensor_and_multiplicativity(a_p_dict, primes)
    fig3_big_prime_and_compression(a_p_dict, primes, big_ap, BIG_P)

    print()
    print("─" * 78)
    print("  Summary")
    print("─" * 78)
    print(f"  • Curve:        37a1, y² + y = x³ − x, conductor 37 prime, rank 1")
    print(f"  • Prime DNA:    {len(primes)} primes ≤ {BOUND:,}")
    print(f"  • Big prime:    a_{BIG_P:,} = {big_ap}")
    print(f"  • Hasse:        |a_p| = {abs(big_ap)} ≤ 2√p ≈ {2*sqrt(BIG_P):.0f}  ✓")
    print(f"  • Three figures saved to viz/figures/ (41, 42, 43).")
    print()
    print("  The Andrianov-Hecke determination theorem (HSLNHecke.lean,")
    print("  fourier_determined_by_primes_genus1) is what *guarantees* that the prime")
    print("  DNA — alone — is enough to reconstruct every a_n. Empirically demonstrated")
    print("  here via the rank-2 linear recurrence at each prime + multiplicativity.")


if __name__ == "__main__":
    main()
