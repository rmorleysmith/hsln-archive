"""hsln_bignum_many.py — train F_N with many neurons (dg=30) and inspect."""

from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import numpy as np
import mpmath as mp
import matplotlib.pyplot as plt
import matplotlib as mpl

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import modular
import hsln_factor_dna as hfd

mpl.rcParams.update({'figure.facecolor':'white','axes.facecolor':'white'})

N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)
LANE_Y = hsln.LANE_Y


def cand_at(alpha, k):
    mp.mp.dps = max(60, int(k * 0.302) + 50)
    return int(mp.nint(mp.power(2, mp.mpf(k) + mp.mpf(alpha))))


def q_to_pos(q_root: complex) -> tuple[float, float]:
    re = (math.atan2(q_root.imag, q_root.real) / (2 * math.pi)) % 1.0
    im = -math.log(abs(q_root)) / (2 * math.pi)
    return re, im


def run_for_dg(DG: int, pos_N: float, label_suffix=''):
    print(f'\n{"━"*78}\n  dg = {DG}   ({DG-1} neurons)\n{"━"*78}')

    probes = np.array(hsln.PROBES)
    probe_idx = hfd.closest_probe(pos_N)
    target = np.zeros_like(probes, dtype=float)
    target[probe_idx] = 1.0

    steps = 4000 if DG <= 20 else 5000
    print(f'  training with one-hot target at probe {probe_idx} '
          f'(pos {float(probes[probe_idx]):.4f}), steps={steps} ...')
    net, hist = hfd.train(target, dg=DG, steps=steps, seed=0)
    print(f'  loss {hist[0]:.4f} → {hist[-1]:.6f}')

    dna = np.asarray(net.dna)

    # ── DNA table ───────────────────────────────────────────────────────────
    print(f'\n  DNA  (length {len(dna)}):')
    print(f'    n  |    Re a_n        Im a_n       |a_n|       arg(°)')
    print(f'   ----+----------------------------------------------------')
    for n, a in enumerate(dna):
        ang = math.degrees(math.atan2(a.imag, a.real))
        marker = '  ←' if abs(a) > 0.5 else ''
        print(f'    {n:2d} | {a.real:+.6f}    {a.imag:+.6f}    {abs(a):.5f}    {ang:+7.2f}{marker}')

    # ── Zeros in q-space and their positions ──────────────────────────────
    q_roots = np.roots(dna[::-1])
    pos_list = []
    for qr in q_roots:
        re_t, im_t = q_to_pos(qr)
        pos_list.append((re_t, im_t, qr))
    pos_list.sort(key=lambda t: t[0])
    print(f'\n  {len(q_roots)} roots of F_N in q-space:')
    print(f'    Re τ      Im τ      |q|     on-lane?')
    on_lane_positions = []
    for re_t, im_t, qr in pos_list:
        on_lane = abs(im_t - LANE_Y) < 0.04
        if on_lane:
            on_lane_positions.append(re_t)
        marker = '  ★ on lane' if on_lane else ''
        print(f'    {re_t:.4f}    {im_t:.4f}    {abs(qr):.4f}{marker}')
    print(f'\n  On-lane positions: {[f"{p:.4f}" for p in on_lane_positions]}')

    # ── Pair-sum: find pairs (i, j) with (pos_i + pos_j) mod 1 ≈ pos(N) ────
    all_positions = [t[0] for t in pos_list]
    print(f'\n  Pair-sum hunt: pairs (i, j) where (Re τ_i + Re τ_j) mod 1 ≈ pos(N) = {pos_N:.4f}')
    print(f'    tolerance ±0.005')
    pair_matches = []
    for i in range(len(all_positions)):
        for j in range(i, len(all_positions)):  # include i==j (double root)
            s = (all_positions[i] + all_positions[j]) % 1.0
            err = min(abs(s - pos_N), 1 - abs(s - pos_N))
            if err < 0.005:
                pair_matches.append((i, j, all_positions[i], all_positions[j], err))
                print(f'      ({i:2d},{j:2d})  α_i={all_positions[i]:.4f}, '
                      f'α_j={all_positions[j]:.4f}, sum={s:.4f}, err={err:.5f}')
    print(f'    → {len(pair_matches)} pair(s) match pos(N) within tolerance')

    # ── Sweep all on-lane positions + all positions of pair matches ──────────
    cand_positions = set([round(p, 8) for p in on_lane_positions])
    for _, _, a, b, _ in pair_matches:
        cand_positions.add(round(a, 8))
        cand_positions.add(round(b, 8))
    cand_positions = sorted(cand_positions)

    nb = N.bit_length()
    K_LO = max(2, nb // 2 - 50)
    K_HI = nb - 1
    print(f'\n  Sweeping {len(cand_positions)} positions × k∈[{K_LO}..{K_HI}] × wiggle ±8 ...')
    hits = []
    tried = 0
    t0 = time.perf_counter()
    for alpha in cand_positions:
        for k in range(K_LO, K_HI + 1):
            c0 = cand_at(alpha, k)
            for di in range(-8, 9):
                c = c0 + di
                if c <= 1 or c >= N: continue
                tried += 1
                if N % c == 0:
                    hits.append((alpha, k, c, N // c))
                    print(f'    ✓ HIT  α={alpha:.6f}  k={k}  di={di}  '
                          f'factor={c} ({c.bit_length()} bits)')
    print(f'  {tried} candidates in {time.perf_counter()-t0:.1f}s, {len(hits)} factor(s) found')

    return dna, pos_list, on_lane_positions, pair_matches, hits, hist


def main():
    mp.mp.dps = 1100
    pos_N_mp = mp.log(N, 2) - mp.floor(mp.log(N, 2))
    pos_N = float(pos_N_mp)
    print(f'N is {N.bit_length()}-bit')
    print(f'pos(N) = {pos_N:.10f}')

    results = {}
    for DG in [12, 20, 30, 50]:
        dna, pos_list, on_lane, pair_matches, hits, hist = run_for_dg(DG, pos_N)
        results[DG] = {
            'dna': dna,
            'pos_list': pos_list,
            'on_lane': on_lane,
            'pair_matches': pair_matches,
            'hits': hits,
            'loss': hist[-1],
        }

    # ── Comparison figure ────────────────────────────────────────────────────
    fig, axes = plt.subplots(2, len(results), figsize=(5*len(results), 9),
                             gridspec_kw={'height_ratios':[1, 1.2]})
    for col, (DG, info) in enumerate(results.items()):
        ax = axes[0, col]
        mags = np.abs(info['dna'])
        ax.bar(range(len(mags)), mags, color='#2ca02c', edgecolor='black', alpha=0.85)
        ax.set_title(f'dg={DG}   loss={info["loss"]:.4f}')
        ax.set_xlabel('coeff n'); ax.set_ylabel('|a_n|')
        ax.grid(alpha=0.3)

        ax = axes[1, col]
        for re_t, im_t, qr in info['pos_list']:
            on_lane = abs(im_t - LANE_Y) < 0.04
            color = '#d62728' if on_lane else '#aaa'
            size = 90 if on_lane else 40
            ax.scatter(re_t, im_t, c=color, s=size, edgecolor='black', linewidth=0.4,
                       zorder=5 if on_lane else 3)
        ax.axhline(LANE_Y, color='cyan', linestyle='--', linewidth=0.7, alpha=0.6)
        ax.axvline(pos_N, color='red', linewidth=1.2, alpha=0.7,
                   label=f'pos(N)={pos_N:.3f}')
        ax.set_xlim(0, 1); ax.set_ylim(0, 0.5)
        ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
        ax.set_title(f'{len(info["on_lane"])} on lane, '
                     f'{len(info["pair_matches"])} pair-sum match(es)')
        ax.legend(loc='upper right', fontsize=8)
        ax.grid(alpha=0.3)

    fig.suptitle(f'F_N trained at multiple dg values on the 309-digit N\n'
                 f'Red dots = on-lane neurons (Im τ ≈ {LANE_Y})', fontsize=13)
    out = HERE / 'figures' / '53_hsln_many_neurons.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'\n  ✓ figure: {out.name}')

    # ── Summary ──────────────────────────────────────────────────────────────
    print(f'\n{"="*78}\n SUMMARY\n{"="*78}')
    print(f'  dg  | loss     | on-lane | pair-sum matches | factors found')
    print(f' -----+----------+---------+-------------------+----------------')
    for DG, info in results.items():
        print(f'  {DG:2d}  | {info["loss"]:.4f}   |    {len(info["on_lane"]):2d}    |        '
              f'{len(info["pair_matches"]):2d}         |       {len(info["hits"])}')


if __name__ == '__main__':
    main()
