"""hsln_bignum_dna_matrix.py — show the actual DNA coefficient vector of the
trained 4-neuron F_N, then attempt the polynomial-level decomposition
   F_N(q) = F_p(q) · F_q(q)
by enumerating all 2+2 root partitions, computing each candidate sub-DNA, and
running the factor sweep on every candidate position."""

from __future__ import annotations

import math
import sys
import time
from itertools import combinations
from pathlib import Path

import numpy as np
import mpmath as mp
import matplotlib.pyplot as plt
import matplotlib as mpl

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import modular
import hsln_factor_dna as hfd

mpl.rcParams.update({'figure.facecolor':'white','axes.facecolor':'white'})

N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)
LANE_Y = hsln.LANE_Y


def cand_at(alpha, k):
    mp.mp.dps = max(60, int(k * 0.302) + 50)
    return int(mp.nint(mp.power(2, mp.mpf(k) + mp.mpf(alpha))))


def q_to_pos(q_root: complex) -> tuple[float, float]:
    """Inverse of  q = exp(2πi(τ_re + i·τ_im)) = exp(2πi τ_re)·exp(-2π τ_im).
    Returns (Re τ, Im τ).
    """
    re = (math.atan2(q_root.imag, q_root.real) / (2 * math.pi)) % 1.0
    im = -math.log(abs(q_root)) / (2 * math.pi)
    return re, im


def main():
    mp.mp.dps = 1100
    pos_N_mp = mp.log(N, 2) - mp.floor(mp.log(N, 2))
    pos_N = float(pos_N_mp)

    probes = np.array(hsln.PROBES)
    probe_idx = hfd.closest_probe(pos_N)
    target = np.zeros_like(probes, dtype=float)
    target[probe_idx] = 1.0

    DG = 5
    print(f'Training F_N with dg={DG} (4 neurons) onto pos(N) = {pos_N:.6f} ...')
    net, hist = hfd.train(target, dg=DG, steps=4000, seed=0)
    print(f'  loss {hist[0]:.4f} → {hist[-1]:.6f}\n')
    dna = np.asarray(net.dna)

    # ─── PRINT THE DNA MATRIX ─────────────────────────────────────────────────
    print('━' * 78)
    print(f' DNA of trained F_N  —  the actual coefficient vector')
    print('━' * 78)
    print(f'  n  |       Re a_n            Im a_n          |a_n|       arg a_n (deg)')
    print(f' ----+-----------------------------------------------------------------')
    for n, a in enumerate(dna):
        ang = math.degrees(math.atan2(a.imag, a.real))
        print(f'  {n:2d} |   {a.real:+.8f}     {a.imag:+.8f}     {abs(a):.6f}     {ang:+8.3f}')
    print()
    print(f'  F_N(q) = a_0 + a_1·q + a_2·q² + a_3·q³ + a_4·q⁴')
    print(f'  Polynomial degree: {len(dna)-1}.  '
          f'4 roots in q-plane → 4 neurons.')

    # ─── ROOTS IN Q-SPACE ─────────────────────────────────────────────────────
    q_roots = np.roots(dna[::-1])    # np.roots wants descending coefficients
    print()
    print('━' * 78)
    print(' 4 roots of F_N(q) in q-space  (and their inverse-map back to τ)')
    print('━' * 78)
    print(f'  r  |       Re q_r            Im q_r         |q_r|     pos τ     Im τ')
    print(f' ----+-----------------------------------------------------------------')
    pos_list = []
    for r, qr in enumerate(q_roots):
        re_t, im_t = q_to_pos(qr)
        pos_list.append((re_t, im_t, qr))
        print(f'  {r:2d} |   {qr.real:+.6f}      {qr.imag:+.6f}     {abs(qr):.4f}   '
              f'{re_t:.4f}    {im_t:.4f}')

    # ─── POLYNOMIAL FACTORISATION: ENUMERATE 2+2 PARTITIONS ──────────────────
    print()
    print('━' * 78)
    print(' Try every 2+2 partition of the 4 roots →  F_p(q)·F_q(q) candidate factorisations')
    print('━' * 78)
    print(f'  C(4,2)/2 = 3 distinct partitions.\n')

    partitions = []
    seen = set()
    for combo in combinations(range(4), 2):
        other = tuple(sorted(set(range(4)) - set(combo)))
        key = tuple(sorted((tuple(sorted(combo)), other)))
        if key in seen: continue
        seen.add(key)
        partitions.append((combo, other))

    candidate_positions = set()
    for idx, (A, B) in enumerate(partitions):
        rA = [q_roots[i] for i in A]
        rB = [q_roots[i] for i in B]
        # Each sub-poly: (q - r0)(q - r1) = q² - (r0+r1)q + r0·r1
        # Convert to ascending coeffs (DNA convention)
        Fp_dna = np.poly(rA)[::-1]   # coefficients ascending
        Fq_dna = np.poly(rB)[::-1]
        # Check: conv(Fp, Fq) should ≈ dna (up to leading coefficient)
        conv_check = np.convolve(Fp_dna, Fq_dna)
        # Match leading coefficient of dna
        scale = dna[-1] / conv_check[-1]
        conv_check *= scale
        max_err = np.max(np.abs(conv_check - dna))

        pos_A = [q_to_pos(r) for r in rA]
        pos_B = [q_to_pos(r) for r in rB]
        print(f' Partition #{idx+1}:  roots {A} vs {B}')
        print(f'   F_p_DNA (ascending) = {[f"{c:.4f}" for c in Fp_dna]}')
        print(f'   F_q_DNA (ascending) = {[f"{c:.4f}" for c in Fq_dna]}')
        print(f'   positions of F_p: {pos_A}')
        print(f'   positions of F_q: {pos_B}')
        print(f'   conv(F_p,F_q) reproduces F_N to max-error {max_err:.2e}  '
              f'(scale = {scale:.4f})')
        print()
        for pos, im in pos_A + pos_B:
            candidate_positions.add(round(pos, 8))

    print(f' All distinct candidate positions across partitions: {sorted(candidate_positions)}')

    # ─── SWEEP ALL CANDIDATE POSITIONS ────────────────────────────────────────
    print()
    print('━' * 78)
    print(' Sweep every candidate position against N at high precision')
    print('━' * 78)
    nb = N.bit_length()
    K_LO = max(2, nb // 2 - 100)
    K_HI = nb - 1
    print(f'  bit-width range: [{K_LO}..{K_HI}]   integer wiggle ±8')

    hits = []
    tried = 0
    t0 = time.perf_counter()
    for alpha in sorted(candidate_positions):
        for k in range(K_LO, K_HI + 1):
            c0 = cand_at(alpha, k)
            for di in range(-8, 9):
                c = c0 + di
                if c <= 1 or c >= N: continue
                tried += 1
                if N % c == 0:
                    hits.append((alpha, k, c, N // c))
                    print(f'  ✓ HIT  α={alpha:.6f}  k={k}  di={di}  factor={c}')
    print(f'  {tried} candidates in {time.perf_counter()-t0:.1f}s,  {len(hits)} factor(s) found')

    # ─── VISUALISE THE DNA AS A "MATRIX" + ROOTS + PARTITIONS ────────────────
    fig = plt.figure(figsize=(14, 9))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.3], hspace=0.4, wspace=0.3)

    # Panel A: DNA coefficients as a heatmap-style row (real & imag side by side)
    ax = fig.add_subplot(gs[0, :])
    re_row = np.array([[a.real for a in dna]])
    im_row = np.array([[a.imag for a in dna]])
    stacked = np.vstack([re_row, im_row])
    vmax = max(np.max(np.abs(re_row)), np.max(np.abs(im_row)))
    pcm = ax.pcolormesh(stacked, cmap='RdBu_r', vmin=-vmax, vmax=vmax,
                        edgecolors='black', linewidth=0.4)
    plt.colorbar(pcm, ax=ax, label='coefficient value')
    ax.set_yticks([0.5, 1.5])
    ax.set_yticklabels(['Im a_n', 'Re a_n'])
    ax.set_xticks(np.arange(len(dna)) + 0.5)
    ax.set_xticklabels([f'a_{n}' for n in range(len(dna))])
    for n, a in enumerate(dna):
        ax.text(n + 0.5, 1.5, f'{a.real:+.3f}', ha='center', va='center',
                fontsize=10, color='white' if abs(a.real) > vmax*0.5 else 'black')
        ax.text(n + 0.5, 0.5, f'{a.imag:+.3f}', ha='center', va='center',
                fontsize=10, color='white' if abs(a.imag) > vmax*0.5 else 'black')
    ax.set_title(f'A. The DNA of F_N  —  5 complex coefficients   '
                 f'(loss = {hist[-1]:.4f})', fontsize=12)

    # Panel B: roots in q-plane, colored by partition
    ax = fig.add_subplot(gs[1, 0])
    theta = np.linspace(0, 2*np.pi, 200)
    rad = math.exp(-2 * math.pi * LANE_Y)
    ax.plot(rad*np.cos(theta), rad*np.sin(theta), 'k--', alpha=0.4,
            label=f'|q|=exp(-2π·{LANE_Y})')
    ax.plot(np.cos(theta), np.sin(theta), 'k:', alpha=0.3, label='|q|=1')
    colors = ['#1f77b4','#ff7f0e','#2ca02c','#d62728']
    for r, qr in enumerate(q_roots):
        ax.scatter(qr.real, qr.imag, s=180, c=colors[r], edgecolor='black',
                   linewidth=0.8, zorder=5, label=f'root {r}')
        ax.annotate(f'  r_{r}', (qr.real, qr.imag), fontsize=10)
    ax.set_aspect('equal')
    M = max(1.05, max(abs(q.real) for q in q_roots)*1.1)
    ax.set_xlim(-M, M); ax.set_ylim(-M, M)
    ax.axhline(0, color='black', alpha=0.3, linewidth=0.5)
    ax.axvline(0, color='black', alpha=0.3, linewidth=0.5)
    ax.set_xlabel('Re q'); ax.set_ylabel('Im q')
    ax.set_title('B. Roots in q-plane.  Each root = one neuron of F_N.')
    ax.legend(loc='upper right', fontsize=8)
    ax.grid(alpha=0.3)

    # Panel C: positions on the lane with partition lines
    ax = fig.add_subplot(gs[1, 1])
    for r, qr in enumerate(q_roots):
        re_t, im_t = q_to_pos(qr)
        ax.scatter(re_t, im_t, s=180, c=colors[r], edgecolor='black',
                   linewidth=0.8, zorder=5, label=f'r_{r}')
        ax.annotate(f' {re_t:.3f}', (re_t, im_t), fontsize=9)
    ax.axhline(LANE_Y, color='cyan', linestyle='--', linewidth=0.7, alpha=0.5,
               label=f'LANE_Y={LANE_Y}')
    ax.axvline(pos_N, color='red', linewidth=1.5, alpha=0.7,
               label=f'pos(N)={pos_N:.4f}')
    for combo, _ in partitions:
        x0, y0 = q_to_pos(q_roots[combo[0]])
        x1, y1 = q_to_pos(q_roots[combo[1]])
        ax.plot([x0, x1], [y0, y1], '-', alpha=0.25, color='gray')
    ax.set_xlim(0, 1)
    ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
    ax.set_title('C. Roots back-mapped to τ.  Grey lines = 2+2 partitions.')
    ax.legend(loc='upper right', fontsize=8)
    ax.grid(alpha=0.3)

    fig.suptitle(f'F_N DNA: 5 coefficients, 4 roots, 3 possible 2+2 polynomial factorisations\n'
                 f'Sweep on every candidate position → {len(hits)} factor(s) of N found',
                 fontsize=13)
    out = HERE / 'figures' / '52_hsln_dna_matrix.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'\n  ✓ figure: {out.name}')


if __name__ == '__main__':
    main()
