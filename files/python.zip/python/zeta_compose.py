"""Build the Riemann zeta SERIES from first principles by COMPOSING per-prime models.

Each prime p is a little model: its Euler factor  1/(1 - p^{-s}) = sum_{k>=0} p^{-ks}.
In the Dirichlet-series basis (the n^{-s} basis) its coefficients are 1 at the powers of
p  (n = 1, p, p^2, ...)  and 0 elsewhere.

MERGE them by Dirichlet multiplication (= the Euler product). Because every integer
factors UNIQUELY into prime powers, the merged coefficients become ALL ONES:

        prod_p (1/(1 - p^{-s}))  =  sum_{n>=1} 1/n^s  =  zeta(s).

This is the "golden key": Euler product = series  <=>  unique factorization. It is the
same multiply-composition we've used (tensor product of generating functions), here in
the Dirichlet world whose multiplication IS the arithmetic of the integers.

Dual to the prime sieve (fig 31): there we multiplied "drop the multiples of p" and the
PRIMES survived; here we multiply "keep the powers of p" and ALL INTEGERS are built.

Honest scope: this constructs the series for Re(s) > 1 (where the product/series converge).
It does NOT touch the zeros or RH -- those live in the analytic continuation beyond here.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

M = 48


def primes_upto(n):
    return [k for k in range(2, n + 1) if all(k % d for d in range(2, int(k ** 0.5) + 1))]


def euler_factor(p, M=M):
    """Dirichlet coefficients of 1/(1 - p^{-s}): 1 at 1, p, p^2, ... (the little model)."""
    c = np.zeros(M + 1)
    k = 1
    while k <= M:
        c[k] = 1.0
        k *= p
    return c


def dirichlet_mul(a, b, M=M):
    """(a * b)[n] = sum_{d|n} a[d] b[n/d) -- the multiplication of Dirichlet series."""
    c = np.zeros(M + 1)
    for d in range(1, M + 1):
        if a[d] == 0:
            continue
        for e in range(1, M // d + 1):
            c[d * e] += a[d] * b[e]
    return c


def compose_primes(primes, M=M):
    c = np.zeros(M + 1); c[1] = 1.0
    snaps = []
    for p in primes:
        c = dirichlet_mul(c, euler_factor(p, M), M)
        snaps.append(c.copy())
    return c, snaps


def run(make_fig=True):
    ps = primes_upto(M)
    composite, snaps = compose_primes(ps)
    coeffs = composite[1:M + 1]
    print(f"composed {len(ps)} per-prime models (primes up to {M}).")
    print(f"recovered Dirichlet coefficients a(n) for n=1..{M}: "
          f"{'all ones' if np.allclose(coeffs, 1.0) else 'NOT all ones'}  -> this is "
          f"zeta(s) = sum 1/n^s")

    # numerical golden key at s = 2: Euler product vs series vs pi^2/6
    target = np.pi ** 2 / 6
    prod_by_P = []
    val = 1.0
    for p in ps:
        val *= 1.0 / (1.0 - p ** (-2.0))
        prod_by_P.append(val)
    series_by_N = np.cumsum(1.0 / np.arange(1, M + 1) ** 2.0)
    print(f"Euler product over primes<= {M} at s=2: {prod_by_P[-1]:.6f}")
    print(f"series sum_(n<= {M}) 1/n^2:            {series_by_N[-1]:.6f}")
    print(f"zeta(2) = pi^2/6:                     {target:.6f}")

    if make_fig:
        _figure(ps, snaps, prod_by_P, series_by_N, target)
    return np.allclose(coeffs, 1.0)


def _figure(ps, snaps, prod_by_P, series_by_N, target):
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    import style  # noqa: F401

    TEAL, GOLD, NEURON, GREEN = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A"
    COLP = ["#46f0d0", "#ffd166", "#ff7b6b", "#c0a3ff"]

    fig = plt.figure(figsize=(15.5, 8.0))
    gs = fig.add_gridspec(2, 1, height_ratios=[1, 1.1], hspace=0.34)
    topo = gs[0].subgridspec(1, 2, width_ratios=[1.15, 1])
    a = fig.add_subplot(topo[0]); c = fig.add_subplot(topo[1])
    b = fig.add_subplot(gs[1])

    # --- A: the little per-prime models (Dirichlet coeff combs) --- #
    ns = np.arange(1, M + 1)
    for i, p in enumerate([2, 3, 5, 7]):
        ef = euler_factor(p)[1:]
        base = 1.4 * i
        a.vlines(ns[ef > 0], base, base + 1.0, color=COLP[i], lw=2)
        a.plot(ns[ef > 0], base + np.ones((ef > 0).sum()), "o", color=COLP[i], ms=5)
        a.text(M * 0.62, base + 0.35, f"factor of {p}: n = 1, {p}, {p}², …",
               color=COLP[i], fontsize=8.5)
    a.set_yticks([]); a.set_xlabel("n"); a.set_ylim(-0.3, 1.4 * 4)
    a.set_title("four little models: each prime's Euler factor\n"
                "(coefficients at the powers of p)", fontsize=12)

    # --- C: the golden key numerically at s=2 --- #
    c.plot(np.arange(1, len(prod_by_P) + 1), prod_by_P, "o-", color=GOLD, lw=2, ms=5,
           label="Euler product (vs #primes)")
    c.plot(np.arange(1, M + 1), series_by_N, color=TEAL, lw=1.8,
           label="series Σ 1/n² (vs #terms)")
    c.axhline(target, color=NEURON, ls="--", lw=1.2, label=r"$\zeta(2)=\pi^2/6$")
    c.set_xlabel("number of primes (gold) / terms (teal) included")
    c.set_ylabel(r"value at $s=2$")
    c.set_title("the golden key, numerically:\nboth → ζ(2)", fontsize=12)
    c.legend(loc="lower right", fontsize=8.5, framealpha=0.3)

    # --- B: composition fills in the integers (the series emerges) --- #
    grid = np.array(snaps)[:, 1:M + 1]              # rows: after adding each prime; cols: n
    grid = (grid > 0).astype(float)
    b.imshow(grid, origin="lower", aspect="auto", cmap=ListedColormap(["#11111a", GREEN]),
             extent=[0.5, M + 0.5, -0.5, len(ps) - 0.5], interpolation="nearest")
    b.set_yticks(range(len(ps)))
    b.set_yticklabels([f"≤{p}" for p in ps], fontsize=7)
    b.set_xlabel("integer n  (coefficient filled = built from the primes so far)")
    b.set_ylabel("primes included up to")
    b.set_title("merging the models builds every integer exactly once (unique factorization): "
                "the all-ones row at the top IS the ζ series", fontsize=12)

    fig.suptitle("Building ζ(s) = Σ 1/nˢ from first principles by composing per-prime Euler "
                 "factors (the golden key = our multiply-composition)", fontsize=13, y=0.99)
    out = Path(__file__).parent / "figures" / "32_zeta_compose.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
