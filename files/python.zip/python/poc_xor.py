"""Temporal XOR on the HSLN (genus 1, CPU), via the spike mechanism.

Two pulse-encoded channels move the state to a position; the network spikes when
1/|F| diverges, i.e. when that position is a ZERO of the field. XOR is solved by the
gravity field learning to place a zero exactly at the single-pulse position, with no
zero at the none/both positions. Counts {0,2} -> no spike, {1} -> spike: a genuine
nonlinear fold performed by the field.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np
from jax import grad, value_and_grad

jax.config.update("jax_enable_x64", True)

DG = 5
DRIVE_GAIN = 0.40                 # = (pulse duration) * dt, the per-channel displacement
B1 = jnp.array([0.50, 0.00])
B2 = jnp.array([0.46, 0.05])      # nearly same direction, slightly distinct channel
START = jnp.array([0.30, 0.22])
SIGMA_F = 0.14                    # spike sharpness in |F|
PATTERNS = [(0, 0), (1, 0), (0, 1), (1, 1)]
TARGET = jnp.array([0.0, 1.0, 1.0, 0.0])  # XOR


def gcoeffs(p):
    return p[:DG] + 1j * p[DG:]


def Fmag2(p, xy):
    q = jnp.exp(2j * jnp.pi * (xy[0] + 1j * xy[1]))
    f = jnp.sum(gcoeffs(p) * q ** jnp.arange(DG))
    return jnp.real(f * jnp.conj(f))


def lane(u1, u2):
    """Pulse-encoded landing position (drive only): input -> a point in the strip."""
    dx = (u1 * B1[0] + u2 * B2[0]) * DRIVE_GAIN
    dy = (u1 * B1[1] + u2 * B2[1]) * DRIVE_GAIN
    return jnp.array([START[0] + dx, START[1] + dy])


def spike(p, u1, u2):
    return jnp.exp(-Fmag2(p, lane(u1, u2)) / (2 * SIGMA_F ** 2))  # 1 near a zero, else ~0


def loss(p):
    L = 0.0
    for (u1, u2), tgt in zip(PATTERNS, TARGET):
        L = L + (spike(p, float(u1), float(u2)) - tgt) ** 2
    return L + 1e-4 * jnp.sum(p ** 2)


_loss_and_grad = jax.jit(value_and_grad(loss))


def init_params(seed=0):
    rng = np.random.default_rng(seed)
    # seed a zero at the single-pulse lane, others parked harmlessly higher up
    single = np.array([lane(1.0, 0.0)[0], lane(1.0, 0.0)[1]])
    zeros = np.array([single[0] + 1j * single[1], 0.5 + 0.6j, 0.5 + 0.85j])
    c = np.poly(np.exp(2j * np.pi * zeros))[::-1]
    c = c / np.max(np.abs(c))
    c = np.concatenate([c, np.zeros(DG - len(c), dtype=complex)])
    return jnp.array(np.concatenate([c.real, c.imag]) + 0.04 * rng.standard_normal(2 * DG))


def train(steps=1200, lr=0.01, seed=0):
    p = init_params(seed); p0 = p
    m = jnp.zeros_like(p); v = jnp.zeros_like(p)
    b1, b2, eps = 0.9, 0.999, 1e-8
    hist = []
    for t in range(1, steps + 1):
        L, g = _loss_and_grad(p)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        p = p - lr * (m / (1 - b1 ** t)) / (jnp.sqrt(v / (1 - b2 ** t)) + eps)
        hist.append(float(L))
    return p0, p, hist


def scores(p):
    return np.array([float(spike(p, float(a), float(b))) for a, b in PATTERNS])


def visualize(steps=1200, lr=0.01, seed=0):
    import matplotlib.pyplot as plt
    from pathlib import Path
    import style

    p0, p, hist = train(steps=steps, lr=lr, seed=seed)
    s0, s1 = scores(p0), scores(p)
    labels = [f"({a},{b})" for a, b in PATTERNS]
    cols = ["#6a6a7c", "#46f0d0", "#46f0d0", "#ff3b6b"]

    fig, ax = plt.subplots(1, 3, figsize=(16, 4.6), gridspec_kw={"width_ratios": [1.1, 1.2, 1]})

    x = np.arange(4)
    ax[0].bar(x - 0.18, s0, 0.34, color="#444", label="before")
    ax[0].bar(x + 0.18, s1, 0.34, color=cols, label="after")
    ax[0].plot(x, np.array(TARGET), "k*", ms=15, mec="white", label="target (XOR)")
    ax[0].set_xticks(x); ax[0].set_xticklabels(labels)
    ax[0].set_ylabel("spike score  1/|F|→"); ax[0].set_ylim(0, 1.1)
    ax[0].set_title("learned XOR truth table", fontsize=12)
    ax[0].legend(fontsize=8, framealpha=0.3)

    # spike landscape along the lane line (input -> x position)
    yL = float(lane(1.0, 0.0)[1])
    xs = np.linspace(0.05, 0.95, 400)
    Sline = np.array([float(jnp.exp(-Fmag2(p, jnp.array([xx, yL])) / (2 * SIGMA_F ** 2)))
                      for xx in xs])
    ax[1].plot(xs, Sline, color="#46f0d0", lw=2)
    for (a, b), c in zip(PATTERNS, cols):
        lx = float(lane(float(a), float(b))[0])
        ax[1].axvline(lx, color=c, ls="--", lw=1.2)
        ax[1].text(lx, 1.04, f"({a},{b})", color=c, ha="center", fontsize=8)
    ax[1].set_xlabel(r"Re $\tau$  (input position)"); ax[1].set_ylabel("spike score")
    ax[1].set_ylim(0, 1.12)
    ax[1].set_title("the field carved a spike at the single-pulse lane", fontsize=12)

    ax[2].plot(hist, color=style.ACCENT, lw=1.6)
    ax[2].set_yscale("log"); ax[2].set_xlabel("Adam step"); ax[2].set_ylabel("loss (log)")
    ax[2].set_title("training the gravity DNA", fontsize=12); ax[2].grid(alpha=0.2)

    fig.suptitle("Temporal XOR: the gravity field learns a zero at the single-pulse position "
                 "(spike) and none at the {0,2} positions", fontsize=13, y=1.02)
    out = Path(__file__).parent / "figures" / "16_poc_xor.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"loss {hist[0]:.4f} -> {hist[-1]:.5f}")
    for lab, a, b in zip(labels, s1, np.array(TARGET)):
        print(f"  {lab}: {a:.3f}  (target {b:.0f})")
    print(f"wrote {out}")


if __name__ == "__main__":
    visualize()
