"""The factorization landscape, big: largest prime factor (and # distinct prime factors)
of every integer up to N, sieved fast.

This is the geology under the prime sieve (fig 31), the Euler product (fig 32) and the
factoriser (fig 33): which integers are "smooth" (small largest prime factor -> easy to
crack) versus which carry a large prime factor (the factoring wall). A linear sieve gives
lpf(n) and omega(n) for all n <= N in one pass.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np


def sieve(N):
    isp = np.ones(N + 1, dtype=bool)
    isp[:2] = False
    for p in range(2, int(N ** 0.5) + 1):
        if isp[p]:
            isp[p * p::p] = False
    primes = np.nonzero(isp)[0]
    lpf = np.zeros(N + 1, dtype=np.int64)
    omega = np.zeros(N + 1, dtype=np.int16)
    for p in primes:                 # p increasing => largest prime factor wins
        lpf[p::p] = p
        omega[p::p] += 1
    return lpf, omega


def run(N=1_000_000, make_fig=True):
    t0 = time.perf_counter()
    lpf, omega = sieve(N)
    print(f"sieved largest-prime-factor + omega for n <= {N:,} in "
          f"{time.perf_counter() - t0:.2f}s")
    n = np.arange(2, N + 1)
    lp = lpf[2:]
    nprimes = int((lp == n).sum())
    print(f"  primes <= {N:,}: {nprimes:,}  ({100*nprimes/len(n):.2f}% of integers)")
    smooth100 = int((lp <= 100).sum())
    print(f"  100-smooth (fully factorable by primes<=100): {100*smooth100/len(n):.2f}%")

    if make_fig:
        _figure(N, n, lp, omega[2:])
    return lpf, omega


def _figure(N, n, lp, om):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    fig, ax = plt.subplots(1, 3, figsize=(17.0, 5.4))

    # A: the (n, largest prime factor) geology -- prime diagonal + hyperbola comb
    a = ax[0]
    h = a.hist2d(np.log10(n), np.log10(lp), bins=320, cmap="magma",
                 norm="log", cmin=1)
    a.plot([0, np.log10(N)], [0, np.log10(N)], color="#46f0d0", lw=0.8, ls="--", alpha=0.7)
    a.text(np.log10(N) - 1.7, np.log10(N) - 0.45, "primes (lpf = n)", color="#46f0d0",
           fontsize=8, rotation=33)
    a.set_xlabel(r"$\log_{10} n$"); a.set_ylabel(r"$\log_{10}$ (largest prime factor)")
    a.set_title(f"factorization geology to {N:,}\nprime diagonal + n/k hyperbola comb",
                fontsize=12)

    # B: smoothness exponent alpha = log(lpf)/log(n)
    b = ax[1]
    alpha = np.log(lp) / np.log(n)
    b.hist(alpha, bins=200, color="#ffd166", density=True)
    b.axvline(1.0, color="#ff3b6b", lw=1.2)
    b.text(0.86, b.get_ylim()[1] * 0.6, "α=1: primes", color="#ff3b6b", fontsize=8,
           rotation=90)
    b.set_xlabel(r"smoothness exponent  $\alpha=\log(\mathrm{lpf})/\log n$")
    b.set_ylabel("density")
    b.set_title("how 'smooth' integers are\n(Dickman-type structure; spike at primes)",
                fontsize=12)

    # C: Erdős–Kac -- the number of distinct prime factors is bell-shaped (asympt. Gaussian)
    c = ax[2]
    kmax = int(om.max())
    ks = np.arange(1, kmax + 1)
    probs = np.array([(om == k).mean() for k in ks])
    mu, sd = om.mean(), om.std()
    c.bar(ks, probs, width=0.8, color="#46f0d0", label="P(ω(n)=k)")
    xx = np.linspace(0.5, kmax + 0.5, 300)
    c.plot(xx, np.exp(-(xx - mu) ** 2 / (2 * sd ** 2)) / (sd * np.sqrt(2 * np.pi)),
           color="#ff3b6b", lw=2.4, label=f"Gaussian (μ={mu:.2f}, σ={sd:.2f})")
    c.set_xlabel("ω(n) = number of distinct prime factors")
    c.set_ylabel("probability")
    c.set_title("Erdős–Kac: ω(n) is bell-shaped\n(asymptotically Gaussian)", fontsize=12)
    c.legend(loc="upper right", fontsize=8.5, framealpha=0.3)

    fig.suptitle(f"The factorization landscape to {N:,}: smooth integers (low) vs large-prime "
                 "carriers (the factoring wall)", fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "36_landscape.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
    run(N)
