"""Scaling benchmark: can we eat these computations for breakfast?

Measured CPU timings (this machine, no GPU) for the operations that matter:
  A. batched forward-pass throughput vs batch size  -- the GPU-relevant axis
  B. forward-pass cost vs DNA length (weight = neuron count)
  C. tensor-composition cost vs number of models composed
  D. genus-1 vs genus-2 evaluation -- the one genuinely heavy axis

Takeaways are printed. The forward pass is a batched, vectorised map (jax.vmap), which
is exactly what a GPU parallelises -- so the batch-throughput curve is a lower bound on
what a GPU would do. Composition is a convolution: trivially cheap. The real cost driver
is GENUS (the Siegel theta sum), not batch size, weight, or composition count.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp
from jax import grad, lax, vmap, jit

import siegel

jax.config.update("jax_enable_x64", True)


def _energy(dna, xy):
    q = jnp.exp(2j * jnp.pi * (xy[0] + 1j * xy[1]))
    f = jnp.sum(dna * q ** jnp.arange(dna.shape[0]))
    return jnp.real(f * jnp.conj(f))


_g = grad(_energy, argnums=1)


def _rollout(dna, x0, T=120, dt=0.02):
    def step(xy, _):
        g = _g(dna, xy)
        gn = g / (jnp.sqrt(g[0] ** 2 + g[1] ** 2) + 1e-4)
        n = jnp.clip(xy - dt * gn, 0.02, 0.98)
        return n, None
    xy, _ = lax.scan(step, x0, jnp.arange(T))
    return xy


def _timeit(fn, reps=3):
    fn()  # warm / compile
    t0 = time.perf_counter()
    for _ in range(reps):
        r = fn()
        if hasattr(r, "block_until_ready"):
            r.block_until_ready()
    return (time.perf_counter() - t0) / reps


def bench_batch(dna, Ns=(1, 16, 128, 1024, 4096)):
    rng = np.random.default_rng(0)
    f = jit(vmap(lambda x0: _rollout(dna, x0)))
    out = []
    for N in Ns:
        starts = jnp.asarray(rng.uniform([0.1, 0.2], [0.9, 0.8], size=(N, 2)))
        dt = _timeit(lambda: f(starts))
        out.append((N, dt, N / dt))
        print(f"  batch {N:5d}: {dt*1e3:8.2f} ms   -> {N/dt:10.0f} inputs/sec")
    return out


def bench_dna_len(Ls=(4, 16, 64, 256, 1024)):
    rng = np.random.default_rng(1)
    starts = jnp.asarray(rng.uniform([0.1, 0.2], [0.9, 0.8], size=(256, 2)))
    out = []
    for L in Ls:
        dna = jnp.asarray((rng.standard_normal(L) + 1j * rng.standard_normal(L)) / L)
        f = jit(vmap(lambda x0: _rollout(dna, x0)))
        dt = _timeit(lambda: f(starts))
        out.append((L, dt))
        print(f"  DNA length {L:5d} (~{L} neurons): {dt*1e3:8.2f} ms / 256 inputs")
    return out


def bench_compose(Ks=(2, 4, 8, 16, 32, 64)):
    rng = np.random.default_rng(2)
    out = []
    for K in Ks:
        dnas = [rng.standard_normal(3) + 1j * rng.standard_normal(3) for _ in range(K)]
        t0 = time.perf_counter()
        comp = dnas[0]
        for d in dnas[1:]:
            comp = np.convolve(comp, d)
        dt = (time.perf_counter() - t0)
        out.append((K, dt, len(comp)))
        print(f"  compose {K:3d} models: {dt*1e6:8.1f} us   (compound length {len(comp)})")
    return out


def bench_genus():
    """Genus-1 theta (E4 q-series) vs genus-2 theta (Siegel, sum over 2x2 forms)."""
    # genus-1: evaluate E4-style series over a batch
    n = jnp.arange(1, 200)
    def g1():
        q = jnp.exp(2j * jnp.pi * (0.3 + 0.7j))
        return jnp.sum(q ** n)
    t1 = _timeit(lambda: g1(), reps=50)
    # genus-2: representation numbers (Fourier data of the E8 genus-2 theta) up to a bound
    res = {}
    for maxn in (4, 6, 8):
        t0 = time.perf_counter()
        d = siegel.representation_numbers(maxn)
        dt = time.perf_counter() - t0
        res[maxn] = (dt, len(d))
        print(f"  genus-2 representation_numbers(maxn={maxn}): {dt*1e3:8.1f} ms "
              f"({len(d)} Fourier coeffs)")
    print(f"  genus-1 series eval: {t1*1e6:.2f} us")
    return t1, res


def run(make_fig=True):
    rng = np.random.default_rng(3)
    dna = jnp.asarray((rng.standard_normal(8) + 1j * rng.standard_normal(8)) / 8)
    print("A. batched forward-pass throughput (genus-1 flow, T=120):")
    batch = bench_batch(dna)
    print("B. forward-pass cost vs DNA length (= neuron count):")
    dnalen = bench_dna_len()
    print("C. tensor-composition cost vs #models:")
    comp = bench_compose()
    print("D. genus-1 vs genus-2 evaluation:")
    g1t, g2 = bench_genus()

    peak = max(r[2] for r in batch)
    print(f"\nPeak CPU throughput: {peak:,.0f} forward passes/sec; composition is ~microseconds;")
    print("the only steep axis is genus (Siegel theta). Batch & composition are GPU-trivial.")

    if make_fig:
        _figure(batch, dnalen, comp, g1t, g2)
    return batch


def _figure(batch, dnalen, comp, g1t, g2):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, NEURON, GREEN = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A"

    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))

    # --- A: batch throughput --- #
    a = ax[0]
    Ns = [r[0] for r in batch]; tput = [r[2] for r in batch]
    a.loglog(Ns, tput, "o-", color=TEAL, lw=2, ms=7)
    a.set_xlabel("batch size (parallel inputs)")
    a.set_ylabel("throughput (forward passes / sec)")
    a.set_title("batched forward pass scales\n(vmap → GPU-parallel)", fontsize=12)
    a.grid(True, which="both", alpha=0.15)

    # --- B: DNA length + composition --- #
    b = ax[1]
    Ls = [r[0] for r in dnalen]; ts = [r[1] * 1e3 for r in dnalen]
    b.loglog(Ls, ts, "o-", color=GOLD, lw=2, ms=7, label="forward pass / 256 inputs")
    Ks = [r[0] for r in comp]; cts = [r[1] * 1e3 for r in comp]
    b.loglog(Ks, cts, "s--", color=GREEN, lw=2, ms=6, label="compose K models (convolve)")
    b.set_xlabel("DNA length (neurons)  /  #models composed")
    b.set_ylabel("time (ms)")
    b.set_title("linear in weight; composition\nis ~microseconds", fontsize=12)
    b.legend(loc="upper left", fontsize=8.5, framealpha=0.3)
    b.grid(True, which="both", alpha=0.15)

    # --- C: genus cost (the heavy axis) --- #
    c = ax[2]
    labels = ["genus-1\nseries"] + [f"genus-2\nmaxn={m}" for m in g2]
    vals = [g1t * 1e3] + [g2[m][0] * 1e3 for m in g2]
    cols = [TEAL] + [NEURON] * len(g2)
    c.bar(range(len(vals)), vals, color=cols)
    c.set_yscale("log")
    c.set_xticks(range(len(vals))); c.set_xticklabels(labels, fontsize=9)
    c.set_ylabel("eval time (ms, log)")
    c.set_title("genus is the only steep axis\n(Siegel theta sum)", fontsize=12)

    fig.suptitle("Scaling (CPU, no GPU): batched forward passes and composition are cheap and "
                 "parallel — genus is the cost driver", fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "28_scaling.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
