"""
Cofactor auditor: shove in any numbers, get a factoring verdict + DNA readout.

Built for auditing candidate moduli for a speculative crypto architecture. For each
input N it runs, side by side:

  * cheap peel of small prime factors (trial division to SCAN_BOUND),
  * the REAL factoring battery from hsln_cofactor_safety on the hard cofactor
    (trial division, Pollard rho/Brent x2, Pollard p-1, DNA->circulant spectral),
  * the trained-DNA coefficient vector a_k(N) = (1/k)|Σ_{j<k} e^{2πi jN/k}|,
    which = 1 exactly when k | N — so the DNA's spikes ARE the detectable divisors.

If ANY method returns a nontrivial divisor it is printed loudly (a security event for
a real modulus). Otherwise the number is reported safe within the tested envelope.

Output:
  * a printed per-number list (the audit table),
  * a figure with one row per number: raw DNA magnitude + spikes, and a verdict block.

Usage:
  .venv/bin/python hsln_cofactor_dna.py 8051 0xDEADBEEF <bignum> ...
  .venv/bin/python hsln_cofactor_dna.py            # demo: 8051 + the genesis cofactor
  .venv/bin/python hsln_cofactor_dna.py 8051 --window 500000 --secs 25

Numbers may be decimal or 0x-hex. Flags:
  --window N   reachable DNA / spectral window               (default 200000)
  --secs   S   per-method time budget for the battery, secs  (default 12)
"""
from __future__ import annotations

import argparse
import time
import numpy as np
import matplotlib.pyplot as plt

from hsln_bitcoin_probe import KEYS, pubkey_x, peel_small_factors, SCAN_BOUND
from hsln_cofactor_safety import (
    trial_division, pollard_brent, pollard_pm1, spectral_circulant,
)
from hsln_e8_torsion_factor import (
    is_prime, FG, ACCENT, ACCENT2, COMP, GRID, save_fig,
)

VIEW_CAP = 10000           # how far to draw the (expensive) magnitude curve


# --------------------------------------------------------------------------
# the DNA readout
# --------------------------------------------------------------------------
def dna_coeffs(N: int, kmax: int) -> np.ndarray:
    """Detector-response magnitude a_k for k = 2..kmax. a_k ∈ [0,1], =1 iff k|N.
    Phases reduced mod k (numpy can't hold a 249-bit phase)."""
    out = np.empty(kmax - 1)
    for k in range(2, kmax + 1):
        nmod = int(N % k)
        r = (np.arange(k) * nmod) % k
        out[k - 2] = np.abs(np.exp(2j * np.pi * r / k).sum()) / k
    return out


def dna_spikes(N: int, window: int) -> list[int]:
    """Nontrivial in-window divisors of N (the exact a_k=1 shortcut, O(window))."""
    return [k for k in range(2, window + 1) if N % k == 0 and 1 < k < N]


# --------------------------------------------------------------------------
# the factoring battery (the methods live in hsln_cofactor_safety)
# --------------------------------------------------------------------------
def battery(n: int, window: int, secs: float) -> list[tuple[str, float, int | None]]:
    """Run every tractable attack on n; return (name, seconds, factor-or-None) each."""
    attempts = [
        # ("trial division < 10^7", lambda: trial_division(n, 10_000_000, secs)),
        # ("Pollard rho (Brent) s2", lambda: pollard_brent(n, secs, seed=2)),
        # ("Pollard rho (Brent) s3", lambda: pollard_brent(n, secs, seed=3)),
        # ("Pollard p-1, B1=2*10^6", lambda: pollard_pm1(n, 2_000_000, secs)),
        (f"DNA->circulant spectral w={window:,}",
         lambda: spectral_circulant(n, window)),
    ]
    out = []
    for name, fn in attempts:
        t0 = time.perf_counter()
        r = fn()
        dt = time.perf_counter() - t0
        ok = r is not None and 1 < r < n and n % r == 0
        out.append((name, dt, r if ok else None))
    return out


# --------------------------------------------------------------------------
# audit one number end to end
# --------------------------------------------------------------------------
def audit(label: str, N: int, window: int, secs: float) -> dict:
    facs, cof = peel_small_factors(N, SCAN_BOUND)
    spikes = dna_spikes(N, window)

    # the battery only earns its keep on a hard remaining cofactor
    bat: list = []
    bat_factor = None
    if cof > 1 and cof > SCAN_BOUND:
        bat = battery(cof, window, secs)
        for _, _, r in bat:
            if r is not None:
                bat_factor = r
                break

    # verdict
    if bat_factor is not None:
        verdict, vcolor = f"FACTOR FOUND in cofactor: {bat_factor}", "#ff6b6b"
    elif cof == 1:
        kind = "prime" if (len(facs) == 1) else "composite"
        verdict, vcolor = f"fully factored by peeling ({kind})", ACCENT2
    elif cof > 1:
        verdict, vcolor = "no factor found by any method — SAFE in envelope", ACCENT2
    else:
        verdict, vcolor = "—", FG

    return dict(label=label, N=N, facs=facs, cof=cof, spikes=spikes,
                battery=bat, bat_factor=bat_factor, verdict=verdict, vcolor=vcolor)


# --------------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------------
def print_list(rows: list[dict], window: int, secs: float) -> None:
    print("=" * 74)
    print(f" COFACTOR AUDIT — {len(rows)} number(s), window {window:,}, "
          f"{secs:g}s/method")
    print("=" * 74)
    for i, r in enumerate(rows, 1):
        nbits, ndig = r["N"].bit_length(), len(str(r["N"]))
        cbits = r["cof"].bit_length()
        print(f"\n[{i}] {r['label']}")
        print(f"    N = {nbits}-bit ({ndig} digits)")
        print(f"    peeled small primes (≤{SCAN_BOUND:.0e}): "
              f"{sorted(set(r['facs'])) if r['facs'] else 'none'}")
        if r["cof"] > 1:
            print(f"    hard cofactor = {cbits}-bit")
        if r["battery"]:
            for name, dt, fac in r["battery"]:
                tag = f"FACTOR {fac}" if fac is not None else "no factor"
                print(f"      {name:30s} {dt:7.2f}s  -> {tag}")
        sp = r["spikes"]
        print(f"    DNA over k≤{window:,}: {len(sp)} in-window divisor(s)"
              f"{' ' + str(sp) if sp else ' (barren)'}")
        print(f"    VERDICT: {r['verdict']}")
    print("\n" + "=" * 74)


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def figure(rows: list[dict], window: int, out: str) -> None:
    n = len(rows)
    view = min(window, VIEW_CAP)
    fig = plt.figure(figsize=(14, 3.5 * n + 1.0))
    fig.suptitle("Cofactor audit — trained DNA (raw) + factoring verdict per number",
                 color=FG, fontsize=15, y=0.99)

    for i, r in enumerate(rows):
        N = r["N"]
        # ---- left: raw DNA magnitude curve, spikes marked ----
        ax = fig.add_subplot(n, 2, 2 * i + 1)
        ks = np.arange(2, view + 1)
        mag = dna_coeffs(N, view)
        ax.plot(ks, mag, color=ACCENT2, lw=0.7, alpha=0.85)
        in_view = [k for k in r["spikes"] if k <= view]
        for k in in_view:
            ax.vlines(k, 0, 1, color=ACCENT, lw=2.2)
            if len(in_view) <= 12:
                ax.annotate(str(k), (k, 1.03), color=ACCENT, fontsize=8, ha="center")
        if not in_view:
            ax.text(0.5, 0.62, "no spike in view\n(no divisor ≤ %d)" % view,
                    transform=ax.transAxes, color=ACCENT2, fontsize=10, ha="center")
        ax.set_ylim(0, 1.2)
        ax.set_xlabel(f"coefficient index k (to {view:,})", color=FG)
        ax.set_ylabel("DNA a_k", color=FG)
        ax.set_title(f"{r['label']} — raw DNA", color=FG, fontsize=11)
        _grid(ax)

        # ---- right: verdict block ----
        ax = fig.add_subplot(n, 2, 2 * i + 2)
        ax.axis("off")
        nbits = N.bit_length()
        extra = len(r["spikes"]) - len(in_view)
        lines = [
            (f"N = {nbits}-bit ({len(str(N))} digits)", FG, 11),
            (f"peeled: {sorted(set(r['facs'])) if r['facs'] else 'none'}", FG, 10),
        ]
        if r["cof"] > 1:
            lines.append((f"hard cofactor = {r['cof'].bit_length()}-bit", FG, 10))
        for name, dt, fac in r["battery"]:
            tag = f"-> {fac}" if fac is not None else "no factor"
            col = "#ff6b6b" if fac is not None else FG
            lines.append((f"  {name}: {tag} ({dt:.1f}s)", col, 9))
        sp = len(r["spikes"])
        lines.append((f"DNA divisors ≤{window:,}: {sp}"
                      + (f" (+{extra} past view)" if extra else ""), FG, 10))
        lines.append(("", FG, 4))
        lines.append((r["verdict"], r["vcolor"], 12))
        yy = 0.97
        for t, c, sz in lines:
            ax.text(0.0, yy, t, color=c, fontsize=sz, va="top", transform=ax.transAxes)
            yy -= 0.105 if t else 0.05

    fig.subplots_adjust(left=0.07, right=0.97, top=0.93 - 0.01 * (n > 1),
                        bottom=0.06, hspace=0.5, wspace=0.18)
    save_fig(fig, out)


# --------------------------------------------------------------------------
def parse_args():
    ap = argparse.ArgumentParser(description="Audit numbers: factor + DNA readout.")
    ap.add_argument("numbers", nargs="*",
                    help="integers to audit (decimal or 0x-hex)")
    # ap.add_argument("base64", nargs="*")
    ap.add_argument("--window", type=int, default=200_000,
                    help="reachable DNA/spectral window (default 200000)")
    ap.add_argument("--secs", type=float, default=12.0,
                    help="per-method battery time budget in seconds (default 12)")
    ap.add_argument("--out", default="62_hsln_cofactor_dna.png",
                    help="output figure filename (under figures/)")
    return ap.parse_args()


def main():
    args = parse_args()
    if args.numbers:
        targets = [(s, int(s, 0)) for s in args.numbers]
    else:
        x = pubkey_x(KEYS["genesis (block 0, Satoshi, unspent)"])
        _, cof = peel_small_factors(x, SCAN_BOUND)
        targets = [("8051 = 83×97 (demo)", 8051),
                   ("genesis cofactor", cof)]

    rows = [audit(label, N, args.window, args.secs) for label, N in targets]
    print_list(rows, args.window, args.secs)
    figure(rows, args.window, args.out)


if __name__ == "__main__":
    main()
