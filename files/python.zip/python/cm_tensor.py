"""Train one model per class, completely separately, then COMPOSE by tensor product
and classify in one shot.

Each class c gets its own minimal gravity DNA F_c with a single neuron (zero) fit to
where class-c inputs land in state space -- trained alone, seeing only its own class.
The compound is the tensor product (multiply the forms = CONVOLVE the DNAs):

        F = F_0 * F_1 * F_2 * F_3,     dna = conv(dna_0, dna_1, dna_2, dna_3).

By the composition theorem the zeros UNION exactly, so the compound has all four
class-neurons in one shared state space. We verify that numerically, then classify the
held-out test set by NEAREST NEURON (detection readout -- no flow, so the tensor-product
cross-talk that breaks routing never enters). The whole 4-class model is assembled from
four independently-trained pieces by one convolution.

(Only two CM j-values are cleanly reachable, so the four data-driven neurons are NOT all
integer-j; we read nearest-neuron here. The 2-bit direct-sum code in cm_classifier.py is
what buys the clean CM-integer readout. We still report j at each neuron.)
"""
from __future__ import annotations

from functools import reduce
from pathlib import Path

import numpy as np

import modular
from cm_classifier import make_data

CNAME = ["AA", "AD", "DA", "DD"]
CCOL = ["#46f0d0", "#ffd166", "#c0a3ff", "#ff7b6b"]


def encode(X):
    """Fixed input->state map: input box -> a region of the strip."""
    X = np.atleast_2d(X)
    re = 0.5 + 0.16 * X[:, 0]
    im = 0.55 + 0.16 * X[:, 1]
    return re + 1j * im


def train_class(taus):
    """Train a single-neuron DNA for one class, alone: the least-squares monic form
    q - a with |F| smallest on this class is a = mean(q_i). Returns (dna, neuron_tau)."""
    q = np.exp(2j * np.pi * taus)
    a = q.mean()
    dna = np.array([-a, 1.0], dtype=complex)          # F(q) = q - a  (low->high)
    tau = (np.angle(a) % (2 * np.pi)) / (2 * np.pi) + 1j * (-np.log(abs(a)) / (2 * np.pi))
    return dna, tau


def run(make_fig=True):
    X, _B1, _B2, C = make_data()
    rng = np.random.default_rng(0)
    idx = rng.permutation(len(X))
    tr, te = idx[:160], idx[160:]
    Tau = encode(X)

    # --- train each class model COMPLETELY SEPARATELY --- #
    dnas, neurons = [], []
    for c in range(4):
        mask = tr[C[tr] == c]
        dna, tau = train_class(Tau[mask])
        dnas.append(dna); neurons.append(tau)
        print(f"class {c} ({CNAME[c]}): neuron tau={tau:.3f}  "
              f"j={complex(modular.jinv(np.array([tau]))[0]).real:8.1f}")
    neurons = np.array(neurons)

    # --- compose by TENSOR PRODUCT = convolve the DNAs --- #
    compound = reduce(np.convolve, dnas)
    print(f"\ncompound DNA degree {len(compound)-1} (4 forms multiplied)")

    # verify: zeros of the compound = exact union of the parents' neurons
    czeros = modular.qpoly_zeros(compound)
    czeros = czeros[(czeros.imag > 0.05) & (czeros.imag < 1.5)]
    err = max(min(abs(z - n) for z in czeros) for n in neurons)
    print(f"compound zeros recovered: {np.round(np.sort_complex(czeros),3)}")
    print(f"max |compound-zero - parent-neuron| = {err:.2e}  (zero-set union is exact)")

    # --- classify held-out test set by NEAREST NEURON --- #
    def classify(taus):
        d = np.abs(taus[:, None] - neurons[None, :])
        return d.argmin(axis=1)

    pred_tr = classify(Tau[tr]); pred_te = classify(Tau[te])
    tr_acc = (pred_tr == C[tr]).mean()
    te_acc = (pred_te == C[te]).mean()
    print(f"\ntrain acc {tr_acc:.3f}   TEST acc {te_acc:.3f}  (4-class, held-out, "
          f"composed model, first run)")

    if make_fig:
        _figure(X, C, tr, te, neurons, czeros, te_acc, dnas, compound)
    return te_acc


def _figure(X, C, tr, te, neurons, czeros, te_acc, dnas, compound):
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    import style  # noqa: F401

    fig, ax = plt.subplots(1, 2, figsize=(14.0, 6.0))

    # --- A: decision regions of the COMPOSED model --- #
    a = ax[0]
    g = 60
    gx = np.linspace(-1.3, 1.3, g)
    grid = np.array([[xi, yi] for yi in gx for xi in gx])
    gt = encode(grid)
    gcls = np.abs(gt[:, None] - neurons[None, :]).argmin(axis=1).reshape(g, g)
    a.imshow(gcls, origin="lower", extent=[-1.3, 1.3, -1.3, 1.3], alpha=0.30,
             cmap=ListedColormap(CCOL), vmin=0, vmax=3, aspect="auto")
    for cls in range(4):
        m = tr[C[tr] == cls]; mt = te[C[te] == cls]
        a.scatter(X[m, 0], X[m, 1], s=16, color=CCOL[cls], edgecolor="white", lw=0.3, zorder=3)
        a.scatter(X[mt, 0], X[mt, 1], s=42, marker="^", color=CCOL[cls],
                  edgecolor="black", lw=0.5, zorder=4)
    a.set_xlim(-1.3, 1.3); a.set_ylim(-1.3, 1.3)
    a.set_xlabel("input $x_1$"); a.set_ylabel("input $x_2$")
    a.set_title(f"the composed model on held-out data  (test acc {te_acc*100:.0f}%)\n"
                "● train   ▲ test", fontsize=12)

    # --- B: tensor composition -> zeros union (verification) --- #
    b = ax[1]
    b.set_facecolor("#0b0b14")
    for c in range(4):
        b.plot(neurons[c].real, neurons[c].imag, "o", color=CCOL[c], ms=15, mfc="none",
               mew=2.5, zorder=4, label=f"{CNAME[c]} parent zero" if c == 0 else None)
        b.annotate(CNAME[c], (neurons[c].real, neurons[c].imag),
                   textcoords="offset points", xytext=(10, 6), color=CCOL[c], fontsize=10)
    b.plot(czeros.real, czeros.imag, "x", color="white", ms=9, mew=2.0, zorder=5,
           label="compound zeros")
    b.set_xlabel(r"$\mathrm{Re}\,\tau$"); b.set_ylabel(r"$\mathrm{Im}\,\tau$")
    b.set_title(r"$F=F_0 F_1 F_2 F_3$:  neurons = exact union" "\n"
                "(four DNAs convolved into one)", fontsize=12)
    b.legend(loc="upper right", fontsize=8.5, framealpha=0.3)
    b.text(0.03, 0.04, "each parent trained alone on its class;\ncompound assembled by one "
           "convolution", transform=b.transAxes, color="#aaa", fontsize=8.5)

    fig.suptitle("Train four models separately, multiply (tensor) their DNAs, classify in "
                 "one shot — composition with a zero-union guarantee", fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "26_cm_tensor.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
