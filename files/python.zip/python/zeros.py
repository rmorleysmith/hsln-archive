"""Cached imaginary parts gamma_n of the nontrivial Riemann zeta zeros (rho = 1/2 + i*gamma).
Computed once with mpmath.zetazero and cached to .npy for reuse across figures."""
from __future__ import annotations

from pathlib import Path

import numpy as np


def get_zeros(N: int = 500, dps: int = 25) -> np.ndarray:
    path = Path(__file__).parent / f"zeta_zeros_{N}.npy"
    if path.exists():
        return np.load(path)
    import mpmath as mp
    mp.mp.dps = dps
    g = np.array([float(mp.zetazero(n).imag) for n in range(1, N + 1)])
    np.save(path, g)
    return g
