"""Composition in the DYNAMICAL regime: does tensoring preserve routing?

In the spike readout (hsln.py) composition is exact: zeros union, so the compound
spikes wherever either parent did. But the *dynamics* need not compose. The flow on
the product field is

    -grad |F_A F_B|^2  =  -( |F_B|^2 grad|F_A|^2  +  |F_A|^2 grad|F_B|^2 ),

a |F_B|^2-weighted A-flow plus a |F_A|^2-weighted B-flow -- NOT the union of the two
flows. So the attractors (zeros) all survive, but the BASINS reshape, and an input
can be captured by the wrong attractor.

We test a "crossing" geometry: task A steers an input rightward across a region where
task B parks an attractor. Each parent routes correctly alone; we then tensor them
and watch where the compound actually sends each input.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np
from jax import grad, lax, value_and_grad

import modular

jax.config.update("jax_enable_x64", True)

Y0 = 0.58            # inputs start here
YT = 0.28            # targets sit here
T, DT = 220, 0.02


def energy(dna, xy):
    q = jnp.exp(2j * jnp.pi * (xy[0] + 1j * xy[1]))
    f = jnp.sum(dna * q ** jnp.arange(dna.shape[0]))
    return jnp.real(f * jnp.conj(f))


_genergy = grad(energy, argnums=1)


def rollout(dna, start, alpha=1.0):
    def step(xy, _):
        g = _genergy(dna, xy)
        gn = g / (jnp.sqrt(g[0] ** 2 + g[1] ** 2) + 1e-4)
        nx = jnp.clip(xy[0] - DT * alpha * gn[0], 0.02, 0.98)
        ny = jnp.clip(xy[1] - DT * alpha * gn[1], 0.05, 0.95)
        new = jnp.array([nx, ny])
        return new, new
    _, traj = lax.scan(step, jnp.asarray(start), jnp.arange(T))
    return traj


def _central_init(seed, dg):
    rng = np.random.default_rng(seed)
    zeros = np.array([0.5 + (YT + 0.05 * k) * 1j for k in range(dg - 1)])
    c = np.poly(np.exp(2j * np.pi * zeros))[::-1]
    c = c / np.max(np.abs(c))
    return jnp.array(np.concatenate([c.real, c.imag]) + 0.04 * rng.standard_normal(2 * dg))


def train_routing(starts, targets, dg=4, steps=1400, lr=0.01, seed=0):
    starts = jnp.asarray(starts, float)
    targets = jnp.asarray(targets, float)

    def to_dna(p):
        return p[:dg] + 1j * p[dg:]

    def loss(p):
        dna = to_dna(p)
        L = 0.0
        for i in range(starts.shape[0]):
            tr = rollout(dna, starts[i])
            end = jnp.mean(tr[-30:], axis=0)           # where it settles
            L = L + jnp.sum((end - targets[i]) ** 2)
        return L + 1e-4 * jnp.sum(p ** 2)

    lg = jax.jit(value_and_grad(loss))
    p = _central_init(seed, dg)
    m = jnp.zeros_like(p); v = jnp.zeros_like(p)
    b1, b2, eps = 0.9, 0.999, 1e-8
    hist = []
    for t in range(1, steps + 1):
        L, g = lg(p)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        p = p - lr * (m / (1 - b1 ** t)) / (jnp.sqrt(v / (1 - b2 ** t)) + eps)
        hist.append(float(L))
    return np.array(to_dna(p)), hist


def endpoint(dna, start):
    return np.array(jnp.mean(rollout(jnp.asarray(dna), start)[-30:], axis=0))


# crossing geometry: A sends 0.40 -> 0.65 (rightward); B sends 0.60 -> 0.35 (leftward).
A_START, A_TARGET = (0.40, Y0), (0.65, YT)
B_START, B_TARGET = (0.60, Y0), (0.35, YT)


def run(make_fig=True):
    dnaA, hA = train_routing([A_START], [A_TARGET], seed=1)
    dnaB, hB = train_routing([B_START], [B_TARGET], seed=2)
    dnaAB = np.convolve(dnaA, dnaB)

    eAA = endpoint(dnaA, A_START)
    eBB = endpoint(dnaB, B_START)
    eABa = endpoint(dnaAB, A_START)
    eABb = endpoint(dnaAB, B_START)

    def near(e, t):
        return float(np.hypot(e[0] - t[0], e[1] - t[1]))

    print(f"parent A: input {A_START[0]} -> {np.round(eAA,3)}  (target {A_TARGET})  err {near(eAA,A_TARGET):.3f}")
    print(f"parent B: input {B_START[0]} -> {np.round(eBB,3)}  (target {B_TARGET})  err {near(eBB,B_TARGET):.3f}")
    print("--- compound A (x) B ---")
    print(f"  A-input {A_START[0]} -> {np.round(eABa,3)}   wants {A_TARGET}  ", end="")
    print(f"(to A:{near(eABa,A_TARGET):.2f}  to B:{near(eABa,B_TARGET):.2f})")
    print(f"  B-input {B_START[0]} -> {np.round(eABb,3)}   wants {B_TARGET}  ", end="")
    print(f"(to A:{near(eABb,A_TARGET):.2f}  to B:{near(eABb,B_TARGET):.2f})")
    okA = near(eABa, A_TARGET) < near(eABa, B_TARGET)
    okB = near(eABb, B_TARGET) < near(eABb, A_TARGET)
    print(f"compound routes A-input correctly: {okA};  B-input correctly: {okB}")

    if make_fig:
        _figure(dnaA, dnaB, dnaAB, (eAA, eBB, eABa, eABb))
    return dnaA, dnaB, dnaAB


def _figure(dnaA, dnaB, dnaAB, ends):
    import matplotlib.pyplot as plt
    from pathlib import Path
    import style

    cA, cB = "#46f0d0", "#ffd166"

    def attractors(dna):
        z = modular.qpoly_zeros(np.asarray(dna))
        return z[(z.imag > 0.1) & (z.imag < 0.5)]  # the low attractors that route

    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.2))
    panels = [
        (dnaA, [(A_START, A_TARGET, cA)], "A alone:  0.40 → 0.65  ✓"),
        (dnaB, [(B_START, B_TARGET, cB)], "B alone:  0.60 → 0.35  ✓"),
        (dnaAB, [(A_START, A_TARGET, cA), (B_START, B_TARGET, cB)], "A ⊗ B:  what happens?"),
    ]
    for a, (dna, runs, title) in zip(ax, panels):
        a.set_facecolor("#0b0b14")
        za = attractors(dna)
        a.plot(za.real, za.imag, "o", color="#888", ms=9, mfc="none", mew=2,
                label="attractors", zorder=4)
        for start, target, c in runs:
            tr = np.array(rollout(jnp.asarray(dna), start))
            a.plot(tr[:, 0], tr[:, 1], color=c, lw=2.0, zorder=5)
            a.plot(start[0], start[1], "o", color=c, mec="white", mew=0.8, ms=8, zorder=6)
            a.plot(target[0], target[1], "*", color=c, ms=20, mec="white", mew=0.9, zorder=6)
        a.set_xlim(0, 1); a.set_ylim(0.1, 0.7); a.set_xlabel(r"Re $\tau$")
        a.set_title(title, fontsize=12)
        a.legend(loc="upper right", fontsize=8, framealpha=0.3)
    ax[0].set_ylabel(r"Im $\tau$")
    ax[2].text(0.03, 0.13, "● input   ★ trained target", color="white", fontsize=8)

    fig.suptitle("Dynamical composition: each parent routes correctly, but the tensor "
                 "product reshapes the basins — routing can cross-talk", fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "19_dynamical_composition.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
