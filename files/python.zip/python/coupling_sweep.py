"""Gravity = the off-diagonal of the period matrix. Dial it and watch composition
break, then watch chaos appear.

Genus-2 state Z = [[tau1, z],[z, tau2]], Y = Im Z = [[y1, w],[w, y2]]. The
Sp(4,R)-invariant Siegel metric makes the Riemannian gradient mix the two
coordinates through Y: on the diagonal slice (w = 0) the energy of a DIRECT SUM
factorizes, log-energy ADDS, and the flow DECOUPLES (each task on its own
coordinate -> perfect routing, fig 20). Turning on the off-diagonal w couples the
two flows -- this is the "gravity" that glues the two E8 sectors.

We use the dimensionless coupling  kappa  with off-diagonal metric entry
w^2 = kappa * y1 * y2, so K = [[y1^2, kappa*y1*y2],[kappa*y1*y2, y2^2]] is PSD for
kappa in [0,1] (det = y1^2 y2^2 (1 - kappa^2)).

Three things, all on plain backgrounds:
  A. routing error vs kappa            -- composition degrades from clean to cross-talk
  B. joint trajectories at a few kappa -- the path bends toward the wrong target
  C. sensitive dependence vs kappa     -- with a periodic drive, coupling unlocks chaos
     (at kappa=0 the two coordinates are independent driven 1-D first-order flows;
      Poincare-Bendixson forbids chaos. Only the off-diagonal opens a 3rd dimension.)
"""
from __future__ import annotations

from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
from jax import grad, lax

import hsln_dyn as g1

jax.config.update("jax_enable_x64", True)

EPS = 1e-2

A_START, A_TARGET = g1.A_START, g1.A_TARGET   # (0.40,0.58) -> (0.65,0.28) on coord 1
B_START, B_TARGET = g1.B_START, g1.B_TARGET   # (0.60,0.58) -> (0.35,0.28) on coord 2


def _logE(dna, xy):
    return jnp.log(g1.energy(dna, xy) + EPS)


_glogE = grad(_logE, argnums=1)               # d log(|F|^2+eps) / d(x,y)


# --------------------------------------------------------------------------- #
#  Coupled genus-2 routing flow (unit-speed, no drive)                        #
# --------------------------------------------------------------------------- #
def coupled_rollout(dnaA, dnaB, s0, kappa, T=320, dt=0.02):
    def step(s, _):
        x1, y1, x2, y2 = s[0], s[1], s[2], s[3]
        gA = _glogE(dnaA, jnp.array([x1, y1]))      # [d/dx1, d/dy1]
        gB = _glogE(dnaB, jnp.array([x2, y2]))      # [d/dx2, d/dy2]
        off = kappa * y1 * y2
        # v = -K @ grad,  K = [[y1^2, off],[off, y2^2]],  applied to x- and y-channels
        vx1 = -(y1 ** 2 * gA[0] + off * gB[0])
        vx2 = -(off * gA[0] + y2 ** 2 * gB[0])
        vy1 = -(y1 ** 2 * gA[1] + off * gB[1])
        vy2 = -(off * gA[1] + y2 ** 2 * gB[1])
        v = jnp.array([vx1, vy1, vx2, vy2])
        v = v / (jnp.linalg.norm(v) + 1e-6)
        ns = s + dt * v
        ns = ns.at[0].set(jnp.clip(ns[0], 0.02, 0.98))
        ns = ns.at[2].set(jnp.clip(ns[2], 0.02, 0.98))
        ns = ns.at[1].set(jnp.clip(ns[1], 0.06, 0.95))
        ns = ns.at[3].set(jnp.clip(ns[3], 0.06, 0.95))
        return ns, ns
    _, tr = lax.scan(step, jnp.asarray(s0), jnp.arange(T))
    return tr


def routing_errors(dnaA, dnaB, kappa):
    s0 = jnp.array([A_START[0], A_START[1], B_START[0], B_START[1]])
    tr = coupled_rollout(dnaA, dnaB, s0, kappa)
    end = jnp.mean(tr[-30:], axis=0)
    eA = float(jnp.hypot(end[0] - A_TARGET[0], end[1] - A_TARGET[1]))
    eB = float(jnp.hypot(end[2] - B_TARGET[0], end[3] - B_TARGET[1]))
    return eA, eB, np.array(tr)


# --------------------------------------------------------------------------- #
#  Driven flow on a MULTI-WELL landscape (clean dimensional argument for chaos)#
#                                                                              #
#  A first-order flow needs >=3 phase dimensions to be chaotic. Drive ONLY x1: #
#   kappa=0  -> x1 is a forced 1-D first-order flow (2-D extended phase, x2     #
#              autonomous) => Poincare-Bendixson forbids chaos: it entrains.   #
#   kappa>0  -> x1,x2 couple, x1 forced => 3-D extended phase => chaos allowed. #
#  So the off-diagonal coupling (gravity) is exactly what unlocks chaos.       #
#  We need several wells per coordinate for the forced particle to hop, so we  #
#  build a richer |F|^2 landscape with 4 zeros placed across the strip.        #
# --------------------------------------------------------------------------- #
def multiwell_dna(xs=(0.2, 0.4, 0.6, 0.8), y0=0.42):
    zeros = np.array([x + 1j * y0 for x in xs])
    c = np.poly(np.exp(2j * np.pi * zeros))[::-1]          # |F| vanishes at each x
    xg = np.linspace(0, 1, 400)
    qg = np.exp(2j * np.pi * (xg + 1j * y0))
    Fg = np.array([np.sum(c * qq ** np.arange(len(c))) for qq in qg])
    c = c / np.sqrt(np.mean(np.abs(Fg) ** 2))              # normalize so |F| ~ O(1)
    return jnp.asarray(c.astype(complex))


def _gx(dna, x, y0):
    return _glogE(dna, jnp.array([x, y0]))[0]              # d log E / dx at fixed y


def driven_rollout(dna, x0, kappa, y0=0.42, amp=1.0, om=0.9,
                   T=12000, dt=0.005, alpha=0.3):
    def step(carry, k):
        x1, x2 = carry[0], carry[1]
        t = k * dt
        gA = _gx(dna, x1, y0)
        gB = _gx(dna, x2, y0)
        off = kappa * y0 * y0
        vx1 = -alpha * (y0 ** 2 * gA + off * gB) + amp * jnp.sin(om * t)
        vx2 = -alpha * (off * gA + y0 ** 2 * gB)
        vx1 = jnp.clip(vx1, -8.0, 8.0)
        vx2 = jnp.clip(vx2, -8.0, 8.0)
        nx1 = jnp.clip(x1 + dt * vx1, 0.02, 0.98)
        nx2 = jnp.clip(x2 + dt * vx2, 0.02, 0.98)
        ns = jnp.array([nx1, nx2])
        return ns, ns
    _, tr = lax.scan(step, jnp.asarray(x0), jnp.arange(T))
    return tr


def separation(dna, kappa, delta=1e-7):
    x0 = jnp.array([0.50, 0.50])
    a = driven_rollout(dna, x0, kappa)
    b = driven_rollout(dna, x0 + jnp.array([delta, 0.0]), kappa)
    sep = np.array(jnp.sqrt(jnp.sum((a - b) ** 2, axis=1)))
    return sep


# --------------------------------------------------------------------------- #
def run(make_fig=True):
    dnaA, _ = g1.train_routing([A_START], [A_TARGET], seed=1)
    dnaB, _ = g1.train_routing([B_START], [B_TARGET], seed=2)
    dnaA, dnaB = jnp.asarray(dnaA), jnp.asarray(dnaB)

    kappas = np.linspace(0.0, 0.95, 13)
    errsA, errsB, trajs = [], [], {}
    keep = {0.0, 0.4, 0.8}
    for kap in kappas:
        eA, eB, tr = routing_errors(dnaA, dnaB, float(kap))
        errsA.append(eA); errsB.append(eB)
        if round(float(kap), 2) in keep or any(abs(kap - k) < 0.04 for k in keep):
            trajs[round(float(kap), 2)] = tr
    print("kappa   errA    errB")
    for kap, eA, eB in zip(kappas, errsA, errsB):
        print(f"{kap:.3f}  {eA:.3f}  {eB:.3f}")

    dna_mw = multiwell_dna()
    sep0 = separation(dna_mw, 0.0)
    sep1 = separation(dna_mw, 0.85)
    print(f"[chaos] final separation  kappa=0: {sep0[-1]:.2e}   kappa=0.85: {sep1[-1]:.2e}")

    if make_fig:
        _figure(kappas, errsA, errsB, trajs, sep0, sep1)
    return errsA, errsB


def _figure(kappas, errsA, errsB, trajs, sep0, sep1):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, GREEN, RED = "#46f0d0", "#ffd166", "#7CFC8A", "#ff3b6b"

    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))

    # --- A: routing error vs coupling (robustness) --- #
    a = ax[0]
    a.plot(kappas, errsA, "o-", color=TEAL, lw=2, label="task A (coord 1)")
    a.plot(kappas, errsB, "s-", color=GOLD, lw=2, label="task B (coord 2)")
    a.axhline(0.05, color="#888", ls="--", lw=1, alpha=0.7, label="routing tolerance")
    a.set_ylim(0, 0.2)
    a.set_xlabel(r"coupling  $\kappa$   (off-diagonal $\mathrm{Im}\,z$)")
    a.set_ylabel("routing error (distance to target)")
    a.set_title("routing stays robust:\nthe joint zero is always an equilibrium", fontsize=12)
    a.legend(loc="upper left", fontsize=9, framealpha=0.3)

    # --- B: joint trajectories bending toward wrong target --- #
    b = ax[1]
    cols = {0.0: GREEN, 0.4: GOLD, 0.8: RED}
    for kap in sorted(trajs):
        tr = trajs[kap]
        col = cols.get(kap, "#aaa")
        b.plot(tr[:, 0], tr[:, 2], color=col, lw=2.0, label=fr"$\kappa$={kap:.1f}")
        b.plot(tr[0, 0], tr[0, 2], "o", color=col, ms=6, mec="white", mew=0.6)
    b.plot(A_TARGET[0], B_TARGET[0], "*", color="white", ms=22, mec=GREEN, mew=1.2,
           label="joint target", zorder=6)
    b.set_xlabel(r"$\mathrm{Re}\,\tau_1$  (task A coordinate)")
    b.set_ylabel(r"$\mathrm{Re}\,\tau_2$  (task B coordinate)")
    b.set_title("but gravity warps the route\n(paths bend, same destination)", fontsize=12)
    b.legend(loc="lower left", fontsize=8.5, framealpha=0.3)

    # --- C: sensitive dependence (chaos signature) --- #
    c = ax[2]
    t0 = np.arange(len(sep0)) * 0.01
    c.plot(t0, np.log10(sep0 + 1e-18), color=GREEN, lw=1.6, label=r"$\kappa$=0  (decoupled)")
    c.plot(t0, np.log10(sep1 + 1e-18), color=RED, lw=1.6, label=r"$\kappa$=0.85 (coupled)")
    c.set_xlabel("time  (driven flow)")
    c.set_ylabel(r"$\log_{10}$ trajectory separation")
    c.set_title("coupling unlocks chaos\n(sensitive dependence)", fontsize=12)
    c.legend(loc="lower right", fontsize=9, framealpha=0.3)

    fig.suptitle("Gravity as the off-diagonal coupling: it warps the route and, under "
                 "drive, unlocks chaos — yet the direct-sum target stays robust", fontsize=13, y=1.02)
    out = Path(__file__).parent / "figures" / "22_coupling_sweep.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
