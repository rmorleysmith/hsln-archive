"""hsln_e8_divisor_bridge.py — the divisor function is the bridge: DNA algebra → Eisenstein → E8 → heterotic.

Ties together figures 37 (DNA/Dirichlet ring), 38 (Lie derivative), 39 (L-functions), and adds
the divisor function as the on-ramp to geometry. The chain, each link a real theorem:

  σ₃ = ζ * Id₃   (Dirichlet ring, fig 37)
       ↓  is the Fourier DNA of …
  E₄(τ) = 1 + 240 Σ σ₃(n) qⁿ            (the weight-4 Eisenstein series)
       ‖  equals (M₄(SL₂ℤ) is 1-dimensional) …
  Θ_{E8}(τ) = Σ_x q^{|x|²/2}            (the E8 lattice theta series)
       ⇒  number of E8 vectors of norm 2n = 240·σ₃(n);  240 = the E8 roots.

  composition (our Ring-A product) = lattice direct sum:
  Θ_{E8} ⋆ Θ_{E8} = E₄² = Θ_{E8×E8}    (heterotic; D16⁺ shares this theta — Witt 1941)

  and the L-function side (fig 39):  Σ σ₃(n) n^{−s} = ζ(s)·ζ(s−3).

We VERIFY the E8 link by actually enumerating E8 lattice points.
"""
from __future__ import annotations

import sys
from itertools import product
from pathlib import Path

import numpy as np
import mpmath as mp
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({'figure.facecolor': 'white', 'axes.facecolor': 'white'})


# ── Dirichlet-ring elements (fig 37/38) ──────────────────────────────────────────
def sigma(k, n):
    return sum(d**k for d in range(1, n + 1) if n % d == 0)

def mobius(n):
    if n == 1: return 1
    m, p, cnt = n, 2, 0
    while p * p <= m:
        if m % p == 0:
            m //= p; cnt += 1
            if m % p == 0: return 0
        p += 1
    if m > 1: cnt += 1
    return -1 if cnt % 2 else 1

def von_mangoldt(n):
    if n < 2: return 0.0
    p, m = 2, n
    while p * p <= n:
        if m % p == 0:
            while m % p == 0: m //= p
            return float(np.log(p)) if m == 1 else 0.0
        p += 1
    return float(np.log(n))  # n prime


# ── E8 lattice enumeration (even-coordinate system) ──────────────────────────────
def e8_counts(max_norm=6):
    """Count E8 vectors by squared-norm. E8 = {x∈ℤ⁸ or (ℤ+½)⁸ : Σxᵢ ∈ 2ℤ}."""
    counts = {}
    # integer shell: |xᵢ| ≤ 2 covers norms ≤ 6
    rng = range(-2, 3)
    for x in product(rng, repeat=8):
        s = sum(x)
        if s % 2: continue                      # Σxᵢ even
        nrm = sum(v * v for v in x)
        if nrm and nrm <= max_norm:
            counts[nrm] = counts.get(nrm, 0) + 1
    # half-integer shell: coords in {±½, ±3/2}; use halves h with hᵢ odd
    hrng = [-3, -1, 1, 3]                        # represents h/2
    for h in product(hrng, repeat=8):
        nrm4 = sum(v * v for v in h)             # = 4·|x|²
        if nrm4 % 4: continue
        nrm = nrm4 // 4
        if nrm > max_norm: continue
        s2 = sum(h)                              # = 2·Σxᵢ ; need Σxᵢ even ⇒ s2 ≡ 0 (mod 4)
        if s2 % 4: continue
        if nrm:
            counts[nrm] = counts.get(nrm, 0) + 1
    return counts


def main():
    Nmax = 30
    ns = np.arange(1, Nmax + 1)
    sig0 = np.array([sigma(0, n) for n in ns])     # d(n) = ζ*ζ
    sig3 = np.array([sigma(3, n) for n in ns])
    mu = np.array([mobius(n) for n in ns])
    Lam = np.array([von_mangoldt(n) for n in ns])

    # E4 = 1 + 240 Σ σ₃(n) qⁿ  ;  E4² coefficients = our Ring-A composition (convolution)
    e4 = np.concatenate([[1.0], 240.0 * sig3])
    e4sq = np.convolve(e4, e4)

    # E8 verification
    e8 = e8_counts(max_norm=6)
    print("=" * 74)
    print("  σ₃ = DNA of E₄ = Θ(E8):  #{E8 vectors of norm 2n} = 240·σ₃(n)")
    print("=" * 74)
    print("    n | 2n | 240·σ₃(n) | counted E8 vectors | match")
    for n in (1, 2, 3):
        pred = 240 * sigma(3, n)
        got = e8.get(2 * n, 0)
        print(f"    {n} | {2*n:2d} | {pred:9d} | {got:18d} | {pred == got}")
    print(f"\n  → 240 = number of E8 roots (norm-2 vectors) = 240·σ₃(1).")
    print(f"  Θ(E8×E8) = E₄²:  norm-2 vectors = {int(e4sq[1])} = 480 E8×E8 roots; +16 Cartan = 496 = dim(E8×E8).")
    print(f"  (D16⁺ has the SAME theta E₄² but is a different lattice — Witt 1941 / heterotic SO(32) vs E8×E8.)")

    # L-function factorisation: Σ σ₃(n) n^{-s} = ζ(s) ζ(s-3)   (Re s > 4)
    mp.mp.dps = 25
    print("\n  L-function (fig 39 tie-in):  Σ σ₃(n) n^{-s}  =  ζ(s)·ζ(s−3)")
    for s in (5, 6):
        lhs = sum(mp.mpf(sigma(3, n)) / mp.mpf(n) ** s for n in range(1, 4000))
        rhs = mp.zeta(s) * mp.zeta(s - 3)
        print(f"    s={s}:  partial Σ = {mp.nstr(lhs,12)}   ζ(s)ζ(s−3) = {mp.nstr(rhs,12)}   "
              f"Δ={mp.nstr(abs(lhs-rhs),3)}")

    # ── figure ───────────────────────────────────────────────────────────────────
    fig = plt.figure(figsize=(13.5, 10))
    gs = fig.add_gridspec(2, 2, hspace=0.38, wspace=0.26)

    # (a) everything from ζ
    ax = fig.add_subplot(gs[0, 0])
    for row, (lbl, arr, col) in enumerate([
            ('d=σ₀=ζ·ζ', sig0 / sig0.max(), '#4c72b0'),
            ('σ₃=ζ·Id₃', sig3 / sig3.max(), '#55a868'),
            ('Λ (primes)', Lam / max(Lam.max(), 1e-9), '#c44e52'),
            ('μ=ζ⁻¹', (mu + 1) / 2, '#8172b3')]):
        ax.vlines(ns, row, row + arr * 0.85, color=col, lw=2)
        ax.text(-1.5, row + 0.3, lbl, ha='right', fontsize=9)
    ax.set_xlim(-6, Nmax + 1); ax.set_ylim(-0.2, 4); ax.set_yticks([])
    ax.set_xlabel('n'); ax.set_title('(a) the DNA algebra — every element is ζ + ring ops')

    # (b) σ₃ = E₄ = Θ(E8)
    ax = fig.add_subplot(gs[0, 1])
    nn = np.arange(1, 6)
    ax.bar(nn - 0.2, 240 * np.array([sigma(3, n) for n in nn]), 0.4,
           label='240·σ₃(n)', color='#55a868')
    ax.bar(nn + 0.2, [e8.get(2 * n, 0) for n in nn], 0.4,
           label='# E8 vectors, norm 2n', color='#dd8452', alpha=0.9)
    ax.set_yscale('log'); ax.set_xlabel('n'); ax.legend(fontsize=9)
    ax.set_title('(b) σ₃ IS the E8 theta series — E₄ = Θ(E8)  [240 roots]')

    # (c) composition = direct sum: E₄² = Θ(E8×E8)
    ax = fig.add_subplot(gs[1, 0])
    kk = np.arange(0, 8)
    ax.bar(kk, e4sq[:8], color='#937860')
    for k in (1, 2):
        ax.annotate(f'{int(e4sq[k])}', (k, e4sq[k]), textcoords='offset points',
                    xytext=(0, 3), ha='center', fontsize=8)
    ax.set_xlabel('n'); ax.set_ylabel('coeff of E₄²')
    ax.set_title('(c) Θ(E8)⋆Θ(E8)=E₄²=Θ(E8×E8) — composition = lattice ⊕  [480 roots]')

    # (d) L-function factorisation
    ax = fig.add_subplot(gs[1, 1])
    svals = np.linspace(4.2, 8, 120)
    lhs = [float(sum(mp.mpf(sigma(3, n)) / mp.mpf(n) ** s for n in range(1, 1500))) for s in svals]
    rhs = [float(mp.zeta(s) * mp.zeta(s - 3)) for s in svals]
    ax.plot(svals, rhs, lw=3, color='#4c72b0', label='ζ(s)·ζ(s−3)')
    ax.plot(svals, lhs, '--', lw=1.5, color='#c44e52', label='Σ σ₃(n) n^{−s}')
    ax.set_xlabel('s'); ax.set_yscale('log'); ax.legend(fontsize=9)
    ax.set_title('(d) the divisor L-function factors — ζ ⊗ ζ shifted (fig 39)')

    fig.suptitle('The divisor function is the bridge:  DNA algebra → E₄ → E8 → E8×E8 heterotic',
                 fontsize=14, y=0.97)
    out = Path(__file__).parent / 'figures' / '56_hsln_e8_divisor_bridge.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"\n  ✓ figure: {out.name}")


if __name__ == "__main__":
    main()
