"""hsln_hash_inverse.py — compute inv(F) for the unknown SHA-256 hash.

DNA = compose_all(32 byte-positions from the hash) — a length-33 polynomial in q.
We compute its multiplicative inverse 1/F as a formal q-power series:

  F(q) = a_0 + a_1 q + a_2 q^2 + ...
  inv  = b_0 + b_1 q + b_2 q^2 + ...     with   F · inv = 1

Recurrence (Newton-form):
  b_0 = 1/a_0
  b_k = − (1/a_0) Σ_{j=1..min(k, deg F)} a_j b_{k−j}

For our 32-zero polynomial, |a_0| ≈ exp(−2π·LANE_Y·32) ≈ 2e−16 — well below double
precision floor — so we run the recurrence in mpmath at 80 digits and convert at the end.

Radius of convergence in q is min |q_zero| = exp(−2π · LANE_Y) ≈ 0.322.
Below the lane, the series converges; on the lane it sits right at the boundary.
Above the lane (|q| < exp(−2π·LANE_Y)) it converges fine.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import mpmath as mp

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln       # local
from hsln_hash_dance import atomic_dna

mpl.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'legend.fontsize': 9,
})

FIG_DIR = HERE / 'figures'
LANE_Y = hsln.LANE_Y


HEX = '12765c998f116a621a3b1a9eaa5b7ab94a06f623233d782bdfaf51c3b7e95b92'


def compose_all_mpc(positions, lane_y=LANE_Y):
    """Convolve atomic DNAs at high precision; return list[mpc]."""
    two_pi = 2 * mp.pi
    dna = [mp.mpc(1, 0)]
    for pos in positions:
        q_pos = mp.exp(mp.mpc(0, two_pi * float(pos))) * mp.exp(-two_pi * lane_y)
        atom = [-q_pos, mp.mpc(1, 0)]
        # naive convolution
        out = [mp.mpc(0)] * (len(dna) + 1)
        for i, a in enumerate(dna):
            out[i] += a * atom[0]
            out[i + 1] += a * atom[1]
        dna = out
    return dna


def invert_series_mpc(a, n_terms):
    """Given coeffs a = [a_0, a_1, ...] of F, return [b_0, ..., b_{n-1}] with F · B ≡ 1."""
    assert a[0] != 0, 'F(0) must be nonzero to invert'
    a0_inv = 1 / a[0]
    deg = len(a) - 1
    b = [mp.mpc(0)] * n_terms
    b[0] = a0_inv
    for k in range(1, n_terms):
        s = mp.mpc(0)
        for j in range(1, min(k, deg) + 1):
            s += a[j] * b[k - j]
        b[k] = -a0_inv * s
    return b


def mpc_list_to_complex(xs):
    return np.array([complex(float(x.real), float(x.imag)) for x in xs])


def evaluate_inv_lane(b_mp, xs, lane_y):
    """Evaluate the (truncated) inverse series along the line Im τ = lane_y.

    Inverse converges for |q| < exp(−2π · LANE_Y).  On the lane |q| = exp(−2π·lane_y).
    Use lane_y > LANE_Y so we stay strictly inside the disc of convergence.
    """
    two_pi = 2 * mp.pi
    out = np.empty(len(xs), dtype=complex)
    for i, x in enumerate(xs):
        q = mp.exp(mp.mpc(0, two_pi * float(x))) * mp.exp(-two_pi * float(lane_y))
        s = mp.mpc(0)
        qk = mp.mpc(1, 0)
        for bk in b_mp:
            s += bk * qk
            qk *= q
        out[i] = complex(float(s.real), float(s.imag))
    return out


def main():
    mp.mp.dps = 80
    print("=" * 78)
    print('  inv(F) for the unknown SHA-256 hash')
    print("=" * 78)
    print(f'\n  Hash: {HEX}')
    digest = bytes.fromhex(HEX)
    positions = np.array([b / 256.0 for b in digest])
    print(f'  Bytes: {len(digest)}   positions: {len(positions)}')

    print(f'\n  Composing DNA via 32-fold Vieta convolution at 80-digit precision ...')
    dna_mp = compose_all_mpc(positions)
    dna = mpc_list_to_complex(dna_mp)
    print(f'  ✓ DNA length: {len(dna_mp)}')
    a0 = dna_mp[0]
    print(f'  |a_0| = {float(abs(a0)):.3e}   (= product of |−q_t|, dominated by exp(−2π·LANE_Y·32))')
    expected_a0 = math.exp(-2 * math.pi * LANE_Y * 32)
    print(f'  expected |a_0| = exp(−2π·{LANE_Y}·32) = {expected_a0:.3e}')

    # ── Compute inv coefficients ──────────────────────────────────────────────
    N_INV = 80   # how many terms of the inverse to keep
    print(f'\n  Computing inv(F) coefficients b_0 .. b_{N_INV-1} at 80-digit precision ...')
    b_mp = invert_series_mpc(dna_mp, N_INV)
    b = mpc_list_to_complex(b_mp)
    print(f'  ✓ inverse coefficients computed')

    # Validate: convolve a * b, check it's [1, 0, 0, ...]
    check = np.zeros(N_INV, dtype=complex)
    for i in range(len(dna)):
        for j in range(N_INV - i):
            check[i + j] += dna[i] * b[j]
    print(f'  Validation:  (F · B)_0 = {check[0]:.6f}   '
          f'max |residual| over n=1..{N_INV-1}: {np.max(np.abs(check[1:])):.2e}')

    # ── Coefficient magnitudes — should grow exponentially ────────────────────
    mags_b = np.abs(b)
    print(f'\n  Inverse coefficient magnitudes:')
    print(f'    n  |    |b_n|              log10 |b_n|')
    print(f'  -----+--------------------------------------')
    for n in range(min(20, N_INV)):
        ln = math.log10(mags_b[n]) if mags_b[n] > 0 else -math.inf
        print(f'    {n:2d} |   {mags_b[n]:.4e}        {ln:+8.3f}')
    print(f'    ... ({N_INV - 20} more)')
    # Growth rate
    # |b_n| ~ |q_min|^(-n) = exp(2π·LANE_Y·n)  → slope = 2π·LANE_Y / ln 10 per step
    expected_slope = 2 * math.pi * LANE_Y / math.log(10)
    actual_slope = (math.log10(mags_b[-1]) - math.log10(mags_b[5])) / (N_INV - 6)
    print(f'\n  Growth rate of log10|b_n| per step:')
    print(f'    expected from radius of convergence: {expected_slope:.4f}')
    print(f'    measured (n=5 → n={N_INV-1}):         {actual_slope:.4f}')

    # ── Evaluate 1/F along the lane (need to be safely INSIDE disc) ───────────
    # |q_zero| = exp(−2π · LANE_Y); to converge we need |q| strictly smaller, i.e.
    # evaluation at Im τ > LANE_Y.
    EVAL_LANE = 0.30   # comfortably above LANE_Y = 0.18
    xs = np.linspace(0.0, 1.0, 1200)
    print(f'\n  Evaluating inverse series along lane Im τ = {EVAL_LANE} (inside disc)...')
    inv_vals = evaluate_inv_lane(b_mp, xs, EVAL_LANE)
    print(f'  max |1/F(τ)| on eval lane: {np.max(np.abs(inv_vals)):.4e}')

    # Compare against direct 1/F (via the original DNA evaluated as a polynomial)
    import modular
    F_eval = modular.qpoly(dna, xs + 1j * EVAL_LANE)
    direct_inv = 1.0 / F_eval
    err = np.max(np.abs(inv_vals - direct_inv))
    print(f'  max |series − direct 1/F| on eval lane: {err:.3e}')

    # ── Visualisation ────────────────────────────────────────────────────────
    fig = plt.figure(figsize=(15.5, 13.0))
    gs = fig.add_gridspec(3, 2, height_ratios=[1, 1.2, 1.4], hspace=0.50, wspace=0.30)

    # A. Inverse coefficient magnitudes (log scale)
    ax = fig.add_subplot(gs[0, 0])
    ns = np.arange(N_INV)
    ax.semilogy(ns, mags_b, 'o-', color='#d62728', markersize=4, linewidth=1.2,
                label='|b_n|')
    # expected envelope: |b_n| ~ C · exp(2π · LANE_Y · n) = C · |q_min|^{-n}
    envelope = mags_b[5] * np.exp(2 * math.pi * LANE_Y * (ns - 5))
    ax.semilogy(ns, envelope, '--', color='black', alpha=0.6,
                label=f'envelope  exp(2π·{LANE_Y}·n)')
    ax.set_xlabel('coefficient index n'); ax.set_ylabel('|b_n|  (log)')
    ax.set_title('A. Inverse DNA magnitudes  |b_n|  — grow as |q_min|⁻ⁿ')
    ax.grid(alpha=0.3, which='both')
    ax.legend()

    # B. Path of inverse coefficients in ℂ
    ax = fig.add_subplot(gs[0, 1])
    # use early coeffs (first ~20) on a normal scale, normalised
    n_show = 25
    b_show = b[:n_show] / mags_b[:n_show].max()
    cmap = plt.cm.plasma
    cols = cmap(np.arange(n_show) / max(n_show - 1, 1))
    ax.plot(b_show.real, b_show.imag, '-', color='gray', alpha=0.4, linewidth=1)
    for i, (bn, c) in enumerate(zip(b_show, cols)):
        ax.scatter(bn.real, bn.imag, color=c, s=60, edgecolor='black',
                   linewidth=0.3, zorder=5)
        if i % 4 == 0 or i == n_show - 1:
            ax.annotate(f'b{i}', (bn.real, bn.imag), textcoords='offset points',
                        xytext=(7, 4), fontsize=8)
    M = float(np.max(np.abs(b_show))) * 1.15
    ax.axhline(0, color='black', linewidth=0.4)
    ax.axvline(0, color='black', linewidth=0.4)
    ax.set_xlim(-M, M); ax.set_ylim(-M, M); ax.set_aspect('equal')
    ax.set_xlabel('Re b_n (normalised)'); ax.set_ylabel('Im b_n (normalised)')
    ax.set_title(f'B. Inverse DNA path in ℂ  (first {n_show}, max-normalised)')
    ax.grid(alpha=0.3)

    # C. |1/F(τ)| along eval lane — the "anti-neuron landscape"
    ax = fig.add_subplot(gs[1, :])
    mag_inv = np.abs(inv_vals)
    ax.semilogy(xs, mag_inv, color='#9467bd', linewidth=1.4,
                label=f'series-sum |1/F|  on lane Im τ = {EVAL_LANE}')
    ax.semilogy(xs, np.abs(direct_inv), '--', color='black', alpha=0.5,
                linewidth=0.9, label='direct 1/F via qpoly')
    # mark byte positions
    for i, pos in enumerate(positions):
        ax.axvline(pos, color='red', linewidth=0.4, alpha=0.4)
    ax.set_xlim(0, 1)
    ax.set_xlabel(f'Re τ   (Im τ = {EVAL_LANE}, above the zero lane)')
    ax.set_ylabel('|1/F(τ)|  (log)')
    ax.set_title('C. The anti-neuron landscape — |1/F| along an eval lane above the zeros.\n'
                 '   Red ticks = the 32 byte positions (where zeros of F sit at LANE_Y = 0.18).')
    ax.grid(alpha=0.3, which='both')
    ax.legend(loc='upper right', fontsize=9)

    # D. 2D pole landscape — colour-map |1/F| over a strip in H
    ax = fig.add_subplot(gs[2, 0])
    Nx, Ny = 320, 220
    xs_g = np.linspace(0.0, 1.0, Nx)
    ys_g = np.linspace(0.05, 0.45, Ny)
    Xg, Yg = np.meshgrid(xs_g, ys_g)
    F_grid = modular.qpoly(dna, Xg + 1j * Yg)
    log_inv = np.log10(1.0 / (np.abs(F_grid) + 1e-30))
    vmax = np.percentile(log_inv, 99)
    vmin = np.percentile(log_inv, 5)
    pcm = ax.pcolormesh(Xg, Yg, log_inv, shading='auto', cmap='inferno',
                        vmin=vmin, vmax=vmax)
    plt.colorbar(pcm, ax=ax, label='log₁₀ |1/F(τ)|')
    # mark byte positions (these ARE the poles of 1/F at Im τ = LANE_Y)
    for pos in positions:
        ax.scatter([pos], [LANE_Y], marker='x', color='cyan', s=40, linewidth=1.2)
    ax.axhline(LANE_Y, color='cyan', linestyle='--', linewidth=0.6, alpha=0.5)
    ax.axhline(EVAL_LANE, color='lime', linestyle='--', linewidth=0.6, alpha=0.5)
    ax.set_xlim(0, 1); ax.set_ylim(0.05, 0.45)
    ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
    ax.set_title('D. Pole landscape  log₁₀|1/F(τ)|  — cyan ✕ = 32 byte positions (poles).\n'
                 '   The dashed cyan line is LANE_Y (zero lane); lime is eval lane.')

    # E. |1/F| at the 32 byte positions, evaluated slightly above LANE_Y
    ax = fig.add_subplot(gs[2, 1])
    near_lane = LANE_Y + 0.01   # slightly above the zeros
    F_byte = modular.qpoly(dna, positions + 1j * near_lane)
    inv_byte = 1.0 / F_byte
    bytes_arr = np.frombuffer(digest, dtype=np.uint8)
    colors_b = plt.cm.twilight(bytes_arr / 255.0)
    ax.bar(np.arange(32), np.abs(inv_byte), color=colors_b, edgecolor='black',
           linewidth=0.4, width=0.85)
    ax.set_yscale('log')
    ax.set_xlabel('byte index t')
    ax.set_ylabel(f'|1/F| at  τ = pos_t + i·{near_lane}   (just above the pole)')
    ax.set_title('E. Inverse evaluated near each pole (Im τ slightly above LANE_Y)')
    ax.grid(alpha=0.3, which='both', axis='y')

    fig.suptitle(
        f'inv(F) for unknown SHA-256\n'
        f'{HEX}\n'
        f'|a_0| = {float(abs(a0)):.2e}   |b_n| grows as exp(2π·{LANE_Y}·n)   '
        f'F · B = 1 verified to {np.max(np.abs(check[1:])):.1e}',
        fontsize=12, y=0.998,
    )
    out = FIG_DIR / '51_hsln_hash_inverse.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'\n  ✓ {out.name}')

    print()
    print('  ─── Honest scoping ───')
    print('  • inv(F) is well-defined as a formal series because a_0 ≠ 0 (LANE_Y > 0).')
    print('  • |b_n| grows exponentially because zeros of F are poles of 1/F.')
    print('  • Radius of convergence = min|q_t| = exp(−2π·LANE_Y) ≈ 0.322.')
    print('  • On the lane Im τ = LANE_Y, 1/F diverges at each byte position.')
    print('  • Inversion is an automorphism of the Cauchy ring: inv(F⊗G) = inv(F) ⊗ inv(G).')
    print('    → it does NOT separate composition.  No factoring help.')


if __name__ == '__main__':
    main()
