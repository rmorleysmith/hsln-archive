"""DNA = truncated Fourier coefficients of a form (spec sec 2.2).

The network's actual finite landscape is F(tau) = sum_n a_n q^n. The zeros of F in
the q-disk are the neurons. We keep:
  - the genus-1 E8 form E4 (one neuron at rho),
  - the (g,k,N)=(1,4,11) PoC target: newform 11.4.a.a from LMFDB,
  - helpers to design a DNA with prescribed neuron positions (illustrating the IFT
    "tweak a coefficient -> move a neuron" claim and the multiplicative merge).
"""
from __future__ import annotations

import numpy as np

SQRT3 = np.sqrt(3.0)

# LMFDB newform 11.4.a.a, rational embedding beta = +sqrt(3). Cusp form => a0 = 0.
# Coefficients a0..a5 (Sturm bound for weight 4 level 11 is 5).
# https://www.lmfdb.org/ModularForm/GL2/Q/holomorphic/11/4/a/a/
LEVEL11_4 = np.array(
    [0.0, 1.0, SQRT3 + 1.0, -4.0 * SQRT3 - 1.0, 2.0 * SQRT3 - 4.0, 8.0 * SQRT3 + 1.0],
    dtype=float,
)

# E4 truncated to the same order, for reference (1 + 240 q + 2160 q^2 + ...).
E4_TRUNC = np.array([1.0, 240.0, 2160.0, 6720.0, 17520.0, 30240.0], dtype=float)


def q_of_tau(tau):
    return np.exp(2j * np.pi * np.asarray(tau, dtype=np.complex128))


def tau_of_q(q):
    q = np.asarray(q, dtype=np.complex128)
    tau = np.log(q) / (2j * np.pi)
    return (tau.real % 1.0) + 1j * tau.imag


def dna_from_neurons(taus, lead=1.0):
    """Truncated-form coefficients (ascending) whose q-roots sit at the given taus.

    Normalized to unit max-magnitude: scaling F by a constant moves no zeros and
    only rescales the flow speed, but it keeps high-degree coefficients in range.
    """
    qs = q_of_tau(np.asarray(taus, dtype=np.complex128))
    poly_desc = np.poly(qs)  # prod (q - q_i), highest power first
    c = (poly_desc[::-1] * lead).astype(np.complex128)
    return c / np.max(np.abs(c))


if __name__ == "__main__":
    import modular

    for name, c in (("E4 (trunc)", E4_TRUNC), ("11.4.a.a", LEVEL11_4)):
        z = modular.qpoly_zeros(c)
        print(f"{name}: {len(z)} neuron(s) in the q-disk")
        for t in sorted(z, key=lambda w: -w.imag):
            print(f"    tau = {t.real:+.4f} {t.imag:+.4f}i   |q| = {abs(q_of_tau(t)):.4f}")
