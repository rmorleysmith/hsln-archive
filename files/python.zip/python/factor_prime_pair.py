#!/usr/bin/env python3
"""factor_prime_pair.py — factor a large semiprime via composable per-prime detection.

================================================================================

In our HSLN framework the prime sieve (fig 31, `viz/prime_sieve.py`) builds the
indicator of primes as the *composition* of per-prime detectors:
   `is_prime(n) = ∏ over primes p < √n of  [p ∤ n]`.
The dual operation — factoring — is finding a SINGLE prime detector that fires.

For a semiprime `N = p · q` the bridge's Dirichlet ring gives `(ζ * ζ)(N) = d(N) = 4`
(divisors: 1, p, q, N). The four divisors are the algebraic data; the search problem is
locating two of them efficiently.

This script demonstrates Pollard's rho with Brent's cycle-finding improvement, framed as
the composable per-prime view:

  * Iterate `f(x) = x² + c mod N` starting from random `x₀`.
  * Modulo any prime divisor `p | N`, the orbit enters a cycle of expected length √p
    (Birthday paradox on `ℤ/pℤ`).
  * The orbit modulo `N` only enters a *global* cycle once its image under every
    `mod p` projection cycles. So the FIRST cycle to close (detected via `gcd(x_i - x_j, N)`
    > 1) reveals the SMALLEST prime divisor.
  * "Per-prime detection composed" — same composition pattern as the sieve, dual direction.

Brent's improvement uses geometric backoff (powers-of-2 epochs) rather than Floyd's tortoise-
and-hare, giving ~25% speedup. Cycle length expected `O(√N^{1/4})` operations to find the
smallest prime divisor `p ≤ √N`.

Runtime scaling: for `N = pq` with each prime ~k bits, rho is O(2^{k/2}). Brent's variant
on 48-bit primes (~96-bit semiprime) takes a few seconds in Python; pushing to 64-bit primes
(~128-bit semiprime) takes minutes-to-hours.

We demonstrate the algorithm across a range of bit-widths, reporting timings.
"""

import secrets
import time
from math import gcd


# ────────────────────────────────────────────────────────────────────────────────
#   Miller-Rabin primality (deterministic for n < 3.3 × 10^24 with the witness set
#   below per Sorenson-Webster 2017; probabilistic but extremely strong above).
# ────────────────────────────────────────────────────────────────────────────────

_SMALL_PRIMES = (
    2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
    73, 79, 83, 89, 97, 101, 103, 107, 109, 113,
)

# Deterministic Miller-Rabin witnesses for n < ~3.3 × 10^24 (Sorenson-Webster).
_MR_WITNESSES = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41)


def is_prime(n: int) -> bool:
    """Deterministic for n < 3.3e24; strong probable-prime above.

    Implements Miller-Rabin with the Sorenson-Webster 2017 witness set, which is
    deterministic for all n < 3,317,044,064,679,887,385,961,981. For larger n the same
    witnesses give an *extraordinarily* strong probabilistic test (no known false
    positives in the cryptographic literature for these witnesses on inputs that pass).
    """
    if n < 2:
        return False
    for p in _SMALL_PRIMES:
        if n == p:
            return True
        if n % p == 0:
            return False

    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1

    for a in _MR_WITNESSES:
        if a >= n:
            continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = (x * x) % n
            if x == n - 1:
                break
        else:
            return False
    return True


def random_prime_of_bits(bits: int) -> int:
    """Generate a random prime of EXACTLY `bits` bits.

    Sets the top bit (length is exactly `bits`) and the bottom bit (odd), then
    rejection-samples until our Miller-Rabin passes.
    """
    while True:
        candidate = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if is_prime(candidate):
            return candidate


def pollard_brent(N: int, *, max_attempts: int = 12) -> int | None:
    """Find a nontrivial factor of `N` via Pollard's rho + Brent.

    Returns a divisor `d` with `1 < d < N`, or None if all attempts fail.

    Composable view: the iteration `f(x) = x² + c mod N` projects, via the CRT, to
    independent iterations on each `ℤ/pℤ` for `p | N`. The composition of these per-prime
    iterations is what we observe modulo `N`. Brent's epoch structure (geometric backoff
    on epoch length) lets us batch the GCD test, amortising the costly large-integer
    `gcd` over many cheap squarings.
    """
    if N % 2 == 0:
        return 2

    for _ in range(max_attempts):
        # Random seed + random polynomial constant — different (x₀, c) hit different
        # rho-shaped trajectories.
        y = secrets.randbelow(N - 2) + 2
        c = secrets.randbelow(N - 1) + 1
        m = 128  # batch size for cumulative-product GCD

        g, r, q = 1, 1, 1
        x, ys = y, y

        while g == 1:
            x = y
            for _ in range(r):
                y = (y * y + c) % N
            k = 0
            while k < r and g == 1:
                ys = y
                lim = min(m, r - k)
                for _ in range(lim):
                    y = (y * y + c) % N
                    q = (q * abs(x - y)) % N
                g = gcd(q, N)
                k += m
            r *= 2

        if g == N:
            # Cumulative product zeroed out the gcd: backtrack the last epoch and
            # check one at a time.
            while True:
                ys = (ys * ys + c) % N
                g = gcd(abs(x - ys), N)
                if g > 1:
                    break

        if 1 < g < N:
            return g

    return None


def factor_semiprime(N: int) -> tuple[int, int] | None:
    """Factor a semiprime `N = p·q` into its two primes (sorted ascending)."""
    d = pollard_brent(N)
    if d is None or not (1 < d < N):
        return None
    p, q = d, N // d
    return (p, q) if p <= q else (q, p)


# ────────────────────────────────────────────────────────────────────────────────
#   Demo
# ────────────────────────────────────────────────────────────────────────────────

def fmt_int(n: int, max_visible: int = 28) -> str:
    """Format a possibly-big int for printing — middle-truncate if too long."""
    s = str(n)
    if len(s) <= max_visible:
        return s
    keep = (max_visible - 1) // 2
    return f"{s[:keep]}…{s[-keep:]} ({len(s)} digits)"


def run_demo(bit_widths: list[int]) -> None:
    print("=" * 78)
    print(" Composable per-prime detection — factoring N = p·q via Pollard-Brent")
    print("=" * 78)
    print()
    print(f"{'bits/prime':>10}  {'N bits':>7}  {'N digits':>8}  {'time (s)':>10}  status")
    print("─" * 78)

    for bits in bit_widths:
        p = random_prime_of_bits(bits)
        q = random_prime_of_bits(bits)
        while q == p:
            q = random_prime_of_bits(bits)
        N = p * q
        n_bits = N.bit_length()
        n_digits = len(str(N))

        t0 = time.perf_counter()
        result = factor_semiprime(N)
        elapsed = time.perf_counter() - t0

        if result is None:
            print(f"{bits:>10}  {n_bits:>7}  {n_digits:>8}  {elapsed:>10.3f}  FAILED")
            continue

        p_found, q_found = result
        p_true, q_true = sorted((p, q))
        assert (p_found, q_found) == (p_true, q_true), (
            f"factorisation mismatch: got ({p_found}, {q_found}), "
            f"expected ({p_true}, {q_true})"
        )

        print(f"{bits:>10}  {n_bits:>7}  {n_digits:>8}  {elapsed:>10.3f}  OK")
        print(f"            p = {fmt_int(p_found)}")
        print(f"            q = {fmt_int(q_found)}")
        print(f"            N = {fmt_int(N)}")
        print()


if __name__ == "__main__":
    import sys

    # Default: scale up across bit widths.
    if len(sys.argv) > 1:
        widths = [int(arg) for arg in sys.argv[1:]]
    else:
        widths = [32, 40, 48, 56, 64]

    run_demo(widths)
