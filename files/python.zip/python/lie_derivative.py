"""The Lie derivative of the system — two faces of one generator.

[REDACTED NAME] asked: "what's the Lie derivative of the system? can we teach the model its own Lie
derivative?" There are two Lie derivatives at play, and the model knows both.

(1) ALONG THE FLOW (the dynamics).  The HSLN is a gradient flow  Ż = −∇E  on the modular energy
    E(Z) = |F(Z)|²  (F a modular form; its zeros are the neurons). The Lie derivative of any
    observable g along the flow field X = Ż is  L_X g = ∇g · Ż.  For the energy itself

        L_X E  =  dE/dt  =  ∇E · (−∇E)  =  −|∇E|²  ≤ 0,

    the Lyapunov dissipation: energy falls monotonically into a zero. We verify this identity
    numerically along a trajectory.

(2) ALONG THE MODULAR SYMMETRY (the q-grading).  The generator of the dilation q ↦ λq is the
    Euler operator  D = q d/dq,  which on a q-expansion is simply  aₙ ↦ n·aₙ.  The deep fact
    (Ramanujan/Halphen) is that the ring of (quasi)modular forms C[E₂,E₄,E₆] is CLOSED under its
    own Lie derivative:

        D E₂ = (E₂² − E₄)/12,   D E₄ = (E₂E₄ − E₆)/3,   D E₆ = (E₂E₆ − E₄²)/2.

    So the model can compute its own derivative and stay in the space. The weight-corrected
    (Serre) derivative ϑ_k = D − (k/12)E₂ climbs the weight ladder Mₖ → Mₖ₊₂ exactly:

        ϑ E₄ = −E₆/3   (weight 4 → 6),     ϑ E₆ = −E₄²/2   (weight 6 → 8).

THE BRIDGE.  The SAME Euler/dilation generator, read in the Dirichlet basis n^{-s}, acts as
aₙ ↦ aₙ·log n. Applied to the Riemann generator ζ and normalised by ζ⁻¹=μ it is −ζ'/ζ = Λ — the
primes (fig 37 / HSLNAlgebra.lean). One Lie derivative, two bases: q-grading ↔ Dirichlet-grading.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np


# --------------------------------------------------------------------- (1) the flow's Lie derivative
# F(z) = (z − z1)(z − z2): a "form" with two zeros (the neurons). E = |F|², gradient flow Ż = −∇E.
Z1, Z2 = -0.60 + 0.85j, 0.70 + 0.55j


def _F(z):
    return (z - Z1) * (z - Z2)


def _energy(z):
    return np.abs(_F(z)) ** 2


def _grad(z):
    """∇E in (x,y) for E=|F|², F holomorphic: ∇E = (2 Re w, −2 Im w), w = conj(F)·F'."""
    Fp = (z - Z1) + (z - Z2)
    w = np.conj(_F(z)) * Fp
    return np.array([2 * w.real, -2 * w.imag])


def flow(z0, dt=2.0e-4, steps=6000):
    z = z0
    zs, Es, dissip = [], [], []
    for _ in range(steps):
        g = _grad(z)
        zs.append(z); Es.append(_energy(z)); dissip.append(-(g @ g))
        # RK4 on  d(x,y)/dt = −∇E
        def f(p):
            return -_grad(p[0] + 1j * p[1])
        p = np.array([z.real, z.imag])
        k1 = f(p); k2 = f(p + dt / 2 * k1); k3 = f(p + dt / 2 * k2); k4 = f(p + dt * k3)
        p = p + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        z = p[0] + 1j * p[1]
    return np.array(zs), np.array(Es), np.array(dissip), dt


# --------------------------------------------------------------------- (2) the modular Lie derivative
N = 12  # truncation; integer coefficients stay exact in float64 at this order


def sigma_k(n, k):
    return sum(d ** k for d in range(1, n + 1) if n % d == 0)


def eisenstein(k, N=N):
    const, power = {2: (-24, 1), 4: (240, 3), 6: (-504, 5)}[k]
    a = np.zeros(N + 1); a[0] = 1.0
    for n in range(1, N + 1):
        a[n] = const * sigma_k(n, power)
    return a


def D(a):                       # q d/dq :  aₙ ↦ n·aₙ
    return a * np.arange(len(a))


def qmul(a, b, N=N):            # product of q-series, truncated
    return np.convolve(a, b)[:N + 1]


def run(make_fig=True):
    # ---- flow Lie derivative ----
    zs, Es, dissip, dt = flow(-1.15 + 1.55j)
    dEdt = np.gradient(Es, dt)                       # numerical L_X E along the trajectory
    interior = slice(2, len(Es) - 2)
    rel = np.abs(dEdt[interior] - dissip[interior]) / (np.abs(dissip[interior]) + 1e-9)
    print(f"(1) flow Lie derivative  L_X E = dE/dt vs −|∇E|² : max rel. error "
          f"{rel.max():.2e}  (energy {Es[0]:.3f} → {Es[-1]:.2e}, monotone={np.all(np.diff(Es)<=1e-9)})")

    # ---- modular Lie derivative: the Ramanujan closed system ----
    E2, E4, E6 = eisenstein(2), eisenstein(4), eisenstein(6)
    res2 = np.abs(D(E2) - (qmul(E2, E2) - E4) / 12).max()
    res4 = np.abs(D(E4) - (qmul(E2, E4) - E6) / 3).max()
    res6 = np.abs(D(E6) - (qmul(E2, E6) - qmul(E4, E4)) / 2).max()
    print(f"(2) Ramanujan: forms closed under their own Lie derivative D=q d/dq")
    print(f"    |DE₂−(E₂²−E₄)/12|={res2:.1e}  |DE₄−(E₂E₄−E₆)/3|={res4:.1e}  "
          f"|DE₆−(E₂E₆−E₄²)/2|={res6:.1e}")

    # ---- Serre derivative climbs the weight ladder ----
    theta4 = D(E4) - (4 / 12) * qmul(E2, E4)         # weight 4 → 6, should be −E6/3
    theta6 = D(E6) - (6 / 12) * qmul(E2, E6)         # weight 6 → 8, should be −E4²/2
    sres4 = np.abs(theta4 - (-E6 / 3)).max()
    sres6 = np.abs(theta6 - (-qmul(E4, E4) / 2)).max()
    print(f"    Serre ϑ raises weight: |ϑE₄−(−E₆/3)|={sres4:.1e} (M₄→M₆)  "
          f"|ϑE₆−(−E₄²/2)|={sres6:.1e} (M₆→M₈)")
    assert max(res2, res4, res6, sres4, sres6) < 1e-6 and rel.max() < 5e-3

    if make_fig:
        _figure(zs, Es, dissip, dEdt, dt, (E2, E4, E6, theta4, theta6))
    return True


def _figure(zs, Es, dissip, dEdt, dt, modular):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    INK, PAPER = "#0a0a12", "#e8e6f0"
    TEAL, GOLD, NEURON, GREEN, VIO = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A", "#c0a3ff"
    E2, E4, E6, theta4, theta6 = modular
    t = np.arange(len(Es)) * dt

    fig = plt.figure(figsize=(16.5, 9.2))
    gs = fig.add_gridspec(2, 2, hspace=0.34, wspace=0.24)
    A = fig.add_subplot(gs[0, 0]); B = fig.add_subplot(gs[0, 1])
    C = fig.add_subplot(gs[1, 0]); Dax = fig.add_subplot(gs[1, 1])

    # --- A: gradient flow on |F|² descending to a zero (neuron) ---
    xs = np.linspace(-1.6, 1.4, 400); ys = np.linspace(0.1, 1.8, 400)
    X, Y = np.meshgrid(xs, ys)
    EE = _energy(X + 1j * Y)
    A.contourf(X, Y, np.log10(EE + 1e-6), levels=40, cmap="magma")
    A.plot(zs.real, zs.imag, color=TEAL, lw=2.2, label="HSLN trajectory  Ż = −∇E")
    A.plot([zs.real[0]], [zs.imag[0]], "o", color=PAPER, ms=7)
    for z in (Z1, Z2):
        A.plot([z.real], [z.imag], "*", color=GREEN, ms=16,
               label="zero of F (neuron = equilibrium)" if z is Z1 else None)
    A.set_xlabel("Re Z"); A.set_ylabel("Im Z")
    A.set_title("the flow on the modular energy  E = |F|²\n(gradient descent into a zero)", fontsize=12)
    A.legend(loc="upper right", fontsize=8.2, framealpha=0.35)

    # --- B: the flow's Lie derivative  L_X E = dE/dt = −|∇E|²  ---
    B.plot(t, dEdt, color=GOLD, lw=3.4, alpha=0.85, label=r"$dE/dt$ (numerical $L_X E$)")
    B.plot(t, dissip, color=NEURON, lw=1.3, ls="--", label=r"$-|\nabla E|^2$ (predicted)")
    B.set_xlabel("time t"); B.set_ylabel(r"$L_X E$")
    B.set_title("the flow's Lie derivative IS the dissipation\n"
                r"$L_X E = dE/dt = -|\nabla E|^2 \leq 0$  (Lyapunov)", fontsize=12)
    B.legend(loc="lower right", fontsize=9, framealpha=0.35)
    bin = B.inset_axes([0.55, 0.55, 0.42, 0.4])
    bin.plot(t, Es, color=TEAL, lw=2)
    bin.set_title("E(t) ↓", fontsize=8, color=PAPER); bin.tick_params(labelsize=6)
    bin.set_facecolor(INK)

    # --- C: the modular Lie derivative — Ramanujan closed system (E4 shown) ---
    ns = np.arange(len(E4))
    lhs = D(E4); rhs = (qmul(E2, E4) - E6) / 3
    C.vlines(ns, 0, lhs, color=VIO, lw=2.4, label=r"$D E_4 = q\,dE_4/dq$  (Lie derivative)")
    C.plot(ns, rhs, "o", color=GOLD, ms=8, mfc="none", mew=1.8,
           label=r"$(E_2 E_4 - E_6)/3$  (back in the ring)")
    C.set_xlabel("q-power n"); C.set_ylabel("coefficient")
    C.set_title("the form is closed under its own Lie derivative\n"
                r"Ramanujan: $D E_4 = (E_2 E_4 - E_6)/3$ — the model computes $DE$ and stays modular",
                fontsize=12)
    C.legend(loc="upper left", fontsize=8.6, framealpha=0.35)

    # --- D: the Serre-corrected Lie derivative climbs the weight ladder ---
    E4sq = qmul(E4, E4)
    Dax.vlines(ns - 0.12, 0, theta4 / (np.abs(theta4).max()), color=TEAL, lw=2.2,
               label=r"$\vartheta E_4$  (= $-E_6/3$, weight 4→6)")
    Dax.plot(ns - 0.12, (-E6 / 3) / (np.abs(theta4).max()), "o", color=TEAL, ms=5, mfc="none")
    Dax.vlines(ns + 0.12, 0, theta6 / (np.abs(theta6).max()), color=NEURON, lw=2.2,
               label=r"$\vartheta E_6$  (= $-E_4^2/2$, weight 6→8)")
    Dax.plot(ns + 0.12, (-E4sq / 2) / (np.abs(theta6).max()), "s", color=NEURON, ms=5, mfc="none")
    Dax.axhline(0, color="#555", lw=0.7)
    Dax.set_xlabel("q-power n"); Dax.set_ylabel("coefficient (scaled)")
    Dax.set_title("the Lie derivative climbs the weight ladder\n"
                  r"Serre $\vartheta = D - \frac{k}{12}E_2$ :  $M_k \to M_{k+2}$, staying modular",
                  fontsize=12)
    Dax.legend(loc="upper right", fontsize=8.4, framealpha=0.35)
    Dax.text(0.02, 0.03,
             "same generator in the Dirichlet basis:\n" r"$a_n\mapsto a_n\log n$,  $-\zeta'/\zeta=\Lambda$ → primes",
             transform=Dax.transAxes, color="#9a96b0", fontsize=8.0, va="bottom")

    fig.suptitle("The Lie derivative of the system: along the FLOW it is the dissipation "
                 r"$L_X E=-|\nabla E|^2$; along the MODULAR grading it is $D=q\,d/dq$, and the "
                 "ring is closed under it (Ramanujan)", fontsize=12.5, y=0.99)
    out = Path(__file__).parent / "figures" / "38_lie_derivative.png"
    fig.savefig(out, dpi=160, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
