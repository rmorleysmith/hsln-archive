"""hsln_bignum_factor.py — train HSLN onto pos(N), then map zeros back to candidate
primes via the inverse of frac(log₂ ·) and trial-divide N.

Per hsln_factor_dna.py: the spike at Re τ = α corresponds to position α on the lane,
and inverting the encoding gives candidate integers  round(2^(k + α))  for k ∈ ℤ.
For a 1024-bit N = p·q with balanced factors, each factor is ~512 bits, so we sweep
k around 512 (and a wide margin around it) for each zero's position.

We test every candidate against N: if N % cand == 0, we've factored it.
"""

from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import numpy as np
import mpmath as mp

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import modular
import hsln_factor_dna as hfd


N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)


def pos_of_bigint(n: int, dps: int = 1100) -> float:
    mp.mp.dps = dps
    L = mp.log(n, 2)
    return float(L - mp.floor(L))


def candidate_prime_from_position(alpha: float, k: int) -> int:
    """round(2^(k + alpha))  computed at enough precision to be the nearest integer.

    For k up to ~1024 we need ~k log10(2) ≈ 300+ decimal digits of mp precision.
    """
    mp.mp.dps = max(60, int(k * 0.302) + 40)
    val = mp.power(2, mp.mpf(k) + mp.mpf(alpha))
    return int(mp.nint(val))


def try_recover_factor(positions, N, k_lo=2, k_hi=1024,
                       wiggle_k=2, wiggle_int=2):
    """For every (α, k) in positions × [k_lo..k_hi], test  round(2^(k+α))  for divisibility.

    Also wiggle ±wiggle_int around each candidate (snap noise) and ±wiggle_k bit-widths.
    Returns list of (alpha, k, candidate, factor_found) for any hits.
    """
    hits = []
    tested = 0
    t0 = time.perf_counter()
    for alpha_idx, alpha in enumerate(positions):
        for k in range(k_lo, k_hi + 1):
            cand0 = candidate_prime_from_position(alpha, k)
            # try wiggle around the exact snap
            for di in range(-wiggle_int, wiggle_int + 1):
                cand = cand0 + di
                if cand <= 1:
                    continue
                tested += 1
                if N % cand == 0 and cand != 1 and cand != N:
                    hits.append((alpha_idx, alpha, k, cand, N // cand))
                    print(f'   ✓ HIT: α={alpha:.4f} k={k} di={di}  cand={cand}  '
                          f'N/cand={N // cand}')
        # status print
        elapsed = time.perf_counter() - t0
        print(f'   α[{alpha_idx}]={alpha:.4f}: swept k∈[{k_lo}..{k_hi}], '
              f'wiggle ±{wiggle_int} ints   ({tested} cands, {elapsed:.1f}s, '
              f'{len(hits)} hits so far)')
    return hits, tested


def try_paired_factor(positions, pos_N, N, k_lo=2, k_hi=1024, wiggle_int=2):
    """Per Multiplicative law pos(p)+pos(q) ≡ pos(N) mod 1, for each zero α treat α as
    pos(p) and infer pos(q) = (pos_N - α) mod 1. Try the integer candidates at every
    bit-size for BOTH α and the inferred partner; flag if either divides N.
    """
    hits = []
    tested = 0
    t0 = time.perf_counter()
    for alpha_idx, alpha in enumerate(positions):
        partner = (pos_N - alpha) % 1.0
        for k in range(k_lo, k_hi + 1):
            cand_a0 = candidate_prime_from_position(alpha, k)
            cand_b0 = candidate_prime_from_position(partner, k)
            for cand0 in (cand_a0, cand_b0):
                for di in range(-wiggle_int, wiggle_int + 1):
                    cand = cand0 + di
                    if cand <= 1:
                        continue
                    tested += 1
                    if N % cand == 0 and cand != 1 and cand != N:
                        hits.append((alpha_idx, alpha, k, cand, N // cand))
                        print(f'   ✓ HIT (paired): α={alpha:.4f} partner={partner:.4f} '
                              f'k={k} di={di}  cand={cand}  N/cand={N // cand}')
        elapsed = time.perf_counter() - t0
        print(f'   α[{alpha_idx}]={alpha:.4f} (partner={partner:.4f}): '
              f'{tested} cands, {elapsed:.1f}s, {len(hits)} hits')
    return hits, tested


def main():
    print("=" * 78)
    print('  HSLN → factor recovery on a 309-digit candidate semiprime')
    print("=" * 78)

    n_bits = N.bit_length()
    print(f'\n  N has {len(str(N))} decimal digits, {n_bits} bits.')

    pos_N = pos_of_bigint(N)
    print(f'  pos(N) = frac(log2 N) = {pos_N:.10f}')

    # ── Train F_N (same as in hsln_bignum_dna.py) ─────────────────────────────
    probes = np.array(hsln.PROBES)
    probe_idx = hfd.closest_probe(pos_N)
    target = np.zeros_like(probes, dtype=float)
    target[probe_idx] = 1.0
    print(f'\n  Training F_N (dg=12, steps=3000, target = probe {probe_idx} at '
          f'{float(probes[probe_idx]):.4f}) ...')
    net, hist = hfd.train(target, dg=12, steps=3000, seed=0)
    print(f'  loss: {hist[0]:.4f} → {hist[-1]:.6f}')

    dna = np.asarray(net.dna)
    zeros = modular.qpoly_zeros(dna)
    zero_positions = sorted({float(z.real % 1.0) for z in zeros})
    print(f'\n  Trained DNA has {len(zeros)} zeros.')
    print(f'  Zero positions (Re τ mod 1): {[f"{a:.4f}" for a in zero_positions]}')

    # ── Bit-size sweep range ──────────────────────────────────────────────────
    # Balanced semiprime: each factor ~n_bits/2 = 512 bits. Sweep ±200 bits around it.
    K_LO = max(2, n_bits // 2 - 200)
    K_HI = min(n_bits - 1, n_bits // 2 + 200)
    print(f'\n  Sweeping bit-widths k ∈ [{K_LO}..{K_HI}] (=balanced ±200) for each zero.')

    # ── Attempt 1: each zero's position directly ──────────────────────────────
    print(f'\n  ── Attempt 1: round(2^(k+α)) for each zero α ──')
    hits1, t1 = try_recover_factor(zero_positions, N, K_LO, K_HI,
                                   wiggle_int=4)
    print(f'  → {t1} candidates tested, {len(hits1)} factors found')

    # ── Attempt 2: zero α treated as pos(p), partner inferred via pos(N)-α ───
    print(f'\n  ── Attempt 2: paired (α, pos(N)−α mod 1) ──')
    hits2, t2 = try_paired_factor(zero_positions, pos_N, N, K_LO, K_HI,
                                  wiggle_int=4)
    print(f'  → {t2} candidates tested, {len(hits2)} factors found')

    # ── Attempt 3: use the TRUE pos(N) directly (not via model) ──────────────
    # Logical sanity check: if 2^(k+pos_N) somehow snapped to N for some k, we'd
    # see it as a self-test. (Should be k = n_bits-1 and the rounding gives N.)
    print(f'\n  ── Sanity attempt: 2^(k+pos_N) at k=n_bits-1 should reconstruct N ──')
    mp.mp.dps = 400
    val_check = mp.power(2, mp.mpf(n_bits - 1) + mp.mpf(pos_N))
    cand_check = int(mp.nint(val_check))
    match = (cand_check == N)
    print(f'   k = {n_bits-1}, snap = 2^(k+pos_N) gives integer with {len(str(cand_check))} digits')
    print(f'   matches N exactly: {match}')

    # ── Summary ───────────────────────────────────────────────────────────────
    print()
    print('=' * 78)
    print('  Result')
    print('=' * 78)
    total_hits = hits1 + hits2
    if total_hits:
        print(f'  ★ FOUND {len(total_hits)} non-trivial factor(s) of N!')
        for alpha_idx, alpha, k, cand, cofactor in total_hits:
            print(f'     α = {alpha:.4f}   k = {k}   factor = {cand}')
            print(f'                                   N / factor = {cofactor}')
            # Verify primality of small factor (light Miller-Rabin)
            try:
                from factor_prime_pair import is_prime
                if is_prime(cand):
                    print(f'     ✓ cand is prime')
                else:
                    print(f'     ✗ cand is COMPOSITE — can iterate')
            except Exception as e:
                print(f'     (primality check skipped: {e})')
    else:
        print('  ✗ No factor recovered from any zero position at any bit width.')
        print(f'    Searched {t1 + t2} candidates over {len(zero_positions)} positions '
              f'× {K_HI - K_LO + 1} bit-widths × 9 wiggles.')
        print()
        print('  Why this was always going to be hard:')
        print('  • pos(p·q) ≡ pos(p) + pos(q) mod 1 is a homomorphism collapsing 2D → 1D.')
        print('  • F_N was trained with one-hot loss at pos(N) — it has no factor info to')
        print('    encode in the first place.')
        print('  • The 5 secondary zeros of F_N sit BELOW the lane (Im τ < 0.11) — they')
        print('    are optimisation filler, not factor coordinates.')
        print()
        print('  The structural composition rule (F_p⊗F_q = conv) needs F_p, F_q as inputs.')
        print('  Going from F_N back to (F_p, F_q) is the missing inverse — and no construction')
        print('  in this framework provides it. Recovery requires the actual algorithmic')
        print('  factorisation of N, which HSLN does not perform.')


if __name__ == '__main__':
    main()
