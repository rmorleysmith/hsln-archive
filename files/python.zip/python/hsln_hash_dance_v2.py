"""hsln_hash_dance_v2.py — Same HSLN-dance demo, but on a hash given by hex string.

Input: 64-hex-char string (SHA-256 of some unknown message).
We treat the 32 bytes as 32 positions on the input lane and build the composed
length-33 DNA (HSLN tensor product of 32 single-neuron networks) by exact Vieta
convolution. Reuses the routines from hsln_hash_dance.py.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln    # local
import modular # local
from hsln_hash_dance import compose_all, atomic_dna  # reuse construction

mpl.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'legend.fontsize': 9,
})

FIG_DIR = HERE / 'figures'
LANE_Y = hsln.LANE_Y


def figure_hash_dance(hex_hash: str, positions: np.ndarray, digest: bytes,
                      dna: np.ndarray, save_path: Path, label: str):
    fig = plt.figure(figsize=(15.5, 13.5))
    gs = fig.add_gridspec(4, 2, height_ratios=[1, 1, 1.4, 1.4],
                          hspace=0.55, wspace=0.30)

    bytes_arr = np.frombuffer(digest, dtype=np.uint8)

    ax = fig.add_subplot(gs[0, :])
    indices = np.arange(32)
    bar_colors = plt.cm.twilight(bytes_arr / 255.0)
    ax.bar(indices, bytes_arr, color=bar_colors, edgecolor='black',
           linewidth=0.4, width=0.85)
    for i, b in enumerate(bytes_arr):
        ax.annotate(f'{b:02x}', (i, b), textcoords='offset points',
                    xytext=(0, 4), ha='center', fontsize=7.5, family='monospace')
    ax.set_xlim(-0.6, 31.6); ax.set_ylim(0, 290)
    ax.set_xticks(indices)
    ax.set_xticklabels([f'{t}' for t in indices], fontsize=8)
    ax.set_xlabel('byte index t')
    ax.set_ylabel('byte value  b_t ∈ [0, 255]')
    ax.set_title(f'A. The score — {label}\n   {hex_hash}', fontsize=11)
    ax.grid(alpha=0.3, axis='y')

    ax = fig.add_subplot(gs[1, :])
    for i, (pos, b) in enumerate(zip(positions, bytes_arr)):
        color = plt.cm.twilight(b / 255.0)
        ax.vlines(pos, 0, 1, color=color, linewidth=2.5, alpha=0.95)
        ax.scatter([pos], [1], s=70, color=color, edgecolor='black',
                   linewidth=0.4, zorder=5)
        ax.annotate(f'{i}', (pos, 1.05), ha='center', fontsize=7.5)
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.18)
    ax.set_xlabel(f'position on input lane  Re τ ∈ [0, 1)   (Im τ = LANE_Y = {LANE_Y})')
    ax.set_yticks([])
    ax.set_title('B. The dance floor — 32 hash bytes mapped to 32 positions  pos_t = b_t / 256')
    ax.grid(alpha=0.3, axis='x')

    ax = fig.add_subplot(gs[2, 0])
    mags = np.abs(dna)
    indices_dna = np.arange(len(dna))
    ax.bar(indices_dna, mags, color='#2ca02c', edgecolor='black',
           alpha=0.85, width=0.85)
    ax.set_xlabel('coefficient index n')
    ax.set_ylabel('|aₙ|')
    ax.set_title(f'C. Composed DNA magnitudes  |aₙ|   (dg = {len(dna)})')
    ax.set_xlim(-0.6, len(dna) - 0.4)
    ax.grid(alpha=0.3, axis='y')

    ax = fig.add_subplot(gs[2, 1])
    cmap = plt.cm.viridis
    cols = cmap(indices_dna / max(indices_dna.max(), 1))
    ax.plot(dna.real, dna.imag, '-', color='gray', alpha=0.4, linewidth=1)
    for i, (an, c) in enumerate(zip(dna, cols)):
        ax.scatter(an.real, an.imag, color=c, s=80, edgecolor='black',
                   linewidth=0.4, zorder=5)
        if i in {0, len(dna) - 1} or i % 8 == 0:
            ax.annotate(f'a{i}', (an.real, an.imag),
                        textcoords='offset points', xytext=(7, 4),
                        fontsize=8, fontweight='bold')
    ax.axhline(0, color='black', linewidth=0.4)
    ax.axvline(0, color='black', linewidth=0.4)
    M = max(mags) * 1.15
    ax.set_xlim(-M, M); ax.set_ylim(-M, M)
    ax.set_xlabel('Re aₙ'); ax.set_ylabel('Im aₙ')
    ax.set_aspect('equal')
    ax.set_title('D. DNA path in ℂ  (33 coefficients ordered by n)')
    ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[3, 0])
    xs = np.linspace(0.0, 1.0, 2000)
    tau_dense = xs + 1j * LANE_Y
    F_vals = modular.qpoly(dna, tau_dense)
    fmag = np.abs(F_vals)
    spike = 1.0 / (fmag + 1e-12)
    spike_norm = spike / spike.max()
    ax.fill_between(xs, 0, spike_norm, color='#9467bd', alpha=0.60)
    ax.plot(xs, spike_norm, color='#54286b', linewidth=1.0)
    for pos, b in zip(positions, bytes_arr):
        ax.axvline(pos, color=plt.cm.twilight(b / 255.0), alpha=0.45,
                   linewidth=0.7, linestyle='--')
    ax.set_xlim(0, 1); ax.set_ylim(-0.02, 1.08)
    ax.set_xlabel('Re τ'); ax.set_ylabel('normalised spike  1/|F|')
    ax.set_title('E. Spike map  1/|F(τ)|  along the lane')
    ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[3, 1])
    Nx, Ny = 300, 200
    xs_g = np.linspace(0.0, 1.0, Nx)
    ys_g = np.linspace(0.05, 0.45, Ny)
    Xg, Yg = np.meshgrid(xs_g, ys_g)
    F_grid = modular.qpoly(dna, Xg + 1j * Yg)
    logF = np.log10(np.abs(F_grid) + 1e-12)
    pcm = ax.pcolormesh(Xg, Yg, logF, shading='auto', cmap='magma_r',
                        vmin=np.percentile(logF, 5), vmax=np.percentile(logF, 95))
    plt.colorbar(pcm, ax=ax, label='log₁₀ |F(τ)|')
    for pos, b in zip(positions, bytes_arr):
        ax.scatter([pos], [LANE_Y], marker='o', s=70,
                   edgecolor=plt.cm.twilight(b / 255.0),
                   facecolors='none', linewidth=1.6)
    ax.axhline(LANE_Y, color='cyan', linestyle='--', linewidth=0.7, alpha=0.5)
    ax.set_xlim(0, 1); ax.set_ylim(0.05, 0.45)
    ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
    ax.set_title('F. Neuron landscape — log₁₀|F(τ)| with all 32 zeros marked')

    fig.suptitle(f'HSLN dances to {label}\n'
                 f'32 hash bytes → 32 neurons → composed DNA of length 33',
                 fontsize=14, y=0.998)
    fig.savefig(save_path, dpi=140, bbox_inches='tight')
    plt.close(fig)


def main():
    HEX = '12765c998f116a621a3b1a9eaa5b7ab94a06f623233d782bdfaf51c3b7e95b92'
    print("=" * 78)
    print(f'  HSLN dances to an unknown SHA-256')
    print("=" * 78)
    print(f'\n  Hash: {HEX}')
    assert len(HEX) == 64, f'expected 64 hex chars, got {len(HEX)}'
    digest = bytes.fromhex(HEX)
    bytes_arr = np.frombuffer(digest, dtype=np.uint8)
    positions = bytes_arr / 256.0
    print(f'  Byte count: {len(digest)}')

    # ── Byte stats and entropy hints ─────────────────────────────────────────
    print(f'\n  Byte stats:')
    print(f'    min = {bytes_arr.min()}, max = {bytes_arr.max()}, mean = {bytes_arr.mean():.1f}')
    # Histogram into 16 buckets to check for uniformity
    h, _ = np.histogram(bytes_arr, bins=16, range=(0, 256))
    print(f'    16-bucket histogram: {h.tolist()}')
    print(f'    expected uniform: {32/16:.1f} per bucket')

    # ── Distance to other known hashes (does it match abc?) ──────────────────
    abc = bytes.fromhex('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
    matches = sum(a == b for a, b in zip(digest, abc))
    print(f"\n  Distance to SHA-256('abc'): {32 - matches}/32 bytes differ")

    # ── Compose DNA ──────────────────────────────────────────────────────────
    print(f'\n  Composing DNA via 32-fold Vieta convolution …')
    dna = compose_all(positions)
    print(f'  ✓ DNA length: {len(dna)}')

    # Sanity
    taus_targets = positions + 1j * LANE_Y
    F_at_targets = modular.qpoly(dna, taus_targets)
    max_err = float(np.max(np.abs(F_at_targets)))
    print(f'  ✓ max |F(τ_t)| over 32 hash positions: {max_err:.2e}')

    # ── Print DNA ─────────────────────────────────────────────────────────────
    print(f'\n  ─── The composed DNA  (33 complex coefficients) ───')
    print(f'    n  |       Re aₙ           Im aₙ         |aₙ|        arg aₙ (deg)')
    print(f'  -----+--------------------------------------------------------------')
    for n, an in enumerate(dna):
        ang = math.degrees(math.atan2(an.imag, an.real))
        print(f'    {n:2d} |  {an.real:+.6f}     {an.imag:+.6f}      {abs(an):.6f}     {ang:+7.2f}')

    print(f'\n  ─── Byte → position mapping ───')
    print(f'     t  byte  hex  pos_t = b/256')
    for t, (b, p) in enumerate(zip(bytes_arr, positions)):
        print(f'    {t:2d}   {b:3d}   {b:02x}    {p:.4f}')

    # ── Visualise ─────────────────────────────────────────────────────────────
    print(f'\n  ─── Generating figure ───')
    out = FIG_DIR / '49_hsln_unknown_hash.png'
    figure_hash_dance(HEX, positions, digest, dna, out, 'unknown SHA-256')
    print(f'  ✓ {out.name}')


if __name__ == '__main__':
    main()
