"""
Lie derivative (and 2nd Lie derivative) of the trained model's complete landscape.

[REDACTED NAME]'s point: we're in a graded ring M_* = ⊕_k M_k whose symmetry we formally proved
(HSLNHodge: Hodge classes are a graded subring closed under cup product; HSLNKTheory:
Chern character is a ring hom). The grading's infinitesimal generator is the Euler /
Lie-derivative operator (lie_derivative.py, figure 38):

    θ = q d/dq ,    θ(a_n q^n) = n a_n q^n        (first  Lie derivative)
    θ² ,            θ²(a_n q^n) = n² a_n q^n       (second Lie derivative)

θ is the Lie derivative along the dilation vector field on the q-disk: on the n-th graded
piece it is multiplication by the grade n. We apply θ and θ² to the COMPLETE landscape of
a trained factoring model — the divisor series D_N(q) = Σ_n [n | N] q^n whose spikes are
the divisors — and read off what the graded symmetry exposes.

The elegant, TRUE payoff (panels 1-2):
    Σ_n θ  D_N  = Σ_{d|N} d   = σ₁(N)
    Σ_n θ² D_N  = Σ_{d|N} d²  = σ₂(N)
the divisor power sums — the very σ_k that are the Fourier DNA of the Eisenstein series
E₄ = Θ(E8) in the bridge we machine-checked. The Serre derivative ϑ_k = θ − (k/12)E₂·(·)
(panel 5) is the grading-COVARIANT version: it keeps θ inside the ring (weight k → k+2),
the connection ∇ of the graded structure. Classical check: ϑ₄E₄ = −⅓E₆.

The honest punchline (panels 3-4, 6):
    θ and θ² are DIAGONAL operators in the grading basis — a fixed reweighting by n, n².
    They amplify the divisor spikes that are already present, but multiplying an absent
    coefficient (0) by n or n² is still 0. So on the 249-bit genesis cofactor the Lie
    derivative of the landscape is exactly as barren as the landscape itself. The graded
    symmetry / cohomology gives STRUCTURE, not SEARCH — the same reason HSLNHodge proves
    the graded subring but leaves `def HodgeConjecture` (the surjection — the finding) open.

Run:  .venv/bin/python hsln_lie_landscape.py
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from lie_derivative import D as _D, eisenstein, qmul  # the proven Lie-derivative operator q d/dq
from hsln_bitcoin_probe import KEYS, pubkey_x, peel_small_factors, SCAN_BOUND
from hsln_e8_torsion_factor import is_prime, FG, ACCENT, ACCENT2, COMP, GRID, save_fig

WINDOW = 200_000
SMALL_P, SMALL_Q = 83, 97


def theta(a: np.ndarray) -> np.ndarray:
    """Lie derivative θ = q d/dq on a q-series: aₙ ↦ n·aₙ. (= lie_derivative.D)"""
    return a * np.arange(len(a))


def serre_derivative(a: np.ndarray, k: int, e2: np.ndarray) -> np.ndarray:
    """Serre (grading-covariant) derivative ϑ_k = θ − (k/12) E₂·(·), weight k → k+2."""
    return theta(a) - (k / 12.0) * np.convolve(e2, a)[:len(a)]


def e2_coeffs(n: int) -> np.ndarray:
    """E₂ = 1 − 24 Σ σ₁(n) qⁿ, truncated to n terms."""
    return eisenstein(2, n - 1).astype(complex)


def divisor_landscape(N: int, nmax: int) -> np.ndarray:
    """Complete landscape D_N(q) = Σ_n [n|N] q^n, coefficients a_0..a_nmax (a_0:=0)."""
    a = np.zeros(nmax + 1)
    for n in range(1, nmax + 1):
        if N % n == 0:
            a[n] = 1.0
    return a


def sigma(N: int, power: int) -> int:
    """σ_power(N) = Σ_{d|N} d^power — exact, big-int."""
    s, d = 0, 1
    while d * d <= N:
        if N % d == 0:
            s += d ** power
            if d != N // d:
                s += (N // d) ** power
        d += 1
    return s


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def main():
    small = SMALL_P * SMALL_Q                       # 8051
    x = pubkey_x(KEYS["genesis (block 0, Satoshi, unspent)"])
    _, cof = peel_small_factors(x, SCAN_BOUND)      # 249-bit composite

    # --- landscapes + Lie derivatives ---
    nmax_s = 120
    F_s = divisor_landscape(small, nmax_s)          # full small divisors 1,83,97 in window
    thF_s = theta(F_s).real
    th2F_s = theta(theta(F_s)).real

    # divisor power sums via the Lie derivative vs the closed form (over ALL divisors)
    s0, s1, s2 = sigma(small, 0), sigma(small, 1), sigma(small, 2)
    F_full = divisor_landscape(small, small)
    lie_s0 = F_full.sum()
    lie_s1 = theta(F_full).real.sum()
    lie_s2 = theta(theta(F_full)).real.sum()

    print("=" * 74)
    print(" Lie derivative of the trained landscape — graded-ring symmetry")
    print("=" * 74)
    print(f"\n small composite {small} = {SMALL_P}×{SMALL_Q}, divisors {{1,83,97,8051}}")
    print(f"   Σ θ⁰D = #divisors  : Lie {lie_s0:.0f}  vs  σ₀={s0}   match={int(lie_s0)==s0}")
    print(f"   Σ θ¹D = σ₁(N)      : Lie {lie_s1:.0f}  vs  σ₁={s1}   match={int(lie_s1)==s1}")
    print(f"   Σ θ²D = σ₂(N)      : Lie {lie_s2:.0f}  vs  σ₂={s2}   match={int(lie_s2)==s2}")
    print("   → the Lie derivative of the landscape IS the divisor-power-sum σ_k,")
    print("     the Fourier DNA of E₄ = Θ(E8) (the bridge we machine-checked).")

    # --- the cofactor: landscape and its Lie derivatives over the reachable window ---
    F_c = divisor_landscape(cof, WINDOW)
    thF_c = theta(F_c).real
    th2F_c = theta(theta(F_c)).real
    print(f"\n 249-bit genesis cofactor, landscape over n ≤ {WINDOW:,}")
    print(f"   nonzero in  D : {int((F_c>0).sum())}")
    print(f"   nonzero in θD : {int((np.abs(thF_c)>0).sum())}")
    print(f"   nonzero in θ²D: {int((np.abs(th2F_c)>0).sum())}")
    print("   → a diagonal operator: n·0 = n²·0 = 0. The symmetry adds no signal.")

    # --- Serre derivative: grading-covariant, stays in the ring (ϑ₄E₄ = −⅓E₆) ---
    E4 = np.array([1, 240, 2160, 6720, 17520, 30240, 60480, 82560], dtype=complex)
    E6 = np.array([1, -504, -16632, -122976, -532728, -1575504, -4058208, -8471232],
                  dtype=complex)
    serre_E4 = serre_derivative(E4, 4, e2_coeffs(len(E4)))
    ratio = (serre_E4.real / E6.real)
    print(f"\n Serre derivative ϑ₄E₄ (grading-covariant, weight 4→6):")
    print(f"   ϑ₄E₄ / E₆ coefficientwise = {np.round(ratio, 4)}  → constant −1/3 "
          f"⇒ stays in the graded ring.")

    # ----------------------------------------------------------------- figure
    fig = plt.figure(figsize=(17, 10))
    fig.suptitle("Lie derivative of the trained landscape — the graded-ring symmetry "
                 "(structure, not search)", color=FG, fontsize=15, y=0.98)

    # 1 · F, θF, θ²F on the small composite — grading amplifies the spikes
    ax = fig.add_subplot(2, 3, 1)
    ks = np.arange(nmax_s + 1)
    for arr, lab, col, off in [(F_s, "D (landscape)", ACCENT2, 0),
                               (thF_s / max(thF_s.max(), 1), "θD  (×n)", ACCENT, 0),
                               (th2F_s / max(th2F_s.max(), 1), "θ²D (×n²)", COMP, 0)]:
        idx = np.where(arr > 0)[0]
        ax.scatter(idx, arr[idx], s=30, c=col, label=lab, zorder=4)
        ax.vlines(idx, 0, arr[idx], color=col, lw=1.6, alpha=0.8)
    for d, lab in [(SMALL_P, "83"), (SMALL_Q, "97")]:
        ax.annotate(lab, (d, 1.04), color=FG, fontsize=9, ha="center")
    ax.set_ylim(0, 1.2)
    ax.set_xlabel("grade n", color=FG); ax.set_ylabel("coeff (each normalised)", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="center right")
    ax.set_title("1 · θ, θ² up-weight the factor spikes by n, n²", color=FG, fontsize=11)
    _grid(ax)

    # 2 · the Lie derivative = divisor power sums σ_k (bridge to E4 = Θ(E8))
    ax = fig.add_subplot(2, 3, 2)
    cats = ["Σθ⁰D = σ₀", "Σθ¹D = σ₁", "Σθ²D = σ₂"]
    lie_vals = [lie_s0, lie_s1, lie_s2]
    sig_vals = [s0, s1, s2]
    xp = np.arange(3)
    ax.bar(xp - 0.2, np.log10(np.maximum(lie_vals, 1)), 0.4, color=ACCENT,
           edgecolor=FG, label="from Lie derivative")
    ax.bar(xp + 0.2, np.log10(np.maximum(sig_vals, 1)), 0.4, color=ACCENT2,
           edgecolor=FG, label="closed-form σ_k")
    for i, (lv, sv) in enumerate(zip(lie_vals, sig_vals)):
        ax.annotate(f"{int(sv)}", (i, np.log10(max(sv, 1)) + 0.1), color=FG,
                    fontsize=8, ha="center")
    ax.set_xticks(xp); ax.set_xticklabels(cats, fontsize=9)
    ax.set_ylabel("log₁₀ value", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2)
    ax.set_title("2 · ΣθᵏD = σₖ — the DNA of E₄ = Θ(E8) [proved]", color=FG, fontsize=11)
    _grid(ax)

    # 3 · the cofactor landscape and its Lie derivatives — all flat
    ax = fig.add_subplot(2, 3, 3)
    step = max(1, WINDOW // 3000)
    xs = np.arange(WINDOW + 1)[::step]
    ax.plot(xs, F_c[::step], color=ACCENT2, lw=0.6, label="D")
    ax.plot(xs, thF_c[::step], color=ACCENT, lw=0.6, label="θD")
    ax.plot(xs, th2F_c[::step], color=COMP, lw=0.6, label="θ²D")
    ax.text(0.5, 0.6, "FLAT — n·0 = n²·0 = 0\nLie derivative adds nothing",
            transform=ax.transAxes, color=ACCENT2, fontsize=12, ha="center")
    ax.set_xlabel("grade n (to 200,000)", color=FG); ax.set_ylabel("coeff", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="upper right")
    ax.set_title("3 · θ, θ² of the 249-bit cofactor landscape — barren",
                 color=FG, fontsize=11)
    _grid(ax)

    # 4 · θ² is a fixed diagonal (n²) — number-independent. Proof it's reweighting.
    ax = fig.add_subplot(2, 3, 4)
    nn = np.arange(1, 60)
    ax.plot(nn, nn ** 2, color=COMP, lw=2, label="θ² gain = n²")
    ax.plot(nn, nn, color=ACCENT, lw=2, label="θ gain = n")
    ax.plot(nn, np.ones_like(nn), color=ACCENT2, lw=2, label="identity")
    ax.set_xlabel("grade n", color=FG); ax.set_ylabel("operator gain on aₙ", color=FG)
    ax.set_yscale("log")
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="upper left")
    ax.set_title("4 · θ, θ² are diagonal: a fixed grade reweighting", color=FG, fontsize=11)
    _grid(ax)

    # 5 · Serre derivative: grading-covariant, stays in the ring (ϑ₄E₄ = −⅓E₆)
    ax = fig.add_subplot(2, 3, 5)
    n6 = np.arange(1, len(E4))
    ax.plot(n6, ratio[1:], "o-", color=ACCENT, lw=1.6, label="ϑ₄E₄ / E₆ (coefficientwise)")
    ax.axhline(-1 / 3, color=ACCENT2, ls="--", lw=1.2, label="−1/3 (exact)")
    ax.set_ylim(-0.6, 0.0)
    ax.set_xlabel("coefficient index n", color=FG)
    ax.set_ylabel("ϑ₄E₄(n) / E₆(n)", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2)
    ax.set_title("5 · Serre ∇: covariant θ stays in the graded ring", color=FG, fontsize=11)
    _grid(ax)

    # 6 · verdict
    ax = fig.add_subplot(2, 3, 6)
    ax.axis("off")
    lines = [
        ("THE GRADED SYMMETRY — what it gives", ACCENT, 12),
        ("", FG, 5),
        ("Lie derivative θ = q d/dq is the grading", FG, 10),
        ("generator: θ(aₙqⁿ)=n aₙqⁿ, θ²→n².", FG, 10),
        ("", FG, 4),
        ("Beautiful & TRUE:  ΣθᵏD_N = σₖ(N), the", ACCENT2, 10),
        ("divisor power sums = Fourier DNA of", FG, 10),
        ("E₄ = Θ(E8). Serre ∇ keeps it in the ring.", FG, 10),
        ("(All of this we machine-checked.)", FG, 10),
        ("", FG, 5),
        ("But θ, θ² are DIAGONAL operators —", "#ff6b6b", 11),
        ("a fixed reweighting by n, n². They", FG, 10),
        ("amplify spikes that exist; n·0 stays 0.", FG, 10),
        ("On the cofactor: still barren.", FG, 10),
        ("", FG, 5),
        ("Cohomology gives STRUCTURE, not SEARCH —", ACCENT2, 10),
        ("the graded subring is provable; the", ACCENT2, 10),
        ("surjection (the finding) is the open core.", ACCENT2, 10),
    ]
    yy = 0.99
    for t, c, sz in lines:
        ax.text(0.0, yy, t, color=c, fontsize=sz, va="top", transform=ax.transAxes)
        yy -= 0.055 if t else 0.026

    fig.subplots_adjust(left=0.05, right=0.97, top=0.91, bottom=0.07,
                        hspace=0.34, wspace=0.24)
    save_fig(fig, "63_hsln_lie_landscape.png")


if __name__ == "__main__":
    main()
