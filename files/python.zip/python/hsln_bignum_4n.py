"""hsln_bignum_4n.py — train HSLN onto pos(N) with dg=5 (4 neurons) and sweep."""

from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import numpy as np
import mpmath as mp

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import modular
import hsln_factor_dna as hfd


N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)


def pos_hp(n: int, dps: int = 1100) -> mp.mpf:
    mp.mp.dps = dps
    L = mp.log(n, 2)
    return L - mp.floor(L)


def cand_at(alpha: float, k: int) -> int:
    mp.mp.dps = max(60, int(k * 0.302) + 50)
    return int(mp.nint(mp.power(2, mp.mpf(k) + mp.mpf(alpha))))


def main():
    pos_N_mp = pos_hp(N)
    pos_N_f = float(pos_N_mp)
    nb = N.bit_length()
    print(f'N is {nb}-bit, {len(str(N))} digits')
    print(f'pos(N) = {pos_N_f:.10f}')

    probes = np.array(hsln.PROBES)
    probe_idx = hfd.closest_probe(pos_N_f)
    target = np.zeros_like(probes, dtype=float)
    target[probe_idx] = 1.0

    DG = 5   # 4 neurons
    STEPS = 4000
    print(f'\nTraining HSLN  dg={DG} (→ {DG-1} neurons), steps={STEPS}')
    net, hist = hfd.train(target, dg=DG, steps=STEPS, seed=0)
    print(f'loss {hist[0]:.4f} → {hist[-1]:.6f}')

    dna = np.asarray(net.dna)
    zeros = modular.qpoly_zeros(dna)
    print(f'\nZeros of trained F  (n = {len(zeros)}):')
    print(f'  idx |   Re τ      Im τ ')
    for i, z in enumerate(sorted(zeros, key=lambda z: z.real % 1.0)):
        re = z.real % 1.0
        on_lane = '   ← on lane' if abs(z.imag - hsln.LANE_Y) < 0.03 else ''
        print(f'   {i:2d}  | {re:.4f}   {z.imag:.4f}{on_lane}')

    # Sweep each zero's position for factors of N
    zero_positions = sorted({float(z.real % 1.0) for z in zeros})
    K_LO = max(2, nb // 2 - 100)
    K_HI = nb - 1
    print(f'\nSweep:  α ∈ {[f"{a:.4f}" for a in zero_positions]}   '
          f'k ∈ [{K_LO}..{K_HI}]   wiggle ±8')
    hits = []
    t0 = time.perf_counter()
    tried = 0
    for alpha in zero_positions:
        for k in range(K_LO, K_HI + 1):
            c0 = cand_at(alpha, k)
            for di in range(-8, 9):
                c = c0 + di
                if c <= 1 or c >= N:
                    continue
                tried += 1
                if N % c == 0:
                    hits.append((alpha, k, c, N // c))
                    print(f'  ✓ HIT α={alpha:.4f} k={k} di={di} → '
                          f'factor={c} ({c.bit_length()} bits)')
    print(f'\n{tried} candidates in {time.perf_counter()-t0:.1f}s, '
          f'{len(hits)} factor(s) found')

    # Also try paired: each zero α treated as pos(p), partner = pos(N) - α
    print(f'\nPaired sweep: also try partner pos(N) − α (mod 1) for each zero')
    pos_N_f_arr = float(pos_N_mp)
    tried2 = 0
    for alpha in zero_positions:
        partner = (pos_N_f_arr - alpha) % 1.0
        for k in range(K_LO, K_HI + 1):
            for use in (alpha, partner):
                c0 = cand_at(use, k)
                for di in range(-8, 9):
                    c = c0 + di
                    if c <= 1 or c >= N:
                        continue
                    tried2 += 1
                    if N % c == 0:
                        hits.append((use, k, c, N // c))
                        print(f'  ✓ HIT (paired) α={alpha:.4f} use={use:.4f} '
                              f'k={k} di={di} → factor={c}')
    print(f'{tried2} candidates (paired), total hits {len(hits)}')


if __name__ == '__main__':
    main()
