"""hsln_skill_forge.py — the Skill Forge: train atomic skills, then EDIT the model with arithmetic.

The whole point of HSLN's composition algebra, made load-bearing:

  • train 3 atomic skill-DNAs independently (gradient descent learns each spike position),
  • MERGE them with ×  (hsln.tensor = convolve):  neurons UNION, zero joint training
        — machine-checked by `neurons_mul` (zeros of F·G = zeros F ∪ zeros G),
  • ERASE one with ÷  (deconvolve):  that skill's neuron vanishes EXACTLY, others untouched
        — the inverse of ×, exact polynomial division.

No standard network can do either: merging needs retraining and interferes; removing a learned
concept cleanly is essentially impossible by gradient descent. Here both are arithmetic.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import modular

mpl.rcParams.update({'figure.facecolor': 'white', 'axes.facecolor': 'white'})
LANE_Y = hsln.LANE_Y


def one_hot_at(pos: float):
    probes = np.array(hsln.PROBES)
    idx = int(np.argmin(np.abs(probes - pos)))
    t = np.zeros_like(probes, dtype=float)
    t[idx] = 1.0
    return t, float(probes[idx])


def deconvolve(c, b):
    """Recover a from c = convolve(a, b)  (exact polynomial division, ascending power)."""
    q, r = np.polydiv(np.asarray(c)[::-1], np.asarray(b)[::-1])
    return q[::-1], r[::-1]


def on_lane_neurons(dna, tol=0.05):
    """Positions Re τ of zeros sitting on the input lane (Im τ ≈ LANE_Y)."""
    out = []
    for z in modular.qpoly_zeros(np.asarray(dna)):
        if abs(z.imag - LANE_Y) < tol:
            out.append(z.real % 1.0)
    return sorted(out)


def dna_table(name, dna):
    print(f"  {name}  (len {len(dna)}):")
    print("    n |    Re aₙ      Im aₙ     |aₙ|")
    for n, a in enumerate(dna):
        print(f"    {n:2d}| {a.real:+.5f}  {a.imag:+.5f}   {abs(a):.5f}")


def main():
    # ── three atomic skills at distinct lane positions ───────────────────────────
    skills = {'A': 0.22, 'B': 0.50, 'C': 0.78}
    DG, STEPS = 4, 2500
    print("=" * 78)
    print("  FORGE — train 3 atomic skill-DNAs independently")
    print("=" * 78)
    nets, snapped = {}, {}
    for name, pos in skills.items():
        target, probe = one_hot_at(pos)
        net, hist = hsln.train_task(target, dg=DG, steps=STEPS, lr=0.01, seed=hash(name) & 0xFFFF)
        nets[name] = net
        snapped[name] = probe
        print(f"\n  skill {name}: target pos {pos:.2f} → probe {probe:.3f}, "
              f"loss {float(hist[0]):.3f} → {float(hist[-1]):.4f}, "
              f"on-lane neuron(s) {[f'{p:.3f}' for p in on_lane_neurons(net.dna)]}")
        dna_table(f"DNA_{name}", np.asarray(net.dna))

    # ── MERGE  (×) : convolve all three → union of neurons, NO joint training ─────
    print("\n" + "=" * 78)
    print("  MERGE  F = F_A · F_B · F_C   (×, hsln.tensor)   — neurons UNION")
    print("=" * 78)
    merged = hsln.tensor(hsln.tensor(nets['A'], nets['B']), nets['C'])
    dna_table("DNA_merged", np.asarray(merged.dna))
    print(f"  on-lane neurons of merged model: "
          f"{[f'{p:.3f}' for p in on_lane_neurons(merged.dna)]}")
    print(f"  expected (union of A,B,C):        "
          f"{[f'{p:.3f}' for p in sorted(snapped.values())]}")

    # ── ERASE  (÷) : deconvolve B out → B's neuron gone, A & C untouched ──────────
    print("\n" + "=" * 78)
    print("  ERASE  F / F_B   (÷, deconvolve)   — remove skill B exactly")
    print("=" * 78)
    erased_dna, remainder = deconvolve(np.asarray(merged.dna), np.asarray(nets['B'].dna))
    direct_AC = np.convolve(np.asarray(nets['A'].dna), np.asarray(nets['C'].dna))
    err = np.max(np.abs(erased_dna - direct_AC))
    dna_table("DNA_erased (= F/F_B)", erased_dna)
    print(f"  deconvolution remainder norm : {np.linalg.norm(remainder):.2e}")
    print(f"  ‖(F/F_B) − (F_A·F_C)‖∞       : {err:.2e}   (exact ⇒ ~0)")
    print(f"  on-lane neurons after erase  : "
          f"{[f'{p:.3f}' for p in on_lane_neurons(erased_dna)]}")
    print(f"  expected (A & C only):         "
          f"{[f'{snapped['A']:.3f}', f'{snapped['C']:.3f}']}")

    # ── verdict ──────────────────────────────────────────────────────────────────
    print("\n" + "=" * 78)
    print("  edited the model with arithmetic: × added skills, ÷ removed one,")
    print("  neurons bookkept exactly — no gradient step at the composite level.")
    print("=" * 78)

    # ── figure (clean spike-map line plots + neuron scatter) ─────────────────────
    xs = np.linspace(0, 1, 1200)

    def spikes(dna):
        s = np.asarray(hsln.spike_map(np.asarray(dna), xs))
        return s / s.max()

    fig = plt.figure(figsize=(13, 11))
    gs = fig.add_gridspec(4, 3, height_ratios=[1, 1, 1, 1.1], hspace=0.55, wspace=0.3)

    # row 1: atoms
    for j, name in enumerate('ABC'):
        ax = fig.add_subplot(gs[0, j])
        ax.fill_between(xs, 0, spikes(nets[name].dna), color='#4c72b0', alpha=0.7)
        ax.axvline(snapped[name], color='k', ls=':', lw=1)
        ax.set_title(f'atom {name}  @ {snapped[name]:.2f}', fontsize=11)
        ax.set_xlim(0, 1); ax.set_ylim(0, 1.1); ax.set_yticks([])
        ax.set_xlabel('lane position')

    # row 2: merged
    ax = fig.add_subplot(gs[1, :])
    ax.fill_between(xs, 0, spikes(merged.dna), color='#55a868', alpha=0.8)
    for name in 'ABC':
        ax.axvline(snapped[name], color='k', ls=':', lw=1)
    ax.set_title('MERGE  F = F_A · F_B · F_C   (×) — 3 skill-neurons, union, no joint training',
                 fontsize=12)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.1); ax.set_yticks([]); ax.set_xlabel('lane position')

    # row 3: erased
    ax = fig.add_subplot(gs[2, :])
    ax.fill_between(xs, 0, spikes(erased_dna), color='#c44e52', alpha=0.8)
    ax.axvline(snapped['A'], color='k', ls=':', lw=1)
    ax.axvline(snapped['C'], color='k', ls=':', lw=1)
    ax.axvline(snapped['B'], color='gray', ls='--', lw=1.6)
    ax.annotate('skill B removed', (snapped['B'], 0.85), color='gray', ha='center', fontsize=10)
    ax.set_title('ERASE  F / F_B   (÷) — skill B gone exactly, A & C untouched', fontsize=12)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.1); ax.set_yticks([]); ax.set_xlabel('lane position')

    # row 4: neuron positions in the τ-plane
    ax = fig.add_subplot(gs[3, :])
    def scatter_neurons(dna, y, color, label):
        for z in modular.qpoly_zeros(np.asarray(dna)):
            on = abs(z.imag - LANE_Y) < 0.05
            ax.scatter(z.real % 1.0, y, s=120 if on else 40,
                       color=color if on else '#cccccc',
                       edgecolor='black', linewidth=0.5, zorder=3 if on else 2)
        ax.text(-0.02, y, label, ha='right', va='center', fontsize=10)
    scatter_neurons(merged.dna, 1, '#55a868', 'merged')
    scatter_neurons(erased_dna, 0, '#c44e52', 'erased')
    ax.axhline(1, color='#ddd', lw=0.5); ax.axhline(0, color='#ddd', lw=0.5)
    for name in 'ABC':
        ax.axvline(snapped[name], color='k', ls=':', lw=0.8, alpha=0.5)
    ax.set_xlim(-0.08, 1); ax.set_ylim(-0.6, 1.6); ax.set_yticks([])
    ax.set_xlabel('Re τ  (filled = on-lane skill-neuron, grey = off-lane filler)')
    ax.set_title('neuron bookkeeping: merged carries A,B,C; erased carries A,C', fontsize=11)

    fig.suptitle('The HSLN Skill Forge — edit a model with arithmetic, not gradient descent',
                 fontsize=14, y=0.995)
    out = HERE / 'figures' / '55_hsln_skill_forge.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"\n  ✓ figure: {out.name}")


if __name__ == "__main__":
    main()
