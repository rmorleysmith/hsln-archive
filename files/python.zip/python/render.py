"""HSLN figure set. Run `uv run python render.py <name|all>`.

The state space (iteration space) of the network is the Siegel upper half-space H_g,
and its energy landscape is the Siegel modular form of E8. At genus 1 that form is
Theta_E8 = E4, a function on the ordinary upper half-plane / Poincare disk; this file
renders it and the network objects (neurons = zeros, reservoir dynamics, algebraic
model merging) built on it, plus the genus-2 Siegel form on slices of H_2.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import solve_ivp

import coloring
import dna
import e8
import geom
import modular
import siegel
import style

FIGDIR = Path(__file__).parent / "figures"
FIGDIR.mkdir(exist_ok=True)
RHO = np.exp(2j * np.pi / 3.0)  # the only zero of E4 per fundamental domain
CYAN = "#46f0d0"


def _save(fig, name):
    path = FIGDIR / f"{name}.png"
    fig.savefig(path)
    plt.close(fig)
    print(f"wrote {path}")
    return path


# ============================================================ genus-1: E4 = Theta_E8

def fig_e4_halfplane(res=1500):
    """Enhanced phase portrait of E4 = Theta_E8 over the upper half-plane."""
    TAU, extent = geom.half_plane_grid((-2.0, 2.0), (0.045, 2.3), res)
    F = modular.e4(TAU)
    rgb = coloring.domain_color(F, cmap="twilight")

    fig, ax = plt.subplots(figsize=(9, 5.6))
    ax.imshow(rgb, extent=extent, origin="upper", interpolation="none", aspect="auto")

    fre, fim = coloring.fundamental_domain_path()
    ax.plot(fre, fim, color=style.PAPER, lw=1.0, alpha=0.5)
    for shift in (-1, 0, 1):
        ax.plot(RHO.real + shift, RHO.imag, "o", color=style.NEURON, ms=7,
                mec="white", mew=0.8, zorder=5)
    ax.text(-1.95, 2.08, r"$\bullet$  zeros of $E_4$ (the genus-1 'neuron')"
            r" at $\tau\equiv\rho=e^{2\pi i/3}$", color=style.NEURON,
            ha="left", va="top", fontsize=10)

    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    ax.set_xlabel(r"Re $\tau$")
    ax.set_ylabel(r"Im $\tau$")
    ax.set_title("The Siegel modular form of E8, genus 1:   "
                 r"$\Theta_{E8}(\tau) = E_4(\tau)$" "\n"
                 r"enhanced phase portrait on the upper half-plane  $\mathcal{H}=\mathcal{H}_1$",
                 fontsize=14)
    fig.text(0.5, -0.02,
             "hue = arg F   ·   brightness bands = level curves of |F|   ·   "
             "fundamental domain of SL(2,Z) outlined",
             ha="center", fontsize=9, color="#9a98aa")
    return _save(fig, "01_e4_halfplane")


def fig_e4_disk(res=1500):
    """E4 = Theta_E8 mapped to the Poincare disk via the Cayley transform."""
    W, mask, extent = geom.disk_grid(res)
    TAU = geom.inv_cayley(W)
    F = np.full(W.shape, np.nan, dtype=np.complex128)
    F[mask] = modular.e4(TAU[mask])
    rgb = coloring.domain_color(F, cmap="twilight")
    rgba = np.dstack([rgb, mask.astype(float)])

    fig, ax = plt.subplots(figsize=(7.6, 7.6))
    ax.imshow(rgba, extent=extent, origin="upper", interpolation="none")
    ax.add_patch(plt.Circle((0, 0), 1.0, fill=False, color=style.PAPER, lw=1.2, alpha=0.6))

    fre, fim = coloring.fundamental_domain_path()
    fd = geom.cayley(fre + 1j * fim)
    ax.plot(fd.real, fd.imag, color=style.PAPER, lw=1.0, alpha=0.55)
    for shift in (-1, 0, 1):
        wz = geom.cayley(RHO + shift)
        ax.plot(wz.real, wz.imag, "o", color=style.NEURON, ms=7, mec="white",
                mew=0.8, zorder=5)

    ax.set_xlim(-1.04, 1.04)
    ax.set_ylim(-1.04, 1.04)
    ax.set_aspect("equal")
    ax.axis("off")
    ax.set_title(r"$\Theta_{E8} = E_4$ on the Poincaré disk" "\n"
                 r"(real axis of $\mathcal{H}\to$ boundary circle; cusps accumulate at the rim)",
                 fontsize=14)

    wheel = fig.add_axes([0.80, 0.80, 0.16, 0.16], projection="polar")
    style.phase_wheel(wheel)
    return _save(fig, "02_e4_disk")


# ============================================================ energy landscape + neurons

def fig_energy_neurons(res=200):
    """|F|^2 energy landscape: zeros are the only minima -> attractors -> neurons."""
    fig = plt.figure(figsize=(14, 6.3))

    # ---- left: true E4, one orbit of wells (the genus-1 'neuron' at rho) ----
    ax1 = fig.add_subplot(1, 2, 1, projection="3d")
    TAU, _ = geom.half_plane_grid((-1.0, 1.0), (0.45, 1.5), res)
    F = modular.e4(TAU)
    Z = np.log10(np.abs(F) ** 2 + 1e-3)
    rgba = np.dstack([coloring.domain_color(F, cmap="twilight"), np.ones(F.shape)])
    ax1.plot_surface(TAU.real, TAU.imag, Z, facecolors=rgba, rstride=2, cstride=2,
                     linewidth=0, antialiased=False, shade=False)
    floor = Z.min()
    for shift in (-0.5, 0.5):
        ax1.scatter([shift], [RHO.imag], [floor], color=style.NEURON, s=60,
                    edgecolor="white", depthshade=False, zorder=10)
    ax1.set_title(r"true $E_4=\Theta_{E8}$:  energy $\log_{10}|F|^2$" "\n"
                  r"one neuron orbit, the zero at $\rho$", fontsize=13)
    ax1.set_xlabel(r"Re $\tau$"); ax1.set_ylabel(r"Im $\tau$")
    ax1.set_zlabel(r"$\log_{10}|F|^2$")
    ax1.view_init(elev=52, azim=-58)

    # ---- right: the (g,k,N)=(1,4,11) PoC truncated DNA, several neurons ----
    ax2 = fig.add_subplot(1, 2, 2, projection="3d")
    TAU2, _ = geom.half_plane_grid((0.0, 1.0), (0.02, 0.62), res)
    F2 = modular.qpoly(dna.LEVEL11_4, TAU2)
    Z2 = np.log10(np.abs(F2) ** 2 + 1e-3)
    rgba2 = np.dstack([coloring.domain_color(F2, cmap="twilight"), np.ones(F2.shape)])
    ax2.plot_surface(TAU2.real, TAU2.imag, Z2, facecolors=rgba2, rstride=2, cstride=2,
                     linewidth=0, antialiased=False, shade=False)
    neurons = modular.qpoly_zeros(dna.LEVEL11_4)
    floor2 = Z2.min()
    ax2.scatter(neurons.real, neurons.imag, np.full(neurons.size, floor2),
                color=style.NEURON, s=55, edgecolor="white", depthshade=False, zorder=10)
    ax2.set_title(r"trained DNA, level-11 newform 11.4.a.a" "\n"
                  rf"truncated $F=\sum_{{n\leq5}}a_n q^n$:  {neurons.size} neurons", fontsize=13)
    ax2.set_xlabel(r"Re $\tau$"); ax2.set_ylabel(r"Im $\tau$")
    ax2.set_zlabel(r"$\log_{10}|F|^2$")
    ax2.view_init(elev=52, azim=-58)

    fig.suptitle("HSLN energy landscape — neurons are the zeros of the modular form "
                 "(the only minima of |F|², by the maximum-modulus principle)",
                 fontsize=14, y=1.0)
    return _save(fig, "03_energy_neurons")


# ============================================================ reservoir dynamics

def _velocity(coeffs, tau, alpha=1.0):
    """Gradient-flow velocity field of dot tau = -alpha grad|F|^2."""
    F, Fp = modular.qpoly_grad(coeffs, tau)
    g = np.conj(F) * Fp
    return -alpha * 2.0 * np.real(g), alpha * 2.0 * np.imag(g), F


def integrate_paths(coeffs, seeds, neurons=None, n_steps=700, dt=0.012,
                    im_floor=0.03, stop_tol=0.02):
    """Vectorized unit-speed gradient-flow paths for all seeds at once.

    We follow the DIRECTION of -grad|F|^2 (identical basins to the spec dynamics)
    at unit speed, which is scale-invariant and stable at any DNA scale; particles
    freeze once they reach a neuron. No dense grid, no coloring ->
    cost is O(n_steps * P * len(coeffs)). Returns history (n_steps + 1, 2, P).
    """
    state = np.stack([seeds.real.astype(float), seeds.imag.astype(float)])
    hist = np.empty((n_steps + 1, 2, state.shape[1]))
    hist[0] = state
    active = np.ones(state.shape[1], dtype=bool)

    def direction(s):
        vx, vy, _ = _velocity(coeffs, s[0] + 1j * s[1])
        v = np.stack([vx, vy])
        return v / (np.hypot(vx, vy) + 1e-12)

    for k in range(n_steps):
        d = direction(state)
        d[:, ~active] = 0.0
        new = state + dt * d
        new[1] = np.clip(new[1], im_floor, im_floor + 3.0)
        bad = ~np.isfinite(new)
        new[bad] = state[bad]
        state = new
        if neurons is not None:
            ends = state[0] + 1j * state[1]
            mind = np.min(np.abs(ends[:, None] - neurons[None, :]), axis=1)
            active &= mind > stop_tol
        hist[k + 1] = state
    return hist


def basin_palette(n):
    return plt.colormaps["turbo"](np.linspace(0.06, 0.95, n))


def _basin_paths(ax, coeffs, neurons, re_lim, im_lim, nx=34, ny=22, tol=0.05):
    """Draw flow paths (colored by which neuron they land in) + neuron markers."""
    xs = np.linspace(re_lim[0] + 0.01, re_lim[1] - 0.01, nx)
    ys = np.linspace(im_lim[0] + 0.01, im_lim[1] - 0.01, ny)
    SX, SY = np.meshgrid(xs, ys)
    seeds = (SX + 1j * SY).ravel()
    hist = integrate_paths(coeffs, seeds, neurons=neurons, im_floor=im_lim[0])
    ends = hist[-1, 0] + 1j * hist[-1, 1]
    dist = np.abs(ends[:, None] - neurons[None, :])
    nearest = np.argmin(dist, axis=1)
    captured = dist[np.arange(ends.size), nearest] < tol
    pal = basin_palette(len(neurons))
    for p in range(seeds.size):
        if captured[p]:
            ax.plot(hist[:, 0, p], hist[:, 1, p], color=pal[nearest[p]], lw=0.7, alpha=0.7)
        else:
            ax.plot(hist[:, 0, p], hist[:, 1, p], color=(0.5, 0.5, 0.55), lw=0.5, alpha=0.2)
    for i, nu in enumerate(neurons):
        ax.plot(nu.real, nu.imag, "*", color=pal[i], ms=19, mec="white", mew=1.0, zorder=6)
    ax.set_xlim(*re_lim); ax.set_ylim(*im_lim)
    ax.set_facecolor("#07070d")
    return int(captured.sum())


def fig_basins():
    """Cheap basin view: neurons + gradient-flow paths only, no field/coloring."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 6.3))

    n3 = np.array([0.30 + 0.46j, 0.68 + 0.52j, 0.50 + 0.27j])
    c3 = dna.dna_from_neurons(n3, lead=40.0)
    _basin_paths(axes[0], c3, n3, (0.0, 1.0), (0.05, 0.92), nx=36, ny=24)
    axes[0].set_title("3 neurons — basins traced by flow paths", fontsize=13)
    axes[0].set_xlabel(r"Re $\tau$"); axes[0].set_ylabel(r"Im $\tau$")

    # scaling demo: a row of 10 neurons, seeds rain down and sort by basin
    re = np.linspace(0.08, 0.92, 10)
    nrow = re + 1j * (0.30 + 0.05 * np.sin(2 * np.pi * re))
    crow = dna.dna_from_neurons(nrow, lead=1.0)
    _basin_paths(axes[1], crow, nrow, (0.0, 1.0), (0.08, 0.52), nx=64, ny=26)
    axes[1].set_title(f"{nrow.size} neurons — same code, ~same cost", fontsize=13)
    axes[1].set_xlabel(r"Re $\tau$")

    fig.suptitle("Neurons (zeros) and reservoir paths only — no domain coloring, "
                 "no dense grid evaluation", fontsize=14, y=1.0)
    return _save(fig, "08_basins_paths")


def fig_dynamics(res=46):
    """Basin paths (cheap) + a driven spike train."""
    neurons = np.array([0.30 + 0.46j, 0.68 + 0.52j, 0.50 + 0.27j])
    coeffs = dna.dna_from_neurons(neurons, lead=40.0)

    fig = plt.figure(figsize=(14, 6.2))

    # ---- left: basin paths (no coloring, no grid) ----
    ax1 = fig.add_subplot(1, 2, 1)
    _basin_paths(ax1, coeffs, neurons, (0.0, 1.0), (0.05, 0.92), nx=36, ny=24)
    ax1.set_xlabel(r"Re $\tau$"); ax1.set_ylabel(r"Im $\tau$")
    ax1.set_title(r"Reservoir flow  $\dot\tau=-\alpha\,\nabla|F|^2$"
                  "\npaths colored by basin · ★ = neurons", fontsize=13)

    # ---- right: a driven trajectory emits spikes near neurons ----
    ax2 = fig.add_subplot(1, 2, 2)
    T = 40.0
    drive_t = np.array([6, 14, 22, 30])
    def u(t):
        return float(np.sum(np.exp(-((t - drive_t) ** 2) / 0.5)))
    Bx, By = 0.9, 0.0

    def rhs(t, s):
        vx, vy, _ = _velocity(coeffs, s[0] + 1j * s[1], alpha=0.6)
        uu = u(t)
        return [vx + Bx * uu, max(vy + By * uu, vy)]
    ts = np.linspace(0, T, 2400)
    sol = solve_ivp(rhs, [0, T], [0.5, 0.85], t_eval=ts, max_step=0.02, rtol=1e-7, atol=1e-9)
    tau_t = sol.y[0] + 1j * sol.y[1]
    Fval = modular.qpoly(coeffs, tau_t)
    inv = 1.0 / (np.abs(Fval) + 1e-9)
    thr = np.percentile(inv, 88)
    ax2.plot(sol.t, inv, color=CYAN, lw=1.4, label=r"$1/|F(\tau(t))|$  (membrane potential)")
    ax2.axhline(thr, color=style.ACCENT, ls="--", lw=1.0, label="spike threshold ε")
    spikes = sol.t[1:][(inv[:-1] < thr) & (inv[1:] >= thr)] if inv.size > 1 else []
    for s in spikes:
        ax2.axvline(s, color=style.NEURON, lw=1.4, alpha=0.8)
    uu = np.array([u(t) for t in sol.t])
    ax2.plot(sol.t, uu * (inv.max() * 0.25), color="#888", lw=1.0, alpha=0.7,
             label="input u(t)")
    ax2.set_xlabel("time"); ax2.set_ylabel("excitation")
    ax2.set_title("Liquid / spiking behaviour\n"
                  r"input drives $\tau$ between basins; spikes when $1/|F|>\varepsilon$",
                  fontsize=13)
    ax2.legend(loc="upper right", fontsize=8, framealpha=0.25)
    return _save(fig, "04_dynamics")


# ============================================================ algebraic model merging

def _phase_panel(ax, coeffs, neurons, title, re_lim=(0.0, 1.0), im_lim=(0.05, 0.95), res=700):
    TAU, extent = geom.half_plane_grid(re_lim, im_lim, res)
    F = modular.qpoly(coeffs, TAU)
    rgb = coloring.domain_color(F, cmap="twilight")
    ax.imshow(rgb, extent=extent, origin="upper", interpolation="none", aspect="auto")
    ax.plot(neurons.real, neurons.imag, "*", color=CYAN, ms=15, mec="black", mew=0.7, zorder=6)
    ax.set_xlim(extent[0], extent[1]); ax.set_ylim(extent[2], extent[3])
    ax.set_xlabel(r"Re $\tau$")
    ax.set_title(title, fontsize=12)


def fig_merge(res=700):
    """Multiplication in the graded ring unions the zero sets (spec 3.4b)."""
    nA = np.array([0.28 + 0.40j, 0.70 + 0.58j])
    nB = np.array([0.50 + 0.30j, 0.15 + 0.62j])
    A = dna.dna_from_neurons(nA, lead=30.0)
    B = dna.dna_from_neurons(nB, lead=30.0)
    M = np.convolve(A, B)  # Cauchy convolution = DNA of the product form
    nM = modular.qpoly_zeros(M)

    fig, axes = plt.subplots(1, 3, figsize=(15, 5.4))
    _phase_panel(axes[0], A, nA, r"model A:  $F_A$,  weight $k_A$", res=res)
    _phase_panel(axes[1], B, nB, r"model B:  $F_B$,  weight $k_B$", res=res)
    _phase_panel(axes[2], M, nM,
                 r"merged:  $F_A\cdot F_B$,  weight $k_A{+}k_B$"
                 "\n"
                 r"zeros$(F_A F_B)=$ zeros$(F_A)\cup$ zeros$(F_B)$", res=res)
    axes[0].set_ylabel(r"Im $\tau$")
    fig.suptitle("Exact zero-shot model merging  =  multiplication of DNAs "
                 "(Cauchy convolution of Fourier coefficients)", fontsize=14, y=1.02)
    fig.text(0.5, -0.02,
             f"verified: merged form has {nM.size} neurons = union of A's "
             f"{nA.size} and B's {nB.size}  ·  cyan ★ = neurons (zeros of F)",
             ha="center", fontsize=9, color="#9a98aa")
    return _save(fig, "05_merge")


# ============================================================ E8 roots + theta DNA

def fig_e8_roots():
    """Coxeter (Petrie) projection of the 240 E8 roots + the theta-series DNA."""
    fig = plt.figure(figsize=(13.5, 6.6))

    ax1 = fig.add_subplot(1, 2, 1)
    roots = e8.shells(2.0)[2]
    P = e8.coxeter_plane(roots)
    r = np.hypot(P[:, 0], P[:, 1])
    rings = sorted(set(np.round(r, 4)))
    cmap = plt.colormaps["plasma"]
    for i, rad in enumerate(rings):
        sel = np.isclose(r, rad, atol=1e-3)
        pts = P[sel]
        ang = np.arctan2(pts[:, 1], pts[:, 0])
        order = np.argsort(ang)
        loop = np.vstack([pts[order], pts[order][:1]])
        col = cmap(i / (len(rings) - 1))
        ax1.plot(loop[:, 0], loop[:, 1], color=col, lw=0.8, alpha=0.7)
        ax1.scatter(pts[:, 0], pts[:, 1], color=col, s=22, edgecolor="white", lw=0.3, zorder=4)
    ax1.set_aspect("equal"); ax1.axis("off")
    ax1.set_title("The 240 roots of E8\nCoxeter-plane (Petrie) projection: "
                  "8 rings × 30 = 240", fontsize=13)

    ax2 = fig.add_subplot(1, 2, 2)
    a = e8.theta1_coeffs(8)
    n = np.arange(a.size)
    ax2.bar(n, a, color=style.ACCENT, edgecolor="white", lw=0.5)
    ax2.set_yscale("symlog")
    for ni, ai in zip(n, a):
        ax2.text(ni, ai * 1.25 + 1, f"{int(ai)}", ha="center", fontsize=8, color=style.PAPER)
    ax2.set_xlabel("n  (Fourier index)")
    ax2.set_ylabel(r"$a_n$  (symlog)")
    ax2.set_title(r"$\Theta_{E8}=E_4=1+240\sum_{n\geq1}\sigma_3(n)\,q^n$"
                  "\nthe theta coefficients = the genus-1 'DNA'", fontsize=13)
    ax2.grid(True, alpha=0.15)
    return _save(fig, "06_e8_roots_dna")


# ============================================================ genus-2 Siegel slices

def fig_siegel(res=620):
    """Truncated Theta^(2)_{E8} over 2-real-dim complex-line slices of H_2."""
    dct = siegel.representation_numbers(maxn=6)

    fig, axes = plt.subplots(1, 3, figsize=(15.5, 5.6))

    # slice 1: Z = diag(tau, tau) -> E4(tau)^2  (genus 1, squared)
    TAU, ext = geom.half_plane_grid((-0.6, 0.6), (0.45, 1.45), res)
    F1 = siegel.theta2(dct, TAU, np.zeros_like(TAU), TAU)
    axes[0].imshow(coloring.domain_color(F1, cmap="twilight"), extent=ext,
                   origin="upper", interpolation="none", aspect="auto")
    axes[0].set_title(r"$Z=\mathrm{diag}(\tau,\tau)$" "\n"
                      r"$\Theta^{(2)}=E_4(\tau)^2$  (decoupled)", fontsize=12)
    axes[0].set_ylabel(r"Im $\tau$"); axes[0].set_xlabel(r"Re $\tau$")

    # slice 2: Z = [[tau, z0],[z0, tau]] with real coupling z0 -> deformed
    z0 = 0.35
    F2 = siegel.theta2(dct, TAU, np.full_like(TAU, z0), TAU)
    axes[1].imshow(coloring.domain_color(F2, cmap="twilight"), extent=ext,
                   origin="upper", interpolation="none", aspect="auto")
    axes[1].set_title(rf"$Z=[[\tau,{z0}],[{z0},\tau]]$" "\n"
                      r"coupling deforms the genus-1 picture", fontsize=12)
    axes[1].set_xlabel(r"Re $\tau$")

    # slice 3: off-diagonal coupling plane. Z = [[i s, z],[z, i s]], vary z
    s = 1.15
    Zx = np.linspace(-0.6, 0.6, res)
    Zy = np.linspace(0.9, -0.9, res)
    ZX, ZY = np.meshgrid(Zx, Zy)
    zz = ZX + 1j * ZY
    diag = 1j * s
    F3 = siegel.theta2(dct, np.full_like(zz, diag), zz, np.full_like(zz, diag))
    pd = (np.abs(zz.imag) < s)  # Im(Z) positive definite <=> |Im z| < s
    F3 = np.where(pd, F3, np.nan)
    axes[2].imshow(coloring.domain_color(F3, cmap="twilight"),
                   extent=(-0.6, 0.6, -0.9, 0.9), origin="upper", interpolation="none",
                   aspect="auto")
    axes[2].set_title(rf"$Z=[[{s}i,\,z],[z,\,{s}i]]$,  vary $z$" "\n"
                      r"the off-diagonal coupling plane", fontsize=12)
    axes[2].set_xlabel(r"Re $z$"); axes[2].set_ylabel(r"Im $z$")

    fig.suptitle(r"Genus-2 Siegel modular form of E8:  $\Theta^{(2)}_{E8}(Z)$ on "
                 r"slices of $\mathcal{H}_2$ (complex dim 3, weight 4, Sp(4,$\mathbb{Z}$))",
                 fontsize=14, y=1.02)
    fig.text(0.5, -0.02, "truncated to E8 vector norms ≤ 6  ·  "
             "diagonal slice verified against E4⊗E4 to 1e-15",
             ha="center", fontsize=9, color="#9a98aa")
    return _save(fig, "07_siegel_genus2")


def genus2_divisor_points(dct, z0, ws, im_lo=0.6, im_hi=1.3):
    """Zeros of the genus-2 form on the slice Z=[[tau,z0],[z0,tau+w]] for each w.

    On this slice F is a polynomial in q=e^{2pi i tau} of degree max((a+c)/2); its roots
    are the points where the zero divisor meets the slice. Returns (N,3): (Re tau, Im tau, w).
    The Im window drops low-Im truncation artifacts, keeping the genuine branch near rho.
    """
    a = np.array([k[0] for k in dct], float)
    b = np.array([k[1] for k in dct], float)
    c = np.array([k[2] for k in dct], float)
    r = np.array([dct[k] for k in dct], float)
    npow = ((a + c) / 2).astype(int)
    deg = int(npow.max())
    base = r * np.exp(2j * np.pi * b * z0)
    pts = []
    for w in ws:
        vals = base * np.exp(1j * np.pi * c * w)
        coeff = np.zeros(deg + 1, dtype=complex)
        np.add.at(coeff, npow, vals)
        q = np.roots(coeff[::-1])
        q = q[np.abs(q) > 1e-12]
        tau = np.log(q) / (2j * np.pi)
        t = tau[(tau.imag > im_lo) & (tau.imag < im_hi)]
        re = (t.real + 0.5) % 1.0 - 0.5
        pts.extend(zip(re, t.imag, np.full(t.size, w)))
    return np.array(pts) if pts else np.empty((0, 3))


def fig_divisor(nw=200):
    """Genus 2: the zero set is a divisor (a curve), not isolated points."""
    dct = siegel.representation_numbers(maxn=8)
    ws = np.linspace(-1.0, 1.0, nw)
    fig = plt.figure(figsize=(14.5, 6.6))
    for idx, (z0, lab) in enumerate([(0.0, "decoupled  (z = 0)"),
                                     (0.35, "coupled  (z = 0.35)")]):
        ax = fig.add_subplot(1, 2, idx + 1, projection="3d")
        P = genus2_divisor_points(dct, z0, ws)
        ax.scatter(P[:, 0], P[:, 1], P[:, 2], c=P[:, 2], cmap="viridis", s=7)
        w0 = ws[np.argmin(np.abs(ws))]
        m0 = np.isclose(P[:, 2], w0)
        ax.scatter(P[m0, 0], P[m0, 1], P[m0, 2], color=style.NEURON, s=55,
                   edgecolor="white", depthshade=False, zorder=8,
                   label="one complex slice → point(s)")
        ax.set_xlabel(r"Re $\tau$"); ax.set_ylabel(r"Im $\tau$"); ax.set_zlabel("w  (slice)")
        ax.set_xlim(-0.5, 0.5); ax.set_ylim(0.6, 1.0); ax.set_zlim(-1, 1)
        ax.set_title(lab, fontsize=12)
        ax.view_init(elev=20, azim=-62)
        ax.legend(loc="upper left", fontsize=8)
    fig.suptitle(r"Genus 2: the 'neuron' is a zero divisor — a curve, not a count" "\n"
                 r"$Z=[[\tau,z],[z,\tau+w]]$ slice of $\mathcal{H}_2$ · red = the zeros on a "
                 r"single slice · the swept set is 1-dimensional", fontsize=13, y=1.0)
    return _save(fig, "09_genus2_divisor")


def fig_divisor_sweep(nw=220):
    """The genus-2 zero divisor as the coupling z grows: it bends and reconnects."""
    dct = siegel.representation_numbers(maxn=8)
    ws = np.linspace(-1.0, 1.0, nw)
    z0s = [0.10, 0.25, 0.40, 0.55]
    fig = plt.figure(figsize=(13.5, 11.5))
    for i, z0 in enumerate(z0s):
        ax = fig.add_subplot(2, 2, i + 1, projection="3d")
        P = genus2_divisor_points(dct, z0, ws, im_lo=0.5, im_hi=1.45)
        ax.scatter(P[:, 0], P[:, 1], P[:, 2], c=P[:, 2], cmap="plasma", s=7)
        ax.set_xlim(-0.5, 0.5); ax.set_ylim(0.5, 1.1); ax.set_zlim(-1, 1)
        ax.set_xlabel(r"Re $\tau$"); ax.set_ylabel(r"Im $\tau$"); ax.set_zlabel("w")
        ax.set_title(f"coupling  z = {z0:.2f}", fontsize=12)
        ax.view_init(elev=20, azim=-62)
    fig.suptitle("Genus-2 zero divisor vs. coupling strength — the curve bends and reconnects",
                 fontsize=14, y=0.99)
    return _save(fig, "10_divisor_sweep")


def _compose_panel(ax, coeffs, stars, hollow, title, res=720):
    re_lim, im_lim = (0.0, 1.0), (0.05, 0.95)
    TAU, ext = geom.half_plane_grid(re_lim, im_lim, res)
    F = modular.qpoly(coeffs, TAU)
    ax.imshow(coloring.domain_color(F), extent=ext, origin="upper",
              interpolation="none", aspect="auto")
    if hollow is not None and len(hollow):
        ax.plot(hollow.real, hollow.imag, "o", mfc="none", mec="#cfcfcf", mew=1.4,
                ms=14, zorder=5)
    if stars is not None and len(stars):
        ax.plot(stars.real, stars.imag, "*", color=CYAN, ms=16, mec="black",
                mew=0.7, zorder=6)
    ax.set_xlim(*re_lim); ax.set_ylim(*im_lim)
    ax.set_title(title, fontsize=12)


def fig_compose(res=720):
    """Addition vs multiplication: + blends the field (zeros recombine), x unions zeros."""
    nA = np.array([0.30 + 0.55j, 0.66 + 0.40j])
    nB = np.array([0.50 + 0.62j, 0.20 + 0.34j, 0.80 + 0.50j])
    A = dna.dna_from_neurons(nA)
    B = dna.dna_from_neurons(nB)
    L = max(A.size, B.size)
    Apad = np.zeros(L, complex); Apad[:A.size] = A
    Bpad = np.zeros(L, complex); Bpad[:B.size] = B
    S = Apad + Bpad
    P = np.convolve(A, B)
    nS = modular.qpoly_zeros(S)
    nP = modular.qpoly_zeros(P)
    union = np.concatenate([nA, nB])

    fig, ax = plt.subplots(2, 2, figsize=(12.5, 11))
    _compose_panel(ax[0, 0], A, nA, None, r"model A:  $F_A$  ($\bigstar$ = its zeros)", res)
    _compose_panel(ax[0, 1], B, nB, None, r"model B:  $F_B$", res)
    _compose_panel(ax[1, 0], S, nS, union,
                   r"$F_A + F_B$  (sum): zeros RECOMBINE — new $\bigstar$, parents' ○ gone", res)
    _compose_panel(ax[1, 1], P, nP, None,
                   r"$F_A \cdot F_B$  (product): zeros UNION — every parent zero kept", res)
    ax[0, 0].set_ylabel(r"Im $\tau$"); ax[1, 0].set_ylabel(r"Im $\tau$")
    ax[1, 0].set_xlabel(r"Re $\tau$"); ax[1, 1].set_xlabel(r"Re $\tau$")
    fig.suptitle("Two ways to compose DNAs:  addition sculpts the field · "
                 "multiplication stacks the attractors", fontsize=14, y=1.0)
    return _save(fig, "11_compose_add_vs_mul")


def fig_heterotic(res=720):
    """E8 x E8 = product of thetas. A frozen 'state' form times a 'gravity' dial."""
    nS = np.array([0.25 + 0.52j, 0.52 + 0.66j, 0.76 + 0.46j, 0.40 + 0.30j])  # state (frozen)
    nG = np.array([0.35 + 0.42j, 0.66 + 0.38j])                              # gravity (dial)
    FS = dna.dna_from_neurons(nS)
    FG = dna.dna_from_neurons(nG)
    FP = np.convolve(FS, FG)  # E8 x E8 : DNA convolution, zeros union, weight adds

    fig, ax = plt.subplots(1, 3, figsize=(16, 5.7))
    _compose_panel(ax[0], FS, nS, None, r"state $E_8$:  $F_S$  (weight 4, frozen)", res)
    _compose_panel(ax[1], FG, nG, None, r"gravity $E_8$:  $F_G$  (the dial)", res)
    _compose_panel(ax[2], FP, None, None,
                   r"$E_8\times E_8$:  $F_S\!\cdot\!F_G$  (weight 8)", res)
    ax[2].plot(nS.real, nS.imag, "*", color=CYAN, ms=15, mec="black", mew=0.7, zorder=6,
               label="state zeros")
    ax[2].plot(nG.real, nG.imag, "*", color=style.ACCENT, ms=15, mec="black", mew=0.7,
               zorder=6, label="gravity zeros")
    ax[2].legend(loc="upper right", fontsize=8, framealpha=0.3)
    ax[0].set_ylabel(r"Im $\tau$")
    for a in ax:
        a.set_xlabel(r"Re $\tau$")
    fig.suptitle(r"$E_8\times E_8$ (heterotic) = product of theta functions:  the gravity DNA "
                 r"$F_G$ multiplicatively reshapes the frozen state field;  "
                 r"zeros$(F_S F_G)$ = state $\cup$ gravity", fontsize=13, y=1.01)
    return _save(fig, "12_heterotic_e8xe8")


def fig_disk_clean(res=900):
    """Clean E4-on-disk image (no axes/title) used as the Game-of-Life backdrop."""
    W, mask, _ = geom.disk_grid(res)
    TAU = geom.inv_cayley(W)
    F = np.full(W.shape, np.nan, dtype=np.complex128)
    F[mask] = modular.e4(TAU[mask])
    rgb = coloring.domain_color(F, cmap="twilight")
    rgba = np.dstack([rgb, mask.astype(float)])
    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
    ax.imshow(rgba, origin="upper", interpolation="none")
    path = FIGDIR / "e4_disk_clean.png"
    fig.savefig(path, dpi=res / 6, transparent=True)
    plt.close(fig)
    print(f"wrote {path}")
    return path


FIGURES = {
    "e4_half": fig_e4_halfplane,
    "e4_disk": fig_e4_disk,
    "energy": fig_energy_neurons,
    "dynamics": fig_dynamics,
    "basins": fig_basins,
    "merge": fig_merge,
    "roots": fig_e8_roots,
    "siegel": fig_siegel,
    "divisor": fig_divisor,
    "divisor_sweep": fig_divisor_sweep,
    "compose": fig_compose,
    "heterotic": fig_heterotic,
    "diskbg": fig_disk_clean,
}


def main(argv):
    names = list(FIGURES) if (not argv or argv[0] == "all") else argv
    for name in names:
        if name not in FIGURES:
            print(f"unknown figure: {name}; have {list(FIGURES)}")
            continue
        FIGURES[name]()


if __name__ == "__main__":
    main(sys.argv[1:])
