"""
"Extract the factors, then run it again on the smaller problem." — let's try.

This is the divide-and-conquer instinct: peel the easy small primes, then attack the
leftover cofactor as a fresh, smaller factoring problem. We do exactly that on the two
real keys and watch why it does NOT cascade into a fast algorithm:

  1. Peeling small primes barely dents the bit-length (you remove a few bits).
  2. The leftover cofactor has, by construction, NO factor below the scan bound — so
     "running it again" at the same bound finds nothing.
  3. And the cofactor turns out to be PRIME (we Miller-Rabin it). A prime has no smaller
     sub-problem: the recursion terminates immediately at an irreducible ~250-bit number.
  4. Even if it were composite, its smallest factor would be > 2,000,000, i.e. up to
     √cofactor ≈ 2^124 — the full exponential wall. The "smaller problem" is not smaller
     in the way that matters.

Moral: factoring doesn't recurse into easy pieces. After the cheap small primes fall off,
what remains is exactly as hard as a fresh RSA modulus of the same size.

Run:  .venv/bin/python hsln_bitcoin_recurse.py
"""
from __future__ import annotations

import random
import numpy as np
import matplotlib.pyplot as plt

from hsln_bitcoin_probe import KEYS, pubkey_x, peel_small_factors, SCAN_BOUND
from hsln_e8_torsion_factor import FG, ACCENT, ACCENT2, COMP, GRID, save_fig

random.seed(0)


def is_probable_prime(n: int, rounds: int = 48) -> bool:
    """Miller-Rabin: deterministic small bases + random witnesses (strong PRP)."""
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    bases = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37] + \
            [random.randrange(2, n - 1) for _ in range(rounds)]
    for a in bases:
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def main():
    results = {}
    print("=" * 74)
    print(" Extract the small factors, then run again on the cofactor")
    print("=" * 74)
    for name, hexk in KEYS.items():
        x = pubkey_x(hexk)
        facs, cof = peel_small_factors(x, SCAN_BOUND)
        prime = is_probable_prime(cof)
        results[name] = dict(x=x, facs=facs, cof=cof, prime=prime)
        chain = " × ".join(f"{p}" for p in sorted(set(facs))) or "1"
        print(f"\n {name}")
        print(f"   x        = {x.bit_length()}-bit")
        print(f"   peeled   = {chain}   (removed {x.bit_length() - cof.bit_length()} bits)")
        print(f"   cofactor = {cof.bit_length()}-bit, "
              f"{'PRIME → nothing left to extract' if prime else 'composite'}")
        if prime:
            print(f"   ⇒ fully factored: x = {chain} × (a {cof.bit_length()}-bit prime). "
                  f"The recursion ends. No smaller problem.")
        else:
            half = cof.bit_length() // 2
            print(f"   ⇒ run-again would need to scan to √cofactor ≈ 2^{half} "
                  f"— the exponential wall, no easier than the original.")

    # ---------------- figure ----------------
    names = list(KEYS)
    short = [n.split(" (")[0] for n in names]

    fig = plt.figure(figsize=(16, 6.5))
    fig.suptitle('"Peel the factors and recurse" — why the smaller problem isn\'t smaller',
                 color=FG, fontsize=14, y=0.99)

    # Panel 1: bit budget — sliver peeled vs irreducible remainder
    ax = fig.add_subplot(1, 3, 1)
    y = np.arange(len(names))
    peeled = [results[n]["x"].bit_length() - results[n]["cof"].bit_length() for n in names]
    rem = [results[n]["cof"].bit_length() for n in names]
    ax.barh(y, peeled, color=ACCENT, edgecolor=FG, label="bits peeled (small primes)")
    ax.barh(y, rem, left=peeled, color=COMP, edgecolor=FG,
            label="irreducible remainder (PRIME)")
    for i, n in enumerate(names):
        ax.text(peeled[i] + rem[i] + 2, i,
                f"{rem[i]}-bit {'prime' if results[n]['prime'] else 'composite'}",
                color=FG, fontsize=8, va="center")
    ax.set_yticks(y); ax.set_yticklabels(short, fontsize=9)
    ax.set_xlabel("bits of the x-coordinate", color=FG)
    ax.set_xlim(0, 300)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="lower right")
    ax.set_title("1 · peeling removes a sliver; the rest is irreducible", color=FG, fontsize=11)
    _grid(ax)

    # Panel 2: raising the scan bound finds nothing more until the wall
    ax = fig.add_subplot(1, 3, 2)
    log2_bounds = np.arange(1, 130)
    for i, n in enumerate(names):
        ufacs = sorted(set(results[n]["facs"]))
        cum = [sum(1 for f in ufacs if f <= 2.0 ** b) for b in log2_bounds]
        ax.step(log2_bounds, cum, where="post", lw=1.8,
                color=ACCENT if i == 0 else ACCENT2, label=short[i])
        wall = results[n]["cof"].bit_length() // 2
        ax.axvline(wall, color=(ACCENT if i == 0 else ACCENT2), ls=":", lw=1)
    ax.axvline(np.log2(SCAN_BOUND), color=GRID, ls="--", lw=1)
    ax.annotate("our scan\nbound (2^21)", (np.log2(SCAN_BOUND), 0.3), color=FG,
                fontsize=7, ha="center")
    ax.annotate("next factor only here →\n(√cofactor ≈ 2^108–2^124, the wall)",
                (70, 3.2), color=FG, fontsize=7.5, ha="center")
    ax.set_xlabel("scan bound (log₂)", color=FG)
    ax.set_ylabel("distinct factors found", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="center right")
    ax.set_title("2 · raise the bound: it flatlines until the wall", color=FG, fontsize=11)
    _grid(ax)

    # Panel 3: verdict — built from the ACTUAL primality results
    ax = fig.add_subplot(1, 3, 3)
    ax.axis("off")
    all_prime = all(results[n]["prime"] for n in names)
    lines = [("RECURSE? — the smaller problem isn't smaller", ACCENT, 12), ("", FG, 5)]
    for n in names:
        r = results[n]
        chain = " × ".join(str(p) for p in sorted(set(r["facs"])))
        tag = "PRIME" if r["prime"] else "COMPOSITE"
        lines.append((f"{n.split(' (')[0]}:", ACCENT2, 10))
        lines.append((f"   x = {chain} × ({r['cof'].bit_length()}-bit {tag})", FG, 9))
    lines.append(("", FG, 5))
    if all_prime:
        lines += [("Every cofactor is PRIME — irreducible.", "#ff6b6b", 11),
                  ("No smaller sub-problem exists; the tree", FG, 10),
                  ("ends at one big prime. Run-again finds", FG, 10),
                  ("nothing.", FG, 10)]
    else:
        lines += [("The cofactor is COMPOSITE — but it has", "#ff6b6b", 11),
                  ("NO factor below our 2^21 scan bound.", FG, 10),
                  ("To split it you must reach √cofactor", FG, 10),
                  (f"≈ 2^{results[names[0]]['cof'].bit_length()//2} — the full exponential wall.", FG, 10)]
    lines += [("", FG, 5),
              ("Either way, peeling removed only a few", FG, 10),
              ("bits and left the hard part untouched.", FG, 10),
              ("", FG, 4),
              ("Factoring does NOT divide-and-conquer:", ACCENT2, 10),
              ("after the cheap primes fall off, what's", ACCENT2, 10),
              ("left is as hard as a fresh RSA modulus.", ACCENT2, 10)]
    yy = 0.99
    for t, c, sz in lines:
        ax.text(0.0, yy, t, color=c, fontsize=sz, va="top", transform=ax.transAxes)
        yy -= 0.052 if t else 0.026

    fig.subplots_adjust(left=0.08, right=0.98, top=0.88, bottom=0.12, wspace=0.30)
    save_fig(fig, "61_hsln_bitcoin_recurse.png")


if __name__ == "__main__":
    main()
