"""Level-1 modular forms by q-series + SL(2,Z) fundamental-domain reduction.

Evaluating E4 by its q-series 1 + 240 sum sigma3(n) q^n only converges quickly for
Im(tau) not too small. To get accurate values everywhere in the upper half-plane we
first reduce tau into the standard fundamental domain D = {|tau|>=1, |Re tau|<=1/2}
by an element g in SL(2,Z), evaluate the fast-converging series there, then undo the
weight-k automorphy factor (c tau + d)^k.

Theta_E8(tau) = E4(tau), so this module *is* the genus-1 Siegel modular form of E8.
"""
from __future__ import annotations

import numpy as np

_NTERMS = 24
_n = np.arange(1, _NTERMS + 1)
_SIG3 = np.array([sum(d ** 3 for d in range(1, k + 1) if k % d == 0) for k in _n], dtype=float)
_SIG5 = np.array([sum(d ** 5 for d in range(1, k + 1) if k % d == 0) for k in _n], dtype=float)


def to_fundamental(tau, iters: int = 80):
    """Reduce tau into the fundamental domain.

    Returns (z, (a, b, c, d)) with z = (a tau + b)/(c tau + d) in D and
    [[a,b],[c,d]] in SL(2,Z). Arrays are broadcast over the input shape.
    """
    tau = np.asarray(tau, dtype=np.complex128)
    shape = tau.shape
    z = tau.ravel().copy()
    a = np.ones(z.size)
    b = np.zeros(z.size)
    c = np.zeros(z.size)
    d = np.ones(z.size)
    for _ in range(iters):
        k = np.round(z.real)
        z = z - k
        a = a - k * c
        b = b - k * d
        m = np.abs(z) < 1.0 - 1e-12
        if m.any():
            zi = z[m]
            z[m] = -1.0 / zi
            am, bm, cm, dm = a[m].copy(), b[m].copy(), c[m].copy(), d[m].copy()
            a[m] = -cm
            b[m] = -dm
            c[m] = am
            d[m] = bm
    return (
        z.reshape(shape),
        (a.reshape(shape), b.reshape(shape), c.reshape(shape), d.reshape(shape)),
    )


def _e4_series(z):
    q = np.exp(2j * np.pi * z)
    qn = q[..., None] ** _n
    return 1.0 + 240.0 * (qn * _SIG3).sum(axis=-1)


def _e4_series_deriv(z):
    """d/dz of the E4 series."""
    q = np.exp(2j * np.pi * z)
    qn = q[..., None] ** _n
    return 240.0 * (qn * (_SIG3 * 2j * np.pi * _n)).sum(axis=-1)


def _e6_series(z):
    q = np.exp(2j * np.pi * z)
    qn = q[..., None] ** _n
    return 1.0 - 504.0 * (qn * _SIG5).sum(axis=-1)


def e4(tau):
    """Weight-4 Eisenstein series = theta function of E8."""
    z, (a, b, c, d) = to_fundamental(tau)
    return (c * tau + d) ** (-4) * _e4_series(z)


def e4_grad(tau):
    """Return (E4(tau), dE4/dtau), the latter via the chain rule through reduction."""
    z, (a, b, c, d) = to_fundamental(tau)
    jac = c * tau + d
    e4z = _e4_series(z)
    e4pz = _e4_series_deriv(z)
    val = jac ** (-4) * e4z
    grad = -4.0 * c * jac ** (-5) * e4z + jac ** (-6) * e4pz
    return val, grad


def e6(tau):
    z, (a, b, c, d) = to_fundamental(tau)
    return (c * tau + d) ** (-6) * _e6_series(z)


def delta(tau):
    """Modular discriminant Delta = (E4^3 - E6^2)/1728 (weight 12, nonvanishing on H)."""
    z, (a, b, c, d) = to_fundamental(tau)
    e4z = _e4_series(z)
    e6z = _e6_series(z)
    return (c * tau + d) ** (-12) * (e4z ** 3 - e6z ** 2) / 1728.0


def jinv(tau):
    """Klein j-invariant E4^3/Delta (weight 0, SL(2,Z)-invariant)."""
    z, _ = to_fundamental(tau)
    e4z = _e4_series(z)
    e6z = _e6_series(z)
    dz = (e4z ** 3 - e6z ** 2) / 1728.0
    return e4z ** 3 / dz


# --- truncated "DNA" forms (the network's actual finite landscape, spec 2.2) ----

def qpoly(coeffs, tau):
    """Evaluate a truncated form F(tau) = sum_n coeffs[n] q^n, q = exp(2 pi i tau)."""
    coeffs = np.asarray(coeffs, dtype=np.complex128)
    q = np.exp(2j * np.pi * np.asarray(tau, dtype=np.complex128))
    powers = q[..., None] ** np.arange(coeffs.size)
    return (powers * coeffs).sum(axis=-1)


def qpoly_grad(coeffs, tau):
    """Return (F, dF/dtau) for the truncated form."""
    coeffs = np.asarray(coeffs, dtype=np.complex128)
    idx = np.arange(coeffs.size)
    q = np.exp(2j * np.pi * np.asarray(tau, dtype=np.complex128))
    powers = q[..., None] ** idx
    val = (powers * coeffs).sum(axis=-1)
    grad = (powers * (coeffs * 2j * np.pi * idx)).sum(axis=-1)
    return val, grad


def qpoly_zeros(coeffs):
    """Zeros (neurons) of F in tau-space: roots of the q-polynomial with |q|<1.

    Returns tau values with Im(tau) > 0 and Re(tau) in [0,1).
    """
    coeffs = np.asarray(coeffs, dtype=np.complex128)
    # strip a leading-zero (cusp) coefficient block; np.roots wants highest power first
    qroots = np.roots(coeffs[::-1])
    qroots = qroots[np.abs(qroots) > 1e-12]
    qroots = qroots[np.abs(qroots) < 1.0 - 1e-9]
    tau = np.log(qroots) / (2j * np.pi)
    tau = tau.real % 1.0 + 1j * tau.imag
    return tau[tau.imag > 1e-6]


if __name__ == "__main__":
    # E4 q-expansion check.
    tau = 1j * 5.0  # large imaginary -> q ~ 0, E4 ~ 1
    print("E4(5i) ~ 1:", e4(tau))
    # Zero of E4 at rho = exp(2 pi i / 3).
    rho = np.exp(2j * np.pi / 3.0)
    print("E4(rho) ~ 0:", abs(e4(rho + 1e-9j)))
    # Modularity: E4(-1/tau) = tau^4 E4(tau).
    t = 0.3 + 0.7j
    lhs = e4(-1.0 / t)
    rhs = t ** 4 * e4(t)
    print("modularity residual:", abs(lhs - rhs))
    # Gradient finite-difference check.
    h = 1e-6
    _, g = e4_grad(t)
    fd = (e4(t + h) - e4(t - h)) / (2 * h)
    print("grad residual:", abs(g - fd))
    print("modular module OK")
