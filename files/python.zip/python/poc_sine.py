"""HSLN driven by a time-varying input: learn to follow a sine wave.

Reuses the genus-1 gravity field from poc.py. The input is now u(t) = sin(omega t),
injected as the drive B u(t); a small linear readout of the state is trained jointly
with the gravity DNA so the output tracks a target sine.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np
from jax import lax, value_and_grad

import poc

jax.config.update("jax_enable_x64", True)

DG = poc.DG
T = 240
DT = 0.03
CYCLES = 2.5
B_VEC = jnp.array([0.55, 0.0])
START = jnp.array([0.5, 0.35])

_ts = jnp.arange(T)
U = jnp.sin(2 * jnp.pi * CYCLES * _ts / T)          # sine input
TARGET = 0.35 * jnp.sin(2 * jnp.pi * CYCLES * _ts / T)  # target waveform to follow

NP = 2 * DG  # gravity params; then readout (a, b, d)


def _split(params):
    return params[:NP], params[NP], params[NP + 1], params[NP + 2]


def rollout(params, alpha=2.0, dt=DT, vmax=3.0, ymin=0.05, ymax=0.95):
    gp = params[:NP]

    def stepfn(xy, u):
        g = poc._grad_energy(gp, xy)
        # RAW gradient (a restoring spring near a zero) -> driven first-order oscillator,
        # clipped for stability. NOT unit-speed (which would pin the state).
        vx = jnp.clip(-alpha * g[0], -vmax, vmax)
        vy = jnp.clip(-alpha * g[1], -vmax, vmax)
        nx = jnp.clip(xy[0] + dt * (vx + B_VEC[0] * u), 0.02, 0.98)
        ny = jnp.clip(xy[1] + dt * (vy + B_VEC[1] * u), ymin, ymax)
        new = jnp.array([nx, ny])
        return new, new
    _, traj = lax.scan(stepfn, START, U)
    return traj


def readout(params, traj):
    _, a, b, d = _split(params)
    return a * (traj[:, 0] - 0.5) + b * (traj[:, 1] - 0.5) + d


def loss(params):
    r = readout(params, rollout(params))
    return jnp.mean((r - TARGET) ** 2) + 1e-4 * jnp.sum(params[:NP] ** 2)


_loss_and_grad = jax.jit(value_and_grad(loss))


def init(seed=0):
    gp = np.array(poc.init_params(seed))
    return jnp.array(np.concatenate([gp, [1.0, 0.0, 0.0]]))


def train(steps=1200, lr=0.01, seed=0):
    p = init(seed)
    p0 = p
    m = jnp.zeros_like(p); v = jnp.zeros_like(p)
    b1, b2, eps = 0.9, 0.999, 1e-8
    hist = []
    for t in range(1, steps + 1):
        L, g = _loss_and_grad(p)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        p = p - lr * (m / (1 - b1 ** t)) / (jnp.sqrt(v / (1 - b2 ** t)) + eps)
        hist.append(float(L))
    return p0, p, hist


def visualize(steps=1200, lr=0.01, seed=0):
    import matplotlib.pyplot as plt
    from pathlib import Path
    import style

    p0, p, hist = train(steps=steps, lr=lr, seed=seed)
    t = np.arange(T) * DT
    r0 = np.array(readout(p0, rollout(p0)))
    r1 = np.array(readout(p, rollout(p)))

    fig, ax = plt.subplots(1, 2, figsize=(14, 4.8), gridspec_kw={"width_ratios": [2, 1]})
    ax[0].plot(t, np.array(U), color="#5a5a6a", lw=1.0, label="input  u(t) = sin")
    ax[0].plot(t, np.array(TARGET), color="white", lw=1.8, ls="--", label="target")
    ax[0].plot(t, r0, color=style.NEURON, lw=1.2, alpha=0.55, label="output (before)")
    ax[0].plot(t, r1, color="#46f0d0", lw=2.2, label="output (after)")
    ax[0].set_xlabel("time"); ax[0].set_ylabel("signal")
    ax[0].set_title("HSLN driven by a sine wave learns to follow it", fontsize=13)
    ax[0].legend(loc="upper right", fontsize=9, framealpha=0.3)
    ax[0].grid(alpha=0.15)

    ax[1].plot(hist, color=style.ACCENT, lw=1.6)
    ax[1].set_yscale("log"); ax[1].set_xlabel("Adam step"); ax[1].set_ylabel("MSE (log)")
    ax[1].set_title("training", fontsize=13); ax[1].grid(alpha=0.2)

    out = Path(__file__).parent / "figures" / "15_poc_sine.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    rmse = float(np.sqrt(np.mean((r1 - np.array(TARGET)) ** 2)))
    print(f"loss {hist[0]:.4f} -> {hist[-1]:.5f};  RMSE {rmse:.4f};  wrote {out}")


if __name__ == "__main__":
    visualize()
