"""hsln_prime_dna.py — Train HSLN onto a big-ish prime and inspect the DNA.

The HSLN framework trains a 1-D modular DNA  F(τ) = Σₙ aₙ qⁿ  so that its `spike
map` (1/|F| on the input lane Im τ = LANE_Y) lights up at a target probe position.
We encode a prime p as a position on the lane via:

    pos(p) = frac(log₂ p) ∈ [0, 1)

and snap to the closest of HSLN's 12 probe positions (PROBES). The model then
learns a complex coefficient vector (a₀, …, a_{dg−1}) — the DNA — whose modular
form has a *neuron* at the position encoded by p.

What we visualise: the **trained DNA itself** — magnitude, phase, real/imag parts —
plus the resulting spike map and the neuron landscape. The point is to *see what
coefficients come out* when HSLN converges onto a prime-encoded target.

For comparison we also train on a handful of smaller primes, giving a "prime DNA
atlas" of the same model architecture at different anchor positions.
"""

from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln    # local
import modular # local

jax.config.update("jax_enable_x64", True)

mpl.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'axes.edgecolor': '#333333',
    'axes.labelsize': 11,
    'axes.titlesize': 12,
    'legend.fontsize': 9,
})

FIG_DIR = HERE / 'figures'


# ───────────────────────────────────────────────────────────────────────────────
#   Encode a prime as a position on the HSLN input lane
# ───────────────────────────────────────────────────────────────────────────────

def encode_prime_as_target(p: int) -> tuple[np.ndarray, int, float]:
    """Map prime p → spike pattern on PROBES.

    Encoding: pos = frac(log₂ p) ∈ [0,1). Snap to closest probe.
    Returns (target_vector, probe_index, pos)."""
    log_p = math.log2(p)
    pos = log_p - math.floor(log_p)
    probes_arr = np.array(hsln.PROBES)
    probe_idx = int(np.argmin(np.abs(probes_arr - pos)))
    target = np.zeros_like(probes_arr, dtype=float)
    target[probe_idx] = 1.0
    return target, probe_idx, pos


# ───────────────────────────────────────────────────────────────────────────────
#   Train one model per prime
# ───────────────────────────────────────────────────────────────────────────────

def train_for_prime(p: int, *, dg: int = 12, steps: int = 2500, lr: float = 0.01,
                    seed: int | None = None):
    """Train HSLN onto the prime p. Returns (Network, history, target, probe_idx, pos)."""
    if seed is None:
        seed = (p * 2654435761) & 0xFFFFFFFF  # Knuth hash, deterministic per p
    target, probe_idx, pos = encode_prime_as_target(p)
    net, hist = hsln.train_task(target, dg=dg, steps=steps, lr=lr, seed=seed)
    return net, np.array(hist), target, probe_idx, pos


# ───────────────────────────────────────────────────────────────────────────────
#   Visualisation A: the focal prime (deep dive)
# ───────────────────────────────────────────────────────────────────────────────

def fig_a_big_prime_focus(net, hist, target, probe_idx, pos, p: int, dg: int):
    fig = plt.figure(figsize=(15.5, 11))
    gs = fig.add_gridspec(3, 2, height_ratios=[1, 1, 1.2], hspace=0.42, wspace=0.28)

    dna = net.dna
    indices = np.arange(dg)

    # ── A1: target vs achieved spike pattern ──────────────────────────────────
    ax = fig.add_subplot(gs[0, 0])
    xs_dense = np.linspace(0.0, 1.0, 800)
    achieved = np.array(hsln.spike_map(jnp.asarray(dna), jnp.asarray(xs_dense)))
    ax.fill_between(xs_dense, 0, achieved, color='#1f77b4', alpha=0.55,
                    label='achieved spike map  1/|F|')
    ax.scatter(hsln.PROBES, target, color='#d62728', s=70, zorder=5, marker='X',
               label='target (encoded prime)')
    ax.axvline(pos, color='black', linestyle=':', linewidth=1, alpha=0.6,
               label=f'pos(p) = frac(log₂ p) = {pos:.4f}')
    ax.axvline(hsln.PROBES[probe_idx], color='#d62728', linestyle='--',
               linewidth=1, alpha=0.4)
    ax.set_xlabel('input position  Re τ')
    ax.set_ylabel('spike amplitude')
    ax.set_title(f'A1. Trained spike map for p = {p:,}\nencoded at probe {probe_idx} (position {hsln.PROBES[probe_idx]:.2f})')
    ax.set_xlim(0, 1); ax.set_ylim(-0.05, 1.15)
    ax.grid(alpha=0.3)
    ax.legend(loc='upper right', fontsize=9)

    # ── A2: DNA — magnitudes ─────────────────────────────────────────────────
    ax = fig.add_subplot(gs[0, 1])
    mags = np.abs(dna)
    ax.bar(indices, mags, width=0.7, color='#2ca02c', edgecolor='black', alpha=0.85)
    for i, m in enumerate(mags):
        ax.annotate(f'{m:.2f}', (i, m), textcoords='offset points',
                    xytext=(0, 4), ha='center', fontsize=8.5)
    ax.set_xlabel('coefficient index n')
    ax.set_ylabel('|aₙ|')
    ax.set_title(f'A2. Trained DNA magnitudes  |aₙ|, n = 0…{dg-1}')
    ax.set_xticks(indices)
    ax.grid(alpha=0.3, axis='y')

    # ── A3: DNA — real and imaginary parts side by side ──────────────────────
    ax = fig.add_subplot(gs[1, 0])
    width = 0.35
    ax.bar(indices - width/2, dna.real, width, label='Re aₙ',
           color='#1f77b4', edgecolor='black', alpha=0.9)
    ax.bar(indices + width/2, dna.imag, width, label='Im aₙ',
           color='#ff7f0e', edgecolor='black', alpha=0.9)
    ax.axhline(0, color='black', linewidth=0.6)
    ax.set_xlabel('coefficient index n')
    ax.set_ylabel('aₙ')
    ax.set_title('A3. Trained DNA: real and imaginary parts')
    ax.set_xticks(indices)
    ax.grid(alpha=0.3, axis='y')
    ax.legend(loc='upper right')

    # ── A4: DNA on the complex plane (each aₙ as a point) ────────────────────
    ax = fig.add_subplot(gs[1, 1])
    cmap = plt.cm.viridis
    colors_n = cmap(indices / max(indices.max(), 1))
    for i, (an, c) in enumerate(zip(dna, colors_n)):
        ax.plot([0, an.real], [0, an.imag], color=c, linewidth=1.4, alpha=0.55)
        ax.scatter(an.real, an.imag, color=c, s=110, zorder=5,
                   edgecolor='black', linewidth=0.5)
        ax.annotate(f'a{i}', (an.real, an.imag),
                    textcoords='offset points', xytext=(7, 3),
                    fontsize=9, fontweight='bold')
    ax.axhline(0, color='black', linewidth=0.4)
    ax.axvline(0, color='black', linewidth=0.4)
    M = max(mags.max() * 1.25, 1.0)
    ax.set_xlim(-M, M); ax.set_ylim(-M, M)
    ax.set_xlabel('Re aₙ'); ax.set_ylabel('Im aₙ')
    ax.set_aspect('equal')
    ax.set_title('A4. DNA in ℂ — each aₙ as a point with phase + magnitude')
    ax.grid(alpha=0.3)

    # ── A5: neuron landscape — |F(τ)| on a slice of upper half-plane ─────────
    ax = fig.add_subplot(gs[2, 0])
    Nx, Ny = 220, 180
    xs = np.linspace(0.0, 1.0, Nx)
    ys = np.linspace(0.05, 0.55, Ny)
    X, Y = np.meshgrid(xs, ys)
    tau_grid = X + 1j * Y
    F = modular.qpoly(dna, tau_grid)
    logF = np.log10(np.abs(F) + 1e-12)
    pcm = ax.pcolormesh(X, Y, logF, shading='auto', cmap='magma_r')
    plt.colorbar(pcm, ax=ax, label='log₁₀ |F(τ)|')
    zeros = net.zeros()
    ax.scatter(zeros.real, zeros.imag, marker='o', s=80,
               edgecolor='#46f0d0', facecolors='none', linewidth=1.8,
               label=f'neurons (zeros of F): {len(zeros)}')
    ax.axhline(hsln.LANE_Y, color='cyan', linestyle='--', linewidth=0.8,
               alpha=0.5, label=f'input lane Im τ = {hsln.LANE_Y}')
    ax.axvline(pos, color='lime', linestyle=':', linewidth=1.2,
               alpha=0.7, label=f'target Re τ = {pos:.3f}')
    ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
    ax.set_title('A5. Neuron landscape: log₁₀|F(τ)| with zeros')
    ax.legend(loc='upper right', fontsize=8.5)

    # ── A6: training loss curve ──────────────────────────────────────────────
    ax = fig.add_subplot(gs[2, 1])
    ax.semilogy(hist, color='#9467bd', linewidth=1.6)
    ax.set_xlabel('training step')
    ax.set_ylabel('loss (log scale)')
    ax.set_title(f'A6. Training loss curve\nstarting {hist[0]:.3f} → final {hist[-1]:.5f}')
    ax.grid(alpha=0.3, which='both')

    fig.suptitle(f'HSLN trained onto p = {p:,}  '
                 f'(dg = {dg}, encoded position = frac(log₂ p) = {pos:.4f})',
                 fontsize=14, y=0.995)

    out = FIG_DIR / '44_hsln_dna_big_prime.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"  ✓ {out.name}")


# ───────────────────────────────────────────────────────────────────────────────
#   Visualisation B: the prime DNA library (comparison across primes)
# ───────────────────────────────────────────────────────────────────────────────

def fig_b_library(results, dg: int):
    primes_sorted = sorted(results.keys())
    M = len(primes_sorted)

    fig, axes = plt.subplots(2, 2, figsize=(15.5, 11))

    # ── B1: heatmap of |aₙ| across primes ─────────────────────────────────────
    ax = axes[0, 0]
    mag_grid = np.array([np.abs(results[p][0].dna) for p in primes_sorted])
    im = ax.imshow(mag_grid, aspect='auto', cmap='viridis', origin='lower')
    ax.set_yticks(range(M))
    ax.set_yticklabels([f'{p:,}' for p in primes_sorted])
    ax.set_xticks(range(dg))
    ax.set_xlabel('coefficient index n')
    ax.set_ylabel('prime p')
    ax.set_title('B1. |aₙ| across primes  (each row = one trained DNA)')
    plt.colorbar(im, ax=ax, label='|aₙ|')

    # ── B2: heatmap of Re aₙ ──────────────────────────────────────────────────
    ax = axes[0, 1]
    re_grid = np.array([results[p][0].dna.real for p in primes_sorted])
    vmax_re = max(abs(re_grid.min()), abs(re_grid.max()))
    im = ax.imshow(re_grid, aspect='auto', cmap='RdBu_r', origin='lower',
                   vmin=-vmax_re, vmax=vmax_re)
    ax.set_yticks(range(M))
    ax.set_yticklabels([f'{p:,}' for p in primes_sorted])
    ax.set_xticks(range(dg))
    ax.set_xlabel('coefficient index n')
    ax.set_ylabel('prime p')
    ax.set_title('B2. Re aₙ across primes')
    plt.colorbar(im, ax=ax, label='Re aₙ')

    # ── B3: trained DNAs as complex-plane scatters ────────────────────────────
    ax = axes[1, 0]
    colors_p = plt.cm.plasma(np.linspace(0.05, 0.92, M))
    for p, c in zip(primes_sorted, colors_p):
        d = results[p][0].dna
        ax.plot(d.real, d.imag, '-o', color=c, alpha=0.75,
                markersize=6, linewidth=1.2,
                label=f'p = {p:,}' if p > 1000 else f'p = {p}')
    ax.axhline(0, color='black', linewidth=0.4)
    ax.axvline(0, color='black', linewidth=0.4)
    ax.set_xlabel('Re aₙ'); ax.set_ylabel('Im aₙ')
    ax.set_aspect('equal')
    ax.set_title(f'B3. Trained DNAs as paths in ℂ  (per-prime, n = 0…{dg-1})')
    ax.legend(loc='upper right', fontsize=8.5, ncols=2)
    ax.grid(alpha=0.3)

    # ── B4: training loss curves ──────────────────────────────────────────────
    ax = axes[1, 1]
    for p, c in zip(primes_sorted, colors_p):
        hist = results[p][1]
        ax.semilogy(hist, color=c, linewidth=1.4, alpha=0.85,
                    label=f'p = {p:,}' if p > 1000 else f'p = {p}')
    ax.set_xlabel('training step')
    ax.set_ylabel('loss (log scale)')
    ax.set_title('B4. Loss curves — convergence across primes')
    ax.legend(loc='upper right', fontsize=8.5, ncols=2)
    ax.grid(alpha=0.3, which='both')

    fig.suptitle(f'Prime DNA atlas: HSLN trained onto {M} different primes (dg = {dg})',
                 fontsize=14, y=1.00)
    plt.tight_layout(rect=[0, 0, 1, 0.97])

    out = FIG_DIR / '45_hsln_dna_atlas.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"  ✓ {out.name}")


# ───────────────────────────────────────────────────────────────────────────────
#   Main
# ───────────────────────────────────────────────────────────────────────────────

def main():
    print("=" * 78)
    print(" HSLN trained onto a big-ish prime — inspect the DNA")
    print("=" * 78)
    print()

    DG = 12
    STEPS = 2500
    BIG_P = 1_000_003   # the focal big-ish prime
    LIBRARY = [2, 3, 5, 7, 11, 13, 23, 37, 101, 1009, BIG_P]

    results = {}
    print(f"  Training HSLN (dg = {DG}, steps = {STEPS}) onto {len(LIBRARY)} primes …\n")
    print(f"   prime      |  encoded position frac(log₂ p)  |  probe idx → pos  |  final loss")
    print(f"  ------------+--------------------------------+-------------------+--------------")
    t_total = 0.0
    for p in LIBRARY:
        t0 = time.perf_counter()
        net, hist, target, probe_idx, pos = train_for_prime(p, dg=DG, steps=STEPS)
        dt = time.perf_counter() - t0
        t_total += dt
        results[p] = (net, hist, target, probe_idx, pos)
        loss_final = float(hist[-1])
        print(f"   {p:>10,}  |          {pos:.4f}                  "
              f"|   {probe_idx:2d} → {hsln.PROBES[probe_idx]:.2f}     "
              f"|  {loss_final:.5f}   ({dt:.1f}s)")
    print(f"\n  ✓ total training time: {t_total:.1f}s\n")

    # ── focal prime: dump the trained DNA explicitly ─────────────────────────
    big_net, big_hist, big_target, big_probe_idx, big_pos = results[BIG_P]
    print(f"  ─── Trained DNA for p = {BIG_P:,}  (dg = {DG}) ───\n")
    print(f"    n  |       Re aₙ           Im aₙ        |aₙ|          arg aₙ (deg)")
    print(f"  -----+---------------------------------------------------------------")
    for n, an in enumerate(big_net.dna):
        ang = math.degrees(math.atan2(an.imag, an.real))
        print(f"    {n:2d} |   {an.real:+.6f}    {an.imag:+.6f}     {abs(an):.6f}      {ang:+7.2f}")
    print()

    print("  ─── Generating figures ───")
    fig_a_big_prime_focus(big_net, big_hist, big_target, big_probe_idx, big_pos, BIG_P, DG)
    fig_b_library(results, DG)

    print()
    print("─" * 78)
    print(f"  Summary: HSLN converged onto a spike encoding p = {BIG_P:,}")
    print(f"  • DNA length: {DG}  (complex coefficients)")
    print(f"  • Encoding: frac(log₂ p) → snap to PROBES[{big_probe_idx}] = {hsln.PROBES[big_probe_idx]:.2f}")
    print(f"  • Final loss: {float(big_hist[-1]):.5f}")
    print(f"  • Two figures saved: 44 (focal prime), 45 (atlas across primes).")


if __name__ == "__main__":
    main()
