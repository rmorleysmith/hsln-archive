"""A discrete task: answer "What is your name?" by emitting symbols at CM points.

Readout = the singular-modulus codebook. Each output coordinate's final state tau*
is reduced to the fundamental domain, its j-invariant j(tau*) computed (an SL(2,Z)
invariant, so it works wherever the flow happens to be), and snapped to the nearest
integer CM value. That integer names a symbol.

We train the gravity DNA so a fixed "question" input routes each of three output
coordinates (a genus-3 direct sum) to a chosen letter's CM point. Because j is
modular-invariant, we route to a LOW-Im representative of each CM class -- e.g.
(0.5, 0.5) reduces to i (j=1728), (0.5, sqrt3/2) is rho (j=0) -- which the gradient
flow can actually reach, then decode the invariant j there.

Answer encoded: A -> j=1728,  D -> j=0   =>   "ADA".
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import jax.numpy as jnp

import hsln_dyn as g1
import modular

# --- CM codebook: integer j-value -> symbol -------------------------------- #
CODEBOOK = {1728: "A", 0: "D", 8000: "I", -3375: "S", -32768: "L",
            -884736: "N", -147197952000: "E", -262537412640768000: "?"}
CODE_VALUES = np.array(sorted(CODEBOOK.keys()), dtype=float)

# letter -> (CM j-value, a low-Im representative tau the flow can reach)
LETTER_CM = {
    "A": (1728, (0.5, 0.5)),          # reduces to i
    "D": (0, (0.5, float(np.sqrt(3) / 2))),  # rho, E4's own zero
}
ANSWER = "ADA"
QUESTION_START = (0.5, 0.62)          # fixed input encoding "What is your name?"


def decode(tau) -> tuple[int, str]:
    """Reduce tau, compute j, snap to nearest CM codeword, return (j_int, symbol)."""
    j = complex(modular.jinv(np.array([tau]))[0]).real
    k = int(np.argmin(np.abs(CODE_VALUES - j)))
    cm = int(CODE_VALUES[k])
    return cm, CODEBOOK[cm]


def run(make_fig=True):
    # verify the chosen representatives carry the intended j-values
    print("readout check (j at the chosen representatives):")
    for L, (j_target, tau) in LETTER_CM.items():
        jval = complex(modular.jinv(np.array([tau[0] + 1j * tau[1]]))[0]).real
        print(f"  {L}: tau={tau}  j={jval:.3f}  (target {j_target})  decode={decode(tau[0]+1j*tau[1])}")

    # train one router per distinct letter: question input -> that letter's CM point
    routers = {}
    for L, (_j, tgt) in LETTER_CM.items():
        dna, hist = g1.train_routing([QUESTION_START], [tgt], steps=1800, seed=hash(L) % 7 + 1)
        end = g1.endpoint(dna, QUESTION_START)
        routers[L] = dict(dna=dna, hist=hist, target=tgt, end=end)
        print(f"router {L}: end={np.round(end,3)} target={tgt} "
              f"decode={decode(end[0]+1j*end[1])}")

    # assemble the answer: coordinate k routes with letter ANSWER[k]'s DNA
    decoded = []
    coords = []
    for k, L in enumerate(ANSWER):
        end = routers[L]["end"]
        cm, sym = decode(end[0] + 1j * end[1])
        decoded.append(sym)
        coords.append((k, end, cm, sym))
    answer = "".join(decoded)
    print(f'\nQ: "What is your name?"   ->   A: "{answer}"   (target "{ANSWER}")')

    if make_fig:
        _figure(routers, coords, answer)
    return answer


def _figure(routers, coords, answer):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    GOLD, TEAL, GREEN, NEURON = "#ffd166", "#46f0d0", "#7CFC8A", "#ff3b6b"
    lcol = {"A": TEAL, "D": GOLD}

    fig, ax = plt.subplots(1, 2, figsize=(14.5, 5.6), gridspec_kw={"width_ratios": [1.1, 1]})

    # --- A: routing to the CM representatives in tau-space --- #
    a = ax[0]
    a.set_facecolor("#0b0b14")
    for L, r in routers.items():
        tr = np.array(g1.rollout(jnp.asarray(r["dna"]), jnp.asarray(QUESTION_START)))
        a.plot(tr[:, 0], tr[:, 1], color=lcol[L], lw=2.2, zorder=4)
        tx, ty = r["target"]
        a.plot(tx, ty, "*", color=lcol[L], ms=22, mec="white", mew=1.0, zorder=6)
        cm, _ = decode(r["end"][0] + 1j * r["end"][1])
        a.annotate(f"'{L}'  →  j={cm}", (tx, ty), textcoords="offset points",
                   xytext=(12, 4), color=lcol[L], fontsize=10)
    a.plot(QUESTION_START[0], QUESTION_START[1], "o", color="white", ms=10, zorder=6)
    a.annotate('"What is your name?"', QUESTION_START, textcoords="offset points",
               xytext=(-10, 12), color="white", fontsize=9, ha="center")
    a.set_xlim(0.0, 1.0)
    a.set_ylim(0.1, 1.05)
    a.set_xlabel(r"$\mathrm{Re}\,\tau$")
    a.set_ylabel(r"$\mathrm{Im}\,\tau$")
    a.set_title("the question routes each output coordinate\nto a letter's CM point", fontsize=12)

    # --- B: decode each coordinate's j onto the CM codebook --- #
    b = ax[1]
    # codebook reference ticks (small |j| ones, for readability)
    small = [v for v in CODE_VALUES if abs(v) <= 4e4]
    for v in small:
        b.axhline(v, color="#33334a", lw=1)
        b.annotate(f"{int(v)} = '{CODEBOOK[int(v)]}'", (len(coords) - 0.4, v),
                   color="#7777aa", fontsize=8, va="center")
    for (k, end, cm, sym) in coords:
        jval = complex(modular.jinv(np.array([end[0] + 1j * end[1]]))[0]).real
        col = lcol.get(sym, GREEN)
        b.plot(k, jval, "o", color=col, ms=9, zorder=4)
        b.annotate("", xy=(k, cm), xytext=(k, jval),
                   arrowprops=dict(arrowstyle="->", color=col, lw=1.5))
        b.plot(k, cm, "s", color=col, ms=12, mec="white", mew=0.8, zorder=5)
        b.annotate(f"'{sym}'", (k, cm), textcoords="offset points", xytext=(0, 12),
                   color=col, fontsize=12, ha="center", fontweight="bold")
    b.set_xticks(range(len(coords)))
    b.set_xticklabels([f"coord {k+1}" for k in range(len(coords))])
    b.set_xlim(-0.5, len(coords) - 0.1)
    b.set_ylim(-4e4, 4e4)
    b.set_ylabel(r"$j(\tau^\ast)$  (snapped to nearest singular modulus)")
    b.set_title(f'decode  →  "{answer}"', fontsize=13)

    fig.suptitle('A discrete task: the network answers "What is your name?" by landing on '
                 'CM points and reading off their integer $j$', fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "24_cm_task.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
