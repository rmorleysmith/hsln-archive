"""
The SHA-256 side: point the instrument at the *hash*, like we did before.

Bitcoin uses SHA-256 twice over: an address is RIPEMD160(SHA256(pubkey)) and mining
is a search over double-SHA256(block header). So the honest "what lights up?" question
for keys and mining is a HASH question, not a factoring question.

Where the factoring detector RESONATED (divisors lit up — the Shor side), SHA-256 stays
DARK. This file shows why, on the real genesis public key:

  1. avalanche      — flip ONE input bit ⇒ ~half the 256 output bits flip. No direction
                      is special.
  2. avalanche dist — the flip-fraction is pinned at 0.5: a perfect coin per output bit.
  3. mining landscape — leading-zero-bits per nonce is structureless noise; a real block
                      needs ~80+ leading zero bits, astronomically far off this chart.
  4. preimage gradient — distance(hash, target) is ~128 regardless of how close the INPUT
                      is to a known preimage. The fitness landscape is flat: there is no
                      gradient for "gravity" to descend. This is the whole game.
  5. the dance      — successive nonce-hashes scatter uniformly across the E8 rings; no
                      attractor, no clustering (contrast the factoring spikes).

Conclusion: SHA-256 exposes no structure for HSLN gravity to grab. That is exactly why
mining and hashed addresses are only QUADRATICALLY helped by quantum (Grover), never
broken by period-finding (Shor). Factoring lights up; hashing does not.

Run:  .venv/bin/python hsln_bitcoin_hash.py
"""
from __future__ import annotations

import hashlib
import random
import numpy as np
import matplotlib.pyplot as plt

from hsln_e8_torsion_factor import e8_root_projection, FG, ACCENT, ACCENT2, COMP, GRID, save_fig

GENESIS_PUB = bytes.fromhex(
    "04678afdb0fe5548271967f1a67130b7105cd6a828e03909a67962e0ea1f61deb6"
    "49f6bc3f4cef38c4f35504e51ec112de5c384df7ba0b8d578a4c702b6bf11d5f"
)
random.seed(170)  # block 170 — the first transaction. deterministic run.


def dsha(b: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()


def hamming(a: bytes, b: bytes) -> int:
    return bin(int.from_bytes(a, "big") ^ int.from_bytes(b, "big")).count("1")


def flip_bits(buf: bytes, d: int) -> bytes:
    bb = bytearray(buf)
    for _ in range(d):
        i = random.randrange(len(bb) * 8)
        bb[i // 8] ^= 1 << (i % 8)
    return bytes(bb)


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def main():
    base = GENESIS_PUB
    h0 = dsha(base)

    # 1. avalanche: flip each of the first 256 input bits
    aval = []
    for i in range(256):
        bb = bytearray(base)
        bb[i // 8] ^= 1 << (i % 8)
        aval.append(hamming(dsha(bytes(bb)), h0))
    aval = np.array(aval)

    # 3. mining landscape over nonces
    M = 6000
    lead = np.empty(M, dtype=int)
    angles = np.empty(M)
    radii = np.empty(M)
    for n in range(M):
        h = dsha(base + n.to_bytes(4, "big"))
        v = int.from_bytes(h, "big")
        lead[n] = 256 - v.bit_length() if v else 256
        angles[n] = 2 * np.pi * ((v % 30) / 30.0)
        radii[n] = ((v >> 200) & 0xFF) / 255.0   # an independent slice → radial spread

    # 4. preimage gradient test
    known = base + (12345).to_bytes(4, "big")
    target = dsha(known)
    T = 3000
    din = np.empty(T, dtype=int)
    dh = np.empty(T, dtype=int)
    for t in range(T):
        cand = flip_bits(known, random.randint(1, len(known) * 8))
        din[t] = hamming(cand, known)
        dh[t] = hamming(dsha(cand), target)

    print("=" * 72)
    print(" SHA-256 analysis of the genesis key (the hash / Grover side)")
    print("=" * 72)
    print(f"  avalanche: mean output bits flipped per 1-bit input flip = "
          f"{aval.mean():.1f} / 256  (ideal 128)")
    print(f"  mining: max leading-zero-bits in {M} nonces = {lead.max()}  "
          f"(a real block needs ~80+ → unreachable here)")
    print(f"  preimage: corr(input-distance, hash-distance-to-target) = "
          f"{np.corrcoef(din, dh)[0,1]:+.3f}  (≈0 ⇒ flat landscape, no gradient)")
    print(f"  hash-distance to target stays at {dh.mean():.1f} ± {dh.std():.1f} / 256 "
          f"no matter how close the input.")

    # ---------------- figure ----------------
    fig = plt.figure(figsize=(17, 10))
    fig.suptitle("The SHA-256 side of the genesis key — the instrument stays DARK "
                 "(why mining & addresses resist quantum)", color=FG, fontsize=15, y=0.98)

    # 1 avalanche
    ax = fig.add_subplot(2, 3, 1)
    ax.scatter(np.arange(256), aval, s=10, c=ACCENT2, alpha=0.7)
    ax.axhline(128, color=ACCENT, ls="--", lw=1.2, label="128 = half of 256")
    ax.set_ylim(90, 165)
    ax.set_xlabel("input bit flipped", color=FG)
    ax.set_ylabel("output bits changed", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2)
    ax.set_title("1 · avalanche: 1 bit in → ~½ the bits out", color=FG, fontsize=12)
    _grid(ax)

    # 2 avalanche distribution
    ax = fig.add_subplot(2, 3, 2)
    ax.hist(aval / 256.0, bins=24, color=ACCENT2, edgecolor=FG)
    ax.axvline(0.5, color=ACCENT, ls="--", lw=1.2)
    ax.set_xlabel("fraction of output bits changed", color=FG)
    ax.set_ylabel("count", color=FG)
    ax.set_title("2 · pinned at 0.5 — a fair coin per bit", color=FG, fontsize=12)
    _grid(ax)

    # 3 mining landscape
    ax = fig.add_subplot(2, 3, 3)
    ax.scatter(np.arange(M), lead, s=5, c=ACCENT2, alpha=0.5)
    ax.axhline(80, color=ACCENT, ls="--", lw=1.2)
    ax.annotate("real block target ≈ 80+ leading zero bits (off the chart)",
                (M * 0.02, 80), color=ACCENT, fontsize=8, va="bottom")
    ax.set_ylim(0, max(20, lead.max() + 4))
    ax.set_xlabel("nonce", color=FG)
    ax.set_ylabel("leading zero bits of hash", color=FG)
    ax.set_title("3 · mining landscape: structureless noise", color=FG, fontsize=12)
    _grid(ax)

    # 4 preimage gradient
    ax = fig.add_subplot(2, 3, 4)
    ax.scatter(din, dh, s=6, c=ACCENT2, alpha=0.35)
    ax.axhline(128, color=ACCENT, ls="--", lw=1.2, label="128 (pure noise)")
    ax.set_ylim(90, 165)
    ax.set_xlabel("input distance from a known preimage (bits)", color=FG)
    ax.set_ylabel("hash distance to target (bits)", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2)
    ax.set_title("4 · NO gradient for gravity to follow", color=FG, fontsize=12)
    _grid(ax)

    # 5 the dance in the E8 plane
    ax = fig.add_subplot(2, 3, 5)
    proj = e8_root_projection()
    r_max = np.abs(proj).max() * 0.98
    ax.scatter(proj[:, 0], proj[:, 1], s=10, c=COMP, alpha=0.25, lw=0)
    px = (0.25 + radii) * r_max * np.cos(angles)
    py = (0.25 + radii) * r_max * np.sin(angles)
    ax.scatter(px, py, s=4, c=ACCENT2, alpha=0.5, lw=0)
    ax.set_aspect("equal"); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_color(GRID)
    ax.set_title("5 · the hash 'dance': uniform scatter, no attractor", color=FG, fontsize=12)

    # 6 verdict
    ax = fig.add_subplot(2, 3, 6)
    ax.axis("off")
    lines = [
        ("VERDICT — the hash side", ACCENT, 13),
        ("", FG, 5),
        ("Factoring (Shor side):   the projection RESONATES.", ACCENT, 11),
        ("  roots-of-unity spikes pick out the factors.", FG, 10),
        ("", FG, 4),
        ("SHA-256 (Grover side):   the instrument is DARK.", "#ff6b6b", 11),
        ("  • avalanche pins every output bit at a 50% coin", FG, 10),
        ("  • the landscape is flat — corr(input, target) ≈ 0", FG, 10),
        ("  • no gradient ⇒ HSLN 'gravity' has nothing to grab", FG, 10),
        ("  • nonces scatter uniformly — no structure at all", FG, 10),
        ("", FG, 5),
        ("So an address / a mined block hides no exploitable", FG, 10),
        ("structure. Quantum gives only Grover's √ speedup —", FG, 10),
        ("never a Shor-style break.", FG, 10),
        ("", FG, 5),
        ("This is the formal reason MINING survives quantum,", ACCENT2, 10),
        ("while exposed-key SIGNATURES (the Shor side) do not.", ACCENT2, 10),
    ]
    yy = 0.98
    for t, c, s in lines:
        ax.text(0.0, yy, t, color=c, fontsize=s, va="top", transform=ax.transAxes)
        yy -= 0.058 if t else 0.026

    fig.subplots_adjust(left=0.05, right=0.97, top=0.91, bottom=0.08,
                        hspace=0.34, wspace=0.24)
    save_fig(fig, "60_hsln_bitcoin_hash.png")


if __name__ == "__main__":
    main()
