"""factor_battery.py — real, time-bounded factoring attempt on N. Pure stdlib.

Runs every feasible classical method against N and reports any factor found.
Each method is wrapped in a hard per-method timeout so nothing hangs. This is the
honest 'use all the tools' attempt: if N has ANY exploitable structure (small factor,
close primes, smooth p±1, perfect power) it falls out here. A hard balanced semiprime
will survive all of them — which is itself the answer.
"""
from __future__ import annotations

import math
import signal
import time

N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)


class Timeout(Exception):
    pass


class deadline:
    def __init__(self, secs): self.secs = secs
    def __enter__(self):
        signal.signal(signal.SIGALRM, self._raise)
        signal.alarm(self.secs)
    def __exit__(self, *a): signal.alarm(0)
    def _raise(self, *a): raise Timeout()


def is_probable_prime(n: int, rounds=16) -> bool:
    if n < 2: return False
    for p in (2,3,5,7,11,13,17,19,23,29,31,37):
        if n % p == 0: return n == p
    d = n - 1; s = 0
    while d % 2 == 0: d //= 2; s += 1
    # fixed strong bases — extremely reliable for 1024-bit
    for a in (2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53)[:rounds]:
        x = pow(a, d, n)
        if x in (1, n-1): continue
        for _ in range(s-1):
            x = x*x % n
            if x == n-1: break
        else:
            return False
    return True


def trial_division(n, limit, secs):
    print(f"  [trial] dividing by primes < {limit:,} ...", flush=True)
    try:
        with deadline(secs):
            # simple sieve
            sieve = bytearray([1]) * (limit)
            sieve[0:2] = b'\x00\x00'
            for i in range(2, int(limit**0.5)+1):
                if sieve[i]:
                    sieve[i*i::i] = b'\x00' * len(sieve[i*i::i])
            for p in range(2, limit):
                if sieve[p] and n % p == 0:
                    return p
    except Timeout:
        print("  [trial] timed out", flush=True)
    return None


def fermat(n, steps, secs):
    print(f"  [fermat] {steps:,} steps (close primes) ...", flush=True)
    try:
        with deadline(secs):
            a = math.isqrt(n) + 1
            for _ in range(steps):
                b2 = a*a - n
                b = math.isqrt(b2)
                if b*b == b2:
                    return a - b
                a += 1
    except Timeout:
        print("  [fermat] timed out", flush=True)
    return None


def pollard_brent(n, secs, seed=2):
    print(f"  [rho] Pollard-Brent (seed {seed}, {secs}s) ...", flush=True)
    if n % 2 == 0: return 2
    try:
        with deadline(secs):
            y, c, m = seed, 1, 1<<20
            g = q = 1; r = 1
            while g == 1:
                x = y
                for _ in range(r): y = (y*y + c) % n
                k = 0
                while k < r and g == 1:
                    ys = y
                    for _ in range(min(m, r-k)):
                        y = (y*y + c) % n
                        q = q * abs(x - y) % n
                    g = math.gcd(q, n); k += m
                r <<= 1
            if g == n:
                while True:
                    ys = (ys*ys + c) % n
                    g = math.gcd(abs(x - ys), n)
                    if g > 1: break
            return g if 1 < g < n else None
    except Timeout:
        print("  [rho] timed out", flush=True)
    return None


def pollard_pm1(n, B1, secs):
    print(f"  [p-1] Pollard p-1, B1={B1:,} ...", flush=True)
    try:
        with deadline(secs):
            a = 2
            # sieve primes up to B1
            sieve = bytearray([1]) * B1
            sieve[0:2] = b'\x00\x00'
            for i in range(2, int(B1**0.5)+1):
                if sieve[i]: sieve[i*i::i] = b'\x00'*len(sieve[i*i::i])
            for p in range(2, B1):
                if not sieve[p]: continue
                pe = p
                while pe * p <= B1: pe *= p
                a = pow(a, pe, n)            # incremental → interruptible
                if p % 4096 == 3:            # occasional gcd check
                    g = math.gcd(a-1, n)
                    if 1 < g < n: return g
            g = math.gcd(a-1, n)
            return g if 1 < g < n else None
    except Timeout:
        print("  [p-1] timed out", flush=True)
    return None


def williams_pp1(n, B1, secs, A=5):
    print(f"  [p+1] Williams p+1, B1={B1:,}, A={A} ...", flush=True)
    try:
        with deadline(secs):
            # Lucas sequence V_k(A); catches p where p+1 is smooth
            def lucas_pow(v, e):
                # compute V_e for Lucas with V_1=A using binary chain
                v0, v1 = 2, v
                for bit in bin(e)[2:]:
                    if bit == '1':
                        v0 = (v0*v1 - v) % n; v1 = (v1*v1 - 2) % n
                    else:
                        v1 = (v0*v1 - v) % n; v0 = (v0*v0 - 2) % n
                return v0
            sieve = bytearray([1]) * B1
            sieve[0:2] = b'\x00\x00'
            for i in range(2, int(B1**0.5)+1):
                if sieve[i]: sieve[i*i::i] = b'\x00'*len(sieve[i*i::i])
            v = A
            for p in range(2, B1):
                if not sieve[p]: continue
                pe = p
                while pe*p <= B1: pe *= p
                v = lucas_pow(v, pe)
                if p % 4096 == 3:
                    g = math.gcd(v-2, n)
                    if 1 < g < n: return g
            g = math.gcd(v-2, n)
            return g if 1 < g < n else None
    except Timeout:
        print("  [p+1] timed out", flush=True)
    return None


def report(p):
    q = N // p
    ok = (p * q == N) and 1 < p < N
    print("\n" + "="*70)
    print(f"  *** FACTOR FOUND ***  valid = {ok}")
    print(f"  p = {p}")
    print(f"  q = {q}")
    print(f"  p prime? {is_probable_prime(p)}   q prime? {is_probable_prime(q)}")
    print("="*70)
    return ok


def main():
    print(f"N: {N.bit_length()} bits, {len(str(N))} digits")
    t0 = time.perf_counter()
    print(f"N probable-prime? {is_probable_prime(N)}")

    methods = [
        # lambda: trial_division(N, 10_000_000, 90),
        # lambda: fermat(N, 5_000_000, 60),
        # lambda: pollard_pm1(N, 3_000_000, 120),
        # lambda: williams_pp1(N, 1_000_000, 120),
        # lambda: pollard_brent(N, 120, seed=2),
        lambda: pollard_brent(N, 120, seed=3),
    ]
    for m in methods:
        f = m()
        if f and 1 < f < N and N % f == 0:
            report(f)
            print(f"\ntotal time {time.perf_counter()-t0:.1f}s")
            return
    print("\n" + "="*70)
    print("  NO FACTOR FOUND by any bounded classical method.")
    print(f"  (trial<1e7, Fermat 5e6, p-1 B1=3e6, p+1 B1=1e6, rho 2×120s)")
    print(f"  total time {time.perf_counter()-t0:.1f}s")
    print("="*70)


if __name__ == "__main__":
    main()
