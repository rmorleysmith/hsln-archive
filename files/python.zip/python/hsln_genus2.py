"""Genus-2 composition by DIRECT SUM (cross product): tasks on separate coordinates.

The genus-1 tensor product put both tasks on the SAME coordinate tau, so their basins
fought (hsln_dyn.py). The direct sum raises the genus: the state is the 2x2 period
matrix
        Z = [[tau1, 0],
             [0,  tau2]]   in H_2  (diagonal slice),
and the direct-sum generating function is F(Z) = F_A(tau1) * F_B(tau2). On the diagonal
the energy factorizes,
        |F|^2 = |F_A(tau1)|^2 * |F_B(tau2)|^2,
so the gradient flow DECOUPLES: tau1 relaxes under sector A, tau2 under sector B, with
the same trajectories the parents had. Each task runs on its own coordinate -> no
cross-talk. We reuse the exact same trained sectors that cross-talked at genus 1.
"""
from __future__ import annotations

import numpy as np
import jax.numpy as jnp

import hsln_dyn as g1

A_TARGET = g1.A_TARGET   # (0.65, 0.28), reached in tau1
B_TARGET = g1.B_TARGET   # (0.35, 0.28), reached in tau2
A_IN = g1.A_START        # (0.40, 0.58)
B_IN = g1.B_START        # (0.60, 0.58)


def _err(e, t):
    return float(np.hypot(e[0] - t[0], e[1] - t[1]))


def run(make_fig=True):
    # same sectors that failed to compose at genus 1
    dnaA, _ = g1.train_routing([A_IN], [A_TARGET], seed=1)
    dnaB, _ = g1.train_routing([B_IN], [B_TARGET], seed=2)

    # genus-1 tensor product (shared coordinate) -- the failing baseline
    dnaAB = np.convolve(dnaA, dnaB)
    g1_A = g1.endpoint(dnaAB, A_IN)
    g1_B = g1.endpoint(dnaAB, B_IN)

    # genus-2 direct sum (separate coordinates): tau1 under A, tau2 under B, decoupled
    tau1 = np.array(g1.rollout(jnp.asarray(dnaA), jnp.asarray(A_IN)))   # task A on coord 1
    tau2 = np.array(g1.rollout(jnp.asarray(dnaB), jnp.asarray(B_IN)))   # task B on coord 2
    g2_A = tau1[-30:].mean(axis=0)
    g2_B = tau2[-30:].mean(axis=0)

    print("                         task A err   task B err")
    print(f"genus-1 tensor (shared tau): {_err(g1_A, A_TARGET):.3f}        {_err(g1_B, B_TARGET):.3f}   <- cross-talk")
    print(f"genus-2 direct sum (tau1,tau2):{_err(g2_A, A_TARGET):.3f}        {_err(g2_B, B_TARGET):.3f}   <- both correct")

    if make_fig:
        _figure(tau1, tau2, g1_A, g1_B, g2_A, g2_B)
    return dnaA, dnaB


def _figure(tau1, tau2, g1_A, g1_B, g2_A, g2_B):
    import matplotlib.pyplot as plt
    from pathlib import Path
    import style

    cA, cB, good = "#46f0d0", "#ffd166", "#7CFC8A"

    fig, ax = plt.subplots(1, 2, figsize=(13.5, 5.4), gridspec_kw={"width_ratios": [1.25, 1]})

    # --- joint state-space: x = task A coordinate (Re tau1), y = task B coordinate (Re tau2)
    a = ax[0]
    a.set_facecolor("#0b0b14")
    a.plot(tau1[:, 0], tau2[:, 0], color=good, lw=2.4, zorder=5, label="genus-2 trajectory")
    a.plot(A_IN[0], B_IN[0], "o", color="white", ms=10, zorder=6, label="input (0.40, 0.60)")
    a.plot(A_TARGET[0], B_TARGET[0], "*", color=good, ms=24, mec="white", mew=1.0,
           zorder=6, label="joint target (0.65, 0.35)")
    # genus-1 tensor outcome (both inputs collapse in the single shared coordinate)
    a.plot(g1_A[0], g1_B[0], "X", color=style.NEURON, ms=14, mew=2, zorder=6,
           label="genus-1 tensor (cross-talk)")
    a.axvline(A_TARGET[0], color=cA, ls=":", lw=1, alpha=0.6)
    a.axhline(B_TARGET[0], color=cB, ls=":", lw=1, alpha=0.6)
    a.set_xlim(0.1, 0.9); a.set_ylim(0.1, 0.9)
    a.set_xlabel(r"task A coordinate  (Re $\tau_1$)")
    a.set_ylabel(r"task B coordinate  (Re $\tau_2$)")
    a.set_title(r"genus-2 direct sum: $Z=\mathrm{diag}(\tau_1,\tau_2)$" "\n"
                "each task on its own coordinate", fontsize=12)
    a.legend(loc="upper left", fontsize=8, framealpha=0.3)

    # --- error comparison
    b = ax[1]
    x = np.arange(2)
    g1errs = [_err(g1_A, A_TARGET), _err(g1_B, B_TARGET)]
    g2errs = [_err(g2_A, A_TARGET), _err(g2_B, B_TARGET)]
    b.bar(x - 0.18, g1errs, 0.34, color=style.NEURON, label="genus-1 tensor (shared τ)")
    b.bar(x + 0.18, g2errs, 0.34, color=good, label="genus-2 direct sum (τ₁⊕τ₂)")
    b.set_xticks(x); b.set_xticklabels(["task A", "task B"])
    b.set_ylabel("routing error  (distance to trained target)")
    b.set_title("same trained sectors, two ways to compose", fontsize=12)
    b.legend(fontsize=9, framealpha=0.3)

    fig.suptitle("Direct sum fixes dynamical composition: separate matrix coordinates don't interfere",
                 fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "20_genus2_directsum.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
