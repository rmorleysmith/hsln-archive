"""A pop at Birch–Swinnerton-Dyer with the composable-DNA framework.

Each elliptic curve E/ℚ has an L-function L(E, s) = Σ aₙ/nˢ = ∏ₚ (local Euler factor)⁻¹ — yet
ANOTHER generator built by composing per-prime factors in the Dirichlet ring. By Wiles et al.
(modularity), the coefficients aₙ are the Fourier coefficients of a weight-2 newform on Γ₀(N),
so L(E, s) is the L-function of a modular-form DNA. The Birch–Swinnerton-Dyer conjecture says

    ord_{s=1} L(E, s)  =  rank E(ℚ).

Honest scope: BSD is open. What is PROVEN (Kolyvagin / Gross–Zagier) is the implication
"L(E, 1) ≠ 0 ⇒ rank 0", and that for analytic-rank ≤ 1 the analytic rank equals the algebraic
rank. The leading-coefficient formula (regulator, Tamagawa, Sha) is also conjectural.

What we demonstrate here:

  1. Build L(E, s) for FIVE famous curves of varying rank by composing per-prime Euler factors
     (computed via point counts on E(𝔽ₚ)):
        11a1   y² + y = x³ − x² − 10x − 20   N=11   rank 0
        14a1   y² + xy + y = x³ + 4x − 6      N=14   rank 0
        37a1   y² + y = x³ − x                N=37   rank 1   (Wiles' favourite)
        389a1  y² + y = x³ + x² − 2x          N=389  rank 2
        5077a1 y² + y = x³ − 7x + 6           N=5077 rank 3

  2. Evaluate L(E, 1) via the exponentially-convergent smoothed-sum formula derived from the
     functional equation Λ(2 − s) = w · Λ(s):

         L(E, 1) = (1 + w) · Σₙ (aₙ / n) · exp(−2π n / √N)

     where w ∈ {±1} is the root number. For w = −1 (odd-rank curves), L(E, 1) is forced
     to 0 by the sign — this is where the parity conjecture's "parity" comes from.

  3. Verify MODULARITY for 11a by matching the computed aₚ to LMFDB newform 11.2.a.a's
     Fourier coefficients.

  4. The BSD pattern: rank-0 curves give L(E, 1) > 0; rank-≥1 give L(E, 1) ≈ 0.

References: LMFDB (https://www.lmfdb.org), Silverman "Arithmetic of Elliptic Curves",
Dokchitser "Computing special values of motivic L-functions" (arXiv:math/0207280).
"""
from __future__ import annotations

from functools import reduce
from pathlib import Path

import numpy as np

# Re-use the Dirichlet ring product (so this is provably in the SAME algebra as ζ, χ, etc.).
from dna_algebra import dirichlet_mul, _delta


# Weierstrass coefficients [a1, a2, a3, a4, a6] (Cremona reference minimal models).
CURVES = {
    "11a1":   {"E": [0, -1, 1, -10, -20], "N": 11,   "w": +1, "rank": 0},
    "14a1":   {"E": [1,  0, 1,   4,  -6], "N": 14,   "w": +1, "rank": 0},
    "37a1":   {"E": [0,  0, 1,  -1,   0], "N": 37,   "w": -1, "rank": 1},
    "389a1":  {"E": [0,  1, 1,  -2,   0], "N": 389,  "w": +1, "rank": 2},
    "5077a1": {"E": [0,  0, 1,  -7,   6], "N": 5077, "w": -1, "rank": 3},
}


def primes_upto(n):
    if n < 2:
        return []
    sieve = np.ones(n + 1, dtype=bool); sieve[:2] = False
    for p in range(2, int(n ** 0.5) + 1):
        if sieve[p]:
            sieve[p * p::p] = False
    return [int(p) for p in np.nonzero(sieve)[0]]


def point_count(E, p):
    """#E(𝔽ₚ) including the point at infinity. y² + a₁xy + a₃y = x³ + a₂x² + a₄x + a₆."""
    a1, a2, a3, a4, a6 = [a % p for a in E]
    if p == 2:
        cnt = 1
        for x in (0, 1):
            for y in (0, 1):
                lhs = (y * y + a1 * x * y + a3 * y) % 2
                rhs = (x * x * x + a2 * x * x + a4 * x + a6) % 2
                if lhs == rhs:
                    cnt += 1
        return cnt
    cnt = 1
    for x in range(p):
        A = (a1 * x + a3) % p
        B = (x * x * x + a2 * x * x + a4 * x + a6) % p
        # solve y² + A y − B = 0 mod p. Multiply by 4: (2y+A)² = A² + 4B.
        D = (A * A + 4 * B) % p
        if D == 0:
            cnt += 1
        else:
            if pow(D, (p - 1) // 2, p) == 1:
                cnt += 2
    return cnt


def a_p(E, p):
    return p + 1 - point_count(E, p)


def local_factor_coeffs(ap, p, NN, divides_N):
    """Dirichlet coefficients of the local Euler factor at prime p, truncated to length NN+1.
    Good p  : (1 − aₚ p⁻ˢ + p · p⁻²ˢ)⁻¹  →  a_{p^k} = aₚ·a_{p^(k-1)} − p·a_{p^(k-2)}.
    Bad p   : (1 − aₚ p⁻ˢ)⁻¹              →  a_{p^k} = aₚ^k."""
    c = np.zeros(NN + 1); c[1] = 1.0
    if p > NN:
        return c
    seq = [1.0, float(ap)]
    pk = p
    k = 1
    while pk <= NN:
        c[pk] = seq[k]
        nxt_pk = pk * p
        if nxt_pk > NN:
            break
        if divides_N:
            seq.append(seq[-1] * ap)
        else:
            seq.append(ap * seq[-1] - p * seq[-2])
        pk = nxt_pk
        k += 1
    return c


def build_an(curve, NN):
    """Build (a_n)_{n≤NN} for E by Dirichlet-convolving per-prime local Euler factors."""
    E, N = curve["E"], curve["N"]
    ps = primes_upto(NN)
    factors = []
    for p in ps:
        ap = a_p(E, p)
        factors.append(local_factor_coeffs(ap, p, NN, N % p == 0))
    return reduce(dirichlet_mul, factors, _delta(NN))


def L_E_1(curve, NN):
    """L(E, 1) via the smoothed-sum formula  (1 + w) · Σ aₙ/n · exp(−2π n / √N)."""
    w, N = curve["w"], curve["N"]
    an = build_an(curve, NN)
    ns = np.arange(1, NN + 1, dtype=float)
    weights = np.exp(-2 * np.pi * ns / np.sqrt(N))
    return float((1 + w) * np.sum(an[1:NN + 1] * weights / ns)), an


def L_E_1_partial(an, w, N, K_grid):
    """Smoothed partial sums of L(E,1) up to each K in K_grid (for the convergence plot)."""
    ns = np.arange(1, len(an), dtype=float)
    weights = np.exp(-2 * np.pi * ns / np.sqrt(N))
    contrib = an[1:] * weights / ns
    cumul = (1 + w) * np.cumsum(contrib)
    return cumul[np.array(K_grid) - 1]


# LMFDB newform 11.2.a.a — Fourier coefficients aₚ at the first primes.
LMFDB_11_2_a_a = {2: -2, 3: -1, 5: 1, 7: -2, 11: 1, 13: 4, 17: -2,
                  19: 0, 23: -1, 29: 0, 31: 7, 37: 3, 41: -8, 43: -6, 47: 8}


def run(make_fig=True):
    # ---------- modularity check on 11a (compare aₚ to LMFDB) ----------
    E11 = CURVES["11a1"]["E"]
    ap_match = {p: (a_p(E11, p), LMFDB_11_2_a_a[p]) for p in LMFDB_11_2_a_a}
    all_ok = all(my == lm for (my, lm) in ap_match.values())
    print("Modularity check (11a1 ↔ LMFDB newform 11.2.a.a):")
    for p, (my, lm) in ap_match.items():
        flag = "✓" if my == lm else "✗"
        print(f"  p={p:>3}   aₚ(by point count) = {my:>3}   LMFDB = {lm:>3}   {flag}")
    assert all_ok

    # ---------- L(E, 1) for the five curves ----------
    print("\nL(E, 1) via smoothed sum  (1+w)·Σ aₙ/n · exp(−2πn/√N):")
    out_vals = {}
    out_an = {}
    for name, c in CURVES.items():
        NN = max(200, int(40 * np.sqrt(c["N"])))            # enough terms for ~1e-5
        L1, an = L_E_1(c, NN)
        out_vals[name] = L1
        out_an[name] = an
        print(f"  {name:>6}  N={c['N']:>4}  w={c['w']:+d}  rank={c['rank']}  "
              f"L(E,1) ≈ {L1:+.6f}   ({'> 0' if L1 > 1e-4 else '≈ 0'})")

    if make_fig:
        _figure(out_vals, out_an, ap_match)
    return True


def _figure(L_vals, an_dict, ap_match):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, NEURON, GREEN, VIO = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A", "#c0a3ff"
    PAPER_DIM = "#9a96b0"

    RANK_COLOR = {0: GREEN, 1: GOLD, 2: TEAL, 3: NEURON}
    fig = plt.figure(figsize=(17.0, 9.6))
    gs = fig.add_gridspec(2, 2, hspace=0.36, wspace=0.22)
    A = fig.add_subplot(gs[0, 0]); B = fig.add_subplot(gs[0, 1])
    C = fig.add_subplot(gs[1, 0]); Dax = fig.add_subplot(gs[1, 1])

    # -- A: aₚ "DNA" of each curve (the per-prime Euler-factor input) --
    P_show = primes_upto(60)
    for name, curve in CURVES.items():
        col = RANK_COLOR[curve["rank"]]
        aps = [a_p(curve["E"], p) for p in P_show]
        # Hasse bound |aₚ| ≤ 2√p, normalised
        norm = [a / (2 * np.sqrt(p)) for a, p in zip(aps, P_show)]
        A.plot(P_show, norm, "o-", color=col, lw=1.3, ms=4.5, alpha=0.85,
               label=f"{name}  (rank {curve['rank']})")
    A.axhline(1, color="#666", ls=":", lw=0.7); A.axhline(-1, color="#666", ls=":", lw=0.7)
    A.text(58, 0.94, "Hasse: |aₚ| ≤ 2√p", color=PAPER_DIM, fontsize=8.4, ha="right")
    A.set_xlabel("prime p"); A.set_ylabel(r"$a_p / (2\sqrt{p})$")
    A.set_title("the DNA of each curve: aₚ across primes\n"
                "(Hasse-normalised; Sato–Tate predicts semicircle distribution)", fontsize=12)
    A.legend(loc="lower right", fontsize=8.2, framealpha=0.3)

    # -- B: convergence of the smoothed sum to L(E, 1) --
    K_grid = np.unique(np.geomspace(1, 1200, 60).astype(int))
    for name, curve in CURVES.items():
        col = RANK_COLOR[curve["rank"]]
        an = an_dict[name]
        K_use = K_grid[K_grid < len(an)]
        partial = L_E_1_partial(an, curve["w"], curve["N"], K_use)
        B.plot(K_use, partial, "-", color=col, lw=1.5, alpha=0.92,
               label=f"{name}  rank {curve['rank']}  (w={curve['w']:+d})")
    B.axhline(0, color="#555", lw=0.8)
    B.set_xscale("log"); B.set_xlabel("partial sum length K")
    B.set_ylabel(r"$(1+w)\sum_{n\leq K} a_n/n \cdot e^{-2\pi n/\sqrt{N}}$")
    B.set_title("L(E, 1) via the smoothed sum\n"
                "rank-0 curves settle positive; w=−1 forces L(E,1)=0 (parity)", fontsize=12)
    B.legend(loc="upper right", fontsize=8.2, framealpha=0.3)

    # -- C: the BSD pattern — rank vs L(E, 1) --
    names = list(CURVES.keys())
    vals = [L_vals[n] for n in names]
    ranks = [CURVES[n]["rank"] for n in names]
    cols = [RANK_COLOR[r] for r in ranks]
    bars = C.bar(names, vals, color=cols, edgecolor="white", lw=0.6)
    for b, r, v in zip(bars, ranks, vals):
        C.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.012,
               f"rank {r}", ha="center", color=RANK_COLOR[r], fontsize=9)
        if abs(v) < 1e-4:
            C.text(b.get_x() + b.get_width() / 2, 0.015,
                   "L(E,1) ≈ 0", ha="center", color="white", fontsize=8.2,
                   rotation=90, va="bottom")
    C.axhline(0, color="#666", lw=0.7)
    C.set_ylabel("L(E, 1)")
    C.set_title("the BSD pattern: L(E, 1) > 0  ⇔  rank 0\n"
                "(proven for rank ≤ 1 by Kolyvagin / Gross–Zagier; BSD itself is open)",
                fontsize=12)

    # -- D: modularity for 11a — my aₚ vs LMFDB newform 11.2.a.a --
    ps = sorted(LMFDB_11_2_a_a.keys())
    mine = [ap_match[p][0] for p in ps]
    lm = [ap_match[p][1] for p in ps]
    Dax.vlines(ps, 0, mine, color=GREEN, lw=2.5, label="aₚ by point count on 11a1")
    Dax.plot(ps, lm, "o", color=GOLD, ms=8, mfc="none", mew=2,
             label="LMFDB newform 11.2.a.a Fourier coeffs")
    Dax.axhline(0, color="#555", lw=0.6)
    Dax.set_xlabel("prime p"); Dax.set_ylabel(r"$a_p$")
    Dax.set_title("modularity, in coefficients\n"
                  "the elliptic curve's L-function DNA  =  the weight-2 newform's DNA "
                  "(Wiles et al.)", fontsize=12)
    Dax.legend(loc="lower left", fontsize=8.5, framealpha=0.3)

    fig.suptitle("A pop at BSD with the composable-DNA framework: L(E,s) = ∏ₚ Euler "
                 "(point counts on E(𝔽ₚ)), evaluated at s=1 by the functional-equation "
                 "smoothed sum — and rank-0 ⇔ L(E,1) > 0 falls right out",
                 fontsize=12.5, y=0.99)
    out = Path(__file__).parent / "figures" / "40_bsd.png"
    fig.savefig(out, dpi=160, bbox_inches="tight")
    plt.close(fig)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    run()
