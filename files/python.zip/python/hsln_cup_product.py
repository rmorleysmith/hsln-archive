"""
Cup product of trained landscapes — does multiplying ever surface a NEW factor?

The ring operation we proved associative (HSLN.lean `neurons_mul`, machine-checked):
    neurons(F ⋆ G) = neurons F ∪ neurons G
i.e. the zeros (spikes) of a product of landscapes are the UNION of the parents' zeros,
because ℂ is an integral domain (mul_eq_zero). HSLNHodge lifts this to the graded subring
closed under cup product.

Read on the factoring detector: a model trained to A spikes at the prime factors of A; one
trained to B spikes at the factors of B. Their cup product spikes at factors(A) ∪ factors(B).

[REDACTED NAME]'s question: can cup-producting landscapes ever surface a factor that NEITHER parent
had — in particular a factor of a hard target N?

What we test:
  1. Union law on real numbers: spikes(A ⋆ B) = factors(A) ∪ factors(B), exactly. (proved)
  2. "No new prime": multiply MANY random landscapes together; tally every prime spike that
     appears and confirm each was already a factor of some parent — never conjured.
  3. The attack that can't work: cup-product a fleet of random landscapes and ask whether a
     factor of the 249-bit genesis cofactor ever appears. It cannot, unless we plant it —
     which would require already knowing the factor.

Conclusion (and it's the theorem, not a hope): the cup product COMPOSES known factors; it
never DISCOVERS one. Same shape as before — structure, not search.

Run:  .venv/bin/python hsln_cup_product.py
"""
from __future__ import annotations

import random
import numpy as np
import matplotlib.pyplot as plt

from hsln_bitcoin_probe import KEYS, pubkey_x, peel_small_factors, SCAN_BOUND
from hsln_e8_torsion_factor import is_prime, FG, ACCENT, ACCENT2, COMP, GRID, save_fig

random.seed(8)
KMAX = 600                      # spike window for the small visual examples


def prime_factors(n: int) -> set[int]:
    out, d, m = set(), 2, n
    while d * d <= m:
        while m % d == 0:
            out.add(d); m //= d
        d += 1
    if m > 1:
        out.add(m)
    return out


def spike_indicator(n: int, kmax: int) -> np.ndarray:
    """Detector landscape: a_k = 1 iff k | n, for k = 1..kmax (the trained-model spikes)."""
    ks = np.arange(1, kmax + 1)
    return np.array([1.0 if n % int(k) == 0 else 0.0 for k in ks])


def cup(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Cup product on landscapes: spike where EITHER has a zero (union of zero-sets),
    the faithful image of neurons(F⋆G)=neurons F ∪ neurons G."""
    return np.maximum(a, b)


def prime_spikes(ind: np.ndarray) -> list[int]:
    return [k for k in range(2, len(ind) + 1) if ind[k - 1] > 0.5 and is_prime(k)]


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def main():
    A, B = 6 * 7 * 13, 5 * 11 * 7      # share the prime 7 on purpose
    indA, indB = spike_indicator(A, KMAX), spike_indicator(B, KMAX)
    indC = cup(indA, indB)
    fa, fb = prime_factors(A), prime_factors(B)
    fc = set(prime_spikes(indC))
    union = fa | fb

    print("=" * 74)
    print(" Cup product of trained landscapes — union law (neurons_mul)")
    print("=" * 74)
    print(f"\n A = {A}, prime factors {sorted(fa)}")
    print(f" B = {B}, prime factors {sorted(fb)}")
    print(f" cup-product spikes      {sorted(fc)}")
    print(f" factors(A) ∪ factors(B) {sorted(union)}")
    print(f" exact union match? {fc == union}   "
          f"new prime introduced? {sorted(fc - union) or 'NONE'}")

    # 2. multiply many random landscapes — tally every prime spike vs the parents' factors
    fleet = [random.randint(100, 9_000) for _ in range(40)]
    acc = spike_indicator(fleet[0], KMAX)
    parent_primes = set(prime_factors(fleet[0]))
    for n in fleet[1:]:
        acc = cup(acc, spike_indicator(n, KMAX))
        parent_primes |= prime_factors(n)
    cup_primes = set(prime_spikes(acc))
    conjured = cup_primes - parent_primes
    print(f"\n cup product of {len(fleet)} random landscapes:")
    print(f"   prime spikes in product : {len(cup_primes)}")
    print(f"   primes present in some parent : {len([p for p in parent_primes if p<=KMAX])}")
    print(f"   primes conjured from nowhere  : {sorted(conjured) or 'NONE'}")

    # 3. the attack that can't work: can a fleet ever spike a factor of the cofactor?
    x = pubkey_x(KEYS["genesis (block 0, Satoshi, unspent)"])
    _, cof = peel_small_factors(x, SCAN_BOUND)
    # cup product of 200 random small landscapes; does any spike divide cof?
    acc2 = spike_indicator(random.randint(2, 5000), 5000)
    for _ in range(200):
        acc2 = cup(acc2, spike_indicator(random.randint(2, 5000), 5000))
    hits = [k for k in range(2, 5001) if acc2[k - 1] > 0.5 and is_prime(k) and cof % k == 0]
    print(f"\n attack: cup-product 200 random landscapes, do any prime spikes divide the")
    print(f"   249-bit cofactor?  hits = {hits or 'NONE'}  (a real factor sits near 2^124)")

    # ----------------------------------------------------------------- figure
    fig = plt.figure(figsize=(17, 10))
    fig.suptitle("Cup product of trained landscapes — it composes factors, never discovers "
                 "one (neurons_mul, proved)", color=FG, fontsize=14.5, y=0.98)

    # 1 · the union law, visually
    ax = fig.add_subplot(2, 3, 1)
    ks = np.arange(1, KMAX + 1)
    for ind, lab, col, yb in [(indA, f"A={A}", ACCENT2, 0),
                              (indB, f"B={B}", COMP, -1.4),
                              (indC, "A ⋆ B (cup)", ACCENT, -2.8)]:
        sp = [k for k in prime_spikes(ind)]
        ax.vlines(sp, yb, yb + 1.0, color=col, lw=2.2)
        ax.scatter(sp, [yb + 1.0] * len(sp), s=40, c=col, edgecolors=FG, linewidths=0.4,
                   zorder=5)
        ax.text(-8, yb + 0.4, lab, color=col, fontsize=9, ha="right", va="center")
        for k in sp:
            ax.annotate(str(k), (k, yb + 1.04), color=col, fontsize=7.5, ha="center")
    ax.set_xlim(-40, 70); ax.set_ylim(-3.0, 1.4)
    ax.set_yticks([]); ax.set_xlabel("prime spike k", color=FG)
    ax.set_title("1 · spikes(A⋆B) = factors(A) ∪ factors(B)", color=FG, fontsize=11)
    _grid(ax)

    # 2 · fleet: cup primes are a subset of parent primes (no conjuring)
    ax = fig.add_subplot(2, 3, 2)
    pp = sorted([p for p in parent_primes if p <= KMAX])
    cp = sorted(cup_primes)
    ax.scatter(pp, [1] * len(pp), s=24, c=ACCENT2, label=f"in some parent ({len(pp)})")
    ax.scatter(cp, [0.5] * len(cp), s=36, c=ACCENT, marker="v",
               label=f"cup-product spikes ({len(cp)})")
    if conjured:
        ax.scatter(sorted(conjured), [0] * len(conjured), s=60, c="#ff3b6b",
                   marker="x", label="conjured (would be a discovery)")
    ax.set_ylim(-0.4, 1.5); ax.set_yticks([])
    ax.set_xlabel("prime", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="upper right")
    ax.set_title("2 · 40 random landscapes: cup spikes ⊆ parent factors", color=FG, fontsize=11)
    _grid(ax)

    # 3 · set-diagram-ish bar: counts
    ax = fig.add_subplot(2, 3, 3)
    cats = ["factors\nof A", "factors\nof B", "shared", "cup\nproduct", "conjured"]
    vals = [len(fa), len(fb), len(fa & fb), len(fc), len(fc - union)]
    cols = [ACCENT2, COMP, "#7CFC8A", ACCENT, "#ff3b6b"]
    bars = ax.bar(cats, vals, color=cols, edgecolor=FG)
    for b, v in zip(bars, vals):
        ax.annotate(str(v), (b.get_x() + b.get_width() / 2, v + 0.04), color=FG,
                    ha="center", fontsize=10)
    ax.set_ylabel("# primes", color=FG)
    ax.set_title("3 · cup = union; conjured = 0", color=FG, fontsize=11)
    _grid(ax)

    # 4 · the attack: spikes vs the cofactor's divisibility — no overlap
    ax = fig.add_subplot(2, 3, 4)
    sp2 = [k for k in range(2, 5001) if acc2[k - 1] > 0.5 and is_prime(k)]
    ax.scatter(sp2, [1] * len(sp2), s=10, c=ACCENT2, alpha=0.6,
               label=f"cup spikes of 200 random ({len(sp2)})")
    if hits:
        ax.scatter(hits, [1] * len(hits), s=80, c="#ff3b6b", marker="*",
                   label="divides the cofactor")
    else:
        ax.text(0.5, 0.45, "NO spike divides the 249-bit cofactor\n"
                "(its factors live near 2^124)", transform=ax.transAxes,
                color=ACCENT2, fontsize=11, ha="center")
    ax.set_ylim(0.6, 1.4); ax.set_yticks([])
    ax.set_xlabel("prime spike k", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="lower center")
    ax.set_title("4 · attack fails: cup can't reach an absent factor", color=FG, fontsize=11)
    _grid(ax)

    # 5 · associativity sanity: (A⋆B)⋆C == A⋆(B⋆C)
    ax = fig.add_subplot(2, 3, 5)
    C = 3 * 17
    iC = spike_indicator(C, KMAX)
    left = cup(cup(indA, indB), iC)
    right = cup(indA, cup(indB, iC))
    same = bool(np.array_equal(left, right))
    sp = prime_spikes(left)
    ax.vlines(sp, 0, 1, color=ACCENT, lw=2)
    for k in sp:
        ax.annotate(str(k), (k, 1.03), color=ACCENT, fontsize=7.5, ha="center")
    ax.set_xlim(-5, 70); ax.set_ylim(0, 1.25); ax.set_yticks([])
    ax.set_xlabel("prime spike k", color=FG)
    ax.set_title(f"5 · associative: (A⋆B)⋆C = A⋆(B⋆C)  [{same}]", color=FG, fontsize=11)
    _grid(ax)

    # 6 · verdict
    ax = fig.add_subplot(2, 3, 6)
    ax.axis("off")
    lines = [
        ("CUP PRODUCT — composes, never discovers", ACCENT, 12),
        ("", FG, 5),
        ("Proved (HSLN.lean neurons_mul):", ACCENT2, 11),
        ("  neurons(F⋆G) = neurons F ∪ neurons G", FG, 10),
        ("  (ℂ integral domain ⇒ mul_eq_zero)", FG, 10),
        ("", FG, 4),
        ("Measured here:", ACCENT2, 11),
        ("  • spikes(A⋆B) = factors(A) ∪ factors(B)", FG, 10),
        ("  • 40 random landscapes: 0 primes conjured", FG, 10),
        ("  • 200-landscape attack on the cofactor: 0 hits", FG, 10),
        ("  • associative, as proved", FG, 10),
        ("", FG, 5),
        ("A factor appears in the product ONLY if it was", "#ff3b6b", 11),
        ("already in a parent. To plant the cofactor's", FG, 10),
        ("factor you'd need to know it first — circular.", FG, 10),
        ("", FG, 5),
        ("The graded ring lets you COMPOSE known", ACCENT2, 10),
        ("structure with guarantees — it is not a search.", ACCENT2, 10),
    ]
    yy = 0.99
    for t, c, sz in lines:
        ax.text(0.0, yy, t, color=c, fontsize=sz, va="top", transform=ax.transAxes)
        yy -= 0.055 if t else 0.026

    fig.subplots_adjust(left=0.05, right=0.97, top=0.91, bottom=0.07,
                        hspace=0.34, wspace=0.24)
    save_fig(fig, "64_hsln_cup_product.png")


if __name__ == "__main__":
    main()
