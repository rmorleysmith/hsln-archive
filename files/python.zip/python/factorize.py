"""Teach little models to factorise -- by composing per-prime divisibility detectors.

Each prime p (<= 100) is a little model that detects its own multiples via the p-th
ROOTS OF UNITY (our native rep):

    D_p(n) = (1/p) * sum_{k=0}^{p-1} exp(2*pi*i * k*n / p)  =  1 if p | n,  else 0.

(The p phasors align and sum to p exactly when p | n; otherwise they cancel to 0.)
COMPOSE the detectors -- apply each, divide out when it fires -- and you factor n. This
is the inverse of the Euler-product composition (fig 32): there we built the integers
from prime powers; here we take them apart.

Using primes <= 100 the factoriser is COMPLETE for every n < 100^2 = 10000 (the smallest
prime factor of a composite is <= sqrt(n) < 100). Beyond that it still cracks "smooth"
numbers, but a product of primes all > 100 (e.g. 101*103) leaves an irreducible residual:
the factoring wall, and the reason the job is hard.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

PRIMES = [p for p in range(2, 10000) if all(p % d for d in range(2, int(p ** 0.5) + 1))]


def detect(p, n):
    """Roots-of-unity divisibility detector: 1 iff p | n."""
    k = np.arange(p)
    s = np.exp(2j * np.pi * k * (n % p) / p).sum() / p
    return abs(s.real - 1.0) < 1e-6            # sum == 1 (aligned) iff p | n


def factorise(n, primes=PRIMES):
    facs, m = {}, n
    for p in primes:
        while m % p == 0 and detect(p, m):     # detector gates each division
            facs[p] = facs.get(p, 0) + 1
            m //= p
    return facs, m                             # m = residual (1 if fully factored)


def true_factor(n):
    facs, m, d = {}, n, 2
    while d * d <= m:
        while m % d == 0:
            facs[d] = facs.get(d, 0) + 1; m //= d
        d += 1
    if m > 1:
        facs[m] = facs.get(m, 0) + 1
    return facs


def fmt(facs, residual):
    parts = [f"{p}" + (f"^{e}" if e > 1 else "") for p, e in sorted(facs.items())]
    if residual > 1:
        parts.append(f"[{residual} ?]")
    return " · ".join(parts) if parts else "1"


def run(make_fig=True):
    tests = [257456295689219220512995411628663795833]
    print(f"factoriser using {len(PRIMES)} prime detectors (primes <= 100):\n")
    for n in tests:
        facs, res = factorise(n)
        full = res == 1
        # cross-check the recovered small-prime part against trial division
        tf = true_factor(n)
        # ok = all(facs.get(p, 0) == e for p, e in tf.items() if p <= 100)
        tag = "fully factored" if full else f"residual {res} has all prime factors > 100"
        print(f"  {n:>8} = {fmt(facs, res):<32}  ({tag})  [matches trial div: no]")
    print("\n  10403 = 101·103 and 1234567 = 127·9721: smallest factor > 100, so the "
          "primes-<=100 detectors find nothing — the factoring wall.")

    # if make_fig:
        # _figure()
    return True


# def _figure():
#     import matplotlib.pyplot as plt
#     import style  # noqa: F401

#     TEAL, GOLD, NEURON, GREEN = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A"

#     fig = plt.figure(figsize=(15.5, 8.0))
#     gs = fig.add_gridspec(2, 1, height_ratios=[1, 1.05], hspace=0.36)
#     topo = gs[0].subgridspec(1, 2, width_ratios=[1, 1.25])
#     a = fig.add_subplot(topo[0]); b = fig.add_subplot(topo[1])
#     c = fig.add_subplot(gs[1])

#     # --- A: divisibility as roots-of-unity resonance --- #
#     a.set_facecolor("#0b0b14")
#     n_demo = 12
#     for p, col, lab in [(3, GREEN, "p=3 | 12  → aligned, Σ=p"),
#                         (5, NEURON, "p=5 ∤ 12  → cancels, Σ=0")]:
#         k = np.arange(p)
#         ph = np.exp(2j * np.pi * k * (n_demo % p) / p)
#         cx = 0.0 if p == 3 else 2.6
#         cy = 0.0
#         for z in ph:
#             a.annotate("", xy=(cx + z.real, cy + z.imag), xytext=(cx, cy),
#                        arrowprops=dict(arrowstyle="->", color=col, lw=1.6, alpha=0.85))
#         S = ph.sum()
#         a.annotate("", xy=(cx + S.real, cy + S.imag), xytext=(cx, cy),
#                    arrowprops=dict(arrowstyle="-|>", color="white", lw=2.4))
#         a.text(cx, -1.7, lab, color=col, fontsize=8.5, ha="center")
#     a.set_xlim(-1.5, 4.5); a.set_ylim(-2.1, 1.6); a.set_aspect("equal"); a.axis("off")
#     a.set_title("each model: divisibility = roots-of-unity resonance\n(n = 12)", fontsize=12)

#     # --- B: factorisation spectrum of one n --- #
#     n = 2310
#     facs, res = factorise(n)
#     resp = [1 if detect(p, n) else 0 for p in PRIMES]
#     b.bar(range(len(PRIMES)), resp, color=[GOLD if r else "#33334a" for r in resp])
#     b.set_xticks(range(len(PRIMES))); b.set_xticklabels(PRIMES, fontsize=6, rotation=90)
#     b.set_yticks([])
#     b.set_xlabel("prime detector"); b.set_title(f"factorising {n}: which detectors fire\n"
#                                                 f"{n} = {fmt(facs, res)}", fontsize=12)

#     # --- C: the wall -- largest prime factor vs the primes-<=100 reach --- #
#     Ns = np.arange(2, 521)
#     lpf = np.array([max(true_factor(int(k)).keys()) for k in Ns])
#     full = lpf <= 100
#     c.scatter(Ns[full], lpf[full], s=10, color=GREEN, label="fully factored (largest prime ≤ 100)")
#     c.scatter(Ns[~full], lpf[~full], s=14, color=NEURON,
#               label="residual (a prime factor > 100)")
#     c.axhline(100, color=GOLD, ls="--", lw=1.2)
#     c.text(8, 108, "reach of the primes-≤100 detectors", color=GOLD, fontsize=9)
#     c.set_yscale("log"); c.set_xlabel("n"); c.set_ylabel("largest prime factor (log)")
#     c.set_title("the factoring wall: composed primes-≤100 detectors crack everything below "
#                 "the line; large prime factors (red) are out of reach", fontsize=12)
#     c.legend(loc="lower right", fontsize=8.5, framealpha=0.3)

#     fig.suptitle("Factorising by composition: per-prime roots-of-unity detectors take integers "
#                  "apart — the inverse of the Euler product", fontsize=13, y=0.99)
#     out = Path(__file__).parent / "figures" / "33_factorize.png"
#     fig.savefig(out, dpi=170, bbox_inches="tight")
#     plt.close(fig)
#     print(f"wrote {out}")


if __name__ == "__main__":
    run()
