#!/usr/bin/env python3
"""phi_via_category.py — push the composable / category-theoretic angle on `φ(N)`.

Hypothesis: maybe the categorical structure of our framework (multiplicative functions as
a monoid under `*`, Dirichlet convolution as composition, Euler product as tensor product
over primes) gives a way to evaluate `φ(N)` *without* decomposing `N`.

We try four routes, one strictly categorical, three classical:

  A. **Euler-product / tensor evaluation**: `φ(N) = N · ∏_{p|N} (1 − 1/p)`.
     Composable view: each prime `p` contributes a local factor `(1 − 1/p)` to the
     functor `φ`. Evaluating the tensor product at `N` requires knowing the index set
     `{p : p | N}`. The categorical "tensor" doesn't bypass the index search.

  B. **Brute coprime count**: `φ(N) = #{a ∈ [1, N] : gcd(a, N) = 1}`. No factorisation,
     but `O(N)` time — exponential in `log N`.

  C. **Order-finding via Lagrange**: pick a random `a ∈ (ℤ/Nℤ)*`, compute its order;
     order divides `φ(N)`. With many `a`'s, the lcm of orders converges to `λ(N)`,
     which divides `φ(N)`. *Order-finding classically: equivalent to factoring* (per
     Boneh & Lipton 1996, and Shor 1994 quantum). For the Carmichael λ to recover
     `φ` we'd still need to factor `λ(N)` and reconstruct via prime structure.

  D. **Möbius / Yoneda evaluation**: `φ = Id * μ` (Dirichlet convolution). Evaluating
     `(Id * μ)(N) = Σ_{d|N} d · μ(N/d)`. The sum is over divisors of `N` — back to
     the factorisation. Yoneda gives `φ(N) = Hom(y(N), φ)` in the presheaf category
     on the divisibility poset; `y(N) = {d : d | N}` IS the divisor enumeration we're
     trying to avoid.

Conclusion (genuine attempt, honest result): every route either requires the factorisation
(A, C, D) or is exponential in `log N` (B). The categorical / compositional structure
**expresses** what `φ(N)` is — a product over prime-power data, equivalently a sum over
divisors — but does not analytically simplify the EVALUATION at a specific unfactored `N`.

References:
  * Miller, G. L. (1976), "Riemann's hypothesis and tests for primality", J. Comput.
    System Sci. **13**(3), 300-317. φ(N) ↔ factor(N) classical equivalence.
  * Boneh, D. & Lipton, R. (1996), "Algorithms for black-box fields and their application
    to cryptography", CRYPTO '96, LNCS **1109**, 283-297. Order-finding ↔ factoring.
  * Shor, P. (1994), "Algorithms for quantum computation: discrete logarithms and
    factoring", FOCS '94, 124-134. Quantum poly-time order-finding ⇒ poly-time factoring.
"""

import secrets
import time
from math import gcd

import sys
sys.path.insert(0, str(__file__).rsplit("/", 1)[0])
from factor_prime_pair import is_prime, random_prime_of_bits, pollard_brent


# ────────────────────────────────────────────────────────────────────────────────
#   The four candidate routes to φ(N)
# ────────────────────────────────────────────────────────────────────────────────

def phi_via_euler_product_with_primes(N: int, primes: list[int]) -> int:
    """**Approach A.** `φ(N) = N · ∏_{p|N} (1 − 1/p)`.

    Categorical view: tensor product over primes, evaluated at `N`. Conditional on
    knowing the primes that divide `N` — i.e., conditional on having the factorisation.
    """
    result = N
    for p in primes:
        result = result * (p - 1) // p
    return result


def phi_via_brute_count(N: int) -> int:
    """**Approach B.** `φ(N) = #{a ∈ [1, N] : gcd(a, N) = 1}`.

    No factorisation needed; `O(N)` time — exponential in `log N`. Only feasible
    for tiny `N`.
    """
    return sum(1 for a in range(1, N) if gcd(a, N) == 1)


def order_of(a: int, N: int, max_steps: int) -> int | None:
    """**Approach C, building block.** Order of `a` modulo `N` (smallest `k > 0` with
    `a^k ≡ 1 mod N`). Bounded search up to `max_steps`; returns None if exceeded.

    Classically: finding the order is at LEAST as hard as factoring (Boneh-Lipton 1996).
    Quantumly: Shor 1994 solves it in poly-time, breaking RSA.
    """
    x = a % N
    if x == 0:
        return None
    for k in range(1, max_steps + 1):
        if x == 1:
            return k
        x = (x * a) % N
    return None


def phi_attempt_via_orders(N: int, n_samples: int = 32, max_order: int = 10**7) -> int | None:
    """**Approach C.** Sample many random `a ∈ (ℤ/Nℤ)*`, find their orders, take lcm.
    For random `a`, lcm of orders → `λ(N)` (Carmichael function). For `N = pq`,
    `λ(N) = lcm(p−1, q−1) | φ(N) = (p−1)(q−1)`.

    Even if we recover `λ(N)`, we'd still need to factor `λ(N)` to reconstruct `φ(N)`
    from it (unless special structure). Returns the lcm of observed orders, or None
    if any order exceeded `max_order`.
    """
    from math import lcm
    cumulative = 1
    for _ in range(n_samples):
        while True:
            a = secrets.randbelow(N - 2) + 2
            if gcd(a, N) == 1:
                break
        ord_a = order_of(a, N, max_order)
        if ord_a is None:
            return None  # search bound exceeded
        cumulative = lcm(cumulative, ord_a)
    return cumulative


def phi_via_moebius_divisor_sum(N: int, divisors: list[int], moebius_vals: dict[int, int]) -> int:
    """**Approach D.** `φ(N) = Σ_{d|N} d · μ(N/d)`. The Möbius-inversion expression.

    Conditional on knowing the divisor list and `μ` at the conjugate divisors — both
    require the factorisation. Yoneda evaluation `Hom(y(N), φ)` where `y(N)` is the
    divisor poset of `N`.
    """
    return sum(d * moebius_vals[N // d] for d in divisors)


# ────────────────────────────────────────────────────────────────────────────────
#   Demo: try each approach on small-to-moderate semiprimes
# ────────────────────────────────────────────────────────────────────────────────

def run_demo() -> None:
    print("=" * 78)
    print(" Computing `φ(N)` from `N` via the composable / categorical structure")
    print("=" * 78)

    for bits in [10, 16, 24]:
        p = random_prime_of_bits(bits)
        q = random_prime_of_bits(bits)
        while q == p:
            q = random_prime_of_bits(bits)
        if p > q:
            p, q = q, p
        N = p * q
        phi_true = (p - 1) * (q - 1)
        divisors = [1, p, q, N]
        moebius_vals = {1: 1, p: -1, q: -1, N: 1}

        print(f"\n  ─── N = {N} ({N.bit_length()} bits), p = {p}, q = {q} ───")
        print(f"  φ(N) true = {phi_true}")
        print()

        # A: Euler product, conditional on knowing primes (≈ "we cheated")
        t0 = time.perf_counter()
        phi_a = phi_via_euler_product_with_primes(N, [p, q])
        t_a = time.perf_counter() - t0
        assert phi_a == phi_true
        print(f"  A. Euler-product tensor (needs primes):     {phi_a}  [{t_a*1e6:7.2f} µs]")

        # B: brute count, O(N), no factorisation
        if N <= 5_000_000:
            t0 = time.perf_counter()
            phi_b = phi_via_brute_count(N)
            t_b = time.perf_counter() - t0
            assert phi_b == phi_true
            print(f"  B. Brute coprime count (O(N), no factor):   {phi_b}  [{t_b*1e3:7.2f} ms]")
        else:
            print(f"  B. Brute coprime count (O(N)):              SKIPPED (N too large)")

        # C: order finding (classically equivalent to factoring)
        if N <= 10**7:
            t0 = time.perf_counter()
            order_lcm = phi_attempt_via_orders(N, n_samples=8, max_order=N)
            t_c = time.perf_counter() - t0
            print(f"  C. Order-finding lcm (=λ(N) for many samples): {order_lcm}  [{t_c*1e3:7.2f} ms]")
            print(f"     λ(N) true = lcm(p−1, q−1) = {phi_true // gcd(p-1, q-1)}")
            print(f"     → λ(N) divides φ(N) but does not RECOVER φ(N) without factoring λ")
        else:
            print(f"  C. Order-finding:                            SKIPPED (N too large)")

        # D: Möbius divisor sum (Yoneda evaluation)
        t0 = time.perf_counter()
        phi_d = phi_via_moebius_divisor_sum(N, divisors, moebius_vals)
        t_d = time.perf_counter() - t0
        assert phi_d == phi_true
        print(f"  D. Möbius divisor sum / Yoneda (needs divisors): {phi_d}  [{t_d*1e6:7.2f} µs]")
        print()

        # Honest summary
        print(f"     Routes A, D condition on factorisation. C is classically hard")
        print(f"     (Boneh-Lipton 1996). B is the only non-factoring route; O(N) time.")

    print()
    print("─" * 78)
    print("  Categorical summary:")
    print()
    print("    • φ : (ℕ, |) → ℕ is a multiplicative functor. Its evaluation at N is")
    print("      determined by N's prime-power factorisation. The tensor product over")
    print("      primes EXPRESSES this, but the index `{p : p | N}` IS the factorisation.")
    print()
    print("    • Yoneda: φ(N) = Hom(y(N), φ) in the presheaf category on the divisibility")
    print("      poset. y(N) = {d : d | N} is the representable functor — and to compute")
    print("      it we need the divisors of N, i.e. the factorisation.")
    print()
    print("    • The composable model unifies ζ, μ, φ, σ, Λ as different multiplicative")
    print("      functors; it does NOT extract their values at unfactored N more cheaply")
    print("      than the underlying number theory permits.")
    print()
    print("    • If a categorical / compositional route to φ(N) existed in poly-time,")
    print("      Miller (1976) + Shor (1994) would already have it — and RSA would be")
    print("      broken. The framework cannot be the missing piece.")
    print()


if __name__ == "__main__":
    run_demo()
