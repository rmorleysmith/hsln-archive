"""Geometry helpers: upper half-plane <-> Poincare disk, sampling grids."""
from __future__ import annotations

import numpy as np


def cayley(tau):
    """Cayley transform H -> unit disk: tau |-> (tau - i)/(tau + i)."""
    tau = np.asarray(tau, dtype=np.complex128)
    return (tau - 1j) / (tau + 1j)


def inv_cayley(w):
    """Inverse Cayley, unit disk -> H: w |-> i (1 + w)/(1 - w)."""
    w = np.asarray(w, dtype=np.complex128)
    return 1j * (1.0 + w) / (1.0 - w)


def half_plane_grid(re_lim, im_lim, res):
    """Grid over the upper half-plane. Returns (TAU, extent) for imshow.

    re_lim = (xmin, xmax), im_lim = (ymin, ymax). Row 0 of TAU is the TOP
    (largest Im) so imshow with origin='upper' renders the way we read H.
    """
    xs = np.linspace(re_lim[0], re_lim[1], res)
    ys = np.linspace(im_lim[1], im_lim[0], res)  # top row = high Im
    X, Y = np.meshgrid(xs, ys)
    extent = (re_lim[0], re_lim[1], im_lim[0], im_lim[1])
    return X + 1j * Y, extent


def disk_grid(res):
    """Grid over the unit disk. Returns (W, mask, extent)."""
    xs = np.linspace(-1, 1, res)
    ys = np.linspace(1, -1, res)
    X, Y = np.meshgrid(xs, ys)
    W = X + 1j * Y
    mask = np.abs(W) <= 1.0 - 1e-9
    return W, mask, (-1, 1, -1, 1)
