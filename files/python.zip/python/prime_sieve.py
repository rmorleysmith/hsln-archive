"""A blind, cheerful attempt at finding primes by COMPOSITION.

Each "skill" detects the multiples of a small prime p: the field sin(pi*x/p) rings to
zero exactly at multiples of p (the p-th-root-of-unity comb -- sin(pi x/p) is the
imaginary part of e^{i pi x/p}, vanishing whenever p | x). COMPOSE the skills by
MULTIPLYING the fields -- the same tensor product whose zeros UNION. So the composed
field

        F(x) = prod_{p in {2,3,5,7}} sin(pi*x/p)

vanishes at every composite (a union of all the multiples), and the PRIMES are exactly
the integers where it SURVIVES.

For n <= 120, sieving by {2,3,5,7} (the primes <= sqrt(120)) catches every composite, so
   prime(n)  <=>  n in {2,3,5,7}  OR  ( n > 1 and F(n) != 0 ).
It works. It's the Sieve of Eratosthenes wearing a Fourier hat. You asked; here it is.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

SIEVE = [2, 3, 5, 7]
M = 100


def field(x):
    x = np.asarray(x, float)
    out = np.ones_like(x)
    for p in SIEVE:
        out = out * np.sin(np.pi * x / p)
    return out


def is_prime(n):
    if n < 2:
        return False
    return all(n % d for d in range(2, int(n ** 0.5) + 1))


def run(make_fig=True):
    n = np.arange(2, M + 1)
    Fn = np.abs(field(n))
    found = set(SIEVE) | {int(k) for k in n if k > max(SIEVE) and abs(field(k)) > 1e-9}
    truth = {int(k) for k in n if is_prime(k)}

    print(f"composed-field survivors -> primes found (<= {M}):")
    print("  " + "  ".join(str(p) for p in sorted(found)))
    print(f"\n{len(found)} found;  true primes <= {M}: {len(truth)};  "
          f"match: {found == truth}")
    missed = truth - found
    extra = found - truth
    if missed or extra:
        print(f"  missed {sorted(missed)}   extra {sorted(extra)}")

    if make_fig:
        _figure(n, Fn, found, truth)
    return found == truth


def _figure(n, Fn, found, truth):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, NEURON = "#46f0d0", "#ffd166", "#ff3b6b"
    COLP = ["#46f0d0", "#ffd166", "#ff7b6b", "#c0a3ff"]

    fig = plt.figure(figsize=(15.5, 7.6))
    gs = fig.add_gridspec(2, 1, height_ratios=[1, 1.15], hspace=0.32)
    top = gs[0].subgridspec(1, 2, width_ratios=[1, 1.1])
    a = fig.add_subplot(top[0]); b = fig.add_subplot(top[1])
    c = fig.add_subplot(gs[1])

    # --- A: the individual detector skills (combs) --- #
    xs = np.linspace(2, 30, 2000)
    for i, p in enumerate(SIEVE):
        a.plot(xs, np.sin(np.pi * xs / p) + 2.4 * i, color=COLP[i], lw=1.3)
        a.axhline(2.4 * i, color="#333", lw=0.5)
        a.text(2.2, 2.4 * i + 0.95, f"÷{p} detector", color=COLP[i], fontsize=9)
    a.set_yticks([]); a.set_xlabel("integer x")
    a.set_title("four skills: each rings to zero at multiples of $p$", fontsize=12)

    # --- B: the composed field; primes survive --- #
    xs2 = np.linspace(2, 50, 6000)
    b.plot(xs2, np.abs(field(xs2)), color="#5a5a72", lw=0.9, alpha=0.8)
    for k in range(2, 51):
        prime = k in truth
        b.plot(k, abs(field(k)), "o", color=GOLD if prime else "#444",
               ms=8 if prime else 5, mec="white" if prime else "none",
               mew=0.5, zorder=4 if prime else 3)
    b.set_xlabel("integer"); b.set_ylabel(r"$|F(x)|$ = $\prod_p |\sin(\pi x/p)|$")
    b.set_title("compose (multiply) → field vanishes at composites,\nsurvives at primes (gold)",
                fontsize=12)

    # --- C: the result, 2..M --- #
    for k in range(2, M + 1):
        prime = k in found
        c.plot(k, 0, "s", color=GOLD if prime else "#2a2a38",
               ms=11 if prime else 8, mec="white" if prime else "#444", mew=0.4)
        if prime:
            c.annotate(str(k), (k, 0), textcoords="offset points", xytext=(0, 9),
                       color=GOLD, fontsize=7.5, ha="center", rotation=90)
    ok = found == truth
    c.set_ylim(-0.5, 1.2); c.set_yticks([]); c.set_xlabel("integer")
    c.set_title(f"primes ≤ {M} recovered by composition: {len(found)} found  "
                f"({'exact match with the true primes' if ok else 'MISMATCH'})", fontsize=12)

    fig.suptitle("Finding primes by composition: multiply the divisibility-detector fields "
                 "(zeros union = composites) — the survivors are prime", fontsize=13, y=0.99)
    out = Path(__file__).parent / "figures" / "31_prime_sieve.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
