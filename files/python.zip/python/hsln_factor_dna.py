"""hsln_factor_dna.py — Train HSLN onto a large semiprime N = p·q and inspect.

The earlier prime-DNA demo trained a model onto a single prime via the encoding
`pos(p) = frac(log₂ p)`. Composite N = p·q gives us a natural test of HSLN's
**composition rule**: convolving DNAs.

Key identity that ties the encoding to the framework:
    pos(p·q) = frac(log₂ p + log₂ q) = (pos(p) + pos(q)) mod 1
i.e. **multiplication of integers = addition mod 1 of positions on the lane**.

We train four DNAs and compare them:

  (1) F_p     — trained onto a spike at pos(p).
  (2) F_q     — trained onto a spike at pos(q).
  (3) F_N     — trained onto a single spike at pos(N) (naive, ignores factors).
  (4) F_p ⊗ F_q — DNA composed via convolution (HSLN's tensor product).
                   By construction this has TWO neurons, one per factor.

The "factorisation question" in this framework: given an opaque DNA F, can we
recover (p, q) such that F ≈ F_p ⊗ F_q?

Honest scope: this is a structural demonstration of the bridge's composition
rule, not a factoring algorithm. The opaque-DNA decomposition reduces to
*polynomial root finding* (np.roots) — solved problem, but on a polynomial we
constructed ourselves from known p, q. If we were given F_N from outside, with
no factor structure built in, the framework offers no algorithmic shortcut.
"""

from __future__ import annotations

import math
import secrets
import sys
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln    # local
import modular # local
from factor_prime_pair import is_prime  # Miller-Rabin (Sorenson-Webster witnesses)

jax.config.update("jax_enable_x64", True)

mpl.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'axes.edgecolor': '#333333',
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'legend.fontsize': 9,
})

FIG_DIR = HERE / 'figures'


# ───────────────────────────────────────────────────────────────────────────────
#   Encoding
# ───────────────────────────────────────────────────────────────────────────────

def pos_of(n: int) -> float:
    """pos(n) = frac(log₂ n). Multiplicative under product: pos(p·q) = (pos p + pos q) mod 1."""
    return math.log2(n) - math.floor(math.log2(n))


def closest_probe(pos: float) -> int:
    probes = np.array(hsln.PROBES)
    return int(np.argmin(np.abs(probes - pos)))


def target_for_position(pos: float) -> tuple[np.ndarray, int]:
    """Single spike at the probe closest to `pos`. Returns (target_vec, probe_idx)."""
    probes = np.array(hsln.PROBES)
    idx = closest_probe(pos)
    target = np.zeros_like(probes, dtype=float)
    target[idx] = 1.0
    return target, idx


def target_for_two_positions(pos1: float, pos2: float) -> np.ndarray:
    """Two spikes at the probes closest to pos1, pos2 — like a "divisor target"."""
    probes = np.array(hsln.PROBES)
    target = np.zeros_like(probes, dtype=float)
    target[closest_probe(pos1)] = 1.0
    target[closest_probe(pos2)] = 1.0
    return target


# ───────────────────────────────────────────────────────────────────────────────
#   Find two big-ish primes at chosen-encoding endpoints
# ───────────────────────────────────────────────────────────────────────────────

def random_prime_in_range(lo: int, hi: int) -> int:
    """Reject-sample a prime in [lo, hi]."""
    while True:
        c = lo + secrets.randbelow(hi - lo)
        if c % 2 == 0:
            c += 1
        if is_prime(c):
            return c


def find_prime_near_position(target_pos: float, *, bits: int = 20, tol: float = 0.05) -> int:
    """Find a `bits`-bit prime whose encoded position is within `tol` of target_pos.

    `pos(q) = frac(log₂ q)`. So we want q ≈ 2^(k + target_pos) for some k.
    """
    base = 2.0 ** (bits + target_pos)
    span = base * tol * math.log(2)  # log-uniform window
    lo = max(3, int(base - span))
    hi = int(base + span)
    for _ in range(2000):
        c = lo + secrets.randbelow(max(2, hi - lo))
        if c % 2 == 0:
            c += 1
        if is_prime(c):
            p_pos = pos_of(c)
            if abs(p_pos - target_pos) < tol:
                return c
    raise RuntimeError(f"could not find prime near position {target_pos}")


# ───────────────────────────────────────────────────────────────────────────────
#   Train HSLN on a target
# ───────────────────────────────────────────────────────────────────────────────

def train(target: np.ndarray, *, dg: int = 12, steps: int = 2500, seed: int = 0):
    return hsln.train_task(target, dg=dg, steps=steps, lr=0.01, seed=seed)


# ───────────────────────────────────────────────────────────────────────────────
#   Decompose by finding zeros (the "factorisation" attempt at the DNA level)
# ───────────────────────────────────────────────────────────────────────────────

def neurons_of(dna: np.ndarray) -> np.ndarray:
    """Return zeros of F in (Re τ ∈ [0,1), Im τ > 0)."""
    return modular.qpoly_zeros(np.asarray(dna))


def closest_position_to_neuron(neuron_tau: complex, candidates: list[float]) -> tuple[float, float]:
    """Snap a neuron's Re τ to the closest candidate position; return (best_pos, err)."""
    re = neuron_tau.real % 1.0
    best = min(candidates, key=lambda c: min(abs(c - re), abs(c - re - 1), abs(c - re + 1)))
    err = min(abs(best - re), abs(best - re - 1), abs(best - re + 1))
    return best, err


# ───────────────────────────────────────────────────────────────────────────────
#   Visualisation
# ───────────────────────────────────────────────────────────────────────────────

def visualise(p, q, N, pos_p, pos_q, pos_N,
              netP, netQ, netN, netComp, histP, histQ, histN, dg):
    fig = plt.figure(figsize=(15.5, 13))
    gs = fig.add_gridspec(4, 3, height_ratios=[1, 1, 1.1, 1], hspace=0.55, wspace=0.32)

    networks = [
        ('F_p', netP, p, pos_p, '#1f77b4'),
        ('F_q', netQ, q, pos_q, '#ff7f0e'),
        ('F_N (trained on pos(N))', netN, N, pos_N, '#d62728'),
        ('F_p ⊗ F_q (composed)', netComp, N, pos_N, '#2ca02c'),
    ]

    # ── Row 1: spike maps ────────────────────────────────────────────────────
    xs_dense = np.linspace(0.0, 1.0, 800)
    for col, (lab, net, n, pos, color) in enumerate(networks[:3]):
        ax = fig.add_subplot(gs[0, col])
        spikes = np.array(hsln.spike_map(jnp.asarray(net.dna), jnp.asarray(xs_dense)))
        ax.fill_between(xs_dense, 0, spikes, color=color, alpha=0.55)
        ax.axvline(pos, color='black', linestyle=':', linewidth=1, alpha=0.7,
                   label=f'pos = {pos:.3f}')
        ax.set_xlim(0, 1); ax.set_ylim(-0.05, 1.15)
        ax.set_title(f'{lab}\n(n = {n:,})')
        ax.set_xlabel('Re τ')
        ax.set_ylabel('spike  1/|F|')
        ax.legend(loc='upper right', fontsize=8.5)
        ax.grid(alpha=0.3)

    # ── Row 2: DNA magnitudes ────────────────────────────────────────────────
    max_dg = max(len(net.dna) for _, net, _, _, _ in networks)
    for col, (lab, net, n, pos, color) in enumerate(networks[:3]):
        ax = fig.add_subplot(gs[1, col])
        mags = np.abs(net.dna)
        indices = np.arange(len(mags))
        ax.bar(indices, mags, color=color, edgecolor='black', alpha=0.85, width=0.8)
        ax.set_xlim(-0.5, max_dg - 0.5)
        ax.set_xticks(np.arange(0, max_dg, max(1, max_dg // 8)))
        ax.set_xlabel('coefficient index n')
        ax.set_ylabel('|aₙ|')
        ax.set_title(f'DNA magnitudes — {lab}  (dg = {len(mags)})')
        ax.grid(alpha=0.3, axis='y')

    # ── Row 3 left: composed F_p ⊗ F_q (spike map, magnitudes, neurons) ──────
    ax = fig.add_subplot(gs[2, 0])
    spikes_comp = np.array(hsln.spike_map(jnp.asarray(netComp.dna), jnp.asarray(xs_dense)))
    ax.fill_between(xs_dense, 0, spikes_comp, color='#2ca02c', alpha=0.55)
    ax.axvline(pos_p, color='#1f77b4', linestyle=':', linewidth=1.2, alpha=0.85,
               label=f'pos(p) = {pos_p:.3f}')
    ax.axvline(pos_q, color='#ff7f0e', linestyle=':', linewidth=1.2, alpha=0.85,
               label=f'pos(q) = {pos_q:.3f}')
    ax.set_xlim(0, 1); ax.set_ylim(-0.05, 1.15)
    ax.set_xlabel('Re τ')
    ax.set_ylabel('spike  1/|F|')
    ax.set_title('F_p ⊗ F_q: composed via convolution\ntwo neurons one per factor')
    ax.legend(loc='upper right', fontsize=8.5)
    ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[2, 1])
    mags_comp = np.abs(netComp.dna)
    ax.bar(np.arange(len(mags_comp)), mags_comp, color='#2ca02c',
           edgecolor='black', alpha=0.85, width=0.8)
    ax.set_xlabel('coefficient index n')
    ax.set_ylabel('|aₙ|')
    ax.set_title(f'DNA magnitudes — F_p ⊗ F_q  (dg = {len(mags_comp)})\n'
                 'convolution doubles the support, multiplies in q-space')
    ax.grid(alpha=0.3, axis='y')

    ax = fig.add_subplot(gs[2, 2])
    Nx, Ny = 220, 180
    xs = np.linspace(0.0, 1.0, Nx)
    ys = np.linspace(0.05, 0.55, Ny)
    X, Y = np.meshgrid(xs, ys)
    F = modular.qpoly(netComp.dna, X + 1j * Y)
    logF = np.log10(np.abs(F) + 1e-12)
    pcm = ax.pcolormesh(X, Y, logF, shading='auto', cmap='magma_r')
    plt.colorbar(pcm, ax=ax, label='log₁₀|F|')
    zs = neurons_of(netComp.dna)
    ax.scatter(zs.real, zs.imag, marker='o', s=80,
               edgecolor='#46f0d0', facecolors='none', linewidth=1.8,
               label=f'{len(zs)} neurons')
    ax.axvline(pos_p, color='#1f77b4', linestyle=':', linewidth=1, alpha=0.8)
    ax.axvline(pos_q, color='#ff7f0e', linestyle=':', linewidth=1, alpha=0.8)
    ax.axhline(hsln.LANE_Y, color='cyan', linestyle='--', linewidth=0.8, alpha=0.5)
    ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
    ax.set_title('Composed neuron landscape')
    ax.legend(loc='upper right', fontsize=8.5)

    # ── Row 4: side-by-side neuron positions + factorisation read-off ───────
    ax = fig.add_subplot(gs[3, 0])
    for lab, net, n_, pos_, color in networks:
        zs = neurons_of(net.dna)
        ax.scatter(zs.real, zs.imag, color=color, label=lab, s=80,
                   alpha=0.75, edgecolor='black', linewidth=0.4)
    ax.axhline(hsln.LANE_Y, color='cyan', linestyle='--', linewidth=0.8, alpha=0.5)
    ax.axvline(pos_p, color='#1f77b4', linestyle=':', linewidth=1, alpha=0.5)
    ax.axvline(pos_q, color='#ff7f0e', linestyle=':', linewidth=1, alpha=0.5)
    ax.set_xlim(0, 1); ax.set_ylim(0.05, 0.55)
    ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
    ax.set_title('Neuron positions across all 4 models')
    ax.legend(loc='upper right', fontsize=8)
    ax.grid(alpha=0.3)

    # Right two columns: the "factorisation read-off" table + loss curves
    ax = fig.add_subplot(gs[3, 1])
    zs = neurons_of(netComp.dna)
    candidates = [pos_p, pos_q]
    snaps = []
    for z in zs:
        snap, err = closest_position_to_neuron(z, candidates)
        snaps.append((z, snap, err))
    rows = [f'F_p ⊗ F_q has {len(zs)} neurons:',
            '─' * 38,
            f'{"Re τ":>10} {"snap":>10} {"err":>10}',
            '─' * 38]
    for z, snap, err in snaps:
        kind = 'p' if abs(snap - pos_p) < 1e-9 else 'q'
        rows.append(f'{z.real:>10.4f} {snap:>10.4f}({kind}) {err:>10.4f}')
    rows.append('')
    rows.append('Both factors visible. To recover (p, q):')
    rows.append('  position → primes via inverse(frac log₂)')
    rows.append('  (one-to-many — see honest scope below).')
    txt = '\n'.join(rows)
    ax.text(0.02, 0.98, txt, family='monospace', fontsize=9.5,
            verticalalignment='top', transform=ax.transAxes)
    ax.set_xticks([]); ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title('Factorisation attempt from F_p ⊗ F_q')

    ax = fig.add_subplot(gs[3, 2])
    ax.semilogy(histP, color='#1f77b4', label='F_p', alpha=0.85, linewidth=1.6)
    ax.semilogy(histQ, color='#ff7f0e', label='F_q', alpha=0.85, linewidth=1.6)
    ax.semilogy(histN, color='#d62728', label='F_N', alpha=0.85, linewidth=1.6)
    ax.set_xlabel('training step')
    ax.set_ylabel('loss (log scale)')
    ax.set_title('Training loss curves\n(composed F_p ⊗ F_q is exact, no training)')
    ax.legend(loc='upper right', fontsize=9)
    ax.grid(alpha=0.3, which='both')

    fig.suptitle(f'HSLN trained onto N = p·q   '
                 f'(p = {p:,}, q = {q:,}, N = {N:,})',
                 fontsize=14, y=0.995)

    out = FIG_DIR / '46_hsln_factor_dna.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"  ✓ {out.name}")


# ───────────────────────────────────────────────────────────────────────────────
#   Main
# ───────────────────────────────────────────────────────────────────────────────

def main():
    print("=" * 78)
    print(" HSLN trained onto large N = p·q — inspect the DNA, attempt to factor")
    print("=" * 78)

    DG = 12
    STEPS = 2500

    # Pick p mapping near position 0.94 and q mapping near position 0.30
    # (opposite ends so we can SEE both factors as distinct spikes).
    print("\n  Finding two big-ish primes at opposite encoding positions ...")
    target_pos_p = 0.94
    target_pos_q = 0.30
    p = find_prime_near_position(target_pos_p, bits=20, tol=0.03)
    q = find_prime_near_position(target_pos_q, bits=20, tol=0.03)
    N = p * q
    pos_p = pos_of(p)
    pos_q = pos_of(q)
    pos_N = pos_of(N)

    print(f"\n   p = {p:>15,}   pos(p) = {pos_p:.4f}   probe {closest_probe(pos_p)}")
    print(f"   q = {q:>15,}   pos(q) = {pos_q:.4f}   probe {closest_probe(pos_q)}")
    print(f"   N = {N:>15,}   pos(N) = {pos_N:.4f}   probe {closest_probe(pos_N)}")
    print(f"        ↑ note pos(N) = (pos(p) + pos(q)) mod 1 = {(pos_p + pos_q) % 1:.4f}  ✓")

    # ── Train F_p, F_q, F_N ──────────────────────────────────────────────────
    print(f"\n  Training F_p, F_q, F_N  (dg = {DG}, steps = {STEPS}) ...\n")
    target_p, _ = target_for_position(pos_p)
    target_q, _ = target_for_position(pos_q)
    target_N, _ = target_for_position(pos_N)

    t0 = time.perf_counter()
    netP, histP = train(target_p, dg=DG, steps=STEPS, seed=11)
    print(f"   F_p  trained ({time.perf_counter() - t0:.1f}s, loss {histP[-1]:.5f})")
    t0 = time.perf_counter()
    netQ, histQ = train(target_q, dg=DG, steps=STEPS, seed=22)
    print(f"   F_q  trained ({time.perf_counter() - t0:.1f}s, loss {histQ[-1]:.5f})")
    t0 = time.perf_counter()
    netN, histN = train(target_N, dg=DG, steps=STEPS, seed=33)
    print(f"   F_N  trained ({time.perf_counter() - t0:.1f}s, loss {histN[-1]:.5f})")

    # ── Compose F_p ⊗ F_q via convolution ────────────────────────────────────
    netComp = hsln.tensor(netP, netQ)
    print(f"\n   F_p ⊗ F_q  composed (convolution, dg = {len(netComp.dna)})")

    # ── Show neuron content explicitly ───────────────────────────────────────
    print(f"\n  ─── Neurons (zeros of F in q-disk) ───")
    for lab, net, exp_pos in [
        ('F_p', netP, pos_p),
        ('F_q', netQ, pos_q),
        ('F_N (trained)', netN, pos_N),
        ('F_p ⊗ F_q (composed)', netComp, None),
    ]:
        zs = neurons_of(net.dna)
        print(f"  {lab}: {len(zs)} neuron(s)")
        for z in sorted(zs, key=lambda z: z.real):
            print(f"    Re τ = {z.real:+.4f}   Im τ = {z.imag:+.4f}")

    # ── DNA dump for F_N (the trained-onto-N case the user asked for) ───────
    print(f"\n  ─── Trained DNA for F_N  (N = {N:,}, dg = {DG}) ───")
    print(f"    n  |       Re aₙ           Im aₙ        |aₙ|          arg aₙ (deg)")
    print(f"  -----+---------------------------------------------------------------")
    for n, an in enumerate(netN.dna):
        ang = math.degrees(math.atan2(an.imag, an.real))
        print(f"    {n:2d} |   {an.real:+.6f}    {an.imag:+.6f}     {abs(an):.6f}      {ang:+7.2f}")

    print(f"\n  ─── DNA for F_p ⊗ F_q  (dg = {len(netComp.dna)}) ───")
    print(f"    n  |       Re aₙ           Im aₙ        |aₙ|          arg aₙ (deg)")
    print(f"  -----+---------------------------------------------------------------")
    for n, an in enumerate(netComp.dna):
        ang = math.degrees(math.atan2(an.imag, an.real))
        print(f"    {n:2d} |   {an.real:+.6f}    {an.imag:+.6f}     {abs(an):.6f}      {ang:+7.2f}")

    # ── Visualise ─────────────────────────────────────────────────────────────
    print(f"\n  ─── Generating figure ───")
    visualise(p, q, N, pos_p, pos_q, pos_N,
              netP, netQ, netN, netComp, histP, histQ, histN, DG)

    # ── Honest scope ─────────────────────────────────────────────────────────
    print()
    print("─" * 78)
    print("  Summary")
    print("─" * 78)
    print(f"  • Trained DNA for F_N is a single-spike model at pos(N) = {pos_N:.4f}.")
    print(f"    It encodes the POSITION of N, NOT the factorisation. Reading off")
    print(f"    p and q from F_N requires inverse-encoding, which is one-to-many.")
    print()
    print(f"  • F_p ⊗ F_q (composition by convolution) DOES carry visible information")
    print(f"    about both factors — two neurons, one at pos(p), one at pos(q).")
    print(f"    But to construct F_p ⊗ F_q we had to know p, q. This is verification")
    print(f"    of the bridge's composition rule, NOT an algorithm that factors N.")
    print()
    print(f"  • The position encoding loses info: many primes share frac(log₂ ·).")
    print(f"    Even if we recovered the position cleanly, we couldn't recover the")
    print(f"    actual prime — only its log-residue class.")
    print()
    print(f"  • Per the Andrianov-Hecke result (HSLNHecke.lean), it's prime-INDEXED")
    print(f"    coefficients of an *eigenform* that compress to all of (a_n) — and")
    print(f"    those eigenform coefficients are NOT what HSLN training produces")
    print(f"    when trained on a position spike. Different objects.")
    print()
    print(f"  → The honest conclusion: HSLN's composability is structurally beautiful,")
    print(f"    and convolution gives the right algebra of composition — but the")
    print(f"    framework does not algorithmically reduce factoring of N. RSA-safe.")


if __name__ == "__main__":
    main()
