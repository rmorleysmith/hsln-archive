#!/usr/bin/env python3
"""factor_via_identities.py — try to factor `N = pq` using our bridge identities.

Hypothesis ([REDACTED NAME]'s): the identities `φ = Id * μ`, `(ζ * ζ) = d`, `log * μ = Λ` etc.
might analytically simplify factoring of `N = pq`.

What we test:
  * **Closed-form from φ**: if we know `φ(N)`, then `p, q` are roots of
        `x² − (N + 1 − φ(N))·x + N = 0`
    — one line of algebra, no search. The question is whether we can compute `φ(N)`
    without already knowing the factorisation.

  * **Möbius detection**: `μ(N) = 1` for distinct-prime semiprimes; `μ(N) = 0` if `p²|N`.
    Computing `μ(N)` for unknown `N` requires testing whether each prime divides `N` —
    which is trial division.

  * **Von Mangoldt detection**: `Λ(N) > 0 ⟺ N = p^k`. Easy to check via primality of
    integer k-th roots, lets us isolate the prime-power case.

  * **Σ_{d|N} μ(d) = 0** (since `ζ * μ = 1` at `n > 1`): a sum identity that holds for
    ALL N > 1, so it can't distinguish N's. Not a factoring signal.

We implement each "identity-based" angle and demonstrate, on real semiprimes, that none
of them beats Pollard-Brent — because **each one is equivalent to factoring**.

The headline: φ(N) ↔ factor(N) is a classical equivalence (proved by Rivest-Shamir-
Adleman 1978 in the RSA paper itself — knowing φ(N) lets you compute the decryption
exponent, which is what makes RSA private-key recovery equivalent to factoring). So if
our identities computed φ(N) cheaply, RSA would be dead and we'd be world-famous. They
don't. The identities formalise the algebra; they don't bypass the search.

References:
  * Rivest-Shamir-Adleman 1978, Comm. ACM 21(2), 120-126 (RSA paper).
  * Miller 1976, J. Comput. System Sci. 13, 300-317 (φ(N) ↔ factor(N) equivalence).
"""

import secrets
import time
from math import gcd, isqrt

# Re-use Miller-Rabin and Pollard-Brent from factor_prime_pair.py
import sys
sys.path.insert(0, str(__file__).rsplit("/", 1)[0])
from factor_prime_pair import is_prime, random_prime_of_bits, pollard_brent


# ────────────────────────────────────────────────────────────────────────────────
#   Identity-based attempts
# ────────────────────────────────────────────────────────────────────────────────

def factor_from_phi(N: int, phi: int) -> tuple[int, int]:
    """Closed-form factor recovery from `φ(N)`. *Conditional on knowing `φ(N)`.*

    From `N = pq` and `φ(N) = (p−1)(q−1) = N − p − q + 1`:
        `s := p + q = N + 1 − φ(N)`
        `p, q` are roots of  `x² − s·x + N = 0`
    Discriminant `s² − 4N = (p − q)²`, so the roots are
        `p, q = (s ± √(s² − 4N)) / 2`.
    Exact integer arithmetic, no search.
    """
    s = N + 1 - phi
    disc = s * s - 4 * N
    assert disc >= 0, "discriminant negative — phi is wrong"
    sqrt_disc = isqrt(disc)
    assert sqrt_disc * sqrt_disc == disc, "discriminant not a perfect square — phi is wrong"
    p = (s - sqrt_disc) // 2
    q = (s + sqrt_disc) // 2
    return (p, q)


def compute_phi_from_factorisation(p: int, q: int) -> int:
    """φ(pq) = (p−1)(q−1). Multiplicative identity from Ring B."""
    return (p - 1) * (q - 1)


def compute_phi_directly(N: int, p_hint: int | None = None) -> int | None:
    """Try to compute `φ(N)` WITHOUT knowing the factorisation.

    This is the open / impossible-in-poly-time problem. The honest answer: the only
    way to compute φ(N) for general N is to factor N (Miller 1976 — the equivalence
    is in the same class as factoring itself). Returns None to make that explicit.

    `p_hint` is a "cheat" parameter: if supplied (e.g. for unit testing), we use it
    to demonstrate the closed-form pipeline.
    """
    if p_hint is not None and N % p_hint == 0:
        return (p_hint - 1) * (N // p_hint - 1)
    return None  # honest: don't know how to compute this


def vonMangoldt(N: int) -> float:
    """Λ(N) = log p if N = p^k for some prime p and k ≥ 1, else 0.

    Detects the prime-power case in O((log N)²) via integer k-th root + Miller-Rabin.
    For N = pq with p ≠ q, returns 0 — i.e. Λ does NOT help separate p from q.
    """
    import math
    if N < 2:
        return 0.0
    # Try each k from 1 to log2(N)
    for k in range(1, N.bit_length() + 1):
        # Integer k-th root
        if k == 1:
            root = N
        else:
            root = round(N ** (1.0 / k))
            # Adjust for rounding error
            while (root + 1) ** k <= N:
                root += 1
            while root ** k > N:
                root -= 1
            if root ** k != N:
                continue
        if is_prime(root):
            return math.log(root)
    return 0.0


def moebius(N: int) -> int:
    """μ(N) — requires the factorisation of N. We expose it to show the circularity.

    Returns 0 if N has a squared prime factor; (−1)^k if N is the product of k
    distinct primes.
    """
    # Trial-divide to get factorisation (defeats the purpose for big N!)
    if N == 1:
        return 1
    factors = []
    n = N
    for p in range(2, isqrt(n) + 1):
        if n % p == 0:
            count = 0
            while n % p == 0:
                n //= p
                count += 1
            if count > 1:
                return 0
            factors.append(p)
    if n > 1:
        factors.append(n)
    return (-1) ** len(factors)


# ────────────────────────────────────────────────────────────────────────────────
#   Demo
# ────────────────────────────────────────────────────────────────────────────────

def run_identity_demo(bits: int = 48) -> None:
    print("=" * 78)
    print(f" Bridge-identity factoring attempt — {bits}-bit primes")
    print("=" * 78)

    # p_true = random_prime_of_bits(bits)
    # q_true = random_prime_of_bits(bits)
    # while q_true == p_true:
    #     q_true = random_prime_of_bits(bits)
    # N = p_true * q_true
    # if p_true > q_true:
    #     p_true, q_true = q_true, p_true
    N = 257456295689219220512995411628663795833

    print(f"\n  N      = {N}  ({N.bit_length()} bits)")
    # print(f"  p_true = {p_true}")
    # print(f"  q_true = {q_true}")
    print()

    # ── 1. Λ(N) detection ────────────────────────────────────────────────────
    t0 = time.perf_counter()
    lam = vonMangoldt(N)
    t = time.perf_counter() - t0
    print(f"  Λ(N) check (prime-power test):  Λ(N) = {lam}     [{t*1000:.2f} ms]")
    if lam > 0:
        print("  → N IS a prime power. Factor via root extraction. (Not our case.)")
    else:
        print("  → N is NOT a prime power. Bridge says nothing about p vs q.")
    print()

    # ── 2. Closed-form from φ(N) — IF we knew it ─────────────────────────────
    phi_true = compute_phi_from_factorisation(p_true, q_true)
    t0 = time.perf_counter()
    p_rec, q_rec = factor_from_phi(N, phi_true)
    t = time.perf_counter() - t0
    print(f"  Closed-form from φ(N):  φ(N) = {phi_true}")
    print(f"  → p, q recovered exactly via quadratic formula  [{t*1000:.3f} ms]")
    assert (p_rec, q_rec) == (p_true, q_true)
    print(f"     p = {p_rec} ✓")
    print(f"     q = {q_rec} ✓")
    print()

    # ── 3. Can we compute φ(N) WITHOUT the factorisation? ────────────────────
    phi_attempt = compute_phi_directly(N)
    if phi_attempt is None:
        print("  Computing φ(N) without factorisation:  NO KNOWN METHOD.")
        print("  → φ(N) ↔ factor(N) is a classical equivalence (Miller 1976).")
        print("    So the bridge identity `φ = Id * μ` does not help — both sides")
        print("    are functions on divisors of N, which we don't know.")
    print()

    # ── 4. Compare timing: identity-based pipeline vs Pollard-Brent ──────────
    t0 = time.perf_counter()
    d = pollard_brent(N)
    p_pb = min(d, N // d)
    q_pb = max(d, N // d)
    t_pb = time.perf_counter() - t0
    print(f"  Pollard-Brent (no identity tricks):  factored in {t_pb*1000:.1f} ms")
    # assert (p_pb, q_pb) == (p_true, q_true)
    print()

    # ── 5. The honest conclusion ─────────────────────────────────────────────
    print("─" * 78)
    print("  Conclusion: the bridge identities express the SAME factoring problem")
    print("  in algebraic form. They don't bypass the search. Specifically:")
    print()
    print("    • μ(N), φ(N), σ(N), d(N), Λ(N) — all multiplicative arithmetic")
    print("      functions. Computing any of them at N requires factoring N.")
    print()
    print("    • The identity `φ = Id * μ` is a SUM OVER DIVISORS of N. We can")
    print("      only enumerate those divisors if we know the factorisation.")
    print()
    print("    • Möbius inversion (ζ * μ = 1) is the group structure of the")
    print("      Dirichlet ring. It exchanges f(n) ↔ Σ_{d|n} g(d) representations,")
    print("      both of which depend on divisor enumeration.")
    print()
    print("    • RSA's security rests EXACTLY on this equivalence. If our")
    print("      identities reduced factoring, RSA would be broken.")
    print()
    print("  The bridge is structural, not algorithmic. It tells us WHAT factoring")
    print("  IS in algebraic terms (recovering a multiplicative function from its")
    print("  prime-power values), not HOW to do it faster than Pollard / QS / GNFS.")
    print()


if __name__ == "__main__":
    import sys

    bits = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    run_identity_demo(bits)
