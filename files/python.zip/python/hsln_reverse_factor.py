"""
Reverse the test: start at N, drive to 1 — where are the spikes, and is it fast?

[REDACTED NAME]'s question: the forward test drives 1 → N and the roots-of-unity projection
spikes at the prime factors. Surely it's reversible — so run it N → 1. And: pray it
isn't a polynomial-time factoring algorithm that way round.

Two honest findings, both shown here:

  REVERSIBLE — YES.  The detector D(k) = (1/k)|Σ_{j<k} e^{2πi jN/k}| = [k | N] is a
  property of N, not of the direction of travel. Divisors come in pairs d ↔ N/d folded
  about √N. So the reverse pass (N → 1) lights up the SAME points; the only change is
  which one you meet first: forward meets the small factor p, reverse meets its
  co-factor q = N/p. Same factorisation, mirror-imaged.

  POLYNOMIAL — NO.  To locate a spike you must scan candidates. The cheap direction
  (forward, up to √N) costs ~√N evaluations; the reverse (down from N to the largest
  proper divisor) costs ~N. Both are EXPONENTIAL in the bit-length of N — a straight
  line on the log-evaluations-vs-bits plot. Reversing is no shortcut (it's worse).

  The twist: the structure [REDACTED NAME] spotted is real and deep. The roots-of-unity /
  Fourier view of divisibility IS what makes factoring polynomial — but only with a
  *quantum* Fourier transform (Shor 1994, period finding). Classically you pay the
  exponential scan. So: a beautiful picture, and RSA is safe on classical hardware.

Run:  .venv/bin/python hsln_reverse_factor.py
"""
from __future__ import annotations

import time
import numpy as np
import matplotlib.pyplot as plt

from hsln_e8_torsion_factor import (
    is_prime, interior_divisors, FG, BG, ACCENT, ACCENT2, COMP, GRID, palette, save_fig,
)


# --------------------------------------------------------------------------
# Detector values (exact) + a stable roots-of-unity spot-check
# --------------------------------------------------------------------------
def ru_detector_stable(N: int, k: int) -> float:
    """The real roots-of-unity sum, computed with phases reduced mod k for numerical
    stability: D(k) = (1/k)|Σ_{j<k} e^{2πi·((jN) mod k)/k}| = 1 iff k|N."""
    r = (np.arange(k) * N) % k
    return float(np.abs(np.exp(2j * np.pi * r / k).sum()) / k)


def divisors_of(N: int) -> list[int]:
    return interior_divisors(N)


def smallest_factor(N: int) -> int:
    k = 2
    while k * k <= N:
        if N % k == 0:
            return k
        k += 1
    return N


# --------------------------------------------------------------------------
# Reversibility check + cost model
# --------------------------------------------------------------------------
def spikes(N: int) -> list[int]:
    """Where the projection fires (interior divisors) — direction-independent."""
    return divisors_of(N)


def evals_to_first_factor_forward(p: int, q: int) -> int:
    """Scan k = 2,3,... upward; first divisor is the smaller prime p."""
    return min(p, q) - 1


def evals_to_first_factor_reverse(p: int, q: int) -> int:
    """Scan k = N-1, N-2,... downward; first proper divisor is q = N/p (the larger)."""
    N = p * q
    largest_proper = N // min(p, q)          # = max(p, q)
    return (N - 1) - largest_proper + 1


# --------------------------------------------------------------------------
# Panels
# --------------------------------------------------------------------------
def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def plot_reverse_spectrum(ax, p, q, title):
    N = p * q
    divs = divisors_of(N)
    for d in divs:
        pr = is_prime(d)
        ax.vlines(d, 0, 1, color=ACCENT if pr else COMP, lw=2.4 if pr else 1.3)
        ax.scatter([d], [1.0], s=80 if pr else 30, c=ACCENT if pr else COMP,
                   edgecolors=FG, linewidths=0.5, zorder=5)
    first = max(divs)                         # reverse (N→1) meets the largest first
    ax.annotate(f"first hit going N→1:\n{first} = N/{N // first}",
                xy=(first, 1.0), xytext=(0.30, 0.55), textcoords="axes fraction",
                color=ACCENT2, fontsize=8.5,
                arrowprops=dict(arrowstyle="->", color=ACCENT2, lw=1))
    ax.annotate(f"p={min(p,q)}", (min(p, q), 1.04), color=ACCENT, fontsize=9, ha="center")
    ax.annotate(f"q={max(p,q)}", (max(p, q), 1.04), color=ACCENT, fontsize=9, ha="center")
    ax.set_xlim(N, 1)                         # reversed axis = travel N → 1
    ax.set_ylim(0, 1.2)
    ax.set_xlabel("k   (travelling N → 1, i.e. right→left)", color=FG)
    ax.set_title(title, color=FG, fontsize=12)
    _grid(ax)


def plot_fold(ax, pairs):
    """d ↔ N/d reflection about √N — the algebraic reason the test is reversible."""
    for i, (p, q) in enumerate(pairs):
        N = p * q
        lo, hi = min(p, q), max(p, q)
        y = i + 1
        ax.plot([np.log10(lo), np.log10(hi)], [y, y], color=ACCENT2, lw=2, zorder=2)
        ax.scatter([np.log10(np.sqrt(N))], [y], marker="|", s=200, c=FG, zorder=3)
        for v, lab, col in [(lo, f"p={lo}", ACCENT), (hi, f"q={hi}", ACCENT)]:
            ax.scatter([np.log10(v)], [y], s=70, c=col, edgecolors=FG,
                       linewidths=0.5, zorder=4)
        ax.annotate(f"N={N}", (np.log10(np.sqrt(N)), y + 0.18), color=FG,
                    fontsize=8, ha="center")
    ax.set_xlabel("log₁₀(value)   —   √N marked '|'", color=FG)
    ax.set_ylim(0.4, len(pairs) + 0.8)
    ax.set_yticks([])
    ax.set_title("forward factor p  ↔  reverse factor q = N/p   (fold about √N)",
                 color=FG, fontsize=12)
    _grid(ax)


def plot_cost(ax, balanced):
    bits = [(p * q).bit_length() for p, q in balanced]
    fwd = [evals_to_first_factor_forward(p, q) for p, q in balanced]
    rev = [evals_to_first_factor_reverse(p, q) for p, q in balanced]
    ax.plot(bits, np.log10(fwd), "o-", color=ACCENT, lw=1.6,
            label="forward scan  (~√N)")
    ax.plot(bits, np.log10(rev), "s-", color=ACCENT2, lw=1.6,
            label="reverse scan  (~N)")
    # straight lines ⇒ exponential in bit-length
    ax.plot(bits, [b * 0.5 * np.log10(2) for b in bits], "--", color=GRID, lw=1,
            label="½·bits·log2  (√N guide)")
    ax.set_xlabel("bit-length of N", color=FG)
    ax.set_ylabel("log₁₀(evaluations to first factor)", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="upper left")
    ax.set_title("cost is a STRAIGHT line in bit-length ⇒ exponential ⇒ NOT polynomial",
                 color=FG, fontsize=11)
    _grid(ax)


def plot_timing(ax, timed):
    Ns = [N for N, _ in timed]
    ts = [t for _, t in timed]
    ax.loglog(Ns, ts, "o-", color=ACCENT, lw=1.6, label="measured wall-clock")
    # √N reference, anchored at the first point
    ref = [ts[0] * np.sqrt(N / Ns[0]) for N in Ns]
    ax.loglog(Ns, ref, "--", color=GRID, lw=1, label="√N reference")
    ax.set_xlabel("N", color=FG)
    ax.set_ylabel("seconds to first factor", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="upper left")
    ax.set_title("measured cost tracks √N  (balanced semiprimes, the hard case)",
                 color=FG, fontsize=12)
    _grid(ax)


def plot_verdict(ax):
    ax.axis("off")
    lines = [
        ("REVERSE TEST — settled", ACCENT, 13),
        ("", FG, 6),
        ("Reversible?   YES.", ACCENT, 12),
        ("  Detector D(k)=[k|N] is a property of N, not of travel", FG, 10),
        ("  direction. Spikes are the same divisors; forward meets", FG, 10),
        ("  p first, reverse meets q=N/p first. Mirror about √N.", FG, 10),
        ("", FG, 6),
        ("Polynomial?   NO.", "#ff6b6b", 12),
        ("  Forward scan ~√N, reverse scan ~N — both exponential", FG, 10),
        ("  in bit-length. Reversing is no shortcut (it's worse).", FG, 10),
        ("", FG, 6),
        ("The deep part you spotted:", ACCENT2, 11),
        ("  this roots-of-unity / Fourier view of divisibility IS", FG, 10),
        ("  what makes factoring polynomial — but only with a", FG, 10),
        ("  QUANTUM Fourier transform (Shor 1994). Classically", FG, 10),
        ("  you pay the exponential scan. RSA safe on classical HW.", FG, 10),
    ]
    y = 0.96
    for text, col, sz in lines:
        ax.text(0.0, y, text, color=col, fontsize=sz, va="top", transform=ax.transAxes)
        y -= 0.058 if text else 0.030


# --------------------------------------------------------------------------
def main():
    # legible (spread) examples for the spectra; balanced (hard) for the cost
    Na = (7, 1493)        # N = 10451
    Nb = (13, 4099)       # N = 53287  (slightly larger primes)
    balanced = [(11, 13), (101, 103), (1009, 1013), (10007, 10009),
                (100003, 100019), (1000003, 1000033), (10000019, 10000169)]

    print("=" * 72)
    print(" REVERSE TEST: start at N, drive to 1")
    print("=" * 72)
    for (p, q) in (Na, Nb):
        N = p * q
        up = spikes(N)                      # forward encounter order (ascending)
        down = list(reversed(up))           # reverse encounter order (descending)
        # spot-check the real roots-of-unity sum agrees with the indicator at the factors
        chk = all(abs(ru_detector_stable(N, d) - 1.0) < 1e-9 for d in up)
        print(f"  N={N} = {p}×{q}")
        print(f"    forward (1→N) spikes : {up}   (meets p={min(p,q)} first)")
        print(f"    reverse (N→1) spikes : {down}   (meets q={max(p,q)} first)")
        print(f"    same set both ways? {set(up) == set(down)};  "
              f"roots-of-unity sum = k at every factor? {chk}")

    print("\n  COST (is it polynomial?)")
    print(f"  {'N':>16} {'bits':>5} {'fwd evals(~√N)':>16} {'rev evals(~N)':>16}")
    for p, q in balanced:
        N = p * q
        print(f"  {N:>16} {N.bit_length():>5} "
              f"{evals_to_first_factor_forward(p, q):>16} "
              f"{evals_to_first_factor_reverse(p, q):>16}")

    # measured timing: real modulo-scan to first factor (balanced => worst case)
    timed = []
    for p, q in balanced[1:6]:              # skip tiny; stop before it gets slow
        N = p * q
        t0 = time.perf_counter()
        k = 2
        while N % k:
            k += 1
        timed.append((N, time.perf_counter() - t0))
    print("\n  measured time to first factor:")
    for N, t in timed:
        print(f"    N={N:>16}  {t*1e3:8.2f} ms")
    print("  => grows ~√N: exponential in the number of digits. NOT polynomial.")

    # ---- figure ----
    fig = plt.figure(figsize=(17, 10))
    fig.suptitle("Reverse the test (N → 1): reversible YES, polynomial NO",
                 color=FG, fontsize=15, y=0.98)
    plot_reverse_spectrum(fig.add_subplot(2, 3, 1), *Na,
                          f"1 · reverse projection of {Na[0]}×{Na[1]} = {Na[0]*Na[1]}")
    plot_reverse_spectrum(fig.add_subplot(2, 3, 2), *Nb,
                          f"2 · reverse projection of {Nb[0]}×{Nb[1]} = {Nb[0]*Nb[1]} "
                          f"(larger primes)")
    plot_fold(fig.add_subplot(2, 3, 3), [Na, Nb])
    plot_cost(fig.add_subplot(2, 3, 4), balanced)
    plot_timing(fig.add_subplot(2, 3, 5), timed)
    plot_verdict(fig.add_subplot(2, 3, 6))

    fig.subplots_adjust(left=0.05, right=0.97, top=0.91, bottom=0.08,
                        hspace=0.32, wspace=0.24)
    save_fig(fig, "58_hsln_reverse_factor.png")


if __name__ == "__main__":
    main()
