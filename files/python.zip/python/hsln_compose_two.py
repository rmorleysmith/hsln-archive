"""hsln_compose_two.py — JOINTLY train two HSLN models F_a, F_b so that their
COMPOSITION (DNA convolution) spikes at pos(N) for the 309-digit N.

This is the most interesting "compose two to make N" experiment: each component
F_a, F_b is a free HSLN model; only their CONVOLUTION is constrained, via the
shared spike-loss against pos(N). The optimiser is free to distribute zeros
between F_a and F_b however gives the lowest composed-spike loss.

Then inspect:
  • DNA of F_a
  • DNA of F_b
  • DNA of F_a ⊗ F_b   (composition by convolution)
  • zeros of each — where did F_a's neurons land? F_b's? the composition's?
  • on-lane zeros of EACH component → candidate factor positions
  • full sweep over each candidate position
"""

from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import jax
import jax.numpy as jnp
from jax import value_and_grad
import numpy as np
import mpmath as mp
import matplotlib.pyplot as plt
import matplotlib as mpl

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import modular
import hsln_factor_dna as hfd

jax.config.update("jax_enable_x64", True)
mpl.rcParams.update({'figure.facecolor':'white','axes.facecolor':'white'})

N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)
LANE_Y = hsln.LANE_Y


def cand_at(alpha, k):
    mp.mp.dps = max(60, int(k * 0.302) + 50)
    return int(mp.nint(mp.power(2, mp.mpf(k) + mp.mpf(alpha))))


def q_to_pos(q_root: complex):
    re = (math.atan2(q_root.imag, q_root.real) / (2 * math.pi)) % 1.0
    im = -math.log(abs(q_root)) / (2 * math.pi)
    return re, im


def composed_spike_map(dna_a, dna_b, xs):
    """Convolve two DNAs in JAX (Cauchy product), then evaluate spike map."""
    composed = jnp.convolve(dna_a, dna_b)
    return hsln.spike_map(composed, xs)


def joint_train(dg_a: int, dg_b: int, target: jnp.ndarray, *,
                steps: int = 5000, lr: float = 0.01, seed: int = 0):
    """Jointly train F_a (dg_a) and F_b (dg_b) so composed spike map matches target."""

    def unpack(p):
        sa = 2 * dg_a
        pa = p[:sa]
        pb = p[sa:]
        dna_a = pa[:dg_a] + 1j * pa[dg_a:]
        dna_b = pb[:dg_b] + 1j * pb[dg_b:]
        return dna_a, dna_b

    def loss(p):
        dna_a, dna_b = unpack(p)
        spikes = composed_spike_map(dna_a, dna_b, hsln.PROBES)
        spike_err = jnp.sum((spikes - target) ** 2)
        reg = 1e-4 * jnp.sum(p ** 2)
        return spike_err + reg

    lg = jax.jit(value_and_grad(loss))

    rng = np.random.default_rng(seed)
    # Initialise each component HSLN-style (central zeros + jitter)
    def init_one(dg, sub_seed):
        s_rng = np.random.default_rng(sub_seed)
        zeros = np.array([0.5 + (LANE_Y + 0.04 * k) * 1j for k in range(dg - 1)])
        c = np.poly(np.exp(2j * np.pi * zeros))[::-1]
        c = c / np.max(np.abs(c))
        return np.concatenate([c.real, c.imag]) + 0.04 * s_rng.standard_normal(2 * dg)
    p = jnp.array(np.concatenate([init_one(dg_a, seed), init_one(dg_b, seed + 100)]))

    m = jnp.zeros_like(p); v = jnp.zeros_like(p)
    b1, b2, eps = 0.9, 0.999, 1e-8
    hist = []
    for t in range(1, steps + 1):
        L, g = lg(p)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        p = p - lr * (m / (1 - b1 ** t)) / (jnp.sqrt(v / (1 - b2 ** t)) + eps)
        hist.append(float(L))
    dna_a, dna_b = unpack(p)
    return np.asarray(dna_a), np.asarray(dna_b), hist


def main():
    mp.mp.dps = 1100
    pos_N = float(mp.log(N, 2) - mp.floor(mp.log(N, 2)))
    print(f'N is {N.bit_length()}-bit;  pos(N) = {pos_N:.10f}')

    probes = np.array(hsln.PROBES)
    probe_idx = hfd.closest_probe(pos_N)
    target = np.zeros_like(probes, dtype=float)
    target[probe_idx] = 1.0
    target_j = jnp.asarray(target)
    print(f'Target: one-hot at probe {probe_idx} ({float(probes[probe_idx]):.4f})\n')

    # Try several (dg_a, dg_b) shapes
    configs = [(2, 2), (3, 3), (2, 4), (4, 4), (3, 6)]

    fig, axes = plt.subplots(2, len(configs), figsize=(5*len(configs), 9),
                             gridspec_kw={'height_ratios':[1, 1.2]})

    summary = []
    for col, (dg_a, dg_b) in enumerate(configs):
        print('━' * 78)
        print(f'  CONFIG  dg_a = {dg_a},  dg_b = {dg_b}   '
              f'(composition has degree {dg_a + dg_b - 1 - 1} = {dg_a + dg_b - 2} zeros)')
        print('━' * 78)
        dna_a, dna_b, hist = joint_train(dg_a, dg_b, target_j, steps=5000, seed=0)
        composed = np.convolve(dna_a, dna_b)

        # DNA tables
        for label, dna in [('F_a', dna_a), ('F_b', dna_b), ('F_a ⊗ F_b', composed)]:
            print(f'\n  {label}  DNA (length {len(dna)}):')
            for n, a in enumerate(dna):
                marker = '  ←' if abs(a) > 0.2 else ''
                print(f'    {n:2d} | {a.real:+.5f} {a.imag:+.5f}j   |a|={abs(a):.4f}{marker}')

        # Zeros and on-lane positions of EACH component
        def lane_positions(dna):
            if len(dna) < 2: return []
            roots = np.roots(np.asarray(dna)[::-1])
            on_lane = []
            for qr in roots:
                re, im = q_to_pos(qr)
                if abs(im - LANE_Y) < 0.04:
                    on_lane.append(re)
            return on_lane, roots

        on_a, roots_a = lane_positions(dna_a)
        on_b, roots_b = lane_positions(dna_b)
        on_c, roots_c = lane_positions(composed)
        print(f'\n  F_a:        {len(roots_a)} roots, {len(on_a)} on-lane:  '
              f'{[f"{p:.4f}" for p in on_a]}')
        print(f'  F_b:        {len(roots_b)} roots, {len(on_b)} on-lane:  '
              f'{[f"{p:.4f}" for p in on_b]}')
        print(f'  F_a ⊗ F_b:  {len(roots_c)} roots, {len(on_c)} on-lane:  '
              f'{[f"{p:.4f}" for p in on_c]}')

        # Pair sums
        all_a = [q_to_pos(r)[0] for r in roots_a]
        all_b = [q_to_pos(r)[0] for r in roots_b]
        print(f'\n  Pair-sums (α_i in F_a, α_j in F_b)  vs  pos(N):')
        good_pairs = []
        for i, ai in enumerate(all_a):
            for j, bj in enumerate(all_b):
                s = (ai + bj) % 1.0
                err = min(abs(s - pos_N), 1 - abs(s - pos_N))
                tag = '  ★' if err < 0.01 else ''
                if err < 0.05:
                    good_pairs.append((ai, bj, s, err))
                if err < 0.05:
                    print(f'    ({i},{j})  α_a={ai:.4f} + α_b={bj:.4f} = {s:.4f}   err={err:.4f}{tag}')

        # Sweep all candidate positions
        cand_positions = sorted(set([round(p, 8) for p in on_a + on_b + all_a + all_b]))
        nb = N.bit_length()
        K_LO = max(2, nb // 2 - 50)
        K_HI = nb - 1
        print(f'\n  Sweeping {len(cand_positions)} positions × k ∈ [{K_LO}..{K_HI}] × wiggle ±8 ...')
        hits = []
        tried = 0
        t0 = time.perf_counter()
        for alpha in cand_positions:
            for k in range(K_LO, K_HI + 1):
                c0 = cand_at(alpha, k)
                for di in range(-8, 9):
                    c = c0 + di
                    if c <= 1 or c >= N: continue
                    tried += 1
                    if N % c == 0:
                        hits.append((alpha, k, c, N // c))
                        print(f'    ✓ HIT  α={alpha:.6f}  k={k}  di={di}  '
                              f'factor={c}')

        # Pair-sweep: if (cand_a from α_a, cand_b from α_b) and cand_a * cand_b == N
        # this is the "found factorization" check
        pair_hits = []
        for ai, bj, s, err in good_pairs:
            for ka in range(K_LO, K_HI + 1):
                ca0 = cand_at(ai, ka)
                kb = nb - ka  # bit budget: ka + kb ≈ nb-1 since pos sums approx
                if kb < 2 or kb > nb - 1: continue
                cb0 = cand_at(bj, kb)
                for da in range(-8, 9):
                    for db in range(-8, 9):
                        ca = ca0 + da
                        cb = cb0 + db
                        if ca <= 1 or cb <= 1: continue
                        if ca * cb == N:
                            pair_hits.append((ai, bj, ka, kb, ca, cb))
                            print(f'    ✓✓ PAIR HIT  α_a={ai:.4f}  α_b={bj:.4f}  '
                                  f'k_a={ka}  k_b={kb}  → {ca} × {cb} = N')

        print(f'  {tried} positional candidates in {time.perf_counter()-t0:.1f}s')
        print(f'  hits: {len(hits)} positional, {len(pair_hits)} paired')

        summary.append({
            'dg_a': dg_a, 'dg_b': dg_b,
            'loss': hist[-1],
            'on_a': on_a, 'on_b': on_b, 'on_c': on_c,
            'good_pairs': good_pairs,
            'hits': hits, 'pair_hits': pair_hits,
        })

        # Plot
        ax = axes[0, col]
        ax.semilogy(hist, color='#1f77b4', linewidth=1.2)
        ax.set_xlabel('step'); ax.set_ylabel('loss')
        ax.set_title(f'dg_a={dg_a}, dg_b={dg_b}\nfinal loss {hist[-1]:.4f}')
        ax.grid(alpha=0.3, which='both')

        ax = axes[1, col]
        for q in roots_a:
            re, im = q_to_pos(q)
            ax.scatter(re, im, s=110, c='#1f77b4', alpha=0.8,
                       edgecolor='black', linewidth=0.4, label='F_a' if q is roots_a[0] else None)
        for q in roots_b:
            re, im = q_to_pos(q)
            ax.scatter(re, im, s=110, c='#ff7f0e', alpha=0.8,
                       edgecolor='black', linewidth=0.4, label='F_b' if q is roots_b[0] else None)
        ax.axhline(LANE_Y, color='cyan', linestyle='--', linewidth=0.7, alpha=0.6)
        ax.axvline(pos_N, color='red', linewidth=1.2, alpha=0.7,
                   label=f'pos(N)={pos_N:.3f}')
        ax.set_xlim(0, 1); ax.set_ylim(0, 0.5)
        ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
        ax.set_title(f'on-lane: F_a={len(on_a)}  F_b={len(on_b)}  comp={len(on_c)}')
        ax.legend(loc='upper right', fontsize=8)
        ax.grid(alpha=0.3)

    fig.suptitle(f'Joint training of (F_a, F_b) such that conv(F_a, F_b) spikes at pos(N)\n'
                 f'N has {N.bit_length()} bits', fontsize=13)
    out = HERE / 'figures' / '54_hsln_compose_two.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'\n  ✓ figure: {out.name}')

    print(f'\n{"="*78}\n SUMMARY\n{"="*78}')
    print(f' (dg_a, dg_b) | loss   | on-lane (a/b/comp) | pair-sum hits | factor pairs')
    print(f' -------------+--------+--------------------+---------------+--------------')
    for s in summary:
        print(f'  ({s["dg_a"]},{s["dg_b"]})      | {s["loss"]:.4f} | {len(s["on_a"])}/{len(s["on_b"])}/{len(s["on_c"])}              |     {len(s["good_pairs"]):2d}        |     {len(s["pair_hits"])}')


if __name__ == '__main__':
    main()
