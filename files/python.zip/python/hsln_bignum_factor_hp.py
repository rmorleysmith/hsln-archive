"""hsln_bignum_factor_hp.py — Same task, but at HIGH PRECISION end-to-end.

Three precision lifts vs the float64 version:

  1. pos(N)  computed at 1100 mpmath digits (was 16 float digits).
  2. F_N built analytically — single atomic zero EXACTLY at τ = pos(N) + i·LANE_Y.
     No probe snapping, no Adam training, no encoding error.
  3. Candidate prime  cand_k = nearest_int(2^(k + pos(N)))  at enough mp precision
     that the integer is exact (≥ k·0.302 + 40 digits).

Then we do two things:

  A. Re-validate the encoding: at k = n_bits − 1, the inverse must reconstruct N exactly.
  B. Sweep k ∈ [1, n_bits−1] testing each candidate against N.
  C. Repeat the entire procedure on a smaller 60-bit semiprime so we can SEE the
     precision lift actually working when the candidate-prime gap is large enough
     to be resolved by an integer round.
"""

from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import numpy as np
import mpmath as mp

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
from factor_prime_pair import is_prime

LANE_Y = hsln.LANE_Y


N_BIG = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)


# ───────────────────────────────────────────────────────────────────────────────
#  HIGH-PRECISION  pos, encoding inverse, and analytic single-zero DNA
# ───────────────────────────────────────────────────────────────────────────────

def pos_hp(n: int, dps: int = 1100) -> mp.mpf:
    mp.mp.dps = dps
    L = mp.log(n, 2)
    return L - mp.floor(L)


def cand_at(alpha_mp: mp.mpf, k: int) -> int:
    """nearest_int(2^(k + α)) computed exactly."""
    mp.mp.dps = max(60, int(k * 0.302) + 50)
    return int(mp.nint(mp.power(2, mp.mpf(k) + alpha_mp)))


def atomic_dna_hp(pos_mp: mp.mpf, lane_y: float = LANE_Y):
    """Length-2 DNA in mpmath:  F(τ) = (q − q_pos),   q_pos = e^{2πi·pos}·e^{−2π·lane_y}."""
    two_pi = 2 * mp.pi
    q_pos = mp.exp(mp.mpc(0, two_pi * pos_mp)) * mp.exp(-two_pi * lane_y)
    return [-q_pos, mp.mpc(1, 0)]


def eval_qpoly_hp(dna_mp, tau):
    s = mp.mpc(0)
    q = mp.exp(mp.mpc(0, 2 * mp.pi * tau.real) - 2 * mp.pi * tau.imag)
    qk = mp.mpc(1)
    for a in dna_mp:
        s += a * qk
        qk *= q
    return s


# ───────────────────────────────────────────────────────────────────────────────
#  Sweep
# ───────────────────────────────────────────────────────────────────────────────

def sweep_factor(pos_mp: mp.mpf, N: int, k_lo: int, k_hi: int,
                 wiggle_int: int = 6, partner_pos_mp: mp.mpf | None = None):
    """Try cand = nearest_int(2^(k+α)) + di  for every k in [k_lo, k_hi]
    and di in [-wiggle_int, wiggle_int]. If partner_pos_mp given, also try the
    partner position pos(N) − α.

    Returns list of (k, cand, cofactor).
    """
    hits = []
    t0 = time.perf_counter()
    tried = 0
    positions = [pos_mp]
    if partner_pos_mp is not None:
        positions.append(partner_pos_mp)
    for alpha in positions:
        for k in range(k_lo, k_hi + 1):
            c0 = cand_at(alpha, k)
            for di in range(-wiggle_int, wiggle_int + 1):
                c = c0 + di
                if c <= 1 or c >= N:
                    continue
                tried += 1
                if N % c == 0:
                    hits.append((k, c, N // c))
                    print(f'   ✓ FACTOR FOUND   k={k}  di={di}  '
                          f'factor={c} ({c.bit_length()} bits)')
    elapsed = time.perf_counter() - t0
    return hits, tried, elapsed


def run_one(N: int, label: str, k_margin: int = 200):
    print('\n' + '=' * 78)
    print(f'  {label}')
    print('=' * 78)
    nb = N.bit_length()
    print(f'  N has {len(str(N))} digits, {nb} bits.')

    # High-precision position
    pos_mp = pos_hp(N)
    pos_float = float(pos_mp)
    print(f'  pos(N) [1100-digit mp] head = {mp.nstr(pos_mp, 40)}')
    print(f'  pos(N) [float64]          = {pos_float!r}  ({len(str(pos_float)) - 2} digits)')

    # Sanity: round(2^(nb-1 + pos)) = N
    mp.mp.dps = max(60, int(nb * 0.302) + 50)
    rec = int(mp.nint(mp.power(2, mp.mpf(nb - 1) + pos_mp)))
    print(f'  Inverse-encoding sanity:  round(2^({nb-1} + pos(N))) == N  →  {rec == N}')

    # Analytic DNA (no training noise)
    dna_mp = atomic_dna_hp(pos_mp)
    # confirm it's zero at τ = pos + i·LANE_Y to high precision
    tau_target = mp.mpc(float(pos_mp), LANE_Y)
    F_at_target = eval_qpoly_hp(dna_mp, tau_target)
    print(f'  Analytic F_N(τ_target) at LANE_Y → |F| = {float(abs(F_at_target)):.3e}')

    # Sweep
    k_lo = max(2, nb // 2 - k_margin)
    k_hi = nb - 1
    print(f'\n  Sweeping k ∈ [{k_lo}..{k_hi}]   (balanced semiprime → k ≈ {nb//2})')

    print(f'\n  ── α = pos(N) directly ──')
    hits1, t1, sec1 = sweep_factor(pos_mp, N, k_lo, k_hi, wiggle_int=6)
    print(f'   {t1} candidates  in  {sec1:.2f}s  → {len(hits1)} hits')

    print(f'\n  ── α = pos(N), partner = pos(N) − α (= 0 here, trivially)  '
          f'— skipped (same α) ──')

    return pos_mp, hits1


def main():
    print('=' * 78)
    print('  HSLN factor recovery at HIGH PRECISION')
    print('=' * 78)

    # ── First: a known small semiprime to validate the recovery procedure ───
    # 60-bit semiprime so the candidate-prime gap is ≥ 1 — we should find it.
    # Same pair as hsln_factor_dna.py used: p ≈ 2^20 · 1.94 (pos≈0.954),
    # q ≈ 2^20 · 1.23 (pos≈0.299).
    p_small = 2029073   # 21-bit prime, pos ≈ 0.9524
    q_small = 1265981   # 21-bit prime, pos ≈ 0.2718
    N_small = p_small * q_small
    assert is_prime(p_small) and is_prime(q_small)
    print(f'\n  Validation case: N_small = {p_small} × {q_small} = {N_small}'
          f'  ({N_small.bit_length()} bits)')
    pos_small, hits_small = run_one(N_small,
                                    f'Validation: 42-bit semiprime',
                                    k_margin=15)
    if hits_small:
        print(f'\n  ✓ Validation: factor recovered. Wait — but pos(N) ≠ pos(p),'
              f' so why?')
        for k, c, cof in hits_small:
            print(f'      k={k}  c={c}  cof={cof}  '
                  f'(c·cof = N? {c*cof==N_small})')
    else:
        print(f'\n  ✗ Validation: pos(N) does NOT recover a factor — '
              f'as expected (pos(N) ≠ pos(p) in general).')

    # Now try with α = pos(p_small) — the "oracle" run: we feed the model the
    # CORRECT factor position. Recovery must succeed if the encoding is lossless
    # at this scale.
    print('\n' + '=' * 78)
    print('  Oracle run: feed the CORRECT pos(p_small) into the recovery sweep')
    print('=' * 78)
    pos_p_small = pos_hp(p_small)
    print(f'  pos(p_small) [mp] = {mp.nstr(pos_p_small, 40)}')
    print(f'  pos(p_small) [f64] = {float(pos_p_small)!r}')
    hits_oracle, tried_oracle, sec_oracle = sweep_factor(
        pos_p_small, N_small,
        k_lo=max(2, p_small.bit_length() - 5),
        k_hi=p_small.bit_length() + 5,
        wiggle_int=10)
    if hits_oracle:
        print(f'  ✓ Oracle finds factor: {hits_oracle}')
    else:
        print(f'  ✗ Oracle fails even at high precision — encoding gap is too big.')

    # ── The big one ──────────────────────────────────────────────────────────
    pos_big, hits_big = run_one(N_BIG, 'The 309-digit number you gave me',
                                k_margin=200)

    # ── Summary ──────────────────────────────────────────────────────────────
    print('\n' + '=' * 78)
    print('  Summary')
    print('=' * 78)

    print('\n  Validation (42-bit):')
    print(f'    α = pos(N_small)             → {len(hits_small)} hit(s)')
    print(f'    α = pos(p_small) [oracle]    → {len(hits_oracle)} hit(s)')

    print('\n  Big (1024-bit):')
    print(f'    α = pos(N_big)               → {len(hits_big)} hit(s)')
    print(f'    [no oracle available — we don\'t know pos(p_big)]')


if __name__ == '__main__':
    main()
