"""Cost benchmark. Run `uv run python bench.py`."""
from __future__ import annotations

import time

import numpy as np

import dna
import e8
import geom
import modular
import render
import siegel


def _timeit(f, *a, n=1, **k):
    f(*a, **k)  # warm up
    t0 = time.perf_counter()
    for _ in range(n):
        r = f(*a, **k)
    return (time.perf_counter() - t0) / n, r


def neuron_set(d):
    """d distinct neurons inside the q-disk (Im in [0.2, 0.7])."""
    rng = np.random.default_rng(d)
    re = rng.uniform(0.02, 0.98, d)
    im = rng.uniform(0.20, 0.70, d)
    return re + 1j * im


print("=" * 64)
print("NEURON COUNT vs COST")
print("=" * 64)

print("\n1) Designing a DNA with d neurons, then recovering them (np.roots ~ O(d^3)):")
for d in (10, 100, 1000):
    taus = neuron_set(d)
    c = dna.dna_from_neurons(taus)
    dt_find, z = _timeit(modular.qpoly_zeros, c, n=3)
    dt_make, _ = _timeit(dna.dna_from_neurons, taus, n=3)
    print(f"   d={d:5d}:  build DNA {dt_make*1e3:7.2f} ms   "
          f"find {len(z):5d} neurons {dt_find*1e3:8.2f} ms")

print("\n2) The CHEAP viz (neurons + paths): integrate 1000 paths x 700 steps:")
seeds = neuron_set(1000) * 0 + (
    np.random.default_rng(7).uniform(0.03, 0.97, 1000)
    + 1j * np.random.default_rng(8).uniform(0.10, 0.80, 1000)
)
for d in (10, 100):
    c = dna.dna_from_neurons(neuron_set(d))
    dt_paths, _ = _timeit(render.integrate_paths, c, seeds, n=1)
    print(f"   d={d:4d} coeffs:  {dt_paths*1e3:7.1f} ms")

print("\n3) For contrast: the EXPENSIVE bit we removed (dense grid + coloring):")
TAU, _ = geom.half_plane_grid((-2, 2), (0.05, 2.3), 1500)
dt_e4, F = _timeit(modular.e4, TAU, n=1)
import coloring  # noqa: E402
dt_col, _ = _timeit(coloring.domain_color, F, n=1)
print(f"   E4 on 1500^2 grid: {dt_e4*1e3:6.0f} ms   +  domain_color: {dt_col*1e3:5.0f} ms")

print("\n" + "=" * 64)
print("GENUS-2 PRECOMPUTE (the one quadratic cost), O(N_vec^2)")
print("=" * 64)
for m in (6, 8):
    nvec = e8.e8_vectors(float(m)).shape[0]
    dt_rep, dct = _timeit(siegel.representation_numbers, m, n=1)
    print(f"   norm<= {m}:  {nvec:6d} E8 vectors  ->  {len(dct):4d} Fourier terms  "
          f"in {dt_rep:6.2f} s")
print("(one-time precompute; evaluating Theta^(2) on a grid afterwards is cheap)")
