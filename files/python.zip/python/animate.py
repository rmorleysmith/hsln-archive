"""Animations. Run `uv run python animate.py <name|all>` (needs ffmpeg).

genus2  : sweep the off-diagonal coupling z around a loop in C, animating
          Theta^(2)_{E8} on the slice Z = [[tau, z],[z, tau]] -- a 1-parameter
          tour through the 3-complex-dim Siegel upper half-space H_2.
flow    : release particles into the genus-1 reservoir and watch them fall into
          the neurons (zeros) of a trained DNA.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FFMpegWriter, FuncAnimation

import coloring
import dna
import geom
import modular
import siegel
import style

FIGDIR = Path(__file__).parent / "figures"


def genus2(frames=96, res=420, fps=20):
    dct = siegel.representation_numbers(maxn=6)
    TAU, ext = geom.half_plane_grid((-0.6, 0.6), (0.45, 1.45), res)
    tau_flat = TAU.ravel()

    # Theta^(2)(diag tau,tau; off-diag z) = sum_T r_T e^{i pi (a+c) tau} e^{i 2 pi b z}.
    # Precompute the tau-dependent part per term; only the scalar e^{i2pi b z} changes.
    terms = list(dct.items())
    P = np.empty((len(terms), tau_flat.size), dtype=np.complex128)
    bs = np.empty(len(terms))
    for i, ((a, b, c), r) in enumerate(terms):
        P[i] = r * np.exp(1j * np.pi * (a + c) * tau_flat)
        bs[i] = b

    fig, ax = plt.subplots(figsize=(6.2, 6.2))
    img = ax.imshow(np.zeros((res, res, 3)), extent=ext, origin="upper",
                    interpolation="none", aspect="auto")
    ax.set_xlabel(r"Re $\tau$"); ax.set_ylabel(r"Im $\tau$")
    ttl = ax.set_title("")

    def update(k):
        z = 0.45 * np.exp(2j * np.pi * k / frames)
        w = np.exp(1j * 2 * np.pi * bs * z)
        F = (w @ P).reshape(TAU.shape)
        img.set_data(coloring.domain_color(F, cmap="twilight"))
        ttl.set_text(r"$\Theta^{(2)}_{E8}$ on $Z=[[\tau,z],[z,\tau]]$,  "
                     f"$z={z.real:+.2f}{z.imag:+.2f}i$")
        return [img, ttl]

    anim = FuncAnimation(fig, update, frames=frames, blit=False)
    out = FIGDIR / "anim_genus2_coupling.mp4"
    anim.save(out, writer=FFMpegWriter(fps=fps, bitrate=4500), dpi=110)
    plt.close(fig)
    print(f"wrote {out}")


def flow(fps=24, n_neurons=3):
    """Cheap: precompute paths once, animate dots flowing along them into neurons."""
    import render

    if n_neurons == 3:
        neurons = np.array([0.30 + 0.46j, 0.68 + 0.52j, 0.50 + 0.27j])
        coeffs = dna.dna_from_neurons(neurons, lead=40.0)
    else:
        gx, gy = np.meshgrid(np.linspace(0.16, 0.84, 4), np.linspace(0.30, 0.66, 3))
        neurons = (gx + 1j * gy).ravel()
        coeffs = dna.dna_from_neurons(neurons, lead=1.0)

    re_lim, im_lim = (0.0, 1.0), (0.05, 0.90)
    xs = np.linspace(0.02, 0.98, 46)
    ys = np.linspace(0.08, 0.88, 30)
    SX, SY = np.meshgrid(xs, ys)
    seeds = (SX + 1j * SY).ravel()

    n_steps = 700
    hist = render.integrate_paths(coeffs, seeds, neurons=neurons, n_steps=n_steps,
                                  im_floor=im_lim[0])
    ends = hist[-1, 0] + 1j * hist[-1, 1]
    dist = np.abs(ends[:, None] - neurons[None, :])
    nearest = np.argmin(dist, axis=1)
    captured = dist[np.arange(ends.size), nearest] < 0.05
    pal = render.basin_palette(len(neurons))

    fig, ax = plt.subplots(figsize=(7.0, 6.2))
    ax.set_facecolor("#07070d")
    for p in range(seeds.size):  # static path bundles (drawn once)
        col = pal[nearest[p]] if captured[p] else (0.5, 0.5, 0.55, 0.18)
        ax.plot(hist[:, 0, p], hist[:, 1, p], color=col, lw=0.5, alpha=0.45)
    ax.plot(neurons.real, neurons.imag, "*", color="white", ms=20, mec="black",
            mew=0.8, zorder=8)
    dot_colors = np.array([pal[nearest[p]] if captured[p] else (0.7, 0.7, 0.75, 1)
                           for p in range(seeds.size)])
    scat = ax.scatter(hist[0, 0], hist[0, 1], s=14, c=dot_colors, edgecolor="white",
                      linewidth=0.2, zorder=9)
    ax.set_xlim(*re_lim); ax.set_ylim(*im_lim)
    ax.set_xlabel(r"Re $\tau$"); ax.set_ylabel(r"Im $\tau$")
    ax.set_title(r"Reservoir relaxation along $\dot\tau=-\alpha\,\nabla|F|^2$"
                 "\nparticles flow down the paths into the neurons (zeros)")

    step = 3  # show every 3rd integration step as one frame
    def update(k):
        i = min(k * step, n_steps)
        scat.set_offsets(np.column_stack([hist[i, 0], hist[i, 1]]))
        return [scat]

    anim = FuncAnimation(fig, update, frames=n_steps // step + 1, blit=False)
    out = FIGDIR / "anim_reservoir_flow.mp4"
    anim.save(out, writer=FFMpegWriter(fps=fps, bitrate=3500), dpi=110)
    plt.close(fig)
    print(f"wrote {out}")


def tweak(frames=120, fps=20):
    """Tweak one DNA coefficient and watch the neurons (roots) move in the q-disk.

    Shows the catch: the polynomial degree d caps the neuron count, and as you tweak,
    neurons cross |q|=1 (enter/leave the disk) and collide -- the count is not a free
    dial even though the coefficients are.
    """
    base = np.array([0.10 + 0.09j, 0.32 + 0.07j, 0.55 + 0.13j,
                     0.78 + 0.08j, 0.45 + 0.20j])  # near the |q|=1 edge
    c0 = dna.dna_from_neurons(base)
    d = c0.size - 1
    half = frames // 2
    ss = np.concatenate([np.linspace(-2.2, 2.2, half),
                         np.linspace(2.2, -2.2, frames - half)])
    all_roots = []
    for s in ss:
        c = c0.copy()
        c[0] = c0[0] * (10.0 ** s)
        all_roots.append(np.roots(c[::-1]))
    bg = np.concatenate(all_roots)

    fig, ax = plt.subplots(figsize=(6.6, 6.8))
    ax.set_facecolor("#07070d")
    th = np.linspace(0, 2 * np.pi, 400)
    ax.plot(np.cos(th), np.sin(th), color="white", lw=1.3, alpha=0.75)
    ax.scatter(bg.real, bg.imag, s=3, color=(0.55, 0.55, 0.62), alpha=0.12, zorder=2)
    ax.plot(0, 0, "+", color="#888", ms=9)
    sc_in = ax.scatter([], [], s=90, color="#46f0d0", edgecolor="white", lw=0.6, zorder=5)
    sc_out = ax.scatter([], [], s=45, color="#777", edgecolor="none", zorder=4)
    txt = ax.text(-1.38, -1.34, "", color="white", fontsize=11)
    ax.set_xlim(-1.45, 1.45); ax.set_ylim(-1.45, 1.45); ax.set_aspect("equal")
    ax.set_xlabel("Re q"); ax.set_ylabel("Im q")
    ax.set_title(rf"degree-{d} DNA · tweaking one coefficient" "\n"
                 r"inside |q|<1 = neuron · outside = gone (Im $\tau\leq0$)", fontsize=12)

    def update(k):
        r = all_roots[k]
        inside = np.abs(r) < 1.0
        sc_in.set_offsets(np.column_stack([r[inside].real, r[inside].imag]))
        sc_out.set_offsets(np.column_stack([r[~inside].real, r[~inside].imag]))
        txt.set_text(f"neurons (|q|<1): {int(inside.sum())} / {d} possible")
        return [sc_in, sc_out, txt]

    anim = FuncAnimation(fig, update, frames=len(all_roots), blit=False)
    out = FIGDIR / "anim_tweak_neurons.mp4"
    anim.save(out, writer=FFMpegWriter(fps=fps, bitrate=3000), dpi=110)
    plt.close(fig)
    print(f"wrote {out}")


def divisor_orbit(fps=24, frames=144):
    """Orbit the camera around the coupled genus-2 zero divisor curve."""
    import render
    import siegel as _siegel

    dct = _siegel.representation_numbers(maxn=8)
    ws = np.linspace(-1.0, 1.0, 240)
    P = render.genus2_divisor_points(dct, 0.35, ws, im_lo=0.5, im_hi=1.45)

    fig = plt.figure(figsize=(7, 7))
    ax = fig.add_subplot(111, projection="3d")
    ax.scatter(P[:, 0], P[:, 1], P[:, 2], c=P[:, 2], cmap="viridis", s=9)
    ax.set_xlim(-0.5, 0.5); ax.set_ylim(0.5, 1.1); ax.set_zlim(-1, 1)
    ax.set_xlabel(r"Re $\tau$"); ax.set_ylabel(r"Im $\tau$"); ax.set_zlabel("w")
    ax.set_title("Genus-2 zero divisor (coupled, z = 0.35) — the neuron is a curve")

    def update(k):
        ax.view_init(elev=18, azim=-62 + 360.0 * k / frames)
        return []

    anim = FuncAnimation(fig, update, frames=frames, blit=False)
    out = FIGDIR / "anim_divisor_orbit.mp4"
    anim.save(out, writer=FFMpegWriter(fps=fps, bitrate=3500), dpi=110)
    plt.close(fig)
    print(f"wrote {out}")


def gravity(frames=120, fps=20, res=480):
    """Freeze the state E8 form; dial the gravity E8 DNA; watch the product field respond.

    F_total = F_state * F_gravity  (the E8 x E8 theta). State zeros are fixed; the two
    gravity zeros orbit, and the combined energy landscape reshapes around them.
    """
    nS = np.array([0.25 + 0.52j, 0.52 + 0.66j, 0.76 + 0.46j, 0.40 + 0.30j])
    FS = dna.dna_from_neurons(nS)
    TAU, ext = geom.half_plane_grid((0.0, 1.0), (0.05, 0.9), res)

    def gravity_zeros(t):
        c = 0.5 + 0.46j
        return np.array([c + 0.20 * np.exp(2j * np.pi * t),
                         c + 0.20 * np.exp(2j * np.pi * (t + 0.5))])

    fig, ax = plt.subplots(figsize=(7.0, 6.4))
    img = ax.imshow(np.zeros((res, res, 3)), extent=ext, origin="upper",
                    interpolation="none", aspect="auto")
    st = ax.plot(nS.real, nS.imag, "*", color="#46f0d0", ms=17, mec="black", mew=0.7,
                 zorder=6, label="state zeros (frozen)")[0]
    gv = ax.scatter([], [], marker="*", s=240, color=style.ACCENT, edgecolor="black",
                    linewidth=0.7, zorder=7, label="gravity zeros (dial)")
    ax.set_xlim(0, 1); ax.set_ylim(0.05, 0.9)
    ax.set_xlabel(r"Re $\tau$"); ax.set_ylabel(r"Im $\tau$")
    ax.set_title(r"$E_8\times E_8$: dialing the gravity DNA reshapes the frozen state field"
                 "\n"
                 r"$F=F_{\rm state}\cdot F_{\rm gravity}$,  zeros = state $\cup$ gravity")
    ax.legend(loc="upper right", fontsize=8, framealpha=0.3)

    def update(k):
        nG = gravity_zeros(k / frames)
        FG = dna.dna_from_neurons(nG)
        F = modular.qpoly(np.convolve(FS, FG), TAU)
        img.set_data(coloring.domain_color(F, cmap="twilight"))
        gv.set_offsets(np.column_stack([nG.real, nG.imag]))
        return [img, gv]

    anim = FuncAnimation(fig, update, frames=frames, blit=False)
    out = FIGDIR / "anim_gravity_dial.mp4"
    anim.save(out, writer=FFMpegWriter(fps=fps, bitrate=4000), dpi=110)
    plt.close(fig)
    print(f"wrote {out}")


def gravity_divisor(fps=20, frames=110):
    """Wire the gravity dial into the genus-2 divisor: state curve frozen, gravity sector's
    coupling z_G dialed; the network's attractor set is the union of the two sector divisors."""
    import render
    import siegel as _siegel

    dct = _siegel.representation_numbers(maxn=8)
    ws = np.linspace(-1.0, 1.0, 200)
    state = render.genus2_divisor_points(dct, 0.35, ws, im_lo=0.5, im_hi=1.45)  # frozen
    zgs = 0.05 + 0.55 * (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(frames) / frames))

    fig = plt.figure(figsize=(7.4, 7.4))
    ax = fig.add_subplot(111, projection="3d")
    ax.scatter(state[:, 0], state[:, 1], state[:, 2], color="#46f0d0", s=8,
               label="state $E_8$  (coupling z = 0.35, frozen)")
    gsc = ax.scatter([], [], [], color=style.ACCENT, s=11,
                     label="gravity $E_8$  (coupling dialed)")
    ax.set_xlim(-0.5, 0.5); ax.set_ylim(0.5, 1.1); ax.set_zlim(-1, 1)
    ax.set_xlabel(r"Re $\tau$"); ax.set_ylabel(r"Im $\tau$"); ax.set_zlabel("w")
    ax.legend(loc="upper left", fontsize=9)
    ttl = ax.set_title("")

    def update(k):
        zg = zgs[k]
        g = render.genus2_divisor_points(dct, zg, ws, im_lo=0.5, im_hi=1.45)
        gsc._offsets3d = (g[:, 0], g[:, 1], g[:, 2])
        ax.view_init(elev=18, azim=-62 + 24 * np.sin(2 * np.pi * k / frames))
        ttl.set_text(r"$E_8\times E_8$ attractor divisor = state $\cup$ gravity"
                     f"   ·   gravity coupling z = {zg:.2f}")
        return [gsc]

    anim = FuncAnimation(fig, update, frames=frames, blit=False)
    out = FIGDIR / "anim_gravity_divisor.mp4"
    anim.save(out, writer=FFMpegWriter(fps=fps, bitrate=4000), dpi=110)
    plt.close(fig)
    print(f"wrote {out}")


ANIMS = {"genus2": genus2, "flow": flow, "tweak": tweak, "divisor_orbit": divisor_orbit,
         "gravity": gravity, "gravity_divisor": gravity_divisor}


def main(argv):
    names = list(ANIMS) if (not argv or argv[0] == "all") else argv
    for n in names:
        ANIMS.get(n, lambda: print(f"unknown: {n}"))()


if __name__ == "__main__":
    main(sys.argv[1:])
