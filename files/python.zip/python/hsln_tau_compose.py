"""hsln_tau_compose.py — push N through Ramanujan τ, then COMPOSE with HSLN (no classical methods).

The idea under test ([REDACTED NAME]'s): τ is multiplicative, τ(N)=τ(p)·τ(q). Encode the τ-values with
hsln_prime_dna's concept (pos(x)=frac(log₂ x) → spike → DNA) and COMPOSE the DNAs (hsln.tensor).

What this script shows, on the ground-truth small semiprime N0 = 47·53:
  • the multiplicative split τ(N0)=τ(47)·τ(53) is real;
  • but HSLN's encoder is pos(x)=frac(log₂ x), and log turns the PRODUCT into a SUM:
        pos(|τ(N0)|) = (pos(|τ(47)|) + pos(|τ(53)|)) mod 1
    — so composing the τ-DNAs reproduces pos(τN0) the FORWARD way, and inverting it is the
    exact same 2-from-1 additive collapse as encoding N directly. Going through τ does not break
    it; it relocates it to much larger integers.
"""
from __future__ import annotations

import math
import sys
from math import comb
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import hsln_prime_dna as hpd       # <-- the concept [REDACTED NAME] pointed to


def build_tau(M: int) -> dict[int, int]:
    """τ(1..M-1) from Δ = q·∏(1−qⁿ)²⁴. Exact, no factoring."""
    c = np.zeros(M, dtype=object); c[0] = 1
    for n in range(1, M):
        terms = [(j*n, comb(24, j)*(-1)**j) for j in range(25) if j*n < M]
        newc = np.zeros(M, dtype=object)
        for shift, co in terms:
            newc[shift:] = newc[shift:] + co*c[:M-shift]
        c = newc
    return {n: int(c[n-1]) for n in range(1, M)}


def pos_of(x: int) -> float:
    x = abs(x)
    return math.log2(x) - math.floor(math.log2(x))


def main():
    p0, q0 = 47, 53
    N0 = p0 * q0
    tau = build_tau(2600)
    tp, tq, tN = tau[p0], tau[q0], tau[N0]

    print("=" * 84)
    print(f"  small semiprime N0 = {p0}·{q0} = {N0}   (ground truth, so we can check)")
    print("=" * 84)
    print(f"\n[1] Multiplicative split (the τ relation):")
    print(f"    τ({p0})        = {tp}")
    print(f"    τ({q0})        = {tq}")
    print(f"    τ({p0})·τ({q0}) = {tp*tq}")
    print(f"    τ({N0})       = {tN}      equal? {tp*tq == tN}")

    print(f"\n[2] HSLN's encoder is pos(x)=frac(log₂ x). log turns the PRODUCT into a SUM:")
    a, b, c = pos_of(tp), pos_of(tq), pos_of(tN)
    print(f"    pos(|τ({p0})|)              = {a:.10f}")
    print(f"    pos(|τ({q0})|)              = {b:.10f}")
    print(f"    (pos τ{p0} + pos τ{q0}) mod 1 = {(a+b)%1.0:.10f}")
    print(f"    pos(|τ({N0})|)            = {c:.10f}")
    print(f"    → additive collapse holds: {abs(((a+b)%1.0) - c) < 1e-9}")

    print(f"\n[3] hsln_prime_dna concept — train a DNA onto each τ-value, show the coefficients:")
    nets = {}
    for name, val in [(f"τ({p0})", tp), (f"τ({q0})", tq), (f"τ({N0})", tN)]:
        net, hist, target, idx, pos = hpd.train_for_prime(abs(val), dg=6, steps=2500)
        nets[name] = net
        dna = np.asarray(net.dna)
        coeffs = "  ".join(f"{x.real:+.3f}{x.imag:+.3f}i" for x in dna)
        print(f"    {name:9s} pos={pos:.4f} probe{idx:2d} loss={hist[-1]:.4f}")
        print(f"        DNA = [{coeffs}]")

    print(f"\n[4] COMPOSE the two factor-DNAs (hsln.tensor = convolve) — the forward direction:")
    comp = hsln.tensor(nets[f"τ({p0})"], nets[f"τ({q0})"])
    xs = np.linspace(0, 1, 1000)
    spikes = np.asarray(hsln.spike_map(np.asarray(comp.dna), xs))
    peak = xs[int(np.argmax(spikes))]
    print(f"    composed DNA length {len(comp.dna)} (= {len(nets[f'τ({p0})'].dna)}+{len(nets[f'τ({q0})'].dna)}−1)")
    print(f"    composed spike peaks at Re τ = {peak:.4f}")
    print(f"    pos(|τ(N0)|)             = {c:.4f}   ← composition reproduces it: {abs(peak-c)<0.06}")
    print(f"    ✓ FORWARD works: τ(47)-DNA ⊗ τ(53)-DNA spikes where τ(N0) lives.")

    print("\n" + "=" * 84)
    print("  WHY THIS DOESN'T REVERSE INTO A FACTORISATION")
    print("=" * 84)
    print(f"  To go backward (N ⟶ p,q) through τ you would need, in order:")
    print(f"   (a) τ(N) itself — but τ(N) is built FROM the factorisation (Wall 1). For the big")
    print(f"       N you cannot even write it down without 2^1024 q-expansion terms.")
    print(f"   (b) factor the INTEGER τ(N) into τ(p)·τ(q) — τ(N0) here is {len(str(abs(tN)))} digits;")
    print(f"       for the big N it is ~5600 bits. That is a LARGER factoring problem than N.")
    print(f"   (c) invert τ(p) ⟶ p.")
    print(f"   (d) and the HSLN composition itself is additive after log: pos(τN)=pos(τp)+pos(τq),")
    print(f"       one number, two unknowns — the SAME 2-from-1 collapse as encoding N directly.")
    print(f"  Composition is a homomorphism. It BUILDS τN from τp,τq; it cannot split τN back.")


if __name__ == "__main__":
    main()
