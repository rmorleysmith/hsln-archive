"""
Point the HSLN factoring instrument at real Satoshi-era Bitcoin keys.

Honest framing (read first):
  Our roots-of-unity detector factors INTEGERS (the RSA-style problem).
  A Bitcoin key's secret is an ELLIPTIC-CURVE DISCRETE LOG: the private key d with
  P = d·G on secp256k1. Factoring ≠ discrete log. So pointing this instrument at a
  real public key is a category mismatch on purpose: what "lights up" is just the
  small prime factors of the key's x-coordinate AS A NUMBER — which says exactly
  nothing about the private key. The fun is watching it stay dark on what matters.

We use two famous, permanently-public, on-chain keys:
  * the GENESIS block (block 0) coinbase public key — Satoshi's, never spent;
  * the BLOCK 9 coinbase public key — spent to Hal Finney in block 170 (the first
    ever Bitcoin transaction), so its public key has been exposed since Jan 2009.

These are public constants on every full node. Nothing here recovers any key.

Run:  .venv/bin/python hsln_bitcoin_probe.py
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from hsln_e8_torsion_factor import (
    e8_root_projection, is_prime, FG, BG, ACCENT, ACCENT2, COMP, GRID, save_fig,
)

# --- real, public, on-chain keys (uncompressed: 04 || X(32B) || Y(32B)) ----------
KEYS = {
    "genesis (block 0, Satoshi, unspent)":
        "04678afdb0fe5548271967f1a67130b7105cd6a828e03909a67962e0ea1f61deb6"
        "49f6bc3f4cef38c4f35504e51ec112de5c384df7ba0b8d578a4c702b6bf11d5f",
    "block 9 (spent to Hal Finney, block 170)":
        "0411db93e1dcdb8a016b49840f8c53bc1eb68a382e97b1482ecad7b148a6909a5c"
        "b2e0eaddfb84ccf9744464f82e160bfa9b8b64f9d4c03f999b8643f656b412a3",
}
SCAN_BOUND = 100_000_000


def pubkey_x(hexstr: str) -> int:
    """x-coordinate of an uncompressed secp256k1 public key, as an integer."""
    assert hexstr[:2] == "04" and len(hexstr) == 130, "expected uncompressed pubkey"
    return int(hexstr[2:66], 16)


def peel_small_factors(N: int, bound: int):
    """Trial-divide out every prime factor ≤ bound. Returns (factors, cofactor)."""
    n, facs, d = N, [], 2
    while d <= bound and d * d <= n:
        while n % d == 0:
            facs.append(d)
            n //= d
        d += 1 if d == 2 else 2
    # any remaining small factor (n itself ≤ bound and prime)
    if 1 < n <= bound:
        facs.append(n)
        n = 1
    return facs, n


def ru_walk(N: int, k: int) -> np.ndarray:
    """Cumulative sum of the detector's unit phasors e^{2πi·((jN) mod k)/k}, j<k.
    Divisor → all phasors align → straight ray of length k. Non-divisor → cancels."""
    nmod = int(N % k)                       # reduce the 256-bit int first (numpy can't hold it)
    r = (np.arange(k) * nmod) % k
    return np.cumsum(np.exp(2j * np.pi * r / k))


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def main():
    data = {}
    print("=" * 74)
    print(" Pointing the HSLN factoring detector at real Satoshi-era public keys")
    print("=" * 74)
    for name, hexk in KEYS.items():
        x = pubkey_x(hexk)
        facs, cof = peel_small_factors(x, SCAN_BOUND)
        data[name] = dict(x=x, facs=facs, cof=cof)
        print(f"\n {name}")
        print(f"   x-coordinate : {x.bit_length()}-bit integer")
        print(f"   small prime factors ≤ {SCAN_BOUND:,} : {sorted(set(facs)) or 'NONE'}")
        print(f"   unfactored cofactor : {cof.bit_length()}-bit "
              f"({'prime?' if cof > 1 else 'fully peeled'}) — beyond classical reach")

    # ---------------- figure ----------------
    proj = e8_root_projection()
    r_max = np.abs(proj).max() * 0.98
    names = list(KEYS)

    fig = plt.figure(figsize=(17, 10))
    fig.suptitle("HSLN instrument vs real Satoshi-era keys — what lights up "
                 "(and why it doesn't matter)", color=FG, fontsize=15, y=0.98)

    # 1 · the keys placed in the E8 Coxeter plane (the picture)
    ax = fig.add_subplot(2, 3, 1)
    ax.scatter(proj[:, 0], proj[:, 1], s=12, c=ACCENT2, alpha=0.6, lw=0)
    for i, name in enumerate(names):
        N = data[name]["x"]
        th = 2 * np.pi * (N % 30) / 30.0
        pos = 1.28 * r_max * np.array([np.cos(th), np.sin(th)])
        ax.scatter(*pos, s=200, marker="*", c=ACCENT if i == 0 else COMP,
                   edgecolors=FG, linewidths=0.7, zorder=5)
        ax.annotate(name.split(" (")[0], pos, color=FG, fontsize=8,
                    xytext=(6, 6), textcoords="offset points")
    ax.set_aspect("equal"); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_color(GRID)
    lim = 1.5 * r_max
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
    ax.set_title("1 · the two keys placed in the E8 plane", color=FG, fontsize=12)

    # 2 & 3 · what lights up: small factors of each key's x-coordinate
    for idx, name in enumerate(names):
        ax = fig.add_subplot(2, 3, 2 + idx)
        facs = sorted(set(data[name]["facs"]))
        if facs:
            for f in facs:
                ax.vlines(f, 0, 1, color=ACCENT, lw=2.4)
                ax.scatter([f], [1.0], s=70, c=ACCENT, edgecolors=FG, linewidths=0.5,
                           zorder=5)
                ax.annotate(str(f), (f, 1.03), color=ACCENT, fontsize=8, ha="center")
            ax.set_xscale("log")
            ax.set_xlim(2, SCAN_BOUND)
            sub = f"{len(facs)} small prime factor(s) — irrelevant to the key"
        else:
            ax.text(0.5, 0.5, "DARK\nno factor ≤ 2,000,000", transform=ax.transAxes,
                    color=ACCENT2, fontsize=14, ha="center", va="center")
            ax.set_xscale("log"); ax.set_xlim(2, SCAN_BOUND)
            sub = "instrument stays dark"
        ax.set_ylim(0, 1.2)
        ax.set_xlabel("candidate k (log scale)", color=FG)
        ax.set_title(f"{2+idx} · {name.split(' (')[0]}: {sub}", color=FG, fontsize=11)
        _grid(ax)

    # 4 · the √N wall: a sliver peeled, a ~256-bit cofactor untouched
    ax = fig.add_subplot(2, 3, 4)
    short = [n.split(" (")[0] for n in names]
    peeled = [data[n]["x"].bit_length() - data[n]["cof"].bit_length() for n in names]
    wall = [data[n]["cof"].bit_length() for n in names]
    y = np.arange(len(names))
    ax.barh(y, peeled, color=ACCENT, edgecolor=FG, label="bits peeled (small factors)")
    ax.barh(y, wall, left=peeled, color=COMP, edgecolor=FG,
            label="unfactorable cofactor (~√ wall)")
    ax.set_yticks(y); ax.set_yticklabels(short, fontsize=8)
    ax.set_xlabel("bits of the 256-bit x-coordinate", color=FG)
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="lower right")
    ax.set_title("4 · we peel a sliver, then hit the classical wall", color=FG, fontsize=12)
    _grid(ax)

    # 5 · resonance on REAL data: a divisor aligns, a non-divisor cancels
    ax = fig.add_subplot(2, 3, 5)
    g = data[names[0]]
    div = next((f for f in sorted(set(g["facs"])) if 30 <= f <= 600),
               (sorted(set(g["facs"]))[0] if g["facs"] else None))
    nond = next(k for k in range(150, 400) if g["x"] % k != 0)
    if div:
        w = ru_walk(g["x"], div)
        ax.plot(w.real, w.imag, color=ACCENT, lw=1.6,
                label=f"k={div} (divisor → resonates, |Σ|={abs(w[-1]):.0f})")
        ax.scatter([w[-1].real], [w[-1].imag], s=40, c=ACCENT, zorder=5)
    wn = ru_walk(g["x"], nond)
    ax.plot(wn.real, wn.imag, color=ACCENT2, lw=1.0, alpha=0.9,
            label=f"k={nond} (non-divisor → cancels, |Σ|={abs(wn[-1]):.1f})")
    ax.scatter([wn[-1].real], [wn[-1].imag], s=40, c=ACCENT2, zorder=5)
    ax.scatter([0], [0], s=20, c=FG)
    ax.set_aspect("equal")
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="upper left")
    ax.set_title("5 · roots-of-unity walk on the real genesis key", color=FG, fontsize=12)
    _grid(ax)

    # 6 · verdict
    ax = fig.add_subplot(2, 3, 6)
    ax.axis("off")
    lines = [
        ("VERDICT", ACCENT, 13),
        ("", FG, 5),
        ("What lit up: a few small prime factors of each key's", FG, 10),
        ("x-coordinate — a property of the number, found by", FG, 10),
        ("scanning k ≤ 2,000,000.", FG, 10),
        ("", FG, 5),
        ("What it tells us about the private key: NOTHING.", "#ff6b6b", 11),
        ("Bitcoin's secret is the discrete log d (P=d·G on", FG, 10),
        ("secp256k1), not a factorisation. Our instrument", FG, 10),
        ("measures the wrong invariant entirely.", FG, 10),
        ("", FG, 5),
        ("And even on its own terms it stalls: after peeling", FG, 10),
        ("small primes, a ~256-bit cofactor remains — the √N", FG, 10),
        ("wall. Classically dark either way.", FG, 10),
        ("", FG, 5),
        ("So Satoshi's exposed genesis key is safe from this.", ACCENT2, 10),
        ("Only a quantum discrete-log (Shor) would change that.", ACCENT2, 10),
    ]
    yy = 0.97
    for t, c, s in lines:
        ax.text(0.0, yy, t, color=c, fontsize=s, va="top", transform=ax.transAxes)
        yy -= 0.060 if t else 0.028

    fig.subplots_adjust(left=0.05, right=0.97, top=0.91, bottom=0.08,
                        hspace=0.34, wspace=0.24)
    save_fig(fig, "59_hsln_bitcoin_probe.png")


if __name__ == "__main__":
    main()
