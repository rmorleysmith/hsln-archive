"""The explicit formula: the zeta zeros reconstruct the primes.

Riemann / von Mangoldt: the prime-power counting function (Chebyshev's psi) is

    psi(x) = x - log(2*pi) - (1/2) log(1 - x^{-2}) - sum_rho x^rho / rho,

where rho runs over the nontrivial zeros. Pairing rho = 1/2 + i*gamma with its conjugate,
each zero contributes an OSCILLATION  2*sqrt(x)*Re[ x^{i*gamma} / (1/2 + i*gamma) ]. Adding
more zeros sharpens the staircase whose jumps sit exactly at the prime powers 2,3,4,5,7,8,9,…

So the zeros INTERPOLATE the primes -- exactly the "proof by interpolation" intuition,
made into a picture: the smooth term x minus a Fourier-like sum over zeros rebuilds the
discrete prime staircase.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from zeros import get_zeros


def true_psi(xs):
    M = int(xs.max()) + 1
    primes = [p for p in range(2, M + 1) if all(p % d for d in range(2, int(p ** 0.5) + 1))]
    jumps = []
    for p in primes:
        pk = p
        while pk <= M:
            jumps.append((pk, np.log(p)))
            pk *= p
    psi = np.zeros_like(xs)
    for loc, lp in jumps:
        psi += lp * (xs >= loc)
    return psi, sorted(jumps)


def psi_K(xs, g, K):
    out = xs - np.log(2 * np.pi) - 0.5 * np.log(1.0 - xs ** -2.0)
    lnx = np.log(xs)
    for k in range(K):
        gk = g[k]
        out = out - 2 * np.sqrt(xs) * np.real(np.exp(1j * gk * lnx) / (0.5 + 1j * gk))
    return out


def run(make_fig=True):
    g = get_zeros(5000)
    xs = np.linspace(1.6, 30.0, 4000)
    psi_true, jumps = true_psi(xs)
    print(f"reconstructing psi(x) on [1.6,30] from up to {len(g)} zeros.")
    for K in (1, 10, 50, 200, 1000, 10000):
        err = np.abs(psi_K(xs, g, K) - psi_true).mean()
        print(f"  K={K:4d} zeros: mean |psi_K - psi| = {err:.3f}")

    if make_fig:
        _figure(xs, psi_true, jumps, g)
    return True


def _figure(xs, psi_true, jumps, g):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, NEURON, GREEN, VIO = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A", "#c0a3ff"

    fig, ax = plt.subplots(1, 2, figsize=(15.5, 5.6))

    # A: progressive reconstruction
    a = ax[0]
    a.plot(xs, psi_true, color="white", lw=2.2, label="true ψ(x) (prime-power staircase)")
    for K, col in [(1, NEURON), (10, GOLD), (50, TEAL)]:
        a.plot(xs, psi_K(xs, g, K), color=col, lw=1.3, alpha=0.9, label=f"{K} zeros")
    a.set_xlabel("x"); a.set_ylabel("ψ(x)")
    a.set_title("each zero adds an oscillation;\nmore zeros → the staircase emerges", fontsize=12)
    a.legend(loc="upper left", fontsize=8.5, framealpha=0.3)

    # B: K=200 closely tracks the staircase; prime powers marked
    b = ax[1]
    b.plot(xs, psi_true, color="white", lw=2.4, label="true ψ(x)")
    b.plot(xs, psi_K(xs, g, 200), color=GREEN, lw=1.4, label="200 zeros")
    for loc, lp in jumps:
        if loc <= 30:
            b.axvline(loc, color="#445", lw=0.6, alpha=0.6)
    b.set_xlabel("x"); b.set_ylabel("ψ(x)")
    b.set_title("200 zeros reconstruct the primes\n(vertical lines = prime powers)", fontsize=12)
    b.legend(loc="upper left", fontsize=9, framealpha=0.3)

    fig.suptitle("The explicit formula: the zeros 'interpolate' the primes — x minus a sum of "
                 "zero-oscillations rebuilds the prime staircase", fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "35_explicit.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
