"""The spectral / Hilbert-Polya sandbox: do the zeta zeros behave like the eigenvalues
of a self-adjoint (Hermitian) operator?

Hilbert-Polya: if the imaginary parts gamma_n of the zeros were the eigenvalues of some
self-adjoint operator H, they'd be real -> all zeros on the critical line -> RH. We don't
have H (open problem). But Montgomery-Odlyzko found striking evidence: the *statistics* of
the zeros match those of a random Hermitian matrix (the Gaussian Unitary Ensemble, GUE).

We show it with real zeros (mpmath):
  A. |zeta(1/2 + it)| on the critical line -- it hits 0 exactly at the gamma_n.
  B. the unfolded nearest-neighbour spacings of the zeros vs the GUE "Wigner surmise"
     and vs Poisson (independent) -- the zeros follow GUE, not Poisson.
  C. the bulk eigenvalue spacings of an actual random Hermitian matrix -- the same law.
So the zeros behave like a quantum spectrum. (Evidence for Hilbert-Polya; NOT a proof.)
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from zeros import get_zeros


def unfold(g):
    """Smooth counting function N(T) ~ (T/2pi)(log(T/2pi) - 1) + 7/8; gives mean spacing 1."""
    T = g / (2 * np.pi)
    return T * (np.log(T) - 1) + 7 / 8


def wigner_gue(s):
    return (32 / np.pi ** 2) * s ** 2 * np.exp(-4 * s ** 2 / np.pi)


def run(make_fig=True):
    g = get_zeros(500)
    print(f"loaded {len(g)} zeta zeros; first: 1/2 + {g[0]:.4f}i")

    # A: |zeta(1/2+it)| on the line
    import mpmath as mp
    mp.mp.dps = 15
    ts = np.linspace(0.1, 50, 1200)
    zmag = np.array([abs(complex(mp.zeta(0.5 + 1j * t))) for t in ts])

    # B: unfolded spacings (skip small-gamma transient)
    u = unfold(g[20:])
    s = np.diff(u)

    # C: bulk spacings of a random Hermitian (GUE) matrix
    rng = np.random.default_rng(0)
    Nm = 1500
    A = rng.standard_normal((Nm, Nm)) + 1j * rng.standard_normal((Nm, Nm))
    H = (A + A.conj().T) / 2
    ev = np.sort(np.linalg.eigvalsh(H))
    mid = ev[Nm // 4: 3 * Nm // 4]
    sm = np.diff(mid)
    sm = sm / sm.mean()

    # quick KS-ish sanity: mean spacing
    print(f"zero spacings: mean {s.mean():.3f} (target 1.0);  GUE matrix bulk mean {sm.mean():.3f}")

    if make_fig:
        _figure(ts, zmag, g, s, sm)
    return s, sm


def _figure(ts, zmag, g, s, sm):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, NEURON, GREEN = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A"
    ss = np.linspace(0, 3.2, 200)

    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))

    # A: zeta on the critical line
    a = ax[0]
    a.plot(ts, zmag, color=TEAL, lw=1.4)
    for gi in g[g < 50]:
        a.axvline(gi, color=NEURON, ls=":", lw=0.8, alpha=0.7)
    a.set_xlabel("t"); a.set_ylabel(r"$|\zeta(\frac{1}{2} + it)|$")
    a.set_title("zeros live on the critical line\n(|ζ| → 0 at each γₙ)", fontsize=12)

    # B: zero spacings vs GUE & Poisson
    b = ax[1]
    b.hist(s, bins=28, density=True, color="#33445a", edgecolor="#667",
           label="zeta-zero spacings")
    b.plot(ss, wigner_gue(ss), color=GOLD, lw=2.4, label="GUE (random Hermitian)")
    b.plot(ss, np.exp(-ss), color=NEURON, lw=2, ls="--", label="Poisson (independent)")
    b.set_xlabel("normalised spacing s"); b.set_ylabel("density")
    b.set_title("zero spacings follow GUE, not Poisson\n(Montgomery–Odlyzko)", fontsize=12)
    b.legend(loc="upper right", fontsize=8.5, framealpha=0.3)

    # C: GUE matrix eigenvalue spacings
    c = ax[2]
    c.hist(sm, bins=28, density=True, color="#3a5a45", edgecolor="#576",
           label="random Hermitian eigenvalue spacings")
    c.plot(ss, wigner_gue(ss), color=GOLD, lw=2.4, label="GUE Wigner surmise")
    c.set_xlabel("normalised spacing s"); c.set_ylabel("density")
    c.set_title("a real Hermitian matrix's spectrum:\nthe same spacing law", fontsize=12)
    c.legend(loc="upper right", fontsize=8.5, framealpha=0.3)

    fig.suptitle("Spectral sandbox: the zeta zeros behave like the eigenvalues of a random "
                 "Hermitian operator (Hilbert–Pólya evidence — not a proof)", fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "34_spectral.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
