"""Minimal trainable HSLN proof-of-concept (genus 1, CPU, JAX autodiff).

The learnable parameters are the GRAVITY DNA (Fourier coefficients of the energy
form F). The state relaxes under the gradient flow of |F|^2 toward the form's zeros
(the attractors / neurons), and we backpropagate a task loss through the whole
relaxation to tweak the DNA -- i.e. the gravity DNA *is* the thing we train.

Task (minimal): two input classes are encoded as two initial states; the learned
field must relax class A to target A and class B to target B. The field has to grow
two separated attractors and route each input to the right one.

(Input is encoded as the initial condition rather than a tangent drive B u(t) -- a
standard reservoir simplification; the time-driven version is the next rung.)
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np
from jax import grad, lax, value_and_grad

jax.config.update("jax_enable_x64", True)

DG = 6  # gravity DNA: DG complex coeffs -> 2*DG real learnable params


def gravity_coeffs(p):
    return p[:DG] + 1j * p[DG:]


def Fval(p, x, y):
    q = jnp.exp(2j * jnp.pi * (x + 1j * y))
    return jnp.sum(gravity_coeffs(p) * q ** jnp.arange(DG))


def energy(p, xy):
    f = Fval(p, xy[0], xy[1])
    return jnp.real(f * jnp.conj(f))


_grad_energy = grad(energy, argnums=1)

T = 160


# --- task: a CONSTANT input drive distinguishes the classes (spec dynamics, u = const) ---
# Both classes start at the SAME state; only the constant input u differs.
#   d/dt (x,y) = -alpha * grad|F|^2  +  B_vec * u .
START = jnp.array([0.50, 0.55])
B_VEC = jnp.array([0.35, 0.0])
U_A, U_B = 1.0, -1.0
TARGET_A = jnp.array([0.76, 0.30])
TARGET_B = jnp.array([0.24, 0.30])


def rollout(p, u, alpha=1.0, dt=0.02, ymin=0.05, ymax=0.95):
    def stepfn(xy, _):
        g = _grad_energy(p, xy)
        gn = g / (jnp.sqrt(g[0] ** 2 + g[1] ** 2) + 1e-4)  # unit-speed field descent
        nx = jnp.clip(xy[0] - dt * alpha * gn[0] + dt * B_VEC[0] * u, 0.02, 0.98)
        ny = jnp.clip(xy[1] - dt * alpha * gn[1] + dt * B_VEC[1] * u, ymin, ymax)
        new = jnp.array([nx, ny])
        return new, new
    final, traj = lax.scan(stepfn, START, jnp.arange(T))
    return final, traj


def loss(p):
    _, ta = rollout(p, U_A)
    _, tb = rollout(p, U_B)
    dA = jnp.min(jnp.sum((ta - TARGET_A) ** 2, axis=1))
    dB = jnp.min(jnp.sum((tb - TARGET_B) ** 2, axis=1))
    return dA + dB + 1e-3 * jnp.sum(p ** 2)


_loss_and_grad = jax.jit(value_and_grad(loss))


def init_params(seed=0):
    """Seed gravity with a central cluster of zeros (an active field, not flat)."""
    rng = np.random.default_rng(seed)
    zeros = np.array([0.50 + 0.40j, 0.50 + 0.50j, 0.50 + 0.30j])  # central column: both classes collide
    c = np.poly(np.exp(2j * np.pi * zeros))[::-1]
    c = c / np.max(np.abs(c))
    c = np.concatenate([c, np.zeros(DG - len(c), dtype=complex)])
    p = np.concatenate([c.real, c.imag]) + 0.05 * rng.standard_normal(2 * DG)
    return jnp.array(p)


def train(steps=600, lr=0.015, seed=0):
    p = init_params(seed)
    p0 = p
    m = jnp.zeros_like(p); v = jnp.zeros_like(p)
    b1, b2, eps = 0.9, 0.999, 1e-8
    history = []
    for t in range(1, steps + 1):
        L, g = _loss_and_grad(p)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        p = p - lr * (m / (1 - b1 ** t)) / (jnp.sqrt(v / (1 - b2 ** t)) + eps)
        history.append(float(L))
    return p0, p, history


def visualize(steps=800, lr=0.012, seed=0):
    import matplotlib.pyplot as plt
    from pathlib import Path
    import modular, style

    p0, p, hist = train(steps=steps, lr=lr, seed=seed)
    classes = [(U_A, TARGET_A, "#46f0d0", "u = +1"), (U_B, TARGET_B, style.ACCENT, "u = −1")]

    fig, ax = plt.subplots(1, 3, figsize=(16, 5.4))
    for col, (pp, title) in enumerate([(p0, "before training"), (p, "after training")]):
        coeffs = np.array(gravity_coeffs(pp))
        neurons = modular.qpoly_zeros(coeffs)
        ax[col].set_facecolor("#0b0b14")
        ax[col].plot(neurons.real, neurons.imag, "o", color="#6a6a7c", ms=5,
                     label="attractors (zeros of F)")
        for u, target, c, lab in classes:
            tr = np.array(rollout(pp, u)[1])
            ax[col].plot(tr[:, 0], tr[:, 1], color=c, lw=1.8, zorder=5, label=lab)
            ax[col].plot(float(target[0]), float(target[1]), "*", color=c, ms=20,
                         mec="white", mew=0.9, zorder=6)
        ax[col].plot(float(START[0]), float(START[1]), "o", mfc="none", mec="white",
                     mew=1.8, ms=11, zorder=7)
        ax[col].set_xlim(0, 1); ax[col].set_ylim(0.04, 0.85)
        ax[col].set_title(title, fontsize=13); ax[col].set_xlabel(r"Re $\tau$")
    ax[0].set_ylabel(r"Im $\tau$")
    ax[0].legend(loc="lower center", ncol=2, fontsize=9, framealpha=0.3)
    ax[0].text(0.03, 0.10, "○ shared start  ★ class target  — path under constant input",
               color="white", fontsize=9)

    ax[2].plot(hist, color=style.ACCENT, lw=1.6)
    ax[2].set_yscale("log"); ax[2].set_xlabel("Adam step on the gravity DNA")
    ax[2].set_ylabel("task loss (log)"); ax[2].set_title("training the gravity DNA", fontsize=13)
    ax[2].grid(alpha=0.2)

    fig.suptitle(r"Trainable HSLN (genus 1): a constant input drive $B u$ ($u=\pm1$) from a shared "
                 "start; backprop into the gravity DNA routes each input to its class target",
                 fontsize=13, y=1.02)
    out = Path(__file__).parent / "figures" / "14_poc_constant_input.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"loss {hist[0]:.4f} -> {hist[-1]:.5f}; wrote {out}")


if __name__ == "__main__":
    visualize(steps=800, lr=0.012)
