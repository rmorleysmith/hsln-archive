"""Eta-quotient DNA: form multiplication = ADDITION of integer exponent vectors,
and the admissible vectors form an additive monoid (composition with guarantees).

    f_r(tau) = prod_{d|N} eta(d*tau)^{r_d}.

Then  f_r * f_s = f_{r+s}  exactly, the weight k = (1/2) sum_d r_d adds linearly,
and Newman's two congruences + Ligozat's cusp-order cone are LINEAR in r, so the
admissible set is closed under addition: composing two valid networks yields a
valid network, by construction.

Trade-off (honest): eta is non-vanishing on H, so every zero (neuron) of an eta
quotient sits at a CUSP, never the interior. Contrast: E4 has an interior zero at
rho that no eta quotient can reproduce. We show both.
"""
from __future__ import annotations

from math import gcd
from pathlib import Path

import numpy as np


# --------------------------------------------------------------------------- #
#  Dedekind eta and eta quotients (q-expansion, accurate for Im tau >~ 0.1)    #
# --------------------------------------------------------------------------- #
def eta(tau, terms: int = 300):
    tau = np.asarray(tau, complex)
    q = np.exp(2j * np.pi * tau)
    pref = np.exp(1j * np.pi * tau / 12.0)        # q^{1/24}
    prod = np.ones_like(tau)
    qn = np.ones_like(tau)
    for _ in range(terms):
        qn = qn * q
        prod = prod * (1.0 - qn)
    return pref * prod


def eta_quotient(tau, divisors, r):
    tau = np.asarray(tau, complex)
    out = np.ones_like(tau)
    for d, rd in zip(divisors, r):
        out = out * eta(d * tau) ** rd
    return out


# --------------------------------------------------------------------------- #
#  Modularity bookkeeping: Newman congruences + Ligozat cusp orders           #
# --------------------------------------------------------------------------- #
def divisors(N):
    return [d for d in range(1, N + 1) if N % d == 0]


def newman_residues(N, r):
    """The two Newman sums mod 24; both must be 0 for a form on Gamma0(N)."""
    ds = divisors(N)
    s1 = sum(d * rd for d, rd in zip(ds, r))
    s2 = sum((N // d) * rd for d, rd in zip(ds, r))
    return s1 % 24, s2 % 24


def cusp_orders(N, r):
    """Ligozat order of vanishing at each cusp d | N (>=0 == holomorphic)."""
    ds = divisors(N)
    orders = {}
    for c in ds:                                  # cusp 1/c, indexed by c | N
        s = 0.0
        for d, rd in zip(ds, r):
            s += (gcd(c, d) ** 2 * rd) / (gcd(c, N // c) * c * d)
        orders[c] = (N / 24.0) * s
    return orders


def weight(r):
    return 0.5 * sum(r)


def is_admissible(N, r):
    """Holomorphic modular form on Gamma0(N): both congruences + cone + int weight."""
    r1, r2 = newman_residues(N, r)
    w = weight(r)
    cong = (r1 == 0 and r2 == 0)
    holo = all(o >= -1e-9 for o in cusp_orders(N, r).values())
    intwt = abs(w - round(w)) < 1e-9 and w >= 1 - 1e-9
    return cong and holo and intwt


# --------------------------------------------------------------------------- #
#  E4 (for the interior-zero contrast)                                        #
# --------------------------------------------------------------------------- #
def _sigma3(n):
    return sum(d ** 3 for d in range(1, n + 1) if n % d == 0)


def e4(tau, terms: int = 60):
    tau = np.asarray(tau, complex)
    q = np.exp(2j * np.pi * tau)
    out = np.ones_like(tau)
    for n in range(1, terms + 1):
        out = out + 240.0 * _sigma3(n) * q ** n
    return out


# --------------------------------------------------------------------------- #
def run(make_fig: bool = True):
    rng = np.random.default_rng(0)

    # ---- (1) linearization: f_r * f_s == f_{r+s} -------------------------- #
    N_lin = 12
    ds = divisors(N_lin)                          # [1,2,3,4,6,12]
    r = rng.integers(-3, 4, size=len(ds))
    s = rng.integers(-3, 4, size=len(ds))
    taus = (rng.uniform(-0.5, 0.5, 60) + 1j * rng.uniform(0.15, 1.5, 60))
    fr = eta_quotient(taus, ds, r)
    fs = eta_quotient(taus, ds, s)
    frs = eta_quotient(taus, ds, r + s)
    rel = np.abs(fr * fs - frs) / (np.abs(frs) + 1e-300)
    print(f"[linearization]  N={N_lin}  r={list(r)}  s={list(s)}")
    print(f"  weight(r)={weight(r)}  weight(s)={weight(s)}  "
          f"weight(r+s)={weight(r+s)}  (adds: {weight(r)+weight(s)})")
    print(f"  max relative residual |f_r f_s - f_(r+s)| / |f_(r+s)| = {rel.max():.2e}")

    # ---- (2) admissibility lattice + additive closure (N = 11) ------------ #
    N = 11                                        # our PoC level; divisors [1,11]
    box = range(-12, 13)
    cong, adm = [], []
    for a in box:
        for b in box:
            r1, r2 = newman_residues(N, (a, b))
            if r1 == 0 and r2 == 0:
                cong.append((a, b))
                if is_admissible(N, (a, b)):
                    adm.append((a, b))
    base = (2, 2)                                 # eta^2(tau) eta^2(11 tau) = newform 11.2.a.a
    summ = (base[0] + base[0], base[1] + base[1])
    print(f"[lattice N=11]  congruence pts in box: {len(cong)}  admissible(holo) pts: {len(adm)}")
    print(f"  base {base} admissible={is_admissible(N, base)} weight={weight(base)}  "
          f"orders={ {k: round(v,3) for k,v in cusp_orders(N, base).items()} }")
    print(f"  base+base={summ} admissible={is_admissible(N, summ)} weight={weight(summ)}  "
          f"(closure under addition)")

    # ---- (3) zeros pinned to cusps: eta-quotient vs E4 -------------------- #
    y = np.linspace(0.30, 2.3, 400)
    f_nf = eta_quotient(0.13 + 1j * y, [1, 11], [2, 2])     # no interior zero
    e4_line = e4(-0.5 + 1j * y)                              # zero at rho (y=0.866)
    imin = np.abs(f_nf).min()
    print(f"[zeros]  eta-quotient min|f| on interior slice = {imin:.3e} (no interior zero)")
    print(f"  E4 min|E4| on slice through rho = {np.abs(e4_line).min():.3e} (interior zero at y=0.866)")

    if make_fig:
        _figure(taus, rel, cong, adm, base, summ, N, y, f_nf, e4_line)
    return rel.max()


def _figure(taus, rel, cong, adm, base, summ, N, y, f_nf, e4_line):
    import matplotlib.pyplot as plt
    import style  # noqa: F401  (applies rcParams)

    GOLD, TEAL, GREEN = "#ffd166", "#46f0d0", "#7CFC8A"
    NEURON = "#ff3b6b"

    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))

    # --- A: linearization residual --- #
    a = ax[0]
    a.plot(np.arange(len(rel)), np.log10(rel + 1e-18), "o", color=TEAL, ms=4)
    a.axhline(-15, color=GOLD, ls="--", lw=1, alpha=0.7, label="machine precision")
    a.set_ylim(-18, 0)
    a.set_xlabel("sample point  $\\tau$")
    a.set_ylabel(r"$\log_{10}\,|f_r f_s - f_{r+s}|/|f_{r+s}|$")
    a.set_title("multiply = add exponents\n(exact to machine precision)", fontsize=12)
    a.legend(loc="upper right", fontsize=9, framealpha=0.3)

    # --- B: admissibility lattice + closure --- #
    b = ax[1]
    cong = np.array(cong); adm = np.array(adm)
    b.scatter(cong[:, 0], cong[:, 1], s=22, color="#556", label="modular (congruences)")
    if len(adm):
        b.scatter(adm[:, 0], adm[:, 1], s=42, color=GOLD, edgecolor="white",
                  lw=0.4, label="holomorphic form", zorder=4)
    # closure arrows: base + base = summ
    b.annotate("", xy=summ, xytext=base,
               arrowprops=dict(arrowstyle="->", color=GREEN, lw=2))
    b.annotate("", xy=base, xytext=(0, 0),
               arrowprops=dict(arrowstyle="->", color=GREEN, lw=2, alpha=0.6))
    for p, lab in [(base, f"$r$={base}, k={weight(base):.0f}"),
                   (summ, f"$r+r$={summ}, k={weight(summ):.0f}")]:
        b.plot(*p, "o", color=GREEN, ms=9, zorder=5)
        b.annotate(lab, p, textcoords="offset points", xytext=(8, 6),
                   color=GREEN, fontsize=9)
    b.axhline(0, color="#444", lw=0.6); b.axvline(0, color="#444", lw=0.6)
    b.set_xlabel(r"$r_1$  (exponent of $\eta(\tau)$)")
    b.set_ylabel(r"$r_{11}$  (exponent of $\eta(11\tau)$)")
    b.set_title(f"level {N}: admissible exponents\nclosed under addition (a monoid)", fontsize=12)
    b.legend(loc="upper left", fontsize=8, framealpha=0.3)
    b.set_xlim(-12.5, 12.5); b.set_ylim(-12.5, 12.5)

    # --- C: zeros pinned to cusps vs E4 interior zero --- #
    c = ax[2]
    c.plot(y, np.log10(np.abs(f_nf)), color=GOLD, lw=2.2,
           label=r"$\eta^2(\tau)\eta^2(11\tau)$  (eta quotient)")
    c.plot(y, np.log10(np.abs(e4_line)), color=NEURON, lw=2.2,
           label=r"$E_4$  (slice through $\rho$)")
    c.axvline(np.sqrt(3) / 2, color=NEURON, ls=":", lw=1.2, alpha=0.8)
    c.annotate("interior neuron\n(zero of $E_4$ at $\\rho$)", (np.sqrt(3) / 2, -6.5),
               color=NEURON, fontsize=9, ha="center")
    c.annotate("cusp $\\to$", (2.15, np.log10(np.abs(f_nf))[-1] + 0.3),
               color=GOLD, fontsize=9, ha="right")
    c.set_xlabel(r"$\mathrm{Im}\,\tau$")
    c.set_ylabel(r"$\log_{10}|F|$")
    c.set_title("eta quotients: zeros only at cusps\n$E_4$: a zero in the interior", fontsize=12)
    c.legend(loc="lower left", fontsize=8.5, framealpha=0.3)

    fig.suptitle("Eta-quotient DNA: composition is linear (add exponent vectors) and "
                 "stays modular by construction", fontsize=13, y=1.02)
    out = Path(__file__).parent / "figures" / "21_eta_composition.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
