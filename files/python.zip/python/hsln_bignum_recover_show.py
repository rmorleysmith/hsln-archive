"""hsln_bignum_recover_show.py — run the FULL recovery pipeline on the big N, print the numbers.

Same process as the toy case, end to end:
  1. pos(N) at high precision
  2. train HSLN onto pos(N), read the on-lane neuron α
  3. recovery bijection  cand(α, k) = round(2^(k + α))  across bit-shelves k
  4. show every candidate integer and N mod candidate.

Nothing hidden — the actual integers the machine produces are printed.
"""
from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import numpy as np
import mpmath as mp

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln
import modular
import hsln_factor_dna as hfd

N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)
LANE_Y = hsln.LANE_Y


def pos_hp(n: int, dps: int = 1100) -> mp.mpf:
    mp.mp.dps = dps
    L = mp.log(n, 2)
    return L - mp.floor(L)


def cand_at(alpha, k: int) -> int:
    """round(2^(k + alpha)) at precision sufficient for an exact integer."""
    mp.mp.dps = max(80, int(k * 0.302) + 60)
    return int(mp.nint(mp.power(2, mp.mpf(k) + mp.mpf(alpha))))


def abbrev(n: int, head: int = 34, tail: int = 8) -> str:
    s = str(n)
    if len(s) <= head + tail + 3:
        return s
    return f"{s[:head]}…{s[-tail:]} ({len(s)} digits)"


def main():
    pos_N = pos_hp(N)
    pos_N_f = float(pos_N)
    nb = N.bit_length()
    print("=" * 92)
    print(f"  big N : {nb} bits, {len(str(N))} digits")
    print(f"  pos(N) = frac(log2 N) = {pos_N_f:.12f}")
    print("=" * 92)

    # ── 0. The bijection is lossless: feeding pos(N) back reconstructs N exactly. ──
    print("\n[0] SANITY — the recovery bijection round-trips N exactly (high precision):")
    k_top = nb - 1                       # floor(log2 N)
    back = cand_at(pos_N, k_top)
    print(f"    round(2^({k_top} + pos(N)))  ==  N  ?   {back == N}")
    print(f"      → {abbrev(back)}")
    print(f"    The machinery is exact. It recovers the number on pos(N)'s shelf — which is N.")

    # ── 1. Train HSLN onto pos(N) (the 4-neuron case). ──
    print("\n[1] TRAIN — HSLN dg=5 (4 neurons), one-hot target at the probe nearest pos(N):")
    target, idx = hfd.target_for_position(pos_N_f)
    net, hist = hfd.train(target, dg=5, steps=4000, seed=0)
    dna = np.asarray(net.dna)
    print(f"    target probe {idx} (pos {float(np.array(hsln.PROBES)[idx]):.4f}), "
          f"loss {hist[0]:.3f} → {hist[-1]:.5f}")
    print(f"    DNA (length {len(dna)}):")
    for i, a in enumerate(dna):
        print(f"      a[{i}] = {a.real:+.6f} {a.imag:+.6f}i   |a|={abs(a):.5f}")

    zeros = modular.qpoly_zeros(dna)
    on_lane = []
    print(f"    zeros (neurons):")
    for z in sorted(zeros, key=lambda z: z.real % 1.0):
        re = z.real % 1.0
        lane = abs(z.imag - LANE_Y) < 0.04
        if lane:
            on_lane.append(re)
        print(f"      Re τ={re:.5f}  Im τ={z.imag:.5f}{'   ★ ON LANE' if lane else ''}")

    # ── 2. Recover from the trained neuron α, at FACTOR-sized bit-shelves. ──
    # A balanced factor of a 1024-bit semiprime is ~512 bits, so k ≈ 511.
    print("\n[2] RECOVER — bijection round(2^(k+α)) at factor-sized shelves k∈[506..512]:")
    print("    (a balanced factor of a 1024-bit N would be ~512 bits, i.e. k≈511)")
    sources = []
    for a in on_lane:
        sources.append((a, "trained on-lane neuron"))
    sources.append((pos_N_f, "pos(N) itself (oracle)"))
    for alpha, tag in sources:
        print(f"\n    α = {alpha:.6f}   [{tag}]")
        for k in range(506, 513):
            c = cand_at(alpha, k)
            r = N % c if c > 1 else -1
            print(f"      k={k}: cand = {abbrev(c)}")
            print(f"             N mod cand = {abbrev(r) if r>10**8 else r}   divides? {r==0}")

    # ── 3. Full sweep (every shelf × wiggle), report hits and a sample of the integers. ──
    print("\n[3] FULL SWEEP — every on-lane/oracle position × k∈[half−50..1023] × wiggle ±8:")
    positions = sorted(set([round(a, 8) for a in on_lane] + [round(pos_N_f, 8)]))
    K_LO, K_HI = nb // 2 - 50, nb - 1
    hits, tried = [], 0
    sample = []
    t0 = time.perf_counter()
    for alpha in positions:
        for k in range(K_LO, K_HI + 1):
            c0 = cand_at(alpha, k)
            for di in range(-8, 9):
                c = c0 + di
                if c <= 1 or c >= N:
                    continue
                tried += 1
                if k in (510, 511, 512) and di == 0 and len(sample) < 4:
                    sample.append((alpha, k, c))
                if N % c == 0:
                    hits.append((alpha, k, di, c, N // c))
    dt = time.perf_counter() - t0
    print(f"    positions swept: {[f'{p:.4f}' for p in positions]}")
    print(f"    candidates tried: {tried:,}   time: {dt:.1f}s")
    print(f"    sample of the actual integers produced (k≈511):")
    for alpha, k, c in sample:
        print(f"      α={alpha:.4f} k={k}: {abbrev(c)}   divides? {N % c == 0}")
    print(f"\n    >>> factors of N found: {len(hits)} <<<")
    for alpha, k, di, c, cof in hits:
        print(f"      ✓ {c}  ×  {cof}   (α={alpha:.6f}, k={k}, di={di})")

    print("\n" + "=" * 92)
    print("  WHAT CAME OUT")
    print("=" * 92)
    print("  • The bijection is exact: it reconstructs N (and N≫j, the power-of-2 shifts).")
    print("  • Every recovered integer sits on pos(N)'s OWN shelf — never on a factor's shelf.")
    print(f"  • {tried:,} real candidate integers checked against N; 0 divide it.")
    print("  • Because pos(N)=pos(p)+pos(q) mod 1 is one equation in two unknowns, the trained")
    print("    neuron encodes the sum, not the split. The numbers are real; none are factors.")


if __name__ == "__main__":
    main()
