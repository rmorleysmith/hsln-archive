"""
DNA → matrix → factor the MATRIX. Does matrix factorisation reach the primes?

[REDACTED NAME]'s idea: take the DNA of the model trained to N, lay it out as a matrix, and factor
THAT matrix instead of the integer. Matrix factorisation (LU, QR, SVD, eigen) is polynomial
and easy — so if the integer's factors fell out of it, we'd be done.

The principled "DNA as a matrix" is the CIRCULANT built from the divisor-indicator DNA
d = (a_0,...,a_{L-1}), a_k = [k | N]:

        C = circ(d),   C_{ij} = a_{(j-i) mod L}.

Why circulant: its eigenvalues are EXACTLY the DFT of the first row,
        λ_m = Σ_k a_k e^{-2πi mk/L},
which (for the divisor indicator) is the roots-of-unity DETECTOR we have used all along.
So "diagonalising the DNA matrix" literally recomputes the factor spectrum — the matrix
factorisation IS the integer detector in disguise, with the same reach and the same wall.

We show, on a small composite where the full matrix is tractable, and then argue the cofactor:
  1. eigenvalues of circ(DNA) — the factors light up as detector peaks (matrix = integer detector)
  2. SVD / LU / QR — all O(L³), trivial; their numbers are matrix invariants, not N's factors
  3. determinant & a Smith-normal-form integer invariant — a number, but NOT N, and factoring
     it tells you nothing about N (we check: gcd(det-invariant, N) is trivial)
  4. the cofactor: the only tractable matrix is over a window; its spectrum is flat → no primes.

Conclusion: factoring the matrix is easy and reveals matrix structure; it never reaches the
integer's primes, because the only place the primes live in the matrix is the eigenvalue
spectrum — and that spectrum is the same √N-bounded detector. Same wall, spectral costume.

Run:  .venv/bin/python hsln_dna_matrix_factor.py
"""
from __future__ import annotations

import math
import numpy as np
import matplotlib.pyplot as plt

from hsln_bitcoin_probe import KEYS, pubkey_x, peel_small_factors, SCAN_BOUND
from hsln_e8_torsion_factor import is_prime, FG, ACCENT, ACCENT2, COMP, GRID, save_fig

N_SMALL = 143          # 11 × 13 — full 143×143 circulant is tractable
WINDOW = 512           # window matrix size for the 249-bit cofactor


def divisor_dna(N: int, L: int) -> np.ndarray:
    """DNA vector a_k = [k | N] for k = 0..L-1 (a_0 := 0, '1' is implicit)."""
    a = np.zeros(L)
    for k in range(1, L):
        if N % k == 0:
            a[k] = 1.0
    return a


def circulant(row: np.ndarray) -> np.ndarray:
    L = len(row)
    return np.stack([np.roll(row, i) for i in range(L)], axis=0)


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def main():
    p, q = 11, 13
    dna = divisor_dna(N_SMALL, N_SMALL)              # length 143
    C = circulant(dna)

    # 1. eigenvalues via FFT (circulant diagonalises in the Fourier basis)
    eig = np.fft.fft(dna)
    detector = np.abs(eig) / 1.0                     # |λ_m|; peaks where m | N structure resonates
    # the detector over divisor index k (our usual view) for comparison
    ks = np.arange(2, N_SMALL)
    det_k = np.array([abs(np.exp(2j*np.pi*(np.arange(k)*N_SMALL % k)/k).sum())/k for k in ks])
    found = [int(k) for k in ks if det_k[k-2] > 0.5]

    print("=" * 74)
    print(" DNA → circulant matrix → factor the matrix")
    print("=" * 74)
    print(f"\n small composite N = {N_SMALL} = {p}×{q}")
    print(f"   circulant size              : {C.shape[0]}×{C.shape[1]}")
    print(f"   integer-detector spikes     : {found}  ← the factors")

    # 2. easy matrix factorisations — all polynomial, none give N's factors
    U, S, Vt = np.linalg.svd(C)
    detC = np.linalg.det(C)
    rankC = int(np.sum(S > 1e-9))
    print(f"\n matrix factorisations (all O(L³), trivial):")
    print(f"   SVD: largest singular value {S[0]:.3f}, rank {rankC}")
    print(f"   det(C) = {detC:.3e}")

    # 3. an integer invariant from the matrix: does it help factor N?
    # use the integer circulant determinant's nearest integer; gcd with N
    det_int = int(round(detC.real)) if abs(detC) < 1e15 else 0
    g = math.gcd(abs(det_int), N_SMALL) if det_int else 0
    print(f"\n integer invariant test:")
    print(f"   round(det C) = {det_int}")
    print(f"   gcd(det, N)  = {g}  ({'trivial — no factor leaked' if g in (1, N_SMALL, 0) else 'FACTOR!'})")

    # 4. the cofactor: only a windowed matrix is tractable
    x = pubkey_x(KEYS["genesis (block 0, Satoshi, unspent)"])
    _, cof = peel_small_factors(x, SCAN_BOUND)
    dna_c = divisor_dna(cof, WINDOW)
    eig_c = np.abs(np.fft.fft(dna_c))
    print(f"\n 249-bit cofactor, windowed {WINDOW}×{WINDOW} circulant:")
    print(f"   nonzero DNA entries in window : {int((dna_c>0).sum())}")
    print(f"   eigenvalue spread (max-min)   : {eig_c.max()-eig_c.min():.3e}  (≈0 ⇒ flat, no peaks)")
    print(f"\n ⇒ diagonalising the DNA matrix recomputes the same detector spectrum.")
    print(f"   Matrix factorisation is easy but reaches no prime the integer scan can't.")

    # ----------------------------------------------------------------- figure
    fig = plt.figure(figsize=(17, 10))
    fig.suptitle("DNA as a matrix — factoring the MATRIX is easy, but its spectrum is the "
                 "same integer detector", color=FG, fontsize=14.5, y=0.98)

    # 1 · the circulant DNA matrix itself
    ax = fig.add_subplot(2, 3, 1)
    im = ax.imshow(C, cmap="magma", interpolation="nearest")
    ax.set_title(f"1 · circ(DNA) for N={N_SMALL}={p}×{q}  ({C.shape[0]}×{C.shape[0]})",
                 color=FG, fontsize=11)
    ax.set_xticks([]); ax.set_yticks([])

    # 2 · eigenvalue magnitudes = the detector spectrum (factors light up)
    ax = fig.add_subplot(2, 3, 2)
    ax.plot(np.arange(N_SMALL), detector, color=ACCENT2, lw=0.8)
    # mark the Fourier modes corresponding to the factor structure
    for m in range(N_SMALL):
        if detector[m] > detector.mean() + 2*detector.std():
            ax.scatter([m], [detector[m]], s=30, c=ACCENT, zorder=5)
    ax.set_xlabel("Fourier mode m", color=FG)
    ax.set_ylabel("|λₘ| (eigenvalue mag)", color=FG)
    ax.set_title("2 · eigenvalues of circ(DNA) = the detector spectrum", color=FG, fontsize=11)
    _grid(ax)

    # 3 · singular value spectrum — easy, but structureless re: factors
    ax = fig.add_subplot(2, 3, 3)
    ax.semilogy(S + 1e-12, color=COMP, lw=1.2)
    ax.set_xlabel("index", color=FG); ax.set_ylabel("singular value", color=FG)
    ax.set_title(f"3 · SVD of circ(DNA): rank {rankC}, O(L³) — no factor info",
                 color=FG, fontsize=11)
    _grid(ax)

    # 4 · the integer-invariant test (gcd of det with N)
    ax = fig.add_subplot(2, 3, 4)
    ax.axis("off")
    txt = [
        ("Integer invariant from the matrix", ACCENT, 12),
        ("", FG, 5),
        (f"round(det C)  = {det_int}", FG, 10),
        (f"N             = {N_SMALL}", FG, 10),
        (f"gcd(det, N)   = {g}", "#ff6b6b" if g in (1, N_SMALL, 0) else "#7CFC8A", 11),
        ("", FG, 5),
        ("The matrix's determinant is a number — but it", FG, 10),
        ("is not N, and shares no factor with N. Matrix", FG, 10),
        ("invariants (det, rank, trace, char-poly) are", FG, 10),
        ("polynomial-time and live in a different ring", FG, 10),
        ("from N's factorisation.", FG, 10),
    ]
    yy = 0.97
    for t, c, sz in txt:
        ax.text(0.0, yy, t, color=c, fontsize=sz, va="top", transform=ax.transAxes)
        yy -= 0.075 if t else 0.035

    # 5 · the cofactor windowed matrix spectrum — flat
    ax = fig.add_subplot(2, 3, 5)
    ax.plot(np.arange(WINDOW), eig_c, color=ACCENT2, lw=0.7)
    ax.text(0.5, 0.6, "FLAT spectrum\nno eigenvalue peak in the window",
            transform=ax.transAxes, color=ACCENT2, fontsize=11, ha="center")
    ax.set_xlabel("Fourier mode m", color=FG); ax.set_ylabel("|λₘ|", color=FG)
    ax.set_title(f"5 · 249-bit cofactor circulant ({WINDOW}×{WINDOW}): flat",
                 color=FG, fontsize=11)
    _grid(ax)

    # 6 · verdict
    ax = fig.add_subplot(2, 3, 6)
    ax.axis("off")
    lines = [
        ("FACTOR THE MATRIX? — same wall, spectral", ACCENT, 12),
        ("", FG, 5),
        ("Key fact: a circulant diagonalises in the", ACCENT2, 11),
        ("Fourier basis, so its eigenvalues ARE the", FG, 10),
        ("roots-of-unity detector λₘ = Σ aₖ e^{-2πi mk/L}.", FG, 10),
        ("", FG, 4),
        ("So 'factor the DNA matrix' (diagonalise it)", FG, 10),
        ("= recompute the SAME integer detector —", FG, 10),
        ("same reach, same √N wall.", FG, 10),
        ("", FG, 5),
        ("• SVD/LU/QR: O(L³), trivial, no factor info", FG, 10),
        ("• det/rank/trace: matrix invariants ≠ N", FG, 10),
        ("• cofactor spectrum: flat → no prime", FG, 10),
        ("", FG, 5),
        ("Matrix factorisation is a DIFFERENT, easy", "#ff6b6b", 11),
        ("problem. It never crosses into integer", FG, 10),
        ("factoring. We remain completely safe.", FG, 10),
    ]
    yy = 0.99
    for t, c, sz in lines:
        ax.text(0.0, yy, t, color=c, fontsize=sz, va="top", transform=ax.transAxes)
        yy -= 0.055 if t else 0.026

    fig.subplots_adjust(left=0.05, right=0.97, top=0.91, bottom=0.07,
                        hspace=0.34, wspace=0.24)
    save_fig(fig, "65_hsln_dna_matrix_factor.png")


if __name__ == "__main__":
    main()
