"""HSLN end-to-end: a network described by a matrix state-space and a generating function.

A network is fully specified by two objects:
  - a MATRIX state-space: the genus-g period matrix Z in the Siegel upper half-space
    H_g (for g = 1, the 1x1 matrix Z = [tau]); and
  - a GENERATING FUNCTION: the modular/theta form
        F(Z) = sum_T  theta_T  exp(2 pi i tr(T Z)),
    whose coefficients theta (indexed by the half-integral matrices T) are the DNA.

Everything else -- the network's "topological space" of neurons -- is GENERATED from
these two: the neurons are the zeros of F over H_g, the attractors of the flow.

Composition: the tensor product of two networks multiplies their generating functions,
which is the Cauchy convolution of the DNAs and unions the zero sets:
    F_{A x B} = F_A * F_B,   theta_{A x B} = theta_A (*) theta_B,
    zeros(F_A F_B) = zeros(F_A) u zeros(F_B).

This module trains two tasks, tensors them, and tests the compound.

At genus 1 the matrix index T reduces to a scalar n and F = sum_n theta_n q^n,
q = exp(2 pi i tau); the matrix convolution becomes ordinary polynomial convolution.
"""
from __future__ import annotations

from dataclasses import dataclass

import jax
import jax.numpy as jnp
import numpy as np
from jax import value_and_grad

import modular

jax.config.update("jax_enable_x64", True)

LANE_Y = 0.18                       # input is encoded as a position on this lane in H_1
SIGMA = 0.35                        # spike sharpness (on the max-normalized |F|)
PROBES = jnp.round(jnp.linspace(0.06, 0.94, 12), 4)   # input positions sampled by a task


# --------------------------------------------------------------------- generating function
def field(dna, x, y=LANE_Y):
    """F(Z) at the 1x1 state matrix Z = [x + i y]."""
    q = jnp.exp(2j * jnp.pi * (x + 1j * y))
    return jnp.sum(dna * q ** jnp.arange(dna.shape[0]))


def _fmag(dna, x):
    f = field(dna, x)
    return jnp.sqrt(jnp.real(f * jnp.conj(f)))


def spike_map(dna, xs):
    """1/|F| spike readout along the input lane, in [0,1] (1 = on a neuron/zero)."""
    m = jax.vmap(lambda x: _fmag(dna, x))(xs)
    mn = m / (jnp.max(m) + 1e-12)
    return jnp.exp(-mn ** 2 / (2 * SIGMA ** 2))


# --------------------------------------------------------------------- the network object
@dataclass
class Network:
    genus: int
    dna: np.ndarray          # generating-function coefficients (the DNA)

    def zeros(self):
        """The generated topology: neurons = zeros of F in the q-disk."""
        return modular.qpoly_zeros(np.asarray(self.dna))

    def spikes(self, xs=PROBES):
        return np.array(spike_map(jnp.asarray(self.dna), jnp.asarray(xs)))


def tensor(a: Network, b: Network) -> Network:
    """Tensor product: multiply the generating functions = convolve the DNAs."""
    assert a.genus == b.genus
    return Network(a.genus, np.convolve(np.asarray(a.dna), np.asarray(b.dna)))


# --------------------------------------------------------------------- training a task
def _central_init(seed, dg):
    rng = np.random.default_rng(seed)
    zeros = np.array([0.5 + (LANE_Y + 0.04 * k) * 1j for k in range(dg - 1)])
    c = np.poly(np.exp(2j * np.pi * zeros))[::-1]
    c = c / np.max(np.abs(c))
    return jnp.array(np.concatenate([c.real, c.imag]) + 0.04 * rng.standard_normal(2 * dg))


def train_task(target, dg=5, steps=1500, lr=0.01, seed=0):
    """Train a DNA so its spike map matches `target` over PROBES."""
    target = jnp.asarray(target, dtype=float)

    def to_dna(p):
        return p[:dg] + 1j * p[dg:]

    def loss(p):
        return jnp.sum((spike_map(to_dna(p), PROBES) - target) ** 2) + 1e-4 * jnp.sum(p ** 2)

    lg = jax.jit(value_and_grad(loss))
    p = _central_init(seed, dg)
    m = jnp.zeros_like(p); v = jnp.zeros_like(p)
    b1, b2, eps = 0.9, 0.999, 1e-8
    hist = []
    for t in range(1, steps + 1):
        L, g = lg(p)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        p = p - lr * (m / (1 - b1 ** t)) / (jnp.sqrt(v / (1 - b2 ** t)) + eps)
        hist.append(float(L))
    return Network(1, np.array(to_dna(p))), hist


# --------------------------------------------------------------------- the experiment
# Task A: a detector that spikes at two input positions; Task B: spikes at a third.
TARGET_A = np.array([0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0], dtype=float)  # probes 0.22, 0.54
TARGET_B = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], dtype=float)  # probe  0.78
TARGET_UNION = np.maximum(TARGET_A, TARGET_B)


def run(make_fig=True):
    netA, hA = train_task(TARGET_A, seed=1)
    netB, hB = train_task(TARGET_B, seed=2)
    netAB = tensor(netA, netB)

    sA, sB, sAB = netA.spikes(), netB.spikes(), netAB.spikes()
    print(f"task A loss {hA[0]:.3f}->{hA[-1]:.4f}   task B loss {hB[0]:.3f}->{hB[-1]:.4f}")
    print("probe      :", " ".join(f"{p:.2f}" for p in np.array(PROBES)))
    print("target A|B :", " ".join(f"{t:.0f}   " for t in TARGET_UNION))
    print("compound AB:", " ".join(f"{s:.2f}" for s in sAB))
    hit = np.all((sAB > 0.5) == (TARGET_UNION > 0.5))
    print(f"compound matches the UNION of both tasks: {hit}")
    print(f"neurons: A={len(netA.zeros())}  B={len(netB.zeros())}  AB={len(netAB.zeros())}")

    if make_fig:
        _figure(netA, netB, netAB, hA, hB)
    return netA, netB, netAB


def _figure(netA, netB, netAB, hA, hB):
    import matplotlib.pyplot as plt
    from pathlib import Path
    import style

    xs = np.linspace(0.05, 0.95, 500)
    cA, cB, cAB = "#46f0d0", "#ffd166", "#ff3b6b"
    dA = [0.22, 0.54]; dB = [0.78]

    fig, ax = plt.subplots(1, 3, figsize=(16.5, 4.8), gridspec_kw={"width_ratios": [1.3, 1.3, 1]})

    ax[0].plot(xs, np.array(spike_map(jnp.asarray(netA.dna), jnp.asarray(xs))), color=cA, lw=2, label="task A")
    ax[0].plot(xs, np.array(spike_map(jnp.asarray(netB.dna), jnp.asarray(xs))), color=cB, lw=2, label="task B")
    for d in dA: ax[0].axvline(d, color=cA, ls=":", lw=1, alpha=0.6)
    for d in dB: ax[0].axvline(d, color=cB, ls=":", lw=1, alpha=0.6)
    ax[0].set_title("two trained detectors", fontsize=12)
    ax[0].set_xlabel("input position (Re τ)"); ax[0].set_ylabel("spike  1/|F|→"); ax[0].set_ylim(0, 1.1)
    ax[0].legend(fontsize=9, framealpha=0.3)

    ax[1].plot(xs, np.array(spike_map(jnp.asarray(netAB.dna), jnp.asarray(xs))), color=cAB, lw=2.4, label="A ⊗ B")
    for d in dA + dB:
        ax[1].axvline(d, color="white", ls=":", lw=1, alpha=0.5)
    ax[1].set_title("compound = tensor product:  spikes at the UNION", fontsize=12)
    ax[1].set_xlabel("input position (Re τ)"); ax[1].set_ylim(0, 1.1)
    ax[1].legend(fontsize=9, framealpha=0.3)

    ax[2].set_facecolor("#0b0b14")
    for net, c, lab in [(netA, cA, "A"), (netB, cB, "B")]:
        z = net.zeros()
        ax[2].plot(z.real, z.imag, "o", color=c, ms=9, mfc="none", mew=2, label=f"zeros({lab})")
    z = netAB.zeros()
    ax[2].plot(z.real, z.imag, "x", color=cAB, ms=8, mew=1.6, label="zeros(A⊗B)")
    ax[2].axhline(LANE_Y, color="#555", ls="--", lw=0.8)
    ax[2].set_xlim(0, 1); ax[2].set_ylim(0.05, 0.9)
    ax[2].set_xlabel("Re τ"); ax[2].set_ylabel("Im τ")
    ax[2].set_title("generated topology (neurons)\nzeros(A⊗B) = zeros(A) ∪ zeros(B)", fontsize=11)
    ax[2].legend(fontsize=8, framealpha=0.3, loc="upper right")

    fig.suptitle("End-to-end: train two tasks, tensor their generating functions, the compound does both",
                 fontsize=13, y=1.02)
    out = Path(__file__).parent / "figures" / "18_e2e_compose.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
