"""hsln_bignum_dna.py — train HSLN onto a very large semiprime N and look for spikes.

Given a 300-digit candidate semiprime N:
  • compute pos(N) = frac(log2 N) using mpmath (need ~1000 digits)
  • snap to closest HSLN probe, train an HSLN whose spike target is one at that probe
  • plot the resulting DNA, its zeros, and the spike map 1/|F(τ)| along the input lane

Honest framing:
  pos(p·q) = (pos p + pos q) mod 1 is a homomorphism that collapses 2D info to 1D.
  A single training target at pos(N) cannot uniquely recover (pos p, pos q).
  But the trained polynomial F (degree dg) has dg−1 zeros — only ONE of which sits at
  τ_target. Where the other dg−2 land is a function of the optimisation landscape, not
  of (p, q). We expose those landing points so it's clear what's signal and what isn't.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import mpmath as mp

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import hsln       # local
import modular    # local
import hsln_factor_dna as hfd

mpl.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'legend.fontsize': 9,
})

FIG_DIR = HERE / 'figures'
LANE_Y = hsln.LANE_Y


N = int(
    '166676643314584569958125813524374853850083785881267462323651768559185366'
    '646505119707799853485290918612561698303977783991775165717684449220544363'
    '028622922480770756515483472420766057443435764616491550621788433875024432'
    '407476217390626662231604324648161458493720460593796610261829131415544504'
    '730771491377407032047'
)


def pos_of_bigint(n: int, dps: int = 1100) -> float:
    """frac(log2 n) computed at high precision, returned as a 64-bit float."""
    mp.mp.dps = dps
    L = mp.log(n, 2)
    frac = L - mp.floor(L)
    return float(frac)


def main():
    print("=" * 78)
    print(f'  HSLN dances to a ~1000-bit candidate semiprime')
    print("=" * 78)

    n_digits = len(str(N))
    n_bits = N.bit_length()
    print(f'\n  N has {n_digits} decimal digits, {n_bits} bits.')
    print(f'  (RSA-1024 = 309 digits / 1024 bits — this is in that ballpark.)')

    pos_N = pos_of_bigint(N)
    probe_idx = hfd.closest_probe(pos_N)
    probes = np.array(hsln.PROBES)
    probe = float(probes[probe_idx])
    print(f'\n  pos(N) = frac(log2 N) = {pos_N:.10f}')
    print(f'  Closest probe index {probe_idx} at position {probe:.4f}')
    print(f'  Encoding error |pos - probe| = {abs(pos_N - probe):.4f}')

    # ── Train HSLN with a single-spike target at probe_idx ────────────────────
    target = np.zeros_like(probes, dtype=float)
    target[probe_idx] = 1.0
    print(f'\n  Training HSLN  dg=12, steps=3000  (one-hot target at probe {probe_idx})...')
    net, hist = hfd.train(target, dg=12, steps=3000, seed=0)
    print(f'  loss: {hist[0]:.4f}  →  {hist[-1]:.6f}')

    dna = np.asarray(net.dna)

    # ── Where are the zeros of the trained polynomial in τ-space? ─────────────
    zeros = modular.qpoly_zeros(dna)
    zeros_sorted = sorted(zeros, key=lambda z: z.real % 1.0)
    print(f'\n  Trained DNA has {len(zeros_sorted)} zeros in the upper half-plane:')
    print(f'      idx |   Re τ      Im τ    | distance to pos(N)')
    print(f'    ------+----------------------+-------------------')
    for i, z in enumerate(zeros_sorted):
        re = z.real % 1.0
        dist = min(abs(re - pos_N), 1 - abs(re - pos_N))
        marker = '  ← closest to pos(N)' if i == np.argmin([
            min(abs(z.real % 1.0 - pos_N), 1 - abs(z.real % 1.0 - pos_N))
            for z in zeros_sorted
        ]) else ''
        print(f'      {i:2d}  | {re:.4f}   {z.imag:.4f}   |    {dist:.4f}{marker}')

    # ── Spike map along the lane ──────────────────────────────────────────────
    xs = np.linspace(0.0, 1.0, 2000)
    F_vals = modular.qpoly(dna, xs + 1j * LANE_Y)
    fmag = np.abs(F_vals)
    spike = 1.0 / (fmag + 1e-12)
    spike_norm = spike / spike.max()

    # ── Quick trial division up to 100k via a sieve (free sanity check) ───────
    print(f'\n  Quick trial division up to 10^5 (free sanity check)...')
    LIMIT = 10**5
    sieve = np.ones(LIMIT, dtype=bool); sieve[:2] = False
    for i in range(2, int(LIMIT**0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = False
    primes_small = np.nonzero(sieve)[0]
    small_factor = None
    for p in primes_small:
        if N % int(p) == 0:
            small_factor = int(p)
            break
    if small_factor is None:
        print(f'  No factor found below 10^5  (consistent with adversarial composite)')
    else:
        print(f'  Trivial factor found: N = {small_factor} · ({N // small_factor})')

    # ── Visualisation ─────────────────────────────────────────────────────────
    fig = plt.figure(figsize=(15.5, 12.0))
    gs = fig.add_gridspec(3, 2, height_ratios=[1, 1.3, 1.3], hspace=0.50, wspace=0.30)

    # A. DNA magnitudes
    ax = fig.add_subplot(gs[0, 0])
    mags = np.abs(dna)
    indices_dna = np.arange(len(dna))
    ax.bar(indices_dna, mags, color='#2ca02c', edgecolor='black', alpha=0.85, width=0.85)
    ax.set_xlabel('coefficient index n')
    ax.set_ylabel('|aₙ|')
    ax.set_title(f'A. Trained DNA magnitudes  (dg = {len(dna)})')
    ax.grid(alpha=0.3, axis='y')

    # B. DNA path in complex plane
    ax = fig.add_subplot(gs[0, 1])
    cmap = plt.cm.viridis
    cols = cmap(indices_dna / max(indices_dna.max(), 1))
    ax.plot(dna.real, dna.imag, '-', color='gray', alpha=0.4, linewidth=1)
    for i, (an, c) in enumerate(zip(dna, cols)):
        ax.scatter(an.real, an.imag, color=c, s=80, edgecolor='black',
                   linewidth=0.4, zorder=5)
        ax.annotate(f'a{i}', (an.real, an.imag), textcoords='offset points',
                    xytext=(7, 4), fontsize=8, fontweight='bold')
    ax.axhline(0, color='black', linewidth=0.4)
    ax.axvline(0, color='black', linewidth=0.4)
    M = max(mags) * 1.15
    ax.set_xlim(-M, M); ax.set_ylim(-M, M); ax.set_aspect('equal')
    ax.set_xlabel('Re aₙ'); ax.set_ylabel('Im aₙ')
    ax.set_title('B. DNA path in ℂ')
    ax.grid(alpha=0.3)

    # C. Spike map along the lane with all zeros and pos(N) marked
    ax = fig.add_subplot(gs[1, :])
    ax.fill_between(xs, 0, spike_norm, color='#9467bd', alpha=0.55)
    ax.plot(xs, spike_norm, color='#54286b', linewidth=1.2)
    # Mark pos(N)
    ax.axvline(pos_N, color='red', linewidth=1.8, linestyle='-', label=f'pos(N) = {pos_N:.4f}')
    # Mark each probe
    for j, p in enumerate(probes):
        ax.axvline(float(p), color='gray', linewidth=0.5, linestyle=':')
    # Mark each zero
    for z in zeros_sorted:
        re = z.real % 1.0
        ax.scatter([re], [1.04], marker='v', color='black', s=60, zorder=5)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.12)
    ax.set_xlabel(f'position on input lane  Re τ ∈ [0, 1)   (Im τ = LANE_Y = {LANE_Y})')
    ax.set_ylabel('normalised spike  1/|F(τ)|')
    ax.set_title(f'C. Spike map after training onto pos(N).  '
                 f'Black triangles = zeros of F. Red line = pos(N).')
    ax.legend(loc='upper right')
    ax.grid(alpha=0.3)

    # D. Neuron landscape — log|F(τ)| heatmap
    ax = fig.add_subplot(gs[2, 0])
    Nx, Ny = 300, 200
    xs_g = np.linspace(0.0, 1.0, Nx)
    ys_g = np.linspace(0.05, 0.50, Ny)
    Xg, Yg = np.meshgrid(xs_g, ys_g)
    F_grid = modular.qpoly(dna, Xg + 1j * Yg)
    logF = np.log10(np.abs(F_grid) + 1e-12)
    pcm = ax.pcolormesh(Xg, Yg, logF, shading='auto', cmap='magma_r',
                        vmin=np.percentile(logF, 5),
                        vmax=np.percentile(logF, 95))
    plt.colorbar(pcm, ax=ax, label='log₁₀ |F(τ)|')
    for z in zeros_sorted:
        re = z.real % 1.0
        ax.scatter([re], [z.imag], marker='o', s=80, edgecolor='cyan',
                   facecolors='none', linewidth=1.8)
    ax.axhline(LANE_Y, color='cyan', linestyle='--', linewidth=0.7, alpha=0.6)
    ax.axvline(pos_N, color='red', linewidth=1.0, alpha=0.7)
    ax.set_xlim(0, 1); ax.set_ylim(0.05, 0.50)
    ax.set_xlabel('Re τ'); ax.set_ylabel('Im τ')
    ax.set_title('D. Neuron landscape — log₁₀|F(τ)| with zeros (cyan)')

    # E. Sub-spike around pos(N): zoom in
    ax = fig.add_subplot(gs[2, 1])
    zoom_w = 0.30
    xs_zoom = np.linspace(max(0.0, pos_N - zoom_w), min(1.0, pos_N + zoom_w), 1200)
    Fz = modular.qpoly(dna, xs_zoom + 1j * LANE_Y)
    sp = 1.0 / (np.abs(Fz) + 1e-12)
    sp_norm = sp / sp.max()
    ax.fill_between(xs_zoom, 0, sp_norm, color='#1f77b4', alpha=0.55)
    ax.plot(xs_zoom, sp_norm, color='#103a5e', linewidth=1.4)
    ax.axvline(pos_N, color='red', linewidth=1.8, label=f'pos(N) = {pos_N:.4f}')
    for j, p in enumerate(probes):
        if abs(float(p) - pos_N) < zoom_w + 0.02:
            ax.axvline(float(p), color='gray', linewidth=0.6, linestyle=':',
                       label='probe' if j == probe_idx else None)
    for z in zeros_sorted:
        re = z.real % 1.0
        if abs(re - pos_N) < zoom_w + 0.02:
            ax.scatter([re], [1.04], marker='v', color='black', s=70, zorder=5)
    ax.set_xlim(xs_zoom[0], xs_zoom[-1])
    ax.set_ylim(0, 1.12)
    ax.set_xlabel('Re τ (zoomed around pos(N))')
    ax.set_ylabel('normalised spike  1/|F(τ)|')
    ax.set_title('E. Zoom: is the spike actually at pos(N)?')
    ax.legend(loc='upper right', fontsize=8)
    ax.grid(alpha=0.3)

    fig.suptitle(
        f'HSLN trained onto a 309-digit candidate semiprime\n'
        f'pos(N) = {pos_N:.4f}  →  probe {probe_idx} ({probe:.4f}).  '
        f'Loss {hist[-1]:.2e}.  N has {n_bits} bits.',
        fontsize=13, y=0.995,
    )
    out = FIG_DIR / '50_hsln_bignum_dna.png'
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'\n  ✓ {out.name}')

    # ── Honest scoping ────────────────────────────────────────────────────────
    print()
    print('  ─── Honest scoping ───')
    print('  pos(p·q) = (pos p + pos q) mod 1 — a homomorphism collapsing 2D → 1D.')
    print('  Training onto pos(N) cannot recover (pos p, pos q) uniquely.')
    print('  The trained DNA has dg−1 = 11 zeros: ONE near pos(N) is signal, the rest')
    print('  are landings of optimisation. They do NOT correspond to pos(p), pos(q).')
    print('  See the spike map (panel C): the only meaningful peak is at pos(N).')


if __name__ == '__main__':
    main()
