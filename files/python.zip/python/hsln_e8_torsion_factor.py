"""
E8 × Siegel factoring — the projection reveals the prime factors.

[REDACTED NAME]'s conjecture (geometric form): take N, drive a "gravity DNA" to pull a marker
onto N in the space; hold E8 × E8 and contort the second copy (torsion); project back
down and the special points on the way to N are its prime factors.

The honest, faithful reading (what this figure shows):

  * E8 / the Coxeter plane is the PICTURE — the ambient lattice (panels 1-3).
  * The ENGINE is an arithmetic identity we already use (the roots-of-unity sieve /
    inverse Euler product, the Fourier-divisor DNA of the genus-1 Siegel/Eisenstein
    form E4 = Θ(E8)). The detector

        D(k) = (1/k) | Σ_{j<k} exp(2πi·jN/k) |   =  1 iff k | N

    "lights up" exactly at the divisors of N. Among the divisors the PRIME ones are
    the factors. (panels 4-6).

The conjecture generalises cleanly: for N a product of k DISTINCT primes the projection
lights up k prime-points — the k factors. Semiprime → 2 points; p·q·r → 3 points; etc.
(A prime power pⁿ has a single distinct prime, so it shows one factor-point, not two —
it was never a counterexample.)

Run:  .venv/bin/python hsln_e8_torsion_factor.py [--p 17 --q 19] [--animate]
"""
from __future__ import annotations

import argparse
import os
import numpy as np
import matplotlib.pyplot as plt

import style  # importing sets the shared dark rcParams
from e8 import shells, coxeter_plane

FG = style.PAPER          # light ink
BG = style.INK            # dark background
ACCENT = style.ACCENT     # warm yellow — the prime factors
ACCENT2 = "#4cc9f0"       # cyan — divisors / second voice
COMP = "#9b8cff"          # violet — composite (non-prime) divisors
GRID = "#555566"
palette = ["#ffd166", "#4cc9f0", "#ff3b6b", "#55a868", "#9b8cff", "#dd8452"]


def save_fig(fig, name: str) -> None:
    out = os.path.join(os.path.dirname(__file__), "figures", name)
    fig.savefig(out, facecolor=BG)
    print(f"saved {out}")


def e8_root_projection() -> np.ndarray:
    """The 240 E8 roots in the true Coxeter plane (8 rings of 30)."""
    return coxeter_plane(shells(2.0)[2])


# --------------------------------------------------------------------------
# Number theory: the things the conjecture is actually about
# --------------------------------------------------------------------------
def is_prime(n: int) -> bool:
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True


def interior_divisors(n: int) -> list[int]:
    """Divisors of n excluding 1 and n -- the 'points on the way to N'."""
    return [d for d in range(2, n) if n % d == 0]


def prime_factors(n: int) -> list[int]:
    """The DISTINCT prime factors of n -- what the projection should reveal."""
    return [d for d in interior_divisors(n) + [n] if is_prime(d) and n % d == 0]


def detector(N: int, k: int) -> float:
    """Roots-of-unity / inverse-Euler-product detector: 1 iff k | N, else < 1.

    D(k) = (1/k) | Σ_{j<k} exp(2πi·jN/k) |.  A geometric series of k-th roots of
    unity that sums coherently to k exactly when k divides N.
    """
    j = np.arange(k)
    return float(np.abs(np.exp(2j * np.pi * j * N / k).sum()) / k)


def detector_prime_spikes(N: int) -> list[int]:
    """Primes k < N where the projection fires -- i.e. the recovered prime factors."""
    return [k for k in range(2, N) if is_prime(k) and detector(N, k) > 0.5]


# --------------------------------------------------------------------------
# E8 geometry helpers
# --------------------------------------------------------------------------
def gravity_well(points: np.ndarray, center: np.ndarray, mass: float) -> np.ndarray:
    """Torsion field: pull every point toward `center` with strength ~ mass / r."""
    delta = center - points
    r = np.linalg.norm(delta, axis=1, keepdims=True) + 1e-9
    return points + mass * delta / r


def embed_integers(ms: np.ndarray, N: int, r_max: float) -> np.ndarray:
    """Prime-BLIND embedding of integers into the Coxeter plane.

    radius ~ log m (multiplication is additive in radius: log p + log q = log N)
    angle  = 2π (m mod 30) / 30   (ties to E8's 30-fold Coxeter symmetry).
    Uses only m, never its factorization.
    """
    r = r_max * np.log(ms) / np.log(N)
    theta = 2 * np.pi * (ms % 30) / 30.0
    return np.stack([r * np.cos(theta), r * np.sin(theta)], axis=1)


def bent_path(start, end, center, mass, n=200) -> np.ndarray:
    t = np.linspace(0, 1, n)[:, None]
    line = start * (1 - t) + end * t
    return gravity_well(line, center, mass)


# --------------------------------------------------------------------------
# Battery: the projection's prime-spikes match the true prime-factor count
# --------------------------------------------------------------------------
def run_battery():
    cases = [
        ((3, 5), "p·q"), ((5, 7), "p·q"), ((11, 13), "p·q"),
        ((17, 19), "p·q"), ((23, 29), "p·q"),
        ((2, 3, 5), "p·q·r"), ((3, 5, 7), "p·q·r"),
        ((2, 3, 7), "p·q·r"), ((5, 7, 11), "p·q·r"),
        ((2, 3, 5, 7), "p·q·r·s"),
    ]
    print("=" * 76)
    print(" The roots-of-unity projection reveals exactly the distinct prime factors")
    print("=" * 76)
    print(f" {'N':>7}  {'form':>8}  {'true factors':>22}  {'projection fires':>22}  match")
    print("-" * 76)
    rows, all_match = [], True
    for primes, form in cases:
        N = int(np.prod(primes))
        true = sorted(set(primes))
        found = detector_prime_spikes(N)
        ok = found == true
        all_match &= ok
        rows.append((N, form, true, found, ok))
        print(f" {N:>7}  {form:>8}  {str(true):>22}  {str(found):>22}  "
              f"{'OK' if ok else 'MISS'}")
    print("-" * 76)
    print(f" verdict: projection's prime-spikes = distinct prime factors on "
          f"{sum(r[4] for r in rows)}/{len(rows)} cases")
    print(f" cost note: first spike appears only at the least factor (~√N) — "
          f"a faithful picture, not a sub-√N shortcut.")
    return rows


# --------------------------------------------------------------------------
# Figure
# --------------------------------------------------------------------------
def _square(ax):
    ax.set_aspect("equal")
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_color(GRID)


def _grid(ax):
    ax.grid(True, color=GRID, lw=0.5, alpha=0.6)
    ax.tick_params(colors=FG)
    for s in ax.spines.values():
        s.set_color(GRID)


def _detector_panel(ax, N, idx, title):
    """Stem-style detector spectrum; prime divisors = factors (yellow), composite
    divisors (violet), everything else cyan baseline."""
    ks = np.arange(2, N)
    spec = np.array([detector(N, int(k)) for k in ks])
    ax.plot(ks, spec, color=ACCENT2, lw=0.7, alpha=0.8)
    divs = interior_divisors(N)
    for d in divs:
        prime = is_prime(d)
        ax.vlines(d, 0, 1, color=(ACCENT if prime else COMP), lw=2.2 if prime else 1.4)
        ax.scatter([d], [1.0], s=(80 if prime else 34),
                   c=(ACCENT if prime else COMP), edgecolors=FG, linewidths=0.5,
                   zorder=5)
        if prime:
            ax.annotate(str(d), (d, 1.02), color=ACCENT, fontsize=9, ha="center",
                        va="bottom")
    ax.axhline(0.5, color=GRID, ls="--", lw=0.7)
    ax.set_ylim(0, 1.18)
    ax.set_xlabel("k", color=FG)
    ax.set_title(title, color=FG, fontsize=12)
    _grid(ax)


def make_figure(p, q, triple, out):
    N = p * q
    N3 = int(np.prod(triple))
    proj = e8_root_projection()
    r_max = np.abs(proj).max() * 0.98

    fig = plt.figure(figsize=(17, 10))
    fig.suptitle(
        f"E8 × Siegel factoring — the projection reveals the primes   "
        f"(N = {p}×{q} = {N};  three-prime case {'×'.join(map(str, triple))} = {N3})",
        color=FG, fontsize=15, y=0.98,
    )

    # 1 · E8 Coxeter plane (the picture)
    ax = fig.add_subplot(2, 3, 1)
    ax.scatter(proj[:, 0], proj[:, 1], s=14, c=ACCENT2, alpha=0.75, lw=0)
    ax.set_title("1 · E8 probe lattice  (240 roots, 8 rings of 30)", color=FG, fontsize=12)
    _square(ax)

    # 2 · second E8 contorted toward N (torsion field)
    ax = fig.add_subplot(2, 3, 2)
    theta_N = 2 * np.pi * (N % 30) / 30.0
    center = 1.18 * r_max * np.array([np.cos(theta_N), np.sin(theta_N)])
    mass = 0.55 * r_max
    pulled = gravity_well(proj, center, mass)
    disp = np.linalg.norm(pulled - proj, axis=1)
    ax.quiver(proj[:, 0], proj[:, 1], (pulled - proj)[:, 0], (pulled - proj)[:, 1],
              disp, cmap="inferno", angles="xy", scale_units="xy", scale=1,
              width=0.004, alpha=0.9)
    ax.scatter(*center, s=170, marker="*", c=ACCENT, zorder=5, edgecolors=FG, linewidths=0.6)
    ax.annotate("N", center, color=FG, fontsize=12, xytext=(6, 6),
                textcoords="offset points")
    ax.set_title("2 · second E8 contorted toward N  (torsion field)", color=FG, fontsize=12)
    _square(ax)

    # 3 · bent geodesic; the prime-factor sites
    ax = fig.add_subplot(2, 3, 3)
    ms = np.arange(2, N)
    sites = embed_integers(ms, N, r_max)
    end = embed_integers(np.array([N]), N, r_max)[0]
    path = bent_path(np.zeros(2), end, center, mass)
    div_set = set(interior_divisors(N))
    is_div = np.array([m in div_set for m in ms])
    ax.scatter(sites[~is_div, 0], sites[~is_div, 1], s=8, c=GRID, alpha=0.5, lw=0,
               label="integer sites")
    ax.plot(path[:, 0], path[:, 1], color=FG, lw=1.4, alpha=0.85, zorder=2)
    ax.scatter(sites[is_div, 0], sites[is_div, 1], s=120, marker="D", c=ACCENT,
               edgecolors=FG, linewidths=0.7, zorder=4,
               label=f"prime factors {sorted(div_set)}")
    ax.scatter(*end, s=160, marker="*", c=ACCENT2, edgecolors=FG, linewidths=0.6,
               zorder=5, label="N")
    ax.legend(loc="upper left", fontsize=7.5, framealpha=0.25, labelcolor=FG)
    ax.set_title("3 · path to N over the lattice  (factors marked)", color=FG, fontsize=12)
    lim = 1.25 * r_max
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
    _square(ax)

    # 4 · roots-of-unity detector, semiprime → 2 factor-spikes
    _detector_panel(fig.add_subplot(2, 3, 4), N, 4,
                    f"4 · projection of N = {p}×{q}: 2 prime-spikes = the factors")

    # 5 · roots-of-unity detector, three primes → 3 factor-spikes
    _detector_panel(fig.add_subplot(2, 3, 5), N3, 5,
                    f"5 · projection of {'×'.join(map(str, triple))}: 3 prime-spikes "
                    f"('with 3 it works')")

    # 6 · verdict: prime-spikes counted = number of distinct prime factors
    ax = fig.add_subplot(2, 3, 6)
    rows = run_battery.cache  # set by main before calling
    labels = [str(r[0]) for r in rows]
    true_k = [len(r[2]) for r in rows]
    found_k = [len(r[3]) for r in rows]
    x = np.arange(len(rows))
    ax.bar(x - 0.2, true_k, 0.4, color=ACCENT2, edgecolor=FG, linewidth=0.5,
           label="distinct prime factors ω(N)")
    ax.bar(x + 0.2, found_k, 0.4, color=ACCENT, edgecolor=FG, linewidth=0.5,
           label="projection prime-spikes")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=60, fontsize=7)
    ax.set_ylabel("count", color=FG)
    ax.set_yticks(range(0, max(true_k) + 2))
    ax.legend(fontsize=8, labelcolor=FG, framealpha=0.2, loc="upper left")
    ax.set_title("6 · VERDICT — spikes match factor count exactly", color=FG, fontsize=12)
    _grid(ax)

    fig.text(0.5, 0.045,
             "YAY   the prime factors are exactly the points the roots-of-unity projection lights up; "
             "k distinct primes → k factor-points. E8 / the Coxeter plane is the faithful picture.",
             color=ACCENT, fontsize=11, ha="center", va="bottom")
    fig.text(0.5, 0.012,
             "Engine = the inverse-Euler / divisor DNA of the genus-1 Siegel form E4 = Θ(E8). "
             "Honest cost: the first spike sits at the least factor (~√N) — a picture, not a shortcut.",
             color=FG, fontsize=10.5, ha="center", va="bottom")

    fig.subplots_adjust(left=0.05, right=0.97, top=0.91, bottom=0.17, hspace=0.42, wspace=0.22)
    save_fig(fig, out)


# --------------------------------------------------------------------------
# Optional animation: the torsion dial bending the path to N
# --------------------------------------------------------------------------
def make_animation(p, q, out):
    import matplotlib.animation as animation
    N = p * q
    proj = e8_root_projection()
    r_max = np.abs(proj).max() * 0.98
    theta_N = 2 * np.pi * (N % 30) / 30.0
    center = 1.18 * r_max * np.array([np.cos(theta_N), np.sin(theta_N)])
    end = embed_integers(np.array([N]), N, r_max)[0]
    ms = np.arange(2, N)
    sites = embed_integers(ms, N, r_max)
    div_set = set(interior_divisors(N))
    is_div = np.array([m in div_set for m in ms])

    fig, ax = plt.subplots(figsize=(7, 7))
    fig.patch.set_facecolor(BG)
    _square(ax)
    lim = 1.4 * r_max
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
    ax.scatter(proj[:, 0], proj[:, 1], s=8, c=ACCENT2, alpha=0.25, lw=0)
    ax.scatter(sites[is_div, 0], sites[is_div, 1], s=110, marker="D", c=ACCENT,
               edgecolors=FG, linewidths=0.6, zorder=4)
    ax.scatter(*end, s=150, marker="*", c=ACCENT2, edgecolors=FG, zorder=5)
    (pl,) = ax.plot([], [], color=FG, lw=1.6)
    title = ax.set_title("", color=FG)
    masses = np.concatenate([np.linspace(0, 0.55 * r_max, 40), np.full(15, 0.55 * r_max)])

    def update(i):
        m = masses[i]
        path = bent_path(np.zeros(2), end, center, m)
        pl.set_data(path[:, 0], path[:, 1])
        title.set_text(f"torsion dial: mass={m / r_max:.2f}  (N={p}×{q}={N})")
        return pl, title

    anim = animation.FuncAnimation(fig, update, frames=len(masses), interval=60, blit=False)
    path_out = os.path.join(os.path.dirname(__file__), "figures", out)
    anim.save(path_out, writer="ffmpeg", dpi=120, savefig_kwargs={"facecolor": BG})
    print(f"saved {path_out}")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--p", type=int, default=17)
    ap.add_argument("--q", type=int, default=19)
    ap.add_argument("--animate", action="store_true")
    args = ap.parse_args()

    run_battery.cache = run_battery()
    print()
    make_figure(args.p, args.q, (3, 5, 7), "57_hsln_e8_torsion_factor.png")
    if args.animate:
        make_animation(args.p, args.q, "anim_e8_torsion_factor.mp4")


if __name__ == "__main__":
    main()
