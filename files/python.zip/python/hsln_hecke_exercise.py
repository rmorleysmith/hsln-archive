"""hsln_hecke_exercise.py — exercise HSLNHecke.fourier_determined_by_primes_genus1 on real numbers.

The sorry-free genus-1 Andrianov-Hecke theorem: a Hecke eigenform's coefficient sequence
(a_n) is DETERMINED by its prime values (a_p), via
    (1) Hecke recursion   a_{p^{r+2}} = a_p·a_{p^{r+1}} − p^{k-1}·a_{p^r}
    (2) multiplicativity  a_{mn} = a_m·a_n   for gcd(m,n)=1.

We use the most explicit eigenform: Δ = η^24 ∈ S_12(SL₂ℤ), weight k=12, whose coefficients
are Ramanujan's τ(n). We:
  • build τ(1..M) from the q-expansion (no factoring used),
  • EXERCISE the theorem forward: reconstruct τ(N) for composite N from ONLY the primes,
  • then test it BACKWARD as a factoring tool, and show precisely where it stops.
"""
from __future__ import annotations

import sys
from math import comb, isqrt
from pathlib import Path

import numpy as np

K = 12                      # weight of Δ ; the recursion uses p^{k-1} = p^11
M = 2600                    # number of τ-coefficients to build


def build_tau(M: int) -> list[int]:
    """τ(1..M-1) from Δ = q·∏_{n≥1}(1−q^n)^24.  Exact big integers, no factoring."""
    c = np.zeros(M, dtype=object)      # coefficients of ∏(1−q^n)^24
    c[0] = 1
    for n in range(1, M):
        terms = [(j * n, comb(24, j) * (-1) ** j) for j in range(25) if j * n < M]
        newc = np.zeros(M, dtype=object)
        for shift, co in terms:
            newc[shift:] = newc[shift:] + co * c[:M - shift]
        c = newc
    # τ(n) = coeff of q^n in q·∏ = c_{n-1}
    return [int(c[n - 1]) for n in range(1, M)]      # tau[i] = τ(i+1); index helper below


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    for d in range(2, isqrt(n) + 1):
        if n % d == 0:
            return False
    return True


def factorize(n: int) -> dict[int, int]:
    """Honest trial-division factorization (used only for small demo composites)."""
    f, d = {}, 2
    while d * d <= n:
        while n % d == 0:
            f[d] = f.get(d, 0) + 1
            n //= d
        d += 1
    if n > 1:
        f[n] = f.get(n, 0) + 1
    return f


def main():
    print("Building τ(1..%d) from the η^24 q-expansion (no factoring) ..." % (M - 1))
    tau_list = build_tau(M)
    tau = {n: tau_list[n - 1] for n in range(1, M)}   # τ(n)

    # sanity vs known values
    known = {1: 1, 2: -24, 3: 252, 4: -1472, 5: 4830, 6: -6048, 7: -16744,
             8: 84480, 11: 534612, 12: -370944}
    ok = all(tau[n] == v for n, v in known.items())
    print(f"  τ matches known values (τ2=-24, τ11=534612, …): {ok}\n")

    primes = [p for p in range(2, M) if is_prime(p)]

    # ── EXERCISE THE THEOREM, FORWARD ──────────────────────────────────────────
    print("=" * 86)
    print("  EXERCISING  fourier_determined_by_primes_genus1   (forward: primes → all coeffs)")
    print("=" * 86)

    print("\n[A] Hecke recursion at primes:  τ(p²) = τ(p)² − p^11   (k−1 = 11)")
    for p in [2, 3, 5, 7]:
        lhs = tau[p * p]
        rhs = tau[p] ** 2 - p ** 11
        print(f"    p={p:2d}:  τ(p²)={lhs:>16d}   τ(p)²−p^11={rhs:>16d}   match={lhs == rhs}")

    print("\n[B] Multiplicativity:  τ(p·q) = τ(p)·τ(q)   for distinct primes")
    for p, q in [(2, 3), (3, 5), (5, 7), (11, 13), (47, 53)]:
        lhs = tau[p * q]
        rhs = tau[p] * tau[q]
        print(f"    ({p:2d},{q:2d}):  τ(pq)={lhs:>22d}   τ(p)τ(q)={rhs:>22d}   match={lhs == rhs}")

    def reconstruct_from_primes(n: int) -> int:
        """Rebuild τ(n) using ONLY {τ(p)} + recursion + multiplicativity (the theorem)."""
        result = 1
        for p, e in factorize(n).items():
            # prime-power values from τ(p) via the rank-2 recursion
            tp = [0] * (e + 1)
            tp[0] = 1
            tp[1] = tau[p]
            for r in range(2, e + 1):
                tp[r] = tau[p] * tp[r - 1] - p ** (K - 1) * tp[r - 2]
            result *= tp[e]
        return result

    print("\n[C] Full reconstruction of τ(N) from prime values only (the theorem's content):")
    for n in [12, 360, 1000, 2491]:
        rec = reconstruct_from_primes(n)
        print(f"    N={n:<5d} factor={dict(factorize(n))}")
        print(f"          reconstructed τ(N) = {rec}")
        print(f"          direct        τ(N) = {tau[n]}      match={rec == tau[n]}")

    # ── NOW RUN IT BACKWARD AS A FACTORING TOOL ────────────────────────────────
    p0, q0 = 47, 53
    N0 = p0 * q0
    print("\n" + "=" * 86)
    print(f"  RUNNING IT BACKWARD — can a_N recover the factors of N0 = {p0}·{q0} = {N0}?")
    print("=" * 86)

    print(f"\n  The multiplicative split is genuine:")
    print(f"     τ({p0})        = {tau[p0]}")
    print(f"     τ({q0})        = {tau[q0]}")
    print(f"     τ({p0})·τ({q0}) = {tau[p0]*tau[q0]}")
    print(f"     τ({N0})       = {tau[N0]}   ← equal: {tau[p0]*tau[q0] == tau[N0]}")

    print(f"\n  WALL 1 — you cannot evaluate a_N at N without the factorization:")
    print(f"    • via multiplicativity → needs the primes of N (circular).")
    print(f"    • via the q-expansion  → needs N coefficients. For N0 that's {N0};")
    print(f"      for the 1024-bit N that is 2^1024 ≈ 10^308 terms. Infeasible.")

    big_tau = tau[N0]
    digits = len(str(abs(big_tau)))
    print(f"\n  WALL 2 — even GIVEN a_N, the equation a_N = a_p·a_q just relocates the problem:")
    print(f"    • τ({N0}) is a {digits}-digit integer; recovering τ({p0}), τ({q0}) means")
    print(f"      FACTORING that {digits}-digit integer — a LARGER factoring problem than N0.")
    print(f"    • and τ(p) → p is its own inversion: for weight 2 (elliptic curves) it is")
    print(f"      not even injective (|a_p|≤2√p, supersingular a_p=0 collisions).")
    print(f"    Net: 'factor N' is mapped to 'factor a_N', which is strictly harder.")

    print("\n" + "=" * 86)
    print("  WHAT THE THEOREM ACTUALLY IS")
    print("=" * 86)
    print("  • It is a DETERMINATION (reconstruction) theorem: primes ⟶ all coefficients.")
    print("    [C] shows it working perfectly — that is the compression / build direction.")
    print("  • It presupposes the factorization (it is indexed BY primes). Run backward it")
    print("    does not factor; it converts factoring N into factoring the bigger a_N.")
    print("  • The one place this multiplicative structure DOES drive a real factoring algo")
    print("    is Lenstra ECM: a_p = p+1−#E(F_p), and a factor falls out when #E(F_p) is")
    print("    smooth (Lenstra 1987, Ann. Math. 126). Different mechanism — and still")
    print("    sub-exponential, infeasible for a balanced 1024-bit modulus.")


if __name__ == "__main__":
    main()
