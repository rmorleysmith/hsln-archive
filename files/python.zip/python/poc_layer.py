"""Layering by tensor product: doubling the neurons.

Each "sector" is a small monic form with <= 2 zeros. One sector alone cannot place
attractors at 4 targets. Tensoring two sectors (= multiplying the forms = convolving
the DNAs) gives a product form with up to 4 zeros = the union, which covers all 4.

We train (gradient descent on the sector DNAs) to put zeros on the 4 targets and
compare a single sector vs. the layered product.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np
from jax import value_and_grad

import modular

jax.config.update("jax_enable_x64", True)

TARGETS = np.array([0.18 + 0.12j, 0.42 + 0.17j, 0.62 + 0.14j, 0.83 + 0.10j])
_TX = jnp.array([[t.real, t.imag] for t in TARGETS])


def sector(free):
    """Monic degree-2 form from 4 reals: q^2 + a1 q + a0  (<= 2 zeros)."""
    a0 = free[0] + 1j * free[2]
    a1 = free[1] + 1j * free[3]
    return jnp.array([a0, a1, 1.0 + 0j])


def coeffs_single(params):
    return sector(params)


def coeffs_layered(params):
    return jnp.convolve(sector(params[:4]), sector(params[4:]))  # product -> degree 4


def Fmag2(coeffs, xy):
    q = jnp.exp(2j * jnp.pi * (xy[0] + 1j * xy[1]))
    f = jnp.sum(coeffs * q ** jnp.arange(coeffs.shape[0]))
    return jnp.real(f * jnp.conj(f))


def make_loss(coeff_fn):
    def loss(params):
        c = coeff_fn(params)
        return jnp.sum(jax.vmap(lambda t: Fmag2(c, t))(_TX)) + 1e-4 * jnp.sum(params ** 2)
    return loss


def train(coeff_fn, nparams, steps=800, lr=0.02, seed=0):
    rng = np.random.default_rng(seed)
    p = jnp.array(0.3 * rng.standard_normal(nparams))
    lg = jax.jit(value_and_grad(make_loss(coeff_fn)))
    m = jnp.zeros_like(p); v = jnp.zeros_like(p)
    b1, b2, eps = 0.9, 0.999, 1e-8
    hist = []
    for t in range(1, steps + 1):
        L, g = lg(p)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        p = p - lr * (m / (1 - b1 ** t)) / (jnp.sqrt(v / (1 - b2 ** t)) + eps)
        hist.append(float(L))
    return p, hist


def residuals(coeff_fn, p):
    c = np.array(coeff_fn(p))
    return np.array([float(Fmag2(jnp.array(c), t)) ** 0.5 for t in _TX])


def visualize(seed=0):
    import matplotlib.pyplot as plt
    from pathlib import Path
    import style

    ps, hs = train(coeffs_single, 4, seed=seed)
    pl, hl = train(coeffs_layered, 8, seed=seed)
    cs = np.array(coeffs_single(ps))
    cl = np.array(coeffs_layered(pl))
    zs = modular.qpoly_zeros(cs)
    zl = modular.qpoly_zeros(cl)
    rs = residuals(coeffs_single, ps)
    rl = residuals(coeffs_layered, pl)

    fig, ax = plt.subplots(1, 3, figsize=(16, 5.0), gridspec_kw={"width_ratios": [1, 1, 1]})
    for a, (z, title, n) in zip(ax[:2], [(zs, "1 sector  (≤ 2 neurons)", len(zs)),
                                         (zl, "2 sectors tensored  (≤ 4 neurons)", len(zl))]):
        a.set_facecolor("#0b0b14")
        a.plot(TARGETS.real, TARGETS.imag, "*", color=style.ACCENT, ms=22, mec="white",
               mew=0.9, zorder=4, label="targets")
        a.plot(z.real, z.imag, "o", color="#46f0d0", ms=12, mfc="none", mew=2.2,
               zorder=5, label="learned zeros")
        a.set_xlim(0, 1); a.set_ylim(0.02, 0.35)
        a.set_xlabel(r"Re $\tau$"); a.set_title(f"{title}: {n} zeros", fontsize=12)
        a.legend(loc="upper right", fontsize=8, framealpha=0.3)
    ax[0].set_ylabel(r"Im $\tau$")

    x = np.arange(4)
    ax[2].bar(x - 0.18, rs, 0.34, color="#ff3b6b", label="1 sector")
    ax[2].bar(x + 0.18, rl, 0.34, color="#46f0d0", label="2 tensored")
    ax[2].set_xticks(x); ax[2].set_xticklabels([f"T{i+1}" for i in range(4)])
    ax[2].set_ylabel(r"distance $|F|$ at target  (0 = neuron placed)")
    ax[2].set_title("coverage of the 4 targets", fontsize=12)
    ax[2].legend(fontsize=9, framealpha=0.3)

    fig.suptitle("Layering = tensor product: one small sector covers ~2 targets; "
                 "tensoring two covers all 4 (zeros union, DNA convolves)", fontsize=13, y=1.02)
    out = Path(__file__).parent / "figures" / "17_poc_layering.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"single residuals {np.round(rs,3)}  (covers {(rs<0.05).sum()}/4)")
    print(f"layered residuals {np.round(rl,3)}  (covers {(rl<0.05).sum()}/4)")
    print(f"wrote {out}")


if __name__ == "__main__":
    visualize()
