"""Does the HSLN shortcut grokking? Test on (a+b) mod n.

Grokking (Power et al. 2022) on modular arithmetic: a network memorises the train set
first, then -- much later -- suddenly generalises, and the grokked solution turns out to
be a Fourier/circular representation (numbers as e^{2*pi*i*k/n}, addition = rotation;
Nanda et al. 2023). That representation is the HSLN's NATIVE state.

So we compare two models on (a+b) mod n with a 50/50 train/test split:
  A. circular-phase model (HSLN-native): one learnable PHASE per symbol; combine a,b by
     ADDING phases (= rotation); decode by nearest symbol-phase. Only n+1 params -> it
     CANNOT memorise n^2 pairs, only fit the global rule -> train and test rise together
     (no grokking gap), and the phases emerge as roots of unity.
  B. control (generic): a learnable embedding + MLP with capacity to memorise -> the
     classic train>>test gap.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp
from jax import value_and_grad, jit
from jax.tree_util import tree_map

N = 11
A_, B_ = np.meshgrid(np.arange(N), np.arange(N))
PAIRS = np.stack([A_.ravel(), B_.ravel()], 1)
LABELS = (PAIRS[:, 0] + PAIRS[:, 1]) % N
_rng = np.random.default_rng(0)
_perm = _rng.permutation(len(PAIRS))
NTR = len(PAIRS) // 2
TR, TE = jnp.asarray(_perm[:NTR]), jnp.asarray(_perm[NTR:])
PAIRS_J, LABELS_J = jnp.asarray(PAIRS), jnp.asarray(LABELS)


# --- Adam over a pytree --- #
def adam_init(p):
    return {"m": tree_map(jnp.zeros_like, p), "v": tree_map(jnp.zeros_like, p), "t": 0}


def adam_step(p, g, st, lr):
    t = st["t"] + 1
    m = tree_map(lambda m, g: 0.9 * m + 0.1 * g, st["m"], g)
    v = tree_map(lambda v, g: 0.999 * v + 0.001 * g * g, st["v"], g)
    mh = tree_map(lambda m: m / (1 - 0.9 ** t), m)
    vh = tree_map(lambda v: v / (1 - 0.999 ** t), v)
    p = tree_map(lambda p, m, v: p - lr * m / (jnp.sqrt(v) + 1e-8), p, mh, vh)
    return p, {"m": m, "v": v, "t": t}


# --- Model A: circular phases (HSLN-native) --- #
def A_logits(p, idx):
    phi = p["phi"]
    a, b = PAIRS_J[idx, 0], PAIRS_J[idx, 1]
    psi = phi[a] + phi[b]
    return p["kappa"] * jnp.cos(psi[:, None] - phi[None, :])


def A_loss(p, idx):
    z = A_logits(p, idx)
    lp = z - jax.scipy.special.logsumexp(z, 1, keepdims=True)
    return -lp[jnp.arange(idx.shape[0]), LABELS_J[idx]].mean()


# --- Model B: embedding + MLP (control) --- #
def B_logits(p, idx):
    a, b = PAIRS_J[idx, 0], PAIRS_J[idx, 1]
    h = jnp.concatenate([p["E"][a], p["E"][b]], 1)
    h = jnp.tanh(h @ p["W1"] + p["b1"])
    return h @ p["W2"] + p["b2"]


def B_loss(p, idx):
    z = B_logits(p, idx)
    lp = z - jax.scipy.special.logsumexp(z, 1, keepdims=True)
    ce = -lp[jnp.arange(idx.shape[0]), LABELS_J[idx]].mean()
    wd = 1e-3 * sum(jnp.sum(w ** 2) for w in (p["W1"], p["W2"]))
    return ce + wd


def acc(logits_fn, p, idx):
    return float((jnp.argmax(logits_fn(p, idx), 1) == LABELS_J[idx]).mean())


def train(loss_fn, logits_fn, p0, steps, lr):
    lg = jit(value_and_grad(loss_fn))
    p, st = p0, adam_init(p0)
    hist = []
    for s in range(steps + 1):
        _, g = lg(p, TR)
        p, st = adam_step(p, g, st, lr)
        if s % 100 == 0:
            hist.append((s, acc(logits_fn, p, TR), acc(logits_fn, p, TE)))
    return p, np.array(hist)


def run(make_fig=True):
    rng = np.random.default_rng(1)
    pA = {"phi": jnp.asarray(rng.uniform(0, 2 * np.pi, N)), "kappa": jnp.asarray(3.0)}
    pA, hA = train(A_loss, A_logits, pA, steps=3000, lr=0.05)
    print(f"Model A (circular): final train {hA[-1,1]:.3f}  test {hA[-1,2]:.3f}")

    d, h = 24, 96
    pB = {"E": jnp.asarray(rng.standard_normal((N, d)) * 0.3),
          "W1": jnp.asarray(rng.standard_normal((2 * d, h)) * 0.1), "b1": jnp.zeros(h),
          "W2": jnp.asarray(rng.standard_normal((h, N)) * 0.1), "b2": jnp.zeros(N)}
    pB, hB = train(B_loss, B_logits, pB, steps=6000, lr=0.01)
    print(f"Model B (control):  final train {hB[-1,1]:.3f}  test {hB[-1,2]:.3f}")

    if make_fig:
        _figure(hA, hB, np.array(pA["phi"]))
    return hA, hB


def _figure(hA, hB, phi):
    import matplotlib.pyplot as plt
    import style  # noqa: F401

    TEAL, GOLD, NEURON, GREEN = "#46f0d0", "#ffd166", "#ff3b6b", "#7CFC8A"

    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))

    a = ax[0]
    a.plot(hA[:, 0], hA[:, 1], color=TEAL, lw=2, label="train")
    a.plot(hA[:, 0], hA[:, 2], color=GOLD, lw=2, ls="--", label="test (held-out)")
    a.set_ylim(0, 1.05); a.set_xlabel("step"); a.set_ylabel("accuracy")
    a.set_title("HSLN circular model:\ntrain & test rise together — no grok gap", fontsize=12)
    a.legend(loc="lower right", fontsize=9, framealpha=0.3)

    b = ax[1]
    b.plot(hB[:, 0], hB[:, 1], color=TEAL, lw=2, label="train")
    b.plot(hB[:, 0], hB[:, 2], color=GOLD, lw=2, ls="--", label="test (held-out)")
    b.set_ylim(0, 1.05); b.set_xlabel("step"); b.set_ylabel("accuracy")
    b.set_title("generic control:\nmemorises first — train ≫ test (the grok gap)", fontsize=12)
    b.legend(loc="lower right", fontsize=9, framealpha=0.3)

    c = ax[2]
    c.set_facecolor("#0b0b14")
    th = np.linspace(0, 2 * np.pi, 200)
    c.plot(np.cos(th), np.sin(th), color="#333", lw=1)
    order = np.argsort(phi % (2 * np.pi))
    pts = np.stack([np.cos(phi), np.sin(phi)], 1)
    c.plot(pts[order, 0], pts[order, 1], color=GREEN, lw=1, alpha=0.5)
    for k in range(N):
        c.plot(pts[k, 0], pts[k, 1], "o", color=NEURON, ms=12, mec="white", mew=0.6)
        c.annotate(str(k), pts[k], textcoords="offset points", xytext=(7, 4),
                   color=NEURON, fontsize=9)
    c.set_aspect("equal"); c.set_xlim(-1.3, 1.3); c.set_ylim(-1.3, 1.3)
    c.set_title("the rep it learned: phases φ(k)\nemerge as roots of unity", fontsize=12)

    fig.suptitle("Shortcutting grokking on (a+b) mod 11: the HSLN's native circular rep "
                 "generalises immediately; a generic net must memorise then grok",
                 fontsize=13, y=1.0)
    out = Path(__file__).parent / "figures" / "30_grok.png"
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    run()
