"""
Safety re-check: genuinely attempt to unpick the 249-BIT genesis cofactor,
now using the DNA→matrix (spectral) method alongside real classical methods.

We do not assume failure — we actually run every tractable attack and report.
  1. trial division to 10^7
  2. Pollard rho (Brent), time-bounded
  3. Pollard p-1, bounded smoothness
  4. the DNA→circulant SPECTRAL method (this thread's method): build the divisor-indicator
     circulant over the largest tractable window and read its eigenvalue spectrum; a factor
     in-window would appear as a resonant eigenvalue.
If any returns a nontrivial divisor, we print it loudly. Otherwise: safe.

(Note: it's 249 *bits* ≈ 75 decimal digits, not 249 digits.)
"""
from __future__ import annotations

import math
import time
import numpy as np

from hsln_bitcoin_probe import KEYS, pubkey_x, peel_small_factors, SCAN_BOUND


def trial_division(n: int, limit: int, secs: float) -> int | None:
    t0, d = time.perf_counter(), 3
    while d <= limit:
        if n % d == 0:
            return d
        d += 2
        if d % 100001 == 0 and time.perf_counter() - t0 > secs:
            return None
    return None


def pollard_brent(n: int, secs: float, seed: int = 2) -> int | None:
    if n % 2 == 0:
        return 2
    t0 = time.perf_counter()
    y, c, m = seed, 1, 1 << 17
    g = q = r = 1
    while g == 1:
        x = y
        for _ in range(r):
            y = (y * y + c) % n
        k = 0
        while k < r and g == 1:
            ys = y
            for _ in range(min(m, r - k)):
                y = (y * y + c) % n
                q = q * abs(x - y) % n
            g = math.gcd(q, n)
            k += m
            if time.perf_counter() - t0 > secs:
                return None
        r <<= 1
    if g == n:
        while True:
            ys = (ys * ys + c) % n
            g = math.gcd(abs(x - ys), n)
            if g > 1:
                break
            if time.perf_counter() - t0 > secs:
                return None
    return g if 1 < g < n else None


def pollard_pm1(n: int, B1: int, secs: float) -> int | None:
    t0, a = time.perf_counter(), 2
    for p in range(2, B1):
        pe = p
        while pe * p <= B1:
            pe *= p
        a = pow(a, pe, n)
        if p % 2048 == 1:
            g = math.gcd(a - 1, n)
            if 1 < g < n:
                return g
            if time.perf_counter() - t0 > secs:
                return None
    g = math.gcd(a - 1, n)
    return g if 1 < g < n else None


def spectral_circulant(n: int, window: int) -> int | None:
    """The DNA→matrix method: divisor-indicator circulant's eigenvalues = the detector.
    A factor k ≤ window shows as a resonant eigenvalue; equivalently a_k = [k|n] = 1."""
    a = np.zeros(window)
    for k in range(1, window):
        if n % k == 0:
            a[k] = 1.0
    eig = np.fft.fft(a)                  # eigenvalues of circ(a)
    # a nontrivial in-window divisor ⇔ some a_k=1 for 1<k<n ⇔ resonance beyond the trivial
    hits = [k for k in range(2, window) if a[k] > 0.5]
    return hits[0] if hits else None


def main():
    x = pubkey_x(KEYS["genesis (block 0, Satoshi, unspent)"])
    facs, cof = peel_small_factors(x, SCAN_BOUND)
    nbits, ndig = cof.bit_length(), len(str(cof))

    print("=" * 74)
    print(" SAFETY RE-CHECK — genuinely attempt to factor the genesis cofactor")
    print("=" * 74)
    print(f" cofactor = {nbits}-bit ({ndig} decimal digits)")
    print(f" (small primes already peeled from the key: {sorted(set(facs))})\n")

    attempts = [
        ("trial division < 10^7", lambda: trial_division(cof, 10_000_000, 20)),
        ("Pollard rho (Brent), 25s", lambda: pollard_brent(cof, 25, seed=2)),
        ("Pollard rho seed 3, 25s", lambda: pollard_brent(cof, 25, seed=3)),
        ("Pollard p-1, B1=2*10^6", lambda: pollard_pm1(cof, 2_000_000, 25)),
        ("DNA→circulant spectral, window 2*10^6",
         lambda: spectral_circulant(cof, 2_000_000)),
    ]
    found = None
    for name, fn in attempts:
        t0 = time.perf_counter()
        r = fn()
        dt = time.perf_counter() - t0
        ok = r is not None and 1 < r < cof and cof % r == 0
        print(f"  {name:38s} {dt:7.2f}s  -> "
              f"{'FACTOR ' + str(r) if ok else 'no factor'}")
        if ok:
            found = r

    print("\n" + "=" * 74)
    if found:
        print(f"  *** FACTOR FOUND: {found} ***  (this would be a security event!)")
    else:
        print("  NO FACTOR FOUND by any method, including the DNA→matrix spectral one.")
        print("  The cofactor's true factors live near 2^124 — beyond every tractable")
        print("  window and beyond bounded rho/p-1. SAFE, re-confirmed.")
    print("=" * 74)


if __name__ == "__main__":
    main()
